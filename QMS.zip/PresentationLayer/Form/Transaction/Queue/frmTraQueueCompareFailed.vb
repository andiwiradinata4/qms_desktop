﻿Public Class frmTraQueueCompareFailed

#Region "Property Handle"

    Private bolIsSave As Boolean = False
    Private strCompanyID As String, strLocationID As String
    Private clsLPRGet As New VO.LPRGet
    Private clsDataDet As New VO.QueueDet
    Private intCount As Integer = 0
    Private Const cSave = 0, cClose = 1

    Public WriteOnly Property pubCompanyID As String
        Set(value As String)
            strCompanyID = value
        End Set
    End Property

    Public WriteOnly Property pubLocationID As String
        Set(value As String)
            strLocationID = value
        End Set
    End Property

    Public WriteOnly Property pubLPRGet As VO.LPRGet
        Set(value As VO.LPRGet)
            clsLPRGet = value
        End Set
    End Property

    Public WriteOnly Property pubData As VO.QueueDet
        Set(value As VO.QueueDet)
            clsDataDet = value
        End Set
    End Property

    Public ReadOnly Property pubIsSave As Boolean
        Get
            Return bolIsSave
        End Get
    End Property

#End Region

#Region "Function Handle"

    Private Sub prvFillComboStation()
        Dim dtData As New DataTable
        Try
            dtData = BL.Station.ListData
            UI.usForm.FillComboBox(cboStation, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Station")
        End Try
    End Sub

    Private Sub prvFillComboSubStation()
        Dim dtData As New DataTable
        Try
            dtData = BL.SubStation.ListData(strCompanyID, strLocationID, cboStation.SelectedValue, VO.SubStation.FilterIsLinkedStorage.All)
            UI.usForm.FillComboBox(cboSubStation, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Substation")
        End Try
    End Sub

    Private Sub prvFillForm()
        Try
            prvFillComboStation()
            prvFillComboSubStation()

            '# Queue Detail
            txtID.Text = clsDataDet.QueueID
            txtPlatNumber.Text = clsDataDet.PlatNumber
            txtIdx.Value = clsDataDet.Idx
            cboStation.SelectedValue = clsDataDet.StationID
            cboSubStation.SelectedValue = clsDataDet.SubStationID

            '# LPR Detail
            txtIDLPR.Text = clsLPRGet.Id
            txtWBIDLPR.Text = clsLPRGet.WbId
            txtGarduIDLPR.Text = clsLPRGet.GarduId
            txtTypeLPR.Text = clsLPRGet.Tipe
            txtPlatNumberLPR.Text = clsLPRGet.PlatNo
            dtpCaptureDateLPR.Value = clsLPRGet.CaptureDate
            txtMessageLPR.Text = clsLPRGet.Message
            chkStatusLPR.Checked = clsLPRGet.Status
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSave()
        If txtPlatNumberAcknowledge.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Mohon isi nomor plat yang terdapat didetil penyesuaian")
            txtPlatNumberAcknowledge.Focus()
            Exit Sub
        ElseIf txtRemarks.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Keterangan wajib diisi")
            txtRemarks.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Simpan data ini?") Then Exit Sub

        If txtPlatNumber.Text.Trim <> txtPlatNumberAcknowledge.Text.Trim Then
            If Not UI.usForm.frmAskQuestion("Nomor Plat yang terdapat di Detil Antrian berbeda dengan Nomor Plat yang terdapat di Detil Penyesuaian, Lanjutkan proses penyimpanan?") Then txtPlatNumberAcknowledge.Focus() : Exit Sub
        End If

        '# Request
        clsDataDet.StationName = cboStation.Text.Trim
        clsDataDet.SubStationName = cboSubStation.Text.Trim
        clsDataDet.PlatNumberAcknowledge = txtPlatNumberAcknowledge.Text.Trim
        clsDataDet.Remarks = txtRemarks.Text.Trim
        clsDataDet.IsRequested = True
        clsDataDet.LogBy = UI.usUserApp.UserID

        Try
            Dim bolAcknowledge As Boolean = BL.LPRHistory.UpdateAcknowledgePlatNumberAndRemarks(clsLPRGet.InternalID, txtPlatNumberAcknowledge.Text.Trim, txtRemarks.Text.Trim)
            If Not bolAcknowledge Then Return
            If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Request, clsDataDet) Then
                '# Done
                If clsDataDet.StationID = VO.DefaultServer.AutoDoneStationID Then
                    clsDataDet.Remarks = txtRemarks.Text.Trim
                    clsDataDet.IsDone = True
                    clsDataDet.LogBy = UI.usUserApp.UserID
                    BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Done, clsDataDet)
                End If
                UI.usForm.frmMessageBox("Simpan Data Berhasil.")
                bolIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvReGetVer2()
        Me.Cursor = Cursors.WaitCursor
        Try
            clsLPRGet = BL.Queue.LPRReGet(txtWBIDLPR.Text.Trim, False, clsDataDet.ID, txtPlatNumber.Text.Trim)
            If Not clsLPRGet.Status Then UI.usForm.frmMessageBox("REGET data LPR fail!" & vbNewLine & clsLPRGet.Message, "REGET")

            intCount += 1
            txtIDLPR.Text = clsLPRGet.Id
            txtGarduIDLPR.Text = clsLPRGet.GarduId
            txtTypeLPR.Text = clsLPRGet.Tipe
            txtPlatNumberLPR.Text = clsLPRGet.PlatNo
            dtpCaptureDateLPR.Value = clsLPRGet.CaptureDate
            txtMessageLPR.Text = clsLPRGet.Message
            btnReGet.Text = "RE-GET " & intCount & "x"

            If intCount >= 2 And txtPlatNumber.Text.Trim <> clsLPRGet.PlatNo.Trim Then
                txtPlatNumberAcknowledge.BackColor = Color.White
                txtPlatNumberAcknowledge.ReadOnly = False
            End If

            If txtPlatNumber.Text.Trim = clsLPRGet.PlatNo.Trim Then txtPlatNumberAcknowledge.Text = clsLPRGet.PlatNo.Trim
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            Me.Cursor = Cursors.Default
        End Try
    End Sub

#End Region
    
#Region "Form Handle"

    Private Sub frmTraQueueCompareFailed_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmTraQueueCompareFailed_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvFillForm()
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub btnReGet_Click(sender As Object, e As EventArgs) Handles btnReGet.Click
        prvReGetVer2() 'prvReGet()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Simpan" : prvSave()
            Case "Tutup" : Me.Close()
        End Select
    End Sub

#End Region
   
End Class