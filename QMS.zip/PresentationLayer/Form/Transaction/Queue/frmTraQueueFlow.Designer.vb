﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueFlow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkIsRepeat = New DevExpress.XtraEditors.CheckEdit()
        Me.chkIsFreePass = New DevExpress.XtraEditors.CheckEdit()
        Me.cboQueueType = New QMSLib.usComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtQueueNumber = New QMS.usTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPlatNumber = New QMS.usTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTicketParkingID = New QMS.usTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtRFID = New QMS.usTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSPBNumber = New QMS.usTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtID = New QMS.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.grdQueueFlow = New DevExpress.XtraGrid.GridControl()
        Me.grdQueueFlowView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.ToolBarDetail = New QMS.usToolBar()
        Me.BarUp = New System.Windows.Forms.ToolBarButton()
        Me.BarDown = New System.Windows.Forms.ToolBarButton()
        Me.BarSep1 = New System.Windows.Forms.ToolBarButton()
        Me.BarAdd = New System.Windows.Forms.ToolBarButton()
        Me.BarEdit = New System.Windows.Forms.ToolBarButton()
        Me.BarDelete = New System.Windows.Forms.ToolBarButton()
        Me.BarSep2 = New System.Windows.Forms.ToolBarButton()
        Me.BarRequest = New System.Windows.Forms.ToolBarButton()
        Me.BarCancelRequest = New System.Windows.Forms.ToolBarButton()
        Me.BarSep3 = New System.Windows.Forms.ToolBarButton()
        Me.BarDone = New System.Windows.Forms.ToolBarButton()
        Me.BarCancelDone = New System.Windows.Forms.ToolBarButton()
        Me.BarSep4 = New System.Windows.Forms.ToolBarButton()
        Me.BarRefresh = New System.Windows.Forms.ToolBarButton()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.chkIsRepeat.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkIsFreePass.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdQueueFlow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdQueueFlowView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.CadetBlue
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(862, 22)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "« Queue Info"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GridView1
        '
        Me.GridView1.Name = "GridView1"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.CadetBlue
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(0, 144)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(862, 22)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "« Queue Flow"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.chkIsRepeat)
        Me.Panel1.Controls.Add(Me.chkIsFreePass)
        Me.Panel1.Controls.Add(Me.cboQueueType)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.txtQueueNumber)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.txtPlatNumber)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.txtTicketParkingID)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.txtRFID)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.txtSPBNumber)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.txtID)
        Me.Panel1.Controls.Add(Me.lblID)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 22)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(862, 122)
        Me.Panel1.TabIndex = 2
        '
        'chkIsRepeat
        '
        Me.chkIsRepeat.Enabled = False
        Me.chkIsRepeat.Location = New System.Drawing.Point(363, 12)
        Me.chkIsRepeat.Name = "chkIsRepeat"
        Me.chkIsRepeat.Properties.Caption = "Repeat?"
        Me.chkIsRepeat.Size = New System.Drawing.Size(75, 19)
        Me.chkIsRepeat.TabIndex = 2
        '
        'chkIsFreePass
        '
        Me.chkIsFreePass.Enabled = False
        Me.chkIsFreePass.Location = New System.Drawing.Point(278, 12)
        Me.chkIsFreePass.Name = "chkIsFreePass"
        Me.chkIsFreePass.Properties.Caption = "Free Pass?"
        Me.chkIsFreePass.Size = New System.Drawing.Size(75, 19)
        Me.chkIsFreePass.TabIndex = 1
        '
        'cboQueueType
        '
        Me.cboQueueType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQueueType.Enabled = False
        Me.cboQueueType.FormattingEnabled = True
        Me.cboQueueType.Location = New System.Drawing.Point(107, 82)
        Me.cboQueueType.Name = "cboQueueType"
        Me.cboQueueType.Size = New System.Drawing.Size(152, 21)
        Me.cboQueueType.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(30, 86)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(66, 13)
        Me.Label13.TabIndex = 172
        Me.Label13.Text = "Queue Type"
        '
        'txtQueueNumber
        '
        Me.txtQueueNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtQueueNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtQueueNumber.Location = New System.Drawing.Point(615, 59)
        Me.txtQueueNumber.MaxLength = 10
        Me.txtQueueNumber.Name = "txtQueueNumber"
        Me.txtQueueNumber.ReadOnly = True
        Me.txtQueueNumber.Size = New System.Drawing.Size(90, 21)
        Me.txtQueueNumber.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(529, 62)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 13)
        Me.Label7.TabIndex = 134
        Me.Label7.Text = "Queue Number"
        '
        'txtPlatNumber
        '
        Me.txtPlatNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtPlatNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlatNumber.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.txtPlatNumber.Location = New System.Drawing.Point(615, 35)
        Me.txtPlatNumber.MaxLength = 10
        Me.txtPlatNumber.Name = "txtPlatNumber"
        Me.txtPlatNumber.ReadOnly = True
        Me.txtPlatNumber.Size = New System.Drawing.Size(90, 21)
        Me.txtPlatNumber.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(543, 38)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 132
        Me.Label3.Text = "Plat Number"
        '
        'txtTicketParkingID
        '
        Me.txtTicketParkingID.BackColor = System.Drawing.Color.LightYellow
        Me.txtTicketParkingID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTicketParkingID.Location = New System.Drawing.Point(615, 12)
        Me.txtTicketParkingID.Name = "txtTicketParkingID"
        Me.txtTicketParkingID.ReadOnly = True
        Me.txtTicketParkingID.Size = New System.Drawing.Size(90, 21)
        Me.txtTicketParkingID.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(521, 15)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(87, 13)
        Me.Label4.TabIndex = 131
        Me.Label4.Text = "Ticket Parking ID"
        '
        'txtRFID
        '
        Me.txtRFID.BackColor = System.Drawing.Color.LightYellow
        Me.txtRFID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRFID.Location = New System.Drawing.Point(107, 58)
        Me.txtRFID.MaxLength = 20
        Me.txtRFID.Name = "txtRFID"
        Me.txtRFID.ReadOnly = True
        Me.txtRFID.Size = New System.Drawing.Size(331, 21)
        Me.txtRFID.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(30, 62)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 128
        Me.Label6.Text = "RFID"
        '
        'txtSPBNumber
        '
        Me.txtSPBNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtSPBNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSPBNumber.Location = New System.Drawing.Point(107, 35)
        Me.txtSPBNumber.MaxLength = 150
        Me.txtSPBNumber.Name = "txtSPBNumber"
        Me.txtSPBNumber.ReadOnly = True
        Me.txtSPBNumber.Size = New System.Drawing.Size(331, 21)
        Me.txtSPBNumber.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(30, 38)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 13)
        Me.Label5.TabIndex = 127
        Me.Label5.Text = "SPB Number"
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Location = New System.Drawing.Point(107, 12)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(152, 21)
        Me.txtID.TabIndex = 0
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(30, 15)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(18, 13)
        Me.lblID.TabIndex = 120
        Me.lblID.Text = "ID"
        '
        'grdQueueFlow
        '
        Me.grdQueueFlow.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdQueueFlow.Location = New System.Drawing.Point(0, 194)
        Me.grdQueueFlow.MainView = Me.grdQueueFlowView
        Me.grdQueueFlow.Margin = New System.Windows.Forms.Padding(0)
        Me.grdQueueFlow.Name = "grdQueueFlow"
        Me.grdQueueFlow.Size = New System.Drawing.Size(862, 317)
        Me.grdQueueFlow.TabIndex = 5
        Me.grdQueueFlow.UseEmbeddedNavigator = True
        Me.grdQueueFlow.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdQueueFlowView})
        '
        'grdQueueFlowView
        '
        Me.grdQueueFlowView.GridControl = Me.grdQueueFlow
        Me.grdQueueFlowView.Name = "grdQueueFlowView"
        Me.grdQueueFlowView.OptionsCustomization.AllowColumnMoving = False
        Me.grdQueueFlowView.OptionsCustomization.AllowGroup = False
        Me.grdQueueFlowView.OptionsView.ColumnAutoWidth = False
        Me.grdQueueFlowView.OptionsView.ShowAutoFilterRow = True
        Me.grdQueueFlowView.OptionsView.ShowGroupPanel = False
        '
        'ToolBarDetail
        '
        Me.ToolBarDetail.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBarDetail.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarUp, Me.BarDown, Me.BarSep1, Me.BarAdd, Me.BarEdit, Me.BarDelete, Me.BarSep2, Me.BarRequest, Me.BarCancelRequest, Me.BarSep3, Me.BarDone, Me.BarCancelDone, Me.BarSep4, Me.BarRefresh})
        Me.ToolBarDetail.DropDownArrows = True
        Me.ToolBarDetail.Location = New System.Drawing.Point(0, 166)
        Me.ToolBarDetail.Name = "ToolBarDetail"
        Me.ToolBarDetail.ShowToolTips = True
        Me.ToolBarDetail.Size = New System.Drawing.Size(862, 28)
        Me.ToolBarDetail.TabIndex = 4
        Me.ToolBarDetail.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarUp
        '
        Me.BarUp.Name = "BarUp"
        Me.BarUp.Tag = "Up"
        Me.BarUp.Text = "Up"
        '
        'BarDown
        '
        Me.BarDown.Name = "BarDown"
        Me.BarDown.Tag = "Down"
        Me.BarDown.Text = "Down"
        '
        'BarSep1
        '
        Me.BarSep1.Name = "BarSep1"
        Me.BarSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarAdd
        '
        Me.BarAdd.Name = "BarAdd"
        Me.BarAdd.Tag = "Add"
        Me.BarAdd.Text = "Add"
        '
        'BarEdit
        '
        Me.BarEdit.Name = "BarEdit"
        Me.BarEdit.Tag = "Edit"
        Me.BarEdit.Text = "Edit"
        '
        'BarDelete
        '
        Me.BarDelete.Name = "BarDelete"
        Me.BarDelete.Tag = "Delete"
        Me.BarDelete.Text = "Delete"
        '
        'BarSep2
        '
        Me.BarSep2.Name = "BarSep2"
        Me.BarSep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarRequest
        '
        Me.BarRequest.Name = "BarRequest"
        Me.BarRequest.Tag = "Submit"
        Me.BarRequest.Text = "Request"
        '
        'BarCancelRequest
        '
        Me.BarCancelRequest.Name = "BarCancelRequest"
        Me.BarCancelRequest.Tag = "Unapproved"
        Me.BarCancelRequest.Text = "Cancel Request"
        '
        'BarSep3
        '
        Me.BarSep3.Name = "BarSep3"
        Me.BarSep3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarDone
        '
        Me.BarDone.Name = "BarDone"
        Me.BarDone.Tag = "Checked"
        Me.BarDone.Text = "Done"
        '
        'BarCancelDone
        '
        Me.BarCancelDone.Name = "BarCancelDone"
        Me.BarCancelDone.Tag = "Cancel"
        Me.BarCancelDone.Text = "Cancel Done"
        '
        'BarSep4
        '
        Me.BarSep4.Name = "BarSep4"
        Me.BarSep4.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarRefresh
        '
        Me.BarRefresh.Name = "BarRefresh"
        Me.BarRefresh.Tag = "Refresh"
        Me.BarRefresh.Text = "Refresh"
        '
        'frmTraQueueFlow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(862, 511)
        Me.Controls.Add(Me.grdQueueFlow)
        Me.Controls.Add(Me.ToolBarDetail)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTraQueueFlow"
        Me.Text = "Queue"
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.chkIsRepeat.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkIsFreePass.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdQueueFlow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdQueueFlowView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtID As QMS.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtRFID As QMS.usTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSPBNumber As QMS.usTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPlatNumber As QMS.usTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTicketParkingID As QMS.usTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtQueueNumber As QMS.usTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboQueueType As QMSLib.usComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents chkIsRepeat As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkIsFreePass As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents grdQueueFlow As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdQueueFlowView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents ToolBarDetail As QMS.usToolBar
    Friend WithEvents BarAdd As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarEdit As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarDelete As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarRequest As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarCancelRequest As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarDone As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarCancelDone As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarRefresh As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarUp As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarDown As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep4 As System.Windows.Forms.ToolBarButton
End Class
