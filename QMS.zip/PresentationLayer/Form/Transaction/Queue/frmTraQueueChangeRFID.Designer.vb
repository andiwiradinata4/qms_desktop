﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueChangeRFID
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.txtRemarks = New QMS.usTextBox()
        Me.txtNewRFID = New QMS.usTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtRFID = New QMS.usTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDriverFullName = New QMS.usTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDriverID = New QMS.usTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpQueueDate = New System.Windows.Forms.DateTimePicker()
        Me.txtID = New QMS.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.pnlMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(528, 22)
        Me.lblInfo.TabIndex = 0
        Me.lblInfo.Text = "« Change RFID"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlMain
        '
        Me.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlMain.Controls.Add(Me.lblRemarks)
        Me.pnlMain.Controls.Add(Me.txtRemarks)
        Me.pnlMain.Controls.Add(Me.txtNewRFID)
        Me.pnlMain.Controls.Add(Me.Label2)
        Me.pnlMain.Controls.Add(Me.txtRFID)
        Me.pnlMain.Controls.Add(Me.Label6)
        Me.pnlMain.Controls.Add(Me.txtDriverFullName)
        Me.pnlMain.Controls.Add(Me.Label4)
        Me.pnlMain.Controls.Add(Me.txtDriverID)
        Me.pnlMain.Controls.Add(Me.Label1)
        Me.pnlMain.Controls.Add(Me.dtpQueueDate)
        Me.pnlMain.Controls.Add(Me.txtID)
        Me.pnlMain.Controls.Add(Me.lblID)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMain.Location = New System.Drawing.Point(0, 22)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(528, 303)
        Me.pnlMain.TabIndex = 1
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.BackColor = System.Drawing.Color.Transparent
        Me.lblRemarks.ForeColor = System.Drawing.Color.Black
        Me.lblRemarks.Location = New System.Drawing.Point(18, 168)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(48, 13)
        Me.lblRemarks.TabIndex = 134
        Me.lblRemarks.Text = "Remarks"
        '
        'txtRemarks
        '
        Me.txtRemarks.BackColor = System.Drawing.Color.White
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Location = New System.Drawing.Point(98, 165)
        Me.txtRemarks.MaxLength = 250
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(393, 60)
        Me.txtRemarks.TabIndex = 6
        '
        'txtNewRFID
        '
        Me.txtNewRFID.BackColor = System.Drawing.Color.White
        Me.txtNewRFID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNewRFID.Location = New System.Drawing.Point(98, 139)
        Me.txtNewRFID.MaxLength = 20
        Me.txtNewRFID.Name = "txtNewRFID"
        Me.txtNewRFID.Size = New System.Drawing.Size(393, 21)
        Me.txtNewRFID.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(18, 144)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 132
        Me.Label2.Text = "New RFID"
        '
        'txtRFID
        '
        Me.txtRFID.BackColor = System.Drawing.Color.AliceBlue
        Me.txtRFID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRFID.Location = New System.Drawing.Point(98, 113)
        Me.txtRFID.MaxLength = 20
        Me.txtRFID.Name = "txtRFID"
        Me.txtRFID.ReadOnly = True
        Me.txtRFID.Size = New System.Drawing.Size(393, 21)
        Me.txtRFID.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(18, 118)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 130
        Me.Label6.Text = "RFID"
        '
        'txtDriverFullName
        '
        Me.txtDriverFullName.BackColor = System.Drawing.Color.AliceBlue
        Me.txtDriverFullName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDriverFullName.Location = New System.Drawing.Point(98, 87)
        Me.txtDriverFullName.MaxLength = 250
        Me.txtDriverFullName.Name = "txtDriverFullName"
        Me.txtDriverFullName.ReadOnly = True
        Me.txtDriverFullName.Size = New System.Drawing.Size(393, 21)
        Me.txtDriverFullName.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(18, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 128
        Me.Label4.Text = "Driver"
        '
        'txtDriverID
        '
        Me.txtDriverID.BackColor = System.Drawing.Color.AliceBlue
        Me.txtDriverID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDriverID.Location = New System.Drawing.Point(98, 67)
        Me.txtDriverID.MaxLength = 250
        Me.txtDriverID.Name = "txtDriverID"
        Me.txtDriverID.ReadOnly = True
        Me.txtDriverID.Size = New System.Drawing.Size(152, 21)
        Me.txtDriverID.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(18, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 127
        Me.Label1.Text = "Queue Date"
        '
        'dtpQueueDate
        '
        Me.dtpQueueDate.CustomFormat = "dd/MM/yyyy HH:mm:ss"
        Me.dtpQueueDate.Enabled = False
        Me.dtpQueueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpQueueDate.Location = New System.Drawing.Point(98, 40)
        Me.dtpQueueDate.Name = "dtpQueueDate"
        Me.dtpQueueDate.Size = New System.Drawing.Size(152, 21)
        Me.dtpQueueDate.TabIndex = 1
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Location = New System.Drawing.Point(98, 13)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(152, 21)
        Me.txtID.TabIndex = 0
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(18, 16)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(18, 13)
        Me.lblID.TabIndex = 126
        Me.lblID.Text = "ID"
        '
        'frmTraQueueChangeRFID
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(528, 325)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.lblInfo)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTraQueueChangeRFID"
        Me.Text = "Change RFID"
        Me.pnlMain.ResumeLayout(False)
        Me.pnlMain.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents txtDriverFullName As QMS.usTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtDriverID As QMS.usTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpQueueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtID As QMS.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtNewRFID As QMS.usTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtRFID As QMS.usTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents txtRemarks As QMS.usTextBox
End Class
