﻿Public Class frmTraQueueOnProgress

#Region "Properties Handle"

    Private clsData As VO.Queue
    Private intPos As Integer
    Private intComLocDivSubDivID As Integer = 0
    Private strCompanyID As String = "", strLocationID = ""
    Private clsCS As New VO.CS
    Private Const _
       cUpdateIsFreePass = 0, cUpdateIsRepeat = 1, cSep1 = 2, cClose = 3, _
       cCheckAll = 0, cUncheckAll = 1

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "Pick", "Pick", 100, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueNumber", "Queue Number", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "TicketParkingID", "Ticket Parking ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueDate", "Queue Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "PlatNumber", "Plat Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DriverID", "DriverID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DriverFullName", "Driver Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "SPBNumber", "SPB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "RFID", "RFID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivIDStorage", "ComLocDivSubDivID Storage", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ProgramIDStorage", "Program ID Storage", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "StorageGroupID", "Storage Group ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageGroupName", "Storage Group Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageID", "Storage ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageName", "Storage Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueType", "QueueType", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "QueueTypeName", "Queue Type", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueFlowID", "QueueFlowID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ItemCode", "ItemCode", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ItemName", "ItemName", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "IsFreePass", "Free Pass", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "WBNumber", "WB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "WBProgramID", "WB Program ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ContractNumber", "Contract Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsRepeat", "Repeat", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsCompleted", "IsCompleted", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "CompletedBy", "Completed By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CompletedDate", "Completed Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "IsDeleted", "IsDeleted", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cUpdateIsFreePass).Enabled = bolEnable
            .Item(cUpdateIsRepeat).Enabled = bolEnable
        End With

        With ToolBarDetail.Buttons
            .Item(cCheckAll).Enabled = bolEnable
            .Item(cUncheckAll).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvSetDefaultFilter()
        intComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID
        strCompanyID = UI.usUserApp.CompanyID
        txtCompanyName.Text = UI.usUserApp.CompanyName
        strLocationID = UI.usUserApp.LocationID
        txtLocationName.Text = UI.usUserApp.LocationName
        txtDivisionName.Text = UI.usUserApp.DivisionName
        txtSubdivisionName.Text = UI.usUserApp.SubDivisionName
        prvUserAccess()
    End Sub

    Private Sub prvGetCS()
        clsCS = New VO.CS
        clsCS.ProgramID = UI.usUserApp.ProgramID
        clsCS.ProgramName = UI.usUserApp.ProgramName
        clsCS.ComLocDivSubDivID = intComLocDivSubDivID
        clsCS.CompanyID = strCompanyID
        clsCS.CompanyName = txtCompanyName.Text.Trim
        clsCS.LocationID = strLocationID
        clsCS.LocationName = txtLocationName.Text.Trim
        clsCS.DivisionName = txtDivisionName.Text.Trim
        clsCS.SubDivisionName = txtSubdivisionName.Text.Trim
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor
        progressBar.Visible = True

        Try
            grdMain.DataSource = BL.Queue.ListDataOnProgress(intComLocDivSubDivID, dtpDateFrom.Value.Date, dtpDateTo.Value.Date, chkIsFreePass.Checked, chkIsRepeat.Checked)
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
            Me.Cursor = Cursors.Default
            progressBar.Visible = False
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Function prvGetData() As VO.Queue
        Dim returnValue As New VO.Queue
        returnValue.ComLocDivSubDivID = grdView.GetRowCellValue(intPos, "ComLocDivSubDivID")
        returnValue.ID = grdView.GetRowCellValue(intPos, "ID")
        returnValue.QueueNumber = IIf(grdView.GetRowCellValue(intPos, "QueueNumber").Equals(DBNull.Value), 0, grdView.GetRowCellValue(intPos, "QueueNumber"))
        returnValue.TicketParkingID = grdView.GetRowCellValue(intPos, "TicketParkingID")
        returnValue.QueueDate = grdView.GetRowCellValue(intPos, "QueueDate")
        returnValue.PlatNumber = grdView.GetRowCellValue(intPos, "PlatNumber")
        returnValue.DriverID = grdView.GetRowCellValue(intPos, "DriverID")
        returnValue.DriverFullName = grdView.GetRowCellValue(intPos, "DriverFullName")
        returnValue.SPBNumber = grdView.GetRowCellValue(intPos, "SPBNumber")
        returnValue.RFID = grdView.GetRowCellValue(intPos, "RFID")
        returnValue.ComLocDivSubDivIDStorage = grdView.GetRowCellValue(intPos, "ComLocDivSubDivIDStorage")
        returnValue.ProgramIDStorage = grdView.GetRowCellValue(intPos, "ProgramIDStorage")
        returnValue.StorageGroupID = grdView.GetRowCellValue(intPos, "StorageGroupID")
        returnValue.StorageGroupName = grdView.GetRowCellValue(intPos, "StorageGroupName")
        returnValue.StorageID = grdView.GetRowCellValue(intPos, "StorageID")
        returnValue.StorageName = grdView.GetRowCellValue(intPos, "StorageName")
        returnValue.QueueType = grdView.GetRowCellValue(intPos, "QueueType")
        returnValue.QueueTypeName = grdView.GetRowCellValue(intPos, "QueueTypeName")
        returnValue.ItemCode = grdView.GetRowCellValue(intPos, "ItemCode")
        returnValue.ItemName = grdView.GetRowCellValue(intPos, "ItemName")
        returnValue.QueueFlowID = grdView.GetRowCellValue(intPos, "QueueFlowID")
        returnValue.IsFreePass = grdView.GetRowCellValue(intPos, "IsFreePass")
        returnValue.WBNumber = grdView.GetRowCellValue(intPos, "WBNumber")
        returnValue.WBProgramID = grdView.GetRowCellValue(intPos, "WBProgramID")
        returnValue.ContractNumber = grdView.GetRowCellValue(intPos, "ContractNumber")
        returnValue.IsRepeat = grdView.GetRowCellValue(intPos, "IsRepeat")
        returnValue.ReferencesID = grdView.GetRowCellValue(intPos, "ReferencesID")
        returnValue.IDStatus = grdView.GetRowCellValue(intPos, "IDStatus")
        returnValue.StatusInfo = grdView.GetRowCellValue(intPos, "StatusInfo")
        returnValue.IsCompleted = grdView.GetRowCellValue(intPos, "IsCompleted")
        returnValue.CompletedBy = grdView.GetRowCellValue(intPos, "CompletedBy")
        returnValue.CompletedDate = IIf(grdView.GetRowCellValue(intPos, "CompletedDate").Equals(DBNull.Value), "2000/01/01", grdView.GetRowCellValue(intPos, "CompletedDate"))
        returnValue.IsDeleted = grdView.GetRowCellValue(intPos, "IsDeleted")
        returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnValue.CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvUpdateIsRepeatOrIsFreePass(ByVal action As VO.Queue.Action)
        txtCompanyName.Focus()
        Dim dtData As DataTable = grdMain.DataSource
        Dim drSelected() As DataRow = dtData.Select("Pick=True")

        If drSelected.Count = 0 Then UI.usForm.frmMessageBox("Please pick item first") : Exit Sub

        Try
            Dim clsDataAll(drSelected.Count - 1) As VO.Queue
            Dim clsQueue As VO.Queue
            Dim intCount As Integer = 0
            For Each dr As DataRow In drSelected
                clsQueue = New VO.Queue
                clsQueue.ID = dr("ID")
                clsQueue.QueueDate = dr("QueueDate")
                clsQueue.LogBy = UI.usUserApp.UserID
                clsDataAll(intCount) = clsQueue
                intCount += 1
            Next

            Dim frmDetail As New frmTraQueueOnProgressConfirm
            With frmDetail
                .pubAction = action
                .pubCS = clsCS
                .pubSelectedData = clsDataAll
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
                If .pubIsSave Then
                    prvQuery()
                End If
            End With
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSetChecked(ByVal value As Boolean)
        With grdView
            For i As Integer = 0 To .RowCount - 1
                .SetRowCellValue(i, "Pick", value)
                .UpdateCurrentRow()
            Next
        End With
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
        prvSetButton()
    End Sub

    Private Sub prvChooseCompany()
        Dim frmDetail As New frmMstCompany
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strCompanyID = .pubLUDataRow.Item("CompanyID")
                txtCompanyName.Text = .pubLUDataRow.Item("CompanyName")
            End If
        End With
    End Sub

    Private Sub prvChooseLocation()
        Dim frmDetail As New frmMstCompanyLocation
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = strCompanyID
            .pubLULocationID = clsCS.LocationID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strLocationID = .pubLUDataRow.Item("LocationID")
                txtLocationName.Text = .pubLUDataRow.Item("LocationName")
            End If
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cUpdateIsFreePass).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFREEPASS", "EDIT")
            .Item(cUpdateIsRepeat).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEREPEAT", "EDIT")
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueIsRepeatOnProgress_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

    End Sub

    Private Sub frmTraQueueIsRepeatOnProgress_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        ToolBarDetail.SetIcon(Me)
        prvSetGrid()
        prvSetDefaultFilter()
        prvSetButton()

        dtpDateFrom.Value = Today.Date.AddDays(-7)
        dtpDateTo.Value = Today.Date

        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        prvChooseCompany()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        prvChooseLocation()
    End Sub

    Private Sub btnSubDivision_Click(sender As Object, e As EventArgs) Handles btnSubDivision.Click
        If strCompanyID.Trim = "" Then Exit Sub
        Dim frmDetail As New frmMstSubDivision
        With frmDetail
            .pubIsLookUp = True
            .pubLUProgramID = UI.usUserApp.ProgramID
            .pubLUCompanyID = strCompanyID.Trim
            .pubLUComLocDivSubDivID = intComLocDivSubDivID
            .ShowDialog()
            If .pubIsLookUpGet Then
                intComLocDivSubDivID = .pubLUComLocDivSubDivID
                strLocationID = .pubLUDataRow("LocationID")
                txtLocationName.Text = .pubLUDataRow("LocationName")
                txtDivisionName.Text = .pubLUDataRow("DivisionName")
                txtSubdivisionName.Text = .pubLUDataRow("SubDivisionName")
                prvClear()
            End If
        End With
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Update Repeat" : prvUpdateIsRepeatOrIsFreePass(VO.Queue.Action.UpdateIsRepeat)
            Case "Update Free Pass" : prvUpdateIsRepeatOrIsFreePass(VO.Queue.Action.UpdateIsFreePass)
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub ToolBarDetail_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarDetail.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Check All" : prvSetChecked(True)
            Case "Uncheck All" : prvSetChecked(False)
        End Select
    End Sub

#End Region

End Class