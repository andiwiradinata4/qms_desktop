﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueArrange
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTraQueueArrange))
        Dim SerializableAppearanceObject1 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlRight = New System.Windows.Forms.Panel()
        Me.grdOutstanding = New DevExpress.XtraGrid.GridControl()
        Me.grdOutstandingView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnlButton = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnMoveRight = New DevExpress.XtraEditors.SimpleButton()
        Me.btnMoveLeft = New DevExpress.XtraEditors.SimpleButton()
        Me.btnCountOnProgress = New DevExpress.XtraEditors.SimpleButton()
        Me.pnlLeft = New System.Windows.Forms.Panel()
        Me.grdOnProgress = New DevExpress.XtraGrid.GridControl()
        Me.grdOnProgressView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.rpiAutoNumber = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.progressBar = New DevExpress.XtraWaitForm.ProgressPanel()
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnSubDivision = New System.Windows.Forms.Button()
        Me.txtSubdivisionName = New QMS.usTextBox()
        Me.txtDivisionName = New QMS.usTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnClear = New DevExpress.XtraEditors.SimpleButton()
        Me.btnExecute = New DevExpress.XtraEditors.SimpleButton()
        Me.btnLocation = New System.Windows.Forms.Button()
        Me.btnCompany = New System.Windows.Forms.Button()
        Me.txtLocationName = New QMS.usTextBox()
        Me.txtCompanyName = New QMS.usTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ToolBar = New QMS.usToolBar()
        Me.BarSave = New System.Windows.Forms.ToolBarButton()
        Me.BarClose = New System.Windows.Forms.ToolBarButton()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.pnlRight.SuspendLayout()
        CType(Me.grdOutstanding, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdOutstandingView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlButton.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pnlLeft.SuspendLayout()
        CType(Me.grdOnProgress, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdOnProgressView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rpiAutoNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.pnlRight, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.pnlButton, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.pnlLeft, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 150)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(984, 462)
        Me.TableLayoutPanel1.TabIndex = 3
        '
        'pnlRight
        '
        Me.pnlRight.Controls.Add(Me.grdOutstanding)
        Me.pnlRight.Controls.Add(Me.Label2)
        Me.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlRight.Location = New System.Drawing.Point(522, 0)
        Me.pnlRight.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlRight.Name = "pnlRight"
        Me.pnlRight.Size = New System.Drawing.Size(462, 462)
        Me.pnlRight.TabIndex = 2
        '
        'grdOutstanding
        '
        Me.grdOutstanding.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdOutstanding.Location = New System.Drawing.Point(0, 22)
        Me.grdOutstanding.MainView = Me.grdOutstandingView
        Me.grdOutstanding.Name = "grdOutstanding"
        Me.grdOutstanding.Size = New System.Drawing.Size(462, 440)
        Me.grdOutstanding.TabIndex = 1
        Me.grdOutstanding.UseEmbeddedNavigator = True
        Me.grdOutstanding.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdOutstandingView})
        '
        'grdOutstandingView
        '
        Me.grdOutstandingView.GridControl = Me.grdOutstanding
        Me.grdOutstandingView.Name = "grdOutstandingView"
        Me.grdOutstandingView.OptionsCustomization.AllowColumnMoving = False
        Me.grdOutstandingView.OptionsCustomization.AllowGroup = False
        Me.grdOutstandingView.OptionsView.ColumnAutoWidth = False
        Me.grdOutstandingView.OptionsView.ShowAutoFilterRow = True
        Me.grdOutstandingView.OptionsView.ShowGroupPanel = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.CadetBlue
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(462, 22)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "« Outstanding"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlButton
        '
        Me.pnlButton.Controls.Add(Me.TableLayoutPanel2)
        Me.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlButton.Location = New System.Drawing.Point(462, 0)
        Me.pnlButton.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlButton.Name = "pnlButton"
        Me.pnlButton.Size = New System.Drawing.Size(60, 462)
        Me.pnlButton.TabIndex = 1
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel1, 0, 1)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 3
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 135.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(60, 462)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnMoveRight)
        Me.Panel1.Controls.Add(Me.btnMoveLeft)
        Me.Panel1.Controls.Add(Me.btnCountOnProgress)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(1, 163)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(58, 135)
        Me.Panel1.TabIndex = 0
        '
        'btnMoveRight
        '
        Me.btnMoveRight.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnMoveRight.Image = CType(resources.GetObject("btnMoveRight.Image"), System.Drawing.Image)
        Me.btnMoveRight.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleCenter
        Me.btnMoveRight.Location = New System.Drawing.Point(0, 90)
        Me.btnMoveRight.Name = "btnMoveRight"
        Me.btnMoveRight.Size = New System.Drawing.Size(58, 45)
        Me.btnMoveRight.TabIndex = 1
        '
        'btnMoveLeft
        '
        Me.btnMoveLeft.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnMoveLeft.Image = CType(resources.GetObject("btnMoveLeft.Image"), System.Drawing.Image)
        Me.btnMoveLeft.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleCenter
        Me.btnMoveLeft.Location = New System.Drawing.Point(0, 45)
        Me.btnMoveLeft.Name = "btnMoveLeft"
        Me.btnMoveLeft.Size = New System.Drawing.Size(58, 45)
        Me.btnMoveLeft.TabIndex = 0
        '
        'btnCountOnProgress
        '
        Me.btnCountOnProgress.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnCountOnProgress.Image = CType(resources.GetObject("btnCountOnProgress.Image"), System.Drawing.Image)
        Me.btnCountOnProgress.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleCenter
        Me.btnCountOnProgress.Location = New System.Drawing.Point(0, 0)
        Me.btnCountOnProgress.Name = "btnCountOnProgress"
        Me.btnCountOnProgress.Size = New System.Drawing.Size(58, 45)
        Me.btnCountOnProgress.TabIndex = 2
        Me.btnCountOnProgress.ToolTip = "Count Queue Number"
        '
        'pnlLeft
        '
        Me.pnlLeft.Controls.Add(Me.grdOnProgress)
        Me.pnlLeft.Controls.Add(Me.lblInfo)
        Me.pnlLeft.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlLeft.Location = New System.Drawing.Point(0, 0)
        Me.pnlLeft.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlLeft.Name = "pnlLeft"
        Me.pnlLeft.Size = New System.Drawing.Size(462, 462)
        Me.pnlLeft.TabIndex = 0
        '
        'grdOnProgress
        '
        Me.grdOnProgress.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdOnProgress.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdOnProgress.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdOnProgress.Location = New System.Drawing.Point(0, 22)
        Me.grdOnProgress.MainView = Me.grdOnProgressView
        Me.grdOnProgress.Margin = New System.Windows.Forms.Padding(0)
        Me.grdOnProgress.Name = "grdOnProgress"
        Me.grdOnProgress.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.rpiAutoNumber})
        Me.grdOnProgress.Size = New System.Drawing.Size(462, 440)
        Me.grdOnProgress.TabIndex = 2
        Me.grdOnProgress.UseEmbeddedNavigator = True
        Me.grdOnProgress.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdOnProgressView})
        '
        'grdOnProgressView
        '
        Me.grdOnProgressView.GridControl = Me.grdOnProgress
        Me.grdOnProgressView.Name = "grdOnProgressView"
        Me.grdOnProgressView.OptionsCustomization.AllowColumnMoving = False
        Me.grdOnProgressView.OptionsCustomization.AllowGroup = False
        Me.grdOnProgressView.OptionsView.ColumnAutoWidth = False
        Me.grdOnProgressView.OptionsView.ShowAutoFilterRow = True
        Me.grdOnProgressView.OptionsView.ShowGroupPanel = False
        '
        'rpiAutoNumber
        '
        Me.rpiAutoNumber.AutoHeight = False
        Me.rpiAutoNumber.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Up, "", -1, True, True, True, DevExpress.XtraEditors.ImageLocation.MiddleCenter, Nothing, New DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), SerializableAppearanceObject1, "", Nothing, Nothing, True), New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Down)})
        Me.rpiAutoNumber.Name = "rpiAutoNumber"
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(462, 22)
        Me.lblInfo.TabIndex = 0
        Me.lblInfo.Text = "« On Progress"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.progressBar)
        Me.Panel2.Controls.Add(Me.dtpDateFrom)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.btnSubDivision)
        Me.Panel2.Controls.Add(Me.txtSubdivisionName)
        Me.Panel2.Controls.Add(Me.txtDivisionName)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.btnClear)
        Me.Panel2.Controls.Add(Me.btnExecute)
        Me.Panel2.Controls.Add(Me.btnLocation)
        Me.Panel2.Controls.Add(Me.btnCompany)
        Me.Panel2.Controls.Add(Me.txtLocationName)
        Me.Panel2.Controls.Add(Me.txtCompanyName)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 28)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(984, 122)
        Me.Panel2.TabIndex = 1
        '
        'progressBar
        '
        Me.progressBar.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.progressBar.Appearance.Options.UseBackColor = True
        Me.progressBar.AppearanceCaption.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.progressBar.AppearanceCaption.Options.UseFont = True
        Me.progressBar.AppearanceDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.progressBar.AppearanceDescription.Options.UseFont = True
        Me.progressBar.Location = New System.Drawing.Point(814, 23)
        Me.progressBar.Name = "progressBar"
        Me.progressBar.Size = New System.Drawing.Size(145, 66)
        Me.progressBar.TabIndex = 10
        Me.progressBar.Text = "ProgressPanel1"
        Me.progressBar.Visible = False
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CustomFormat = "dd/MM/yyyy"
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(115, 77)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(101, 21)
        Me.dtpDateFrom.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(27, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 13)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Queue Date"
        '
        'btnSubDivision
        '
        Me.btnSubDivision.BackColor = System.Drawing.Color.Transparent
        Me.btnSubDivision.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSubDivision.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSubDivision.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubDivision.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnSubDivision.Image = CType(resources.GetObject("btnSubDivision.Image"), System.Drawing.Image)
        Me.btnSubDivision.Location = New System.Drawing.Point(767, 55)
        Me.btnSubDivision.Name = "btnSubDivision"
        Me.btnSubDivision.Size = New System.Drawing.Size(19, 20)
        Me.btnSubDivision.TabIndex = 7
        Me.btnSubDivision.TabStop = False
        Me.btnSubDivision.UseVisualStyleBackColor = False
        '
        'txtSubdivisionName
        '
        Me.txtSubdivisionName.BackColor = System.Drawing.Color.AliceBlue
        Me.txtSubdivisionName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSubdivisionName.Location = New System.Drawing.Point(498, 56)
        Me.txtSubdivisionName.Name = "txtSubdivisionName"
        Me.txtSubdivisionName.ReadOnly = True
        Me.txtSubdivisionName.Size = New System.Drawing.Size(265, 21)
        Me.txtSubdivisionName.TabIndex = 6
        '
        'txtDivisionName
        '
        Me.txtDivisionName.BackColor = System.Drawing.Color.AliceBlue
        Me.txtDivisionName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDivisionName.Location = New System.Drawing.Point(498, 36)
        Me.txtDivisionName.Name = "txtDivisionName"
        Me.txtDivisionName.ReadOnly = True
        Me.txtDivisionName.Size = New System.Drawing.Size(265, 21)
        Me.txtDivisionName.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(414, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Subdivision"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(414, 39)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Division"
        '
        'btnClear
        '
        Me.btnClear.Appearance.ForeColor = System.Drawing.Color.Black
        Me.btnClear.Appearance.Options.UseForeColor = True
        Me.btnClear.Image = CType(resources.GetObject("btnClear.Image"), System.Drawing.Image)
        Me.btnClear.Location = New System.Drawing.Point(638, 83)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 23)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "Clear"
        '
        'btnExecute
        '
        Me.btnExecute.Image = CType(resources.GetObject("btnExecute.Image"), System.Drawing.Image)
        Me.btnExecute.Location = New System.Drawing.Point(498, 83)
        Me.btnExecute.Name = "btnExecute"
        Me.btnExecute.Size = New System.Drawing.Size(125, 23)
        Me.btnExecute.TabIndex = 8
        Me.btnExecute.Text = "Execute"
        '
        'btnLocation
        '
        Me.btnLocation.BackColor = System.Drawing.Color.Transparent
        Me.btnLocation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLocation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLocation.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLocation.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnLocation.Image = CType(resources.GetObject("btnLocation.Image"), System.Drawing.Image)
        Me.btnLocation.Location = New System.Drawing.Point(354, 57)
        Me.btnLocation.Name = "btnLocation"
        Me.btnLocation.Size = New System.Drawing.Size(19, 20)
        Me.btnLocation.TabIndex = 3
        Me.btnLocation.TabStop = False
        Me.btnLocation.UseVisualStyleBackColor = False
        '
        'btnCompany
        '
        Me.btnCompany.BackColor = System.Drawing.Color.Transparent
        Me.btnCompany.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCompany.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCompany.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompany.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnCompany.Image = CType(resources.GetObject("btnCompany.Image"), System.Drawing.Image)
        Me.btnCompany.Location = New System.Drawing.Point(354, 36)
        Me.btnCompany.Name = "btnCompany"
        Me.btnCompany.Size = New System.Drawing.Size(19, 20)
        Me.btnCompany.TabIndex = 1
        Me.btnCompany.TabStop = False
        Me.btnCompany.UseVisualStyleBackColor = False
        '
        'txtLocationName
        '
        Me.txtLocationName.BackColor = System.Drawing.Color.AliceBlue
        Me.txtLocationName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtLocationName.Location = New System.Drawing.Point(115, 56)
        Me.txtLocationName.Name = "txtLocationName"
        Me.txtLocationName.ReadOnly = True
        Me.txtLocationName.Size = New System.Drawing.Size(235, 21)
        Me.txtLocationName.TabIndex = 2
        '
        'txtCompanyName
        '
        Me.txtCompanyName.BackColor = System.Drawing.Color.AliceBlue
        Me.txtCompanyName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCompanyName.Location = New System.Drawing.Point(115, 36)
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.ReadOnly = True
        Me.txtCompanyName.Size = New System.Drawing.Size(235, 21)
        Me.txtCompanyName.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DimGray
        Me.Label8.Location = New System.Drawing.Point(27, 59)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Location"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DimGray
        Me.Label9.Location = New System.Drawing.Point(27, 39)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 13)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Company"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label10.Location = New System.Drawing.Point(19, 14)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(94, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Query Data By :"
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarSave, Me.BarClose})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.Padding = New System.Windows.Forms.Padding(3)
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(984, 28)
        Me.ToolBar.TabIndex = 4
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarSave
        '
        Me.BarSave.Name = "BarSave"
        Me.BarSave.Tag = "Save"
        Me.BarSave.Text = "Save"
        '
        'BarClose
        '
        Me.BarClose.Name = "BarClose"
        Me.BarClose.Tag = "Close"
        Me.BarClose.Text = "Close"
        '
        'frmTraQueueArrange
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 612)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.ToolBar)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.Name = "frmTraQueueArrange"
        Me.Text = "Queue Arrange"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.pnlRight.ResumeLayout(False)
        CType(Me.grdOutstanding, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdOutstandingView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlButton.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.pnlLeft.ResumeLayout(False)
        CType(Me.grdOnProgress, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdOnProgressView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rpiAutoNumber, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlLeft As System.Windows.Forms.Panel
    Friend WithEvents pnlRight As System.Windows.Forms.Panel
    Friend WithEvents pnlButton As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnMoveLeft As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents grdOutstanding As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdOutstandingView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents progressBar As DevExpress.XtraWaitForm.ProgressPanel
    Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnSubDivision As System.Windows.Forms.Button
    Friend WithEvents txtSubdivisionName As QMS.usTextBox
    Friend WithEvents txtDivisionName As QMS.usTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnClear As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnExecute As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLocation As System.Windows.Forms.Button
    Friend WithEvents btnCompany As System.Windows.Forms.Button
    Friend WithEvents txtLocationName As QMS.usTextBox
    Friend WithEvents txtCompanyName As QMS.usTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents btnMoveRight As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents grdOnProgress As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdOnProgressView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents rpiAutoNumber As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents btnCountOnProgress As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents ToolBar As QMS.usToolBar
    Friend WithEvents BarSave As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton
End Class
