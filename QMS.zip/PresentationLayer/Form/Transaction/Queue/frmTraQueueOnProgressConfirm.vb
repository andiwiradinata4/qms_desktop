﻿Imports System.Data.SqlClient

Public Class frmTraQueueOnProgressConfirm

#Region "Property Handle"

    Property pubIsSave As Boolean = False
    Property pubAction As VO.Queue.Action
    Property pubCS As VO.CS
    Private frmParent As frmTraQueueOnProgress
    Private clsSelectedData() As VO.Queue

    Public WriteOnly Property pubSelectedData As VO.Queue()
        Set(value As VO.Queue())
            clsSelectedData = value
        End Set
    End Property

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetLabelInfoForm()
        If pubAction = VO.Queue.Action.UpdateIsFreePass Then
            lblInfo.Text += " [Update Free Pass]"
        ElseIf pubAction = VO.Queue.Action.UpdateIsRepeat Then
            lblInfo.Text += " [Update Repeat]"
        End If
    End Sub

    Public Sub prvSave()
        Dim bolResult As Boolean = False
        If rdChecked.Checked = False And rdUnchecked.Checked = False Then
            UI.usForm.frmMessageBox("Please choose action first")
            rdChecked.Focus()
            Exit Sub
        End If

        Dim strMessage As String = ""
        If pubAction = VO.Queue.Action.UpdateIsFreePass Then
            strMessage += " Update free pass tobe " & IIf(rdChecked.Checked, "checked", "unchecked") & "?"
        ElseIf pubAction = VO.Queue.Action.UpdateIsRepeat Then
            strMessage += " Update repeat tobe " & IIf(rdChecked.Checked, "checked", "unchecked") & "?"
        End If

        If Not UI.usForm.frmAskQuestion(strMessage) Then Exit Sub

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                For Each clsData As VO.Queue In clsSelectedData
                    If pubAction = VO.Queue.Action.UpdateIsFreePass Then
                        clsData.IsFreePass = IIf(rdChecked.Checked, True, False)
                        BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessChangeFreePass, clsData.ID)
                    ElseIf pubAction = VO.Queue.Action.UpdateIsRepeat Then
                        clsData.IsRepeat = IIf(rdChecked.Checked, True, False)
                        BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessChangeRepeat, clsData.ID)
                    End If
                    clsData.Remarks = txtRemarks.Text.Trim
                Next
            End Using

            If pubAction = VO.Queue.Action.UpdateIsFreePass Then
                bolResult = BL.Queue.ChangeIsFreePass(clsSelectedData)
            ElseIf pubAction = VO.Queue.Action.UpdateIsRepeat Then
                bolResult = BL.Queue.ChangeIsRepeat(clsSelectedData)
            End If

            If bolResult Then
                UI.usForm.frmMessageBox("Save data success.")
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Function ModuleID()
        Dim strReturn = ""
        If pubAction = VO.Queue.Action.UpdateIsFreePass Then
            strReturn = "TRAQUEUEFREEPASS"
        ElseIf pubAction = VO.Queue.Action.UpdateIsRepeat Then
            strReturn = "TRAQUEUEREPEAT"
        End If
        Return strReturn
    End Function

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueOnProgressConfirm_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

    End Sub

    Private Sub frmTraQueueOnProgressConfirm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, ModuleID, "EDIT"))
    End Sub

#End Region

End Class