﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueDet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTraQueueDet))
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripEmpty = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogInc = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogBy = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogDate = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tcQueue = New System.Windows.Forms.TabControl()
        Me.tpMain = New System.Windows.Forms.TabPage()
        Me.lblRFIDStatus = New System.Windows.Forms.Label()
        Me.txtReferencesID = New QMS.usTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cboStatus = New QMSLib.usComboBox()
        Me.lblIDStatus = New System.Windows.Forms.Label()
        Me.txtQueueNumber = New QMS.usTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.txtRemarks = New QMS.usTextBox()
        Me.txtRFID = New QMS.usTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSPBNumber = New QMS.usTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnDriver = New System.Windows.Forms.Button()
        Me.txtDriverFullName = New QMS.usTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPlatNumber = New QMS.usTextBox()
        Me.txtDriverID = New QMS.usTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTicketParkingID = New QMS.usTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpQueueDate = New System.Windows.Forms.DateTimePicker()
        Me.txtID = New QMS.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.tpConfirm = New System.Windows.Forms.TabPage()
        Me.txtStorageGroupID = New QMS.usTextBox()
        Me.txtStorageGroupName = New QMS.usTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cboQueueType = New QMSLib.usComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtItemCode = New QMS.usTextBox()
        Me.txtItemName = New QMS.usTextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtQueueFlowID = New QMS.usTextBox()
        Me.txtQueueFlowName = New QMS.usTextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtWBProgramID = New QMS.usTextBox()
        Me.chkIsRepeat = New DevExpress.XtraEditors.CheckEdit()
        Me.chkIsFreePass = New DevExpress.XtraEditors.CheckEdit()
        Me.txtWBProgramName = New QMS.usTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtWBNumber = New QMS.usTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tpQueueFlow = New System.Windows.Forms.TabPage()
        Me.grdQueueFlow = New DevExpress.XtraGrid.GridControl()
        Me.grdQueueFlowView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.tpStatus = New System.Windows.Forms.TabPage()
        Me.grdStatus = New DevExpress.XtraGrid.GridControl()
        Me.grdStatusView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.txtStorageID = New QMS.usTextBox()
        Me.txtStorageName = New QMS.usTextBox()
        Me.StatusStrip.SuspendLayout()
        Me.tcQueue.SuspendLayout()
        Me.tpMain.SuspendLayout()
        Me.tpConfirm.SuspendLayout()
        CType(Me.chkIsRepeat.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkIsFreePass.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpQueueFlow.SuspendLayout()
        CType(Me.grdQueueFlow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdQueueFlowView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpStatus.SuspendLayout()
        CType(Me.grdStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdStatusView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(528, 22)
        Me.lblInfo.TabIndex = 1
        Me.lblInfo.Text = "« Queue Detail"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'StatusStrip
        '
        Me.StatusStrip.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripEmpty, Me.ToolStripLogInc, Me.ToolStripLogBy, Me.ToolStripStatusLabel1, Me.ToolStripLogDate})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 389)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(528, 22)
        Me.StatusStrip.TabIndex = 4
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'ToolStripEmpty
        '
        Me.ToolStripEmpty.Name = "ToolStripEmpty"
        Me.ToolStripEmpty.Size = New System.Drawing.Size(405, 17)
        Me.ToolStripEmpty.Spring = True
        '
        'ToolStripLogInc
        '
        Me.ToolStripLogInc.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogInc.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogInc.Name = "ToolStripLogInc"
        Me.ToolStripLogInc.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogInc.Text = "Log Inc : "
        '
        'ToolStripLogBy
        '
        Me.ToolStripLogBy.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogBy.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogBy.Name = "ToolStripLogBy"
        Me.ToolStripLogBy.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogBy.Text = "Last Log :"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripLogDate
        '
        Me.ToolStripLogDate.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogDate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogDate.Name = "ToolStripLogDate"
        Me.ToolStripLogDate.Size = New System.Drawing.Size(12, 17)
        Me.ToolStripLogDate.Text = "-"
        '
        'tcQueue
        '
        Me.tcQueue.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tcQueue.Controls.Add(Me.tpMain)
        Me.tcQueue.Controls.Add(Me.tpConfirm)
        Me.tcQueue.Controls.Add(Me.tpQueueFlow)
        Me.tcQueue.Controls.Add(Me.tpStatus)
        Me.tcQueue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcQueue.Location = New System.Drawing.Point(0, 22)
        Me.tcQueue.Name = "tcQueue"
        Me.tcQueue.SelectedIndex = 0
        Me.tcQueue.Size = New System.Drawing.Size(528, 367)
        Me.tcQueue.TabIndex = 2
        '
        'tpMain
        '
        Me.tpMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpMain.Controls.Add(Me.lblRFIDStatus)
        Me.tpMain.Controls.Add(Me.txtReferencesID)
        Me.tpMain.Controls.Add(Me.Label11)
        Me.tpMain.Controls.Add(Me.cboStatus)
        Me.tpMain.Controls.Add(Me.lblIDStatus)
        Me.tpMain.Controls.Add(Me.txtQueueNumber)
        Me.tpMain.Controls.Add(Me.Label7)
        Me.tpMain.Controls.Add(Me.lblRemarks)
        Me.tpMain.Controls.Add(Me.txtRemarks)
        Me.tpMain.Controls.Add(Me.txtRFID)
        Me.tpMain.Controls.Add(Me.Label6)
        Me.tpMain.Controls.Add(Me.txtSPBNumber)
        Me.tpMain.Controls.Add(Me.Label5)
        Me.tpMain.Controls.Add(Me.btnDriver)
        Me.tpMain.Controls.Add(Me.txtDriverFullName)
        Me.tpMain.Controls.Add(Me.Label4)
        Me.tpMain.Controls.Add(Me.txtPlatNumber)
        Me.tpMain.Controls.Add(Me.txtDriverID)
        Me.tpMain.Controls.Add(Me.Label3)
        Me.tpMain.Controls.Add(Me.txtTicketParkingID)
        Me.tpMain.Controls.Add(Me.Label2)
        Me.tpMain.Controls.Add(Me.Label1)
        Me.tpMain.Controls.Add(Me.dtpQueueDate)
        Me.tpMain.Controls.Add(Me.txtID)
        Me.tpMain.Controls.Add(Me.lblID)
        Me.tpMain.Location = New System.Drawing.Point(4, 25)
        Me.tpMain.Name = "tpMain"
        Me.tpMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tpMain.Size = New System.Drawing.Size(520, 338)
        Me.tpMain.TabIndex = 0
        Me.tpMain.Text = "Main - F1"
        Me.tpMain.UseVisualStyleBackColor = True
        '
        'lblRFIDStatus
        '
        Me.lblRFIDStatus.AutoSize = True
        Me.lblRFIDStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblRFIDStatus.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.lblRFIDStatus.ForeColor = System.Drawing.Color.OrangeRed
        Me.lblRFIDStatus.Location = New System.Drawing.Point(257, 149)
        Me.lblRFIDStatus.Name = "lblRFIDStatus"
        Me.lblRFIDStatus.Size = New System.Drawing.Size(65, 13)
        Me.lblRFIDStatus.TabIndex = 157
        Me.lblRFIDStatus.Text = "RFID Status"
        Me.lblRFIDStatus.Visible = False
        '
        'txtReferencesID
        '
        Me.txtReferencesID.BackColor = System.Drawing.Color.LightYellow
        Me.txtReferencesID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtReferencesID.Location = New System.Drawing.Point(99, 266)
        Me.txtReferencesID.Name = "txtReferencesID"
        Me.txtReferencesID.ReadOnly = True
        Me.txtReferencesID.Size = New System.Drawing.Size(152, 21)
        Me.txtReferencesID.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(19, 270)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 13)
        Me.Label11.TabIndex = 131
        Me.Label11.Text = "References ID"
        '
        'cboStatus
        '
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.Enabled = False
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(99, 239)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(152, 21)
        Me.cboStatus.TabIndex = 8
        '
        'lblIDStatus
        '
        Me.lblIDStatus.AutoSize = True
        Me.lblIDStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblIDStatus.ForeColor = System.Drawing.Color.Black
        Me.lblIDStatus.Location = New System.Drawing.Point(19, 243)
        Me.lblIDStatus.Name = "lblIDStatus"
        Me.lblIDStatus.Size = New System.Drawing.Size(38, 13)
        Me.lblIDStatus.TabIndex = 129
        Me.lblIDStatus.Text = "Status"
        '
        'txtQueueNumber
        '
        Me.txtQueueNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtQueueNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtQueueNumber.Location = New System.Drawing.Point(402, 239)
        Me.txtQueueNumber.MaxLength = 10
        Me.txtQueueNumber.Name = "txtQueueNumber"
        Me.txtQueueNumber.ReadOnly = True
        Me.txtQueueNumber.Size = New System.Drawing.Size(90, 21)
        Me.txtQueueNumber.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(316, 242)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 13)
        Me.Label7.TabIndex = 127
        Me.Label7.Text = "Queue Number"
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.BackColor = System.Drawing.Color.Transparent
        Me.lblRemarks.ForeColor = System.Drawing.Color.Black
        Me.lblRemarks.Location = New System.Drawing.Point(19, 176)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(48, 13)
        Me.lblRemarks.TabIndex = 125
        Me.lblRemarks.Text = "Remarks"
        '
        'txtRemarks
        '
        Me.txtRemarks.BackColor = System.Drawing.Color.White
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Location = New System.Drawing.Point(99, 173)
        Me.txtRemarks.MaxLength = 250
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(393, 60)
        Me.txtRemarks.TabIndex = 7
        '
        'txtRFID
        '
        Me.txtRFID.BackColor = System.Drawing.Color.White
        Me.txtRFID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRFID.Location = New System.Drawing.Point(99, 146)
        Me.txtRFID.MaxLength = 20
        Me.txtRFID.Name = "txtRFID"
        Me.txtRFID.Size = New System.Drawing.Size(152, 21)
        Me.txtRFID.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(19, 151)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 124
        Me.Label6.Text = "RFID"
        '
        'txtSPBNumber
        '
        Me.txtSPBNumber.BackColor = System.Drawing.Color.White
        Me.txtSPBNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSPBNumber.Location = New System.Drawing.Point(99, 119)
        Me.txtSPBNumber.MaxLength = 150
        Me.txtSPBNumber.Name = "txtSPBNumber"
        Me.txtSPBNumber.Size = New System.Drawing.Size(393, 21)
        Me.txtSPBNumber.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(19, 123)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 13)
        Me.Label5.TabIndex = 123
        Me.Label5.Text = "SPB Number"
        '
        'btnDriver
        '
        Me.btnDriver.BackColor = System.Drawing.Color.Transparent
        Me.btnDriver.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDriver.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDriver.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDriver.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnDriver.Image = CType(resources.GetObject("btnDriver.Image"), System.Drawing.Image)
        Me.btnDriver.Location = New System.Drawing.Point(255, 71)
        Me.btnDriver.Name = "btnDriver"
        Me.btnDriver.Size = New System.Drawing.Size(19, 20)
        Me.btnDriver.TabIndex = 3
        Me.btnDriver.TabStop = False
        Me.btnDriver.UseVisualStyleBackColor = False
        '
        'txtDriverFullName
        '
        Me.txtDriverFullName.BackColor = System.Drawing.Color.AliceBlue
        Me.txtDriverFullName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDriverFullName.Location = New System.Drawing.Point(99, 92)
        Me.txtDriverFullName.MaxLength = 250
        Me.txtDriverFullName.Name = "txtDriverFullName"
        Me.txtDriverFullName.ReadOnly = True
        Me.txtDriverFullName.Size = New System.Drawing.Size(393, 21)
        Me.txtDriverFullName.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(19, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 121
        Me.Label4.Text = "Driver"
        '
        'txtPlatNumber
        '
        Me.txtPlatNumber.BackColor = System.Drawing.Color.White
        Me.txtPlatNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlatNumber.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.txtPlatNumber.Location = New System.Drawing.Point(402, 45)
        Me.txtPlatNumber.MaxLength = 10
        Me.txtPlatNumber.Name = "txtPlatNumber"
        Me.txtPlatNumber.Size = New System.Drawing.Size(90, 21)
        Me.txtPlatNumber.TabIndex = 11
        '
        'txtDriverID
        '
        Me.txtDriverID.BackColor = System.Drawing.Color.AliceBlue
        Me.txtDriverID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDriverID.Location = New System.Drawing.Point(99, 72)
        Me.txtDriverID.MaxLength = 250
        Me.txtDriverID.Name = "txtDriverID"
        Me.txtDriverID.ReadOnly = True
        Me.txtDriverID.Size = New System.Drawing.Size(152, 21)
        Me.txtDriverID.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(330, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 122
        Me.Label3.Text = "Plat Number"
        '
        'txtTicketParkingID
        '
        Me.txtTicketParkingID.BackColor = System.Drawing.Color.LightYellow
        Me.txtTicketParkingID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTicketParkingID.Location = New System.Drawing.Point(402, 18)
        Me.txtTicketParkingID.Name = "txtTicketParkingID"
        Me.txtTicketParkingID.ReadOnly = True
        Me.txtTicketParkingID.Size = New System.Drawing.Size(90, 21)
        Me.txtTicketParkingID.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(308, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 120
        Me.Label2.Text = "Ticket Parking ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(19, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 119
        Me.Label1.Text = "Queue Date"
        '
        'dtpQueueDate
        '
        Me.dtpQueueDate.CustomFormat = "dd/MM/yyyy HH:mm:ss"
        Me.dtpQueueDate.Enabled = False
        Me.dtpQueueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpQueueDate.Location = New System.Drawing.Point(99, 45)
        Me.dtpQueueDate.Name = "dtpQueueDate"
        Me.dtpQueueDate.Size = New System.Drawing.Size(152, 21)
        Me.dtpQueueDate.TabIndex = 1
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Location = New System.Drawing.Point(99, 18)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(152, 21)
        Me.txtID.TabIndex = 0
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(19, 21)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(18, 13)
        Me.lblID.TabIndex = 118
        Me.lblID.Text = "ID"
        '
        'tpConfirm
        '
        Me.tpConfirm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpConfirm.Controls.Add(Me.txtStorageID)
        Me.tpConfirm.Controls.Add(Me.txtStorageName)
        Me.tpConfirm.Controls.Add(Me.txtStorageGroupID)
        Me.tpConfirm.Controls.Add(Me.txtStorageGroupName)
        Me.tpConfirm.Controls.Add(Me.Label8)
        Me.tpConfirm.Controls.Add(Me.cboQueueType)
        Me.tpConfirm.Controls.Add(Me.Label13)
        Me.tpConfirm.Controls.Add(Me.txtItemCode)
        Me.tpConfirm.Controls.Add(Me.txtItemName)
        Me.tpConfirm.Controls.Add(Me.Label14)
        Me.tpConfirm.Controls.Add(Me.txtQueueFlowID)
        Me.tpConfirm.Controls.Add(Me.txtQueueFlowName)
        Me.tpConfirm.Controls.Add(Me.Label12)
        Me.tpConfirm.Controls.Add(Me.txtWBProgramID)
        Me.tpConfirm.Controls.Add(Me.chkIsRepeat)
        Me.tpConfirm.Controls.Add(Me.chkIsFreePass)
        Me.tpConfirm.Controls.Add(Me.txtWBProgramName)
        Me.tpConfirm.Controls.Add(Me.Label10)
        Me.tpConfirm.Controls.Add(Me.txtWBNumber)
        Me.tpConfirm.Controls.Add(Me.Label9)
        Me.tpConfirm.Location = New System.Drawing.Point(4, 25)
        Me.tpConfirm.Name = "tpConfirm"
        Me.tpConfirm.Size = New System.Drawing.Size(520, 338)
        Me.tpConfirm.TabIndex = 3
        Me.tpConfirm.Text = "Confirm Info - F2"
        Me.tpConfirm.UseVisualStyleBackColor = True
        '
        'txtStorageGroupID
        '
        Me.txtStorageGroupID.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageGroupID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageGroupID.Location = New System.Drawing.Point(110, 212)
        Me.txtStorageGroupID.Name = "txtStorageGroupID"
        Me.txtStorageGroupID.ReadOnly = True
        Me.txtStorageGroupID.Size = New System.Drawing.Size(74, 21)
        Me.txtStorageGroupID.TabIndex = 10
        '
        'txtStorageGroupName
        '
        Me.txtStorageGroupName.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageGroupName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageGroupName.Location = New System.Drawing.Point(183, 212)
        Me.txtStorageGroupName.Name = "txtStorageGroupName"
        Me.txtStorageGroupName.ReadOnly = True
        Me.txtStorageGroupName.Size = New System.Drawing.Size(303, 21)
        Me.txtStorageGroupName.TabIndex = 11
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(22, 216)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 173
        Me.Label8.Text = "Storage"
        '
        'cboQueueType
        '
        Me.cboQueueType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQueueType.Enabled = False
        Me.cboQueueType.FormattingEnabled = True
        Me.cboQueueType.Location = New System.Drawing.Point(110, 16)
        Me.cboQueueType.Name = "cboQueueType"
        Me.cboQueueType.Size = New System.Drawing.Size(176, 21)
        Me.cboQueueType.TabIndex = 0
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(22, 20)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(66, 13)
        Me.Label13.TabIndex = 170
        Me.Label13.Text = "Queue Type"
        '
        'txtItemCode
        '
        Me.txtItemCode.BackColor = System.Drawing.Color.LightYellow
        Me.txtItemCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtItemCode.Location = New System.Drawing.Point(110, 43)
        Me.txtItemCode.Name = "txtItemCode"
        Me.txtItemCode.ReadOnly = True
        Me.txtItemCode.Size = New System.Drawing.Size(176, 21)
        Me.txtItemCode.TabIndex = 3
        '
        'txtItemName
        '
        Me.txtItemName.BackColor = System.Drawing.Color.LightYellow
        Me.txtItemName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtItemName.Location = New System.Drawing.Point(110, 64)
        Me.txtItemName.Multiline = True
        Me.txtItemName.Name = "txtItemName"
        Me.txtItemName.ReadOnly = True
        Me.txtItemName.Size = New System.Drawing.Size(376, 61)
        Me.txtItemName.TabIndex = 4
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(22, 48)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(29, 13)
        Me.Label14.TabIndex = 169
        Me.Label14.Text = "Item"
        '
        'txtQueueFlowID
        '
        Me.txtQueueFlowID.BackColor = System.Drawing.Color.LightYellow
        Me.txtQueueFlowID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtQueueFlowID.Location = New System.Drawing.Point(110, 131)
        Me.txtQueueFlowID.Name = "txtQueueFlowID"
        Me.txtQueueFlowID.ReadOnly = True
        Me.txtQueueFlowID.Size = New System.Drawing.Size(74, 21)
        Me.txtQueueFlowID.TabIndex = 5
        '
        'txtQueueFlowName
        '
        Me.txtQueueFlowName.BackColor = System.Drawing.Color.LightYellow
        Me.txtQueueFlowName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtQueueFlowName.Location = New System.Drawing.Point(183, 131)
        Me.txtQueueFlowName.Name = "txtQueueFlowName"
        Me.txtQueueFlowName.ReadOnly = True
        Me.txtQueueFlowName.Size = New System.Drawing.Size(303, 21)
        Me.txtQueueFlowName.TabIndex = 6
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(22, 135)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(64, 13)
        Me.Label12.TabIndex = 161
        Me.Label12.Text = "Queue Flow"
        '
        'txtWBProgramID
        '
        Me.txtWBProgramID.BackColor = System.Drawing.Color.LightYellow
        Me.txtWBProgramID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWBProgramID.Location = New System.Drawing.Point(110, 158)
        Me.txtWBProgramID.Name = "txtWBProgramID"
        Me.txtWBProgramID.ReadOnly = True
        Me.txtWBProgramID.Size = New System.Drawing.Size(74, 21)
        Me.txtWBProgramID.TabIndex = 7
        '
        'chkIsRepeat
        '
        Me.chkIsRepeat.Enabled = False
        Me.chkIsRepeat.Location = New System.Drawing.Point(411, 16)
        Me.chkIsRepeat.Name = "chkIsRepeat"
        Me.chkIsRepeat.Properties.Caption = "Repeat?"
        Me.chkIsRepeat.Size = New System.Drawing.Size(75, 19)
        Me.chkIsRepeat.TabIndex = 2
        '
        'chkIsFreePass
        '
        Me.chkIsFreePass.Enabled = False
        Me.chkIsFreePass.Location = New System.Drawing.Point(323, 16)
        Me.chkIsFreePass.Name = "chkIsFreePass"
        Me.chkIsFreePass.Properties.Caption = "Free Pass?"
        Me.chkIsFreePass.Size = New System.Drawing.Size(75, 19)
        Me.chkIsFreePass.TabIndex = 1
        '
        'txtWBProgramName
        '
        Me.txtWBProgramName.BackColor = System.Drawing.Color.LightYellow
        Me.txtWBProgramName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWBProgramName.Location = New System.Drawing.Point(183, 158)
        Me.txtWBProgramName.Name = "txtWBProgramName"
        Me.txtWBProgramName.ReadOnly = True
        Me.txtWBProgramName.Size = New System.Drawing.Size(303, 21)
        Me.txtWBProgramName.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(22, 162)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(66, 13)
        Me.Label10.TabIndex = 144
        Me.Label10.Text = "WB Program"
        '
        'txtWBNumber
        '
        Me.txtWBNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtWBNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWBNumber.Location = New System.Drawing.Point(110, 185)
        Me.txtWBNumber.Name = "txtWBNumber"
        Me.txtWBNumber.ReadOnly = True
        Me.txtWBNumber.Size = New System.Drawing.Size(376, 21)
        Me.txtWBNumber.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(22, 189)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(63, 13)
        Me.Label9.TabIndex = 143
        Me.Label9.Text = "WB Number"
        '
        'tpQueueFlow
        '
        Me.tpQueueFlow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpQueueFlow.Controls.Add(Me.grdQueueFlow)
        Me.tpQueueFlow.Location = New System.Drawing.Point(4, 25)
        Me.tpQueueFlow.Name = "tpQueueFlow"
        Me.tpQueueFlow.Size = New System.Drawing.Size(520, 338)
        Me.tpQueueFlow.TabIndex = 1
        Me.tpQueueFlow.Text = "Queue Flow - F3"
        Me.tpQueueFlow.UseVisualStyleBackColor = True
        '
        'grdQueueFlow
        '
        Me.grdQueueFlow.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdQueueFlow.Location = New System.Drawing.Point(0, 0)
        Me.grdQueueFlow.MainView = Me.grdQueueFlowView
        Me.grdQueueFlow.Name = "grdQueueFlow"
        Me.grdQueueFlow.Size = New System.Drawing.Size(516, 334)
        Me.grdQueueFlow.TabIndex = 0
        Me.grdQueueFlow.UseEmbeddedNavigator = True
        Me.grdQueueFlow.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdQueueFlowView})
        '
        'grdQueueFlowView
        '
        Me.grdQueueFlowView.GridControl = Me.grdQueueFlow
        Me.grdQueueFlowView.Name = "grdQueueFlowView"
        Me.grdQueueFlowView.OptionsCustomization.AllowColumnMoving = False
        Me.grdQueueFlowView.OptionsCustomization.AllowGroup = False
        Me.grdQueueFlowView.OptionsView.ColumnAutoWidth = False
        Me.grdQueueFlowView.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never
        Me.grdQueueFlowView.OptionsView.ShowGroupPanel = False
        '
        'tpStatus
        '
        Me.tpStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpStatus.Controls.Add(Me.grdStatus)
        Me.tpStatus.Location = New System.Drawing.Point(4, 25)
        Me.tpStatus.Name = "tpStatus"
        Me.tpStatus.Size = New System.Drawing.Size(520, 338)
        Me.tpStatus.TabIndex = 2
        Me.tpStatus.Text = "Status - F4"
        Me.tpStatus.UseVisualStyleBackColor = True
        '
        'grdStatus
        '
        Me.grdStatus.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdStatus.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdStatus.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdStatus.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdStatus.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdStatus.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdStatus.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdStatus.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdStatus.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdStatus.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdStatus.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdStatus.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdStatus.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdStatus.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdStatus.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdStatus.Location = New System.Drawing.Point(0, 0)
        Me.grdStatus.MainView = Me.grdStatusView
        Me.grdStatus.Name = "grdStatus"
        Me.grdStatus.Size = New System.Drawing.Size(516, 334)
        Me.grdStatus.TabIndex = 0
        Me.grdStatus.UseEmbeddedNavigator = True
        Me.grdStatus.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdStatusView})
        '
        'grdStatusView
        '
        Me.grdStatusView.GridControl = Me.grdStatus
        Me.grdStatusView.Name = "grdStatusView"
        Me.grdStatusView.OptionsCustomization.AllowColumnMoving = False
        Me.grdStatusView.OptionsCustomization.AllowGroup = False
        Me.grdStatusView.OptionsView.ColumnAutoWidth = False
        Me.grdStatusView.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never
        Me.grdStatusView.OptionsView.ShowGroupPanel = False
        '
        'txtStorageID
        '
        Me.txtStorageID.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageID.Location = New System.Drawing.Point(110, 233)
        Me.txtStorageID.Name = "txtStorageID"
        Me.txtStorageID.ReadOnly = True
        Me.txtStorageID.Size = New System.Drawing.Size(74, 21)
        Me.txtStorageID.TabIndex = 12
        '
        'txtStorageName
        '
        Me.txtStorageName.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageName.Location = New System.Drawing.Point(183, 233)
        Me.txtStorageName.Name = "txtStorageName"
        Me.txtStorageName.ReadOnly = True
        Me.txtStorageName.Size = New System.Drawing.Size(303, 21)
        Me.txtStorageName.TabIndex = 13
        '
        'frmTraQueueDet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(528, 411)
        Me.Controls.Add(Me.tcQueue)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.lblInfo)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTraQueueDet"
        Me.Text = "Queue"
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.tcQueue.ResumeLayout(False)
        Me.tpMain.ResumeLayout(False)
        Me.tpMain.PerformLayout()
        Me.tpConfirm.ResumeLayout(False)
        Me.tpConfirm.PerformLayout()
        CType(Me.chkIsRepeat.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkIsFreePass.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpQueueFlow.ResumeLayout(False)
        CType(Me.grdQueueFlow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdQueueFlowView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpStatus.ResumeLayout(False)
        CType(Me.grdStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdStatusView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripEmpty As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogInc As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogBy As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogDate As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tcQueue As System.Windows.Forms.TabControl
    Friend WithEvents tpMain As System.Windows.Forms.TabPage
    Friend WithEvents tpQueueFlow As System.Windows.Forms.TabPage
    Friend WithEvents tpStatus As System.Windows.Forms.TabPage
    Friend WithEvents grdQueueFlow As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdQueueFlowView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents grdStatus As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdStatusView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents txtRemarks As QMS.usTextBox
    Friend WithEvents txtRFID As QMS.usTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSPBNumber As QMS.usTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnDriver As System.Windows.Forms.Button
    Friend WithEvents txtDriverFullName As QMS.usTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPlatNumber As QMS.usTextBox
    Friend WithEvents txtDriverID As QMS.usTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTicketParkingID As QMS.usTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpQueueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtID As QMS.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtQueueNumber As QMS.usTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboStatus As QMSLib.usComboBox
    Friend WithEvents lblIDStatus As System.Windows.Forms.Label
    Friend WithEvents txtReferencesID As QMS.usTextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents tpConfirm As System.Windows.Forms.TabPage
    Friend WithEvents txtWBProgramID As QMS.usTextBox
    Friend WithEvents chkIsRepeat As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkIsFreePass As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents txtWBProgramName As QMS.usTextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtWBNumber As QMS.usTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtQueueFlowID As QMS.usTextBox
    Friend WithEvents txtQueueFlowName As QMS.usTextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cboQueueType As QMSLib.usComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtItemCode As QMS.usTextBox
    Friend WithEvents txtItemName As QMS.usTextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtStorageGroupID As QMS.usTextBox
    Friend WithEvents txtStorageGroupName As QMS.usTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblRFIDStatus As System.Windows.Forms.Label
    Friend WithEvents txtStorageID As QMS.usTextBox
    Friend WithEvents txtStorageName As QMS.usTextBox
End Class
