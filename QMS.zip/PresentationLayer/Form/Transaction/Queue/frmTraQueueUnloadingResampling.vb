﻿Public Class frmTraQueueUnloadingResampling

#Region "Property Handle"

    Property pubIsSave As Boolean = False
    Property pubPlatNumber As String
    Property pubStationID As Integer
    Property pubStationName As String
    Property pubSubStationID As Integer
    Property pubSubStationName As String
    Property pubCS As VO.CS
    Property pubComLocDivSubDivIDStorage As Integer = 0
    Property pubProgramIDStorageID As String = ""
    Property pubStorageGroupID As String = ""
    Property pubStorageID As String = ""
    Private frmParent As frmTraQueueUnloading
    Private clsStation As VO.Station
    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvFillComboStation()
        Dim dtData As New DataTable
        Try
            dtData = BL.Station.ListData
            UI.usForm.FillComboBox(cboStation, dtData, "ID", "Description")
            cboStation.SelectedValue = VO.Station.Values.Laboratory
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Station")
        End Try
    End Sub

    Private Sub prvFillComboSubStation()
        Dim dtData As New DataTable
        Try
            clsStation = BL.Station.GetDetail(cboStation.SelectedValue)
            Dim isLinkedTank As VO.SubStation.FilterIsLinkedStorage = IIf(clsStation.IsLinkStorage, VO.SubStation.FilterIsLinkedStorage.IsLinkedStorage, VO.SubStation.FilterIsLinkedStorage.All)
            dtData = BL.SubStation.ListData(pubCS.CompanyID, pubCS.LocationID, cboStation.SelectedValue, isLinkedTank, pubComLocDivSubDivIDStorage, pubProgramIDStorageID, pubStorageGroupID, pubStorageID)
            UI.usForm.FillComboBox(cboSubStation, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Substation")
        End Try
    End Sub

    Public Sub prvSave()
        If cboStation.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose station first")
            cboStation.Focus()
            Exit Sub
        ElseIf cboSubStation.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose substation first")
            cboSubStation.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Process resampling for Plat Number " & pubPlatNumber & "?") Then Exit Sub

        pubStationID = cboStation.SelectedValue
        pubStationName = cboStation.Text.Trim
        pubSubStationID = cboSubStation.SelectedValue
        pubSubStationName = cboSubStation.Text.Trim
        pubIsSave = True
        Me.Close()
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueUnloadingResampling_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmTraQueueUnloadingResampling_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "ADD"))
        prvFillComboStation()
        prvFillComboSubStation()
        AddHandler cboStation.SelectedIndexChanged, AddressOf cboStation_SelectedIndexChanged
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs)
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

    Private Sub cboStation_SelectedIndexChanged(sender As Object, e As EventArgs)
        prvFillComboSubStation()
    End Sub

#End Region

End Class