﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTraQueueRegister))
        Me.pnlRegister = New System.Windows.Forms.Panel()
        Me.lblRFIDStatus = New System.Windows.Forms.Label()
        Me.txtReferencesID = New QMS.usTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cboStatus = New QMSLib.usComboBox()
        Me.lblIDStatus = New System.Windows.Forms.Label()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.txtRemarks = New QMS.usTextBox()
        Me.txtRFID = New QMS.usTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSPBNumber = New QMS.usTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnDriver = New System.Windows.Forms.Button()
        Me.txtDriverFullName = New QMS.usTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPlatNumber = New QMS.usTextBox()
        Me.txtDriverID = New QMS.usTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTicketParkingID = New QMS.usTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpQueueDate = New System.Windows.Forms.DateTimePicker()
        Me.txtID = New QMS.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.ToolBar = New QMS.usToolBar()
        Me.BarSave = New System.Windows.Forms.ToolBarButton()
        Me.BarClose = New System.Windows.Forms.ToolBarButton()
        Me.pnlList = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.grdMain = New DevExpress.XtraGrid.GridControl()
        Me.grdView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.ToolBarList = New QMS.usToolBar()
        Me.BarDetail = New System.Windows.Forms.ToolBarButton()
        Me.BarDelete = New System.Windows.Forms.ToolBarButton()
        Me.BarSep1 = New System.Windows.Forms.ToolBarButton()
        Me.BarVerify = New System.Windows.Forms.ToolBarButton()
        Me.BarCancelVerify = New System.Windows.Forms.ToolBarButton()
        Me.BarSep2 = New System.Windows.Forms.ToolBarButton()
        Me.BarFactoryIn = New System.Windows.Forms.ToolBarButton()
        Me.BarFactoryOut = New System.Windows.Forms.ToolBarButton()
        Me.BarSep4 = New System.Windows.Forms.ToolBarButton()
        Me.BarComplete = New System.Windows.Forms.ToolBarButton()
        Me.BarCancelComplete = New System.Windows.Forms.ToolBarButton()
        Me.BarSep3 = New System.Windows.Forms.ToolBarButton()
        Me.BarRefresh = New System.Windows.Forms.ToolBarButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.progressBar = New DevExpress.XtraWaitForm.ProgressPanel()
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.tableMain = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlRegister.SuspendLayout()
        Me.pnlList.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.tableMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlRegister
        '
        Me.pnlRegister.AutoScroll = True
        Me.pnlRegister.Controls.Add(Me.lblRFIDStatus)
        Me.pnlRegister.Controls.Add(Me.txtReferencesID)
        Me.pnlRegister.Controls.Add(Me.Label11)
        Me.pnlRegister.Controls.Add(Me.cboStatus)
        Me.pnlRegister.Controls.Add(Me.lblIDStatus)
        Me.pnlRegister.Controls.Add(Me.lblRemarks)
        Me.pnlRegister.Controls.Add(Me.txtRemarks)
        Me.pnlRegister.Controls.Add(Me.txtRFID)
        Me.pnlRegister.Controls.Add(Me.Label6)
        Me.pnlRegister.Controls.Add(Me.txtSPBNumber)
        Me.pnlRegister.Controls.Add(Me.Label5)
        Me.pnlRegister.Controls.Add(Me.btnDriver)
        Me.pnlRegister.Controls.Add(Me.txtDriverFullName)
        Me.pnlRegister.Controls.Add(Me.Label4)
        Me.pnlRegister.Controls.Add(Me.txtPlatNumber)
        Me.pnlRegister.Controls.Add(Me.txtDriverID)
        Me.pnlRegister.Controls.Add(Me.Label3)
        Me.pnlRegister.Controls.Add(Me.txtTicketParkingID)
        Me.pnlRegister.Controls.Add(Me.Label2)
        Me.pnlRegister.Controls.Add(Me.Label1)
        Me.pnlRegister.Controls.Add(Me.dtpQueueDate)
        Me.pnlRegister.Controls.Add(Me.txtID)
        Me.pnlRegister.Controls.Add(Me.lblID)
        Me.pnlRegister.Controls.Add(Me.lblInfo)
        Me.pnlRegister.Controls.Add(Me.ToolBar)
        Me.pnlRegister.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlRegister.Location = New System.Drawing.Point(0, 0)
        Me.pnlRegister.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlRegister.Name = "pnlRegister"
        Me.pnlRegister.Size = New System.Drawing.Size(612, 612)
        Me.pnlRegister.TabIndex = 0
        '
        'lblRFIDStatus
        '
        Me.lblRFIDStatus.AutoSize = True
        Me.lblRFIDStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblRFIDStatus.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.lblRFIDStatus.ForeColor = System.Drawing.Color.OrangeRed
        Me.lblRFIDStatus.Location = New System.Drawing.Point(401, 273)
        Me.lblRFIDStatus.Name = "lblRFIDStatus"
        Me.lblRFIDStatus.Size = New System.Drawing.Size(104, 22)
        Me.lblRFIDStatus.TabIndex = 156
        Me.lblRFIDStatus.Text = "RFID Status"
        Me.lblRFIDStatus.Visible = False
        '
        'txtReferencesID
        '
        Me.txtReferencesID.BackColor = System.Drawing.Color.LightYellow
        Me.txtReferencesID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtReferencesID.Location = New System.Drawing.Point(194, 432)
        Me.txtReferencesID.Name = "txtReferencesID"
        Me.txtReferencesID.ReadOnly = True
        Me.txtReferencesID.Size = New System.Drawing.Size(205, 28)
        Me.txtReferencesID.TabIndex = 13
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(26, 436)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(107, 22)
        Me.Label11.TabIndex = 155
        Me.Label11.Text = "Referensi ID"
        '
        'cboStatus
        '
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.Enabled = False
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(194, 398)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(205, 29)
        Me.cboStatus.TabIndex = 12
        '
        'lblIDStatus
        '
        Me.lblIDStatus.AutoSize = True
        Me.lblIDStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblIDStatus.ForeColor = System.Drawing.Color.Black
        Me.lblIDStatus.Location = New System.Drawing.Point(26, 402)
        Me.lblIDStatus.Name = "lblIDStatus"
        Me.lblIDStatus.Size = New System.Drawing.Size(59, 22)
        Me.lblIDStatus.TabIndex = 154
        Me.lblIDStatus.Text = "Status"
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.BackColor = System.Drawing.Color.Transparent
        Me.lblRemarks.ForeColor = System.Drawing.Color.Black
        Me.lblRemarks.Location = New System.Drawing.Point(26, 337)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(99, 22)
        Me.lblRemarks.TabIndex = 152
        Me.lblRemarks.Text = "Keterangan"
        '
        'txtRemarks
        '
        Me.txtRemarks.BackColor = System.Drawing.Color.White
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Location = New System.Drawing.Point(194, 334)
        Me.txtRemarks.MaxLength = 250
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(375, 60)
        Me.txtRemarks.TabIndex = 11
        '
        'txtRFID
        '
        Me.txtRFID.BackColor = System.Drawing.Color.White
        Me.txtRFID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRFID.Location = New System.Drawing.Point(194, 269)
        Me.txtRFID.MaxLength = 20
        Me.txtRFID.Name = "txtRFID"
        Me.txtRFID.Size = New System.Drawing.Size(205, 28)
        Me.txtRFID.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(26, 274)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 22)
        Me.Label6.TabIndex = 151
        Me.Label6.Text = "RFID"
        '
        'txtSPBNumber
        '
        Me.txtSPBNumber.BackColor = System.Drawing.Color.White
        Me.txtSPBNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSPBNumber.Location = New System.Drawing.Point(194, 237)
        Me.txtSPBNumber.MaxLength = 150
        Me.txtSPBNumber.Name = "txtSPBNumber"
        Me.txtSPBNumber.Size = New System.Drawing.Size(375, 28)
        Me.txtSPBNumber.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(26, 241)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 22)
        Me.Label5.TabIndex = 150
        Me.Label5.Text = "Nomor SPB"
        '
        'btnDriver
        '
        Me.btnDriver.BackColor = System.Drawing.Color.Transparent
        Me.btnDriver.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDriver.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDriver.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDriver.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnDriver.Image = CType(resources.GetObject("btnDriver.Image"), System.Drawing.Image)
        Me.btnDriver.Location = New System.Drawing.Point(405, 179)
        Me.btnDriver.Name = "btnDriver"
        Me.btnDriver.Size = New System.Drawing.Size(19, 20)
        Me.btnDriver.TabIndex = 6
        Me.btnDriver.TabStop = False
        Me.btnDriver.UseVisualStyleBackColor = False
        '
        'txtDriverFullName
        '
        Me.txtDriverFullName.BackColor = System.Drawing.Color.AliceBlue
        Me.txtDriverFullName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDriverFullName.Location = New System.Drawing.Point(194, 205)
        Me.txtDriverFullName.MaxLength = 250
        Me.txtDriverFullName.Name = "txtDriverFullName"
        Me.txtDriverFullName.ReadOnly = True
        Me.txtDriverFullName.Size = New System.Drawing.Size(375, 28)
        Me.txtDriverFullName.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(26, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 22)
        Me.Label4.TabIndex = 148
        Me.Label4.Text = "Supir"
        '
        'txtPlatNumber
        '
        Me.txtPlatNumber.BackColor = System.Drawing.Color.White
        Me.txtPlatNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlatNumber.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold)
        Me.txtPlatNumber.Location = New System.Drawing.Point(194, 301)
        Me.txtPlatNumber.MaxLength = 10
        Me.txtPlatNumber.Name = "txtPlatNumber"
        Me.txtPlatNumber.Size = New System.Drawing.Size(205, 28)
        Me.txtPlatNumber.TabIndex = 10
        '
        'txtDriverID
        '
        Me.txtDriverID.BackColor = System.Drawing.Color.AliceBlue
        Me.txtDriverID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDriverID.Location = New System.Drawing.Point(194, 177)
        Me.txtDriverID.MaxLength = 250
        Me.txtDriverID.Name = "txtDriverID"
        Me.txtDriverID.ReadOnly = True
        Me.txtDriverID.Size = New System.Drawing.Size(205, 28)
        Me.txtDriverID.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(26, 304)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 22)
        Me.Label3.TabIndex = 149
        Me.Label3.Text = "Nomor Plat"
        '
        'txtTicketParkingID
        '
        Me.txtTicketParkingID.BackColor = System.Drawing.Color.LightYellow
        Me.txtTicketParkingID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTicketParkingID.Location = New System.Drawing.Point(194, 114)
        Me.txtTicketParkingID.Name = "txtTicketParkingID"
        Me.txtTicketParkingID.ReadOnly = True
        Me.txtTicketParkingID.Size = New System.Drawing.Size(205, 28)
        Me.txtTicketParkingID.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(26, 117)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 22)
        Me.Label2.TabIndex = 147
        Me.Label2.Text = "Nomor Tiket Parkir"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(26, 149)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 22)
        Me.Label1.TabIndex = 146
        Me.Label1.Text = "Tanggal Antrian"
        '
        'dtpQueueDate
        '
        Me.dtpQueueDate.CustomFormat = "dd/MM/yyyy HH:mm:ss"
        Me.dtpQueueDate.Enabled = False
        Me.dtpQueueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpQueueDate.Location = New System.Drawing.Point(194, 146)
        Me.dtpQueueDate.Name = "dtpQueueDate"
        Me.dtpQueueDate.Size = New System.Drawing.Size(205, 28)
        Me.dtpQueueDate.TabIndex = 4
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Location = New System.Drawing.Point(194, 82)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(205, 28)
        Me.txtID.TabIndex = 2
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(26, 85)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(29, 22)
        Me.lblID.TabIndex = 145
        Me.lblID.Text = "ID"
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 28)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(612, 35)
        Me.lblInfo.TabIndex = 1
        Me.lblInfo.Text = "« Detil Antrian"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarSave, Me.BarClose})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(612, 28)
        Me.ToolBar.TabIndex = 0
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarSave
        '
        Me.BarSave.Name = "BarSave"
        Me.BarSave.Tag = "Save"
        Me.BarSave.Text = "Simpan"
        '
        'BarClose
        '
        Me.BarClose.Name = "BarClose"
        Me.BarClose.Tag = "Close"
        Me.BarClose.Text = "Tutup"
        '
        'pnlList
        '
        Me.pnlList.Controls.Add(Me.Panel2)
        Me.pnlList.Controls.Add(Me.Panel1)
        Me.pnlList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlList.Location = New System.Drawing.Point(612, 0)
        Me.pnlList.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlList.Name = "pnlList"
        Me.pnlList.Size = New System.Drawing.Size(750, 612)
        Me.pnlList.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = True
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.grdMain)
        Me.Panel2.Controls.Add(Me.ToolBarList)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 114)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(750, 498)
        Me.Panel2.TabIndex = 4
        '
        'grdMain
        '
        Me.grdMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdMain.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdMain.Location = New System.Drawing.Point(0, 33)
        Me.grdMain.MainView = Me.grdView
        Me.grdMain.Name = "grdMain"
        Me.grdMain.Size = New System.Drawing.Size(746, 461)
        Me.grdMain.TabIndex = 1
        Me.grdMain.UseEmbeddedNavigator = True
        Me.grdMain.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdView, Me.GridView1})
        '
        'grdView
        '
        Me.grdView.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.grdView.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.grdView.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.grdView.Appearance.FilterPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.FilterPanel.Options.UseFont = True
        Me.grdView.Appearance.FixedLine.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.FixedLine.Options.UseFont = True
        Me.grdView.Appearance.FocusedCell.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.FocusedCell.Options.UseFont = True
        Me.grdView.Appearance.FocusedRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.FocusedRow.Options.UseFont = True
        Me.grdView.Appearance.FooterPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.FooterPanel.Options.UseFont = True
        Me.grdView.Appearance.GroupButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.GroupButton.Options.UseFont = True
        Me.grdView.Appearance.GroupFooter.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.GroupFooter.Options.UseFont = True
        Me.grdView.Appearance.GroupPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.GroupPanel.Options.UseFont = True
        Me.grdView.Appearance.GroupRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.GroupRow.Options.UseFont = True
        Me.grdView.Appearance.HeaderPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.HeaderPanel.Options.UseFont = True
        Me.grdView.Appearance.Row.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.Row.Options.UseFont = True
        Me.grdView.Appearance.SelectedRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdView.Appearance.SelectedRow.Options.UseFont = True
        Me.grdView.GridControl = Me.grdMain
        Me.grdView.Name = "grdView"
        Me.grdView.OptionsCustomization.AllowColumnMoving = False
        Me.grdView.OptionsCustomization.AllowGroup = False
        Me.grdView.OptionsView.ColumnAutoWidth = False
        Me.grdView.OptionsView.ShowAutoFilterRow = True
        Me.grdView.OptionsView.ShowGroupPanel = False
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.grdMain
        Me.GridView1.Name = "GridView1"
        '
        'ToolBarList
        '
        Me.ToolBarList.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBarList.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarDetail, Me.BarDelete, Me.BarSep1, Me.BarVerify, Me.BarCancelVerify, Me.BarSep2, Me.BarFactoryIn, Me.BarFactoryOut, Me.BarSep4, Me.BarComplete, Me.BarCancelComplete, Me.BarSep3, Me.BarRefresh})
        Me.ToolBarList.DropDownArrows = True
        Me.ToolBarList.Location = New System.Drawing.Point(0, 0)
        Me.ToolBarList.Name = "ToolBarList"
        Me.ToolBarList.ShowToolTips = True
        Me.ToolBarList.Size = New System.Drawing.Size(746, 33)
        Me.ToolBarList.TabIndex = 0
        Me.ToolBarList.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarDetail
        '
        Me.BarDetail.Name = "BarDetail"
        Me.BarDetail.Tag = "Detail"
        Me.BarDetail.Text = "Edit"
        '
        'BarDelete
        '
        Me.BarDelete.Name = "BarDelete"
        Me.BarDelete.Tag = "Delete"
        Me.BarDelete.Text = "Hapus"
        '
        'BarSep1
        '
        Me.BarSep1.Name = "BarSep1"
        Me.BarSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarVerify
        '
        Me.BarVerify.Name = "BarVerify"
        Me.BarVerify.Tag = "Submit"
        Me.BarVerify.Text = "Verifikasi"
        '
        'BarCancelVerify
        '
        Me.BarCancelVerify.Name = "BarCancelVerify"
        Me.BarCancelVerify.Tag = "Unapproved"
        Me.BarCancelVerify.Text = "Batal Verifikasi"
        '
        'BarSep2
        '
        Me.BarSep2.Name = "BarSep2"
        Me.BarSep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarFactoryIn
        '
        Me.BarFactoryIn.Name = "BarFactoryIn"
        Me.BarFactoryIn.Tag = "TruckIn"
        Me.BarFactoryIn.Text = "Masuk Pabrik"
        '
        'BarFactoryOut
        '
        Me.BarFactoryOut.Name = "BarFactoryOut"
        Me.BarFactoryOut.Tag = "TruckOut"
        Me.BarFactoryOut.Text = "Keluar Pabrik"
        '
        'BarSep4
        '
        Me.BarSep4.Name = "BarSep4"
        Me.BarSep4.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarComplete
        '
        Me.BarComplete.Name = "BarComplete"
        Me.BarComplete.Tag = "Checked"
        Me.BarComplete.Text = "Selesai"
        '
        'BarCancelComplete
        '
        Me.BarCancelComplete.Name = "BarCancelComplete"
        Me.BarCancelComplete.Tag = "Cancel"
        Me.BarCancelComplete.Text = "Batal Selesai"
        '
        'BarSep3
        '
        Me.BarSep3.Name = "BarSep3"
        Me.BarSep3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarRefresh
        '
        Me.BarRefresh.Name = "BarRefresh"
        Me.BarRefresh.Tag = "Refresh"
        Me.BarRefresh.Text = "Refresh"
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.progressBar)
        Me.Panel1.Controls.Add(Me.dtpDateTo)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.dtpDateFrom)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(750, 114)
        Me.Panel1.TabIndex = 0
        '
        'progressBar
        '
        Me.progressBar.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.progressBar.Appearance.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.progressBar.Appearance.Options.UseBackColor = True
        Me.progressBar.Appearance.Options.UseFont = True
        Me.progressBar.AppearanceCaption.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.progressBar.AppearanceCaption.Options.UseFont = True
        Me.progressBar.AppearanceDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.progressBar.AppearanceDescription.Options.UseFont = True
        Me.progressBar.Location = New System.Drawing.Point(521, 27)
        Me.progressBar.Name = "progressBar"
        Me.progressBar.Size = New System.Drawing.Size(156, 66)
        Me.progressBar.TabIndex = 23
        Me.progressBar.Text = "ProgressPanel1"
        Me.progressBar.Visible = False
        '
        'dtpDateTo
        '
        Me.dtpDateTo.CustomFormat = "dd/MM/yyyy"
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateTo.Location = New System.Drawing.Point(371, 49)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(110, 28)
        Me.dtpDateTo.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DimGray
        Me.Label8.Location = New System.Drawing.Point(330, 52)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 22)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "s.d"
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CustomFormat = "dd/MM/yyyy"
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(212, 49)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(113, 28)
        Me.dtpDateFrom.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DimGray
        Me.Label9.Location = New System.Drawing.Point(40, 51)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(154, 22)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Tanggal Antrian"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label15.Location = New System.Drawing.Point(19, 14)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(232, 22)
        Me.Label15.TabIndex = 10
        Me.Label15.Text = "Filter data berdasarkan :"
        '
        'tableMain
        '
        Me.tableMain.ColumnCount = 2
        Me.tableMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.tableMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
        Me.tableMain.Controls.Add(Me.pnlList, 1, 0)
        Me.tableMain.Controls.Add(Me.pnlRegister, 0, 0)
        Me.tableMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tableMain.Location = New System.Drawing.Point(0, 0)
        Me.tableMain.Name = "tableMain"
        Me.tableMain.RowCount = 1
        Me.tableMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tableMain.Size = New System.Drawing.Size(1362, 612)
        Me.tableMain.TabIndex = 0
        '
        'frmTraQueueRegister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 612)
        Me.Controls.Add(Me.tableMain)
        Me.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmTraQueueRegister"
        Me.Text = "Daftar Antrian"
        Me.pnlRegister.ResumeLayout(False)
        Me.pnlRegister.PerformLayout()
        Me.pnlList.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.tableMain.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlRegister As System.Windows.Forms.Panel
    Friend WithEvents ToolBar As QMS.usToolBar
    Friend WithEvents BarSave As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton
    Friend WithEvents pnlList As System.Windows.Forms.Panel
    Friend WithEvents grdMain As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents tableMain As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtReferencesID As QMS.usTextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cboStatus As QMSLib.usComboBox
    Friend WithEvents lblIDStatus As System.Windows.Forms.Label
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents txtRemarks As QMS.usTextBox
    Friend WithEvents txtRFID As QMS.usTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSPBNumber As QMS.usTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnDriver As System.Windows.Forms.Button
    Friend WithEvents txtDriverFullName As QMS.usTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPlatNumber As QMS.usTextBox
    Friend WithEvents txtDriverID As QMS.usTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTicketParkingID As QMS.usTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpQueueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtID As QMS.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents progressBar As DevExpress.XtraWaitForm.ProgressPanel
    Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ToolBarList As QMS.usToolBar
    Friend WithEvents BarDetail As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarDelete As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarVerify As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarCancelVerify As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarRefresh As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarComplete As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarCancelComplete As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents lblRFIDStatus As System.Windows.Forms.Label
    Friend WithEvents BarFactoryIn As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarFactoryOut As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep4 As System.Windows.Forms.ToolBarButton
End Class
