﻿Public Class frmTraQueueChangeRFID

#Region "Property Handle"

    Private WithEvents tmrWeighBridge As New Timer
    Property pubClsData As VO.Queue
    Private frmParent As frmTraQueue
    Private clsData As VO.Queue
    Private intCount As Integer = 0
    Private bolSuccessSettingSerialPort As Boolean = False

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvFillForm()
        Try
            txtID.Text = pubClsData.ID
            dtpQueueDate.Value = pubClsData.QueueDate
            txtDriverID.Text = pubClsData.DriverID
            txtDriverFullName.Text = pubClsData.DriverFullName
            txtRFID.Text = pubClsData.RFID
            txtNewRFID.Focus()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Form")
        End Try
    End Sub

    Public Sub prvSave()
        If txtNewRFID.Text.Trim = "" Then
            UI.usForm.frmMessageBox("New RFID not allow blank")
            txtNewRFID.Focus()
            Exit Sub
        ElseIf txtRemarks.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Remarks not allow blank")
            txtRemarks.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        clsData = New VO.Queue
        clsData.ComLocDivSubDivID = pubClsData.ComLocDivSubDivID
        clsData.ID = pubClsData.ID
        clsData.RFID = txtRFID.Text.Trim
        clsData.NewRFID = txtNewRFID.Text.Trim
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID

        Try
            BL.Queue.ChangeRFID(clsData)
            UI.usForm.frmMessageBox("Save data success.")
            frmParent.pubRefresh(clsData.ID)
            Me.Close()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort1.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort1.IsOpen Then
                UI.usForm.usSerialPort1.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimer()
    End Sub

    Public Sub prvStartTimer()
        tmrWeighBridge.Enabled = True
        tmrWeighBridge.Interval = 1000
        tmrWeighBridge.Start()
    End Sub

    Public Sub prvStopTimer()
        tmrWeighBridge.Stop()
    End Sub

    Private Sub prvReadCard()
        Try

            If VO.DefaultServer.IsLinkRFIDDevice1 Then
                If Not UI.usForm.usSerialPort1.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort1 = UI.usForm.usSerialPort1.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort1.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Trim

            If VO.DefaultServer.IsLinkRFIDDevice1 Then VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Substring(1, VO.DefaultServer.RFIDValueCOMPort1.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort1.Trim = VO.DefaultServer.PrevRFIDValueCOMPort1.Trim And intCount <= 5 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1
            txtNewRFID.Text = VO.DefaultServer.RFIDValueCOMPort1.Trim
            intCount = 0
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueChangeRFID_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        If UI.usForm.usSerialPort1.IsOpen Then
            VO.DefaultServer.RFIDValueCOMPort1 = ""
            tmrWeighBridge.Dispose()
            UI.usForm.usSerialPort1.Dispose()
        End If
    End Sub

    Private Sub frmTraQueueChangeRFID_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F10 And VO.DefaultServer.IsLinkRFIDDevice1 = False Then
            Dim frmDetail As New frmSysTestInputRFID
            With frmDetail
                .pubPorts = VO.SubStation.Ports.COMPort1
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
            End With
        End If
    End Sub

    Private Sub frmTraQueueChangeRFID_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, "TRAQUEUERFID", "EDIT"))
        prvFillForm()

        If VO.DefaultServer.IsLinkRFIDDevice1 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort1, VO.DefaultServer.COMPort1)
            prvStartReadRFID()
        End If
    End Sub

    Private Sub tmrWeighBridge_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrWeighBridge.Tick
        prvReadCard()
    End Sub

#End Region

End Class