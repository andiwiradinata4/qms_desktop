﻿Public Class frmTraQueueDet

#Region "Property Handle"

    Private WithEvents tmrWeighBridge As New Timer
    Property pubID As String = ""
    Property pubIsSave As Boolean = False
    Property pubIsNew As Boolean = False
    Property pubCS As VO.CS
    Private frmParent As frmTraQueue
    Private clsData As VO.Queue
    Private bolSuccessSettingSerialPort As Boolean = False, bolIsRFIDValid As Boolean = True
    Private intCount As Integer = 0, intComLocDivSubDivIDStorage As Integer = 0
    Private strProgramIDStorage As String = ""

    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        '# Queue Flow
        UI.usForm.SetGrid(grdQueueFlowView, "ID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdQueueFlowView, "QueueID", "QueueID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdQueueFlowView, "Idx", "No", 100, UI.usDefGrid.gIntNum, True)
        UI.usForm.SetGrid(grdQueueFlowView, "IsLinkStorage", "IsLinkStorage", 100, UI.usDefGrid.gBoolean, False)
        UI.usForm.SetGrid(grdQueueFlowView, "StationID", "StationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "StationName", "Station", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "SubStationID", "SubStationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "SubStationName", "Substation", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "IsRequested", "Requested", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdQueueFlowView, "RequestedBy", "Requested By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "RequestedDate", "Requested Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdQueueFlowView, "IsDone", "Done", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdQueueFlowView, "DoneBy", "Done By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "DoneDate", "Done Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdQueueFlowView, "InternalRemarks", "Internal Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdQueueFlowView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)

        '# Status
        UI.usForm.SetGrid(grdStatusView, "Status", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdStatusView, "StatusBy", "Status By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdStatusView, "StatusDate", "Status Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdStatusView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
    End Sub

    Private Sub prvSetTitleForm()
        If pubIsNew Then
            Me.Text += " [new] "
        Else
            Me.Text += " [edit] "
        End If
    End Sub

    Private Sub prvFillComboQueueType()
        Dim dtData As New DataTable
        Try
            dtData = BL.QueueFlow.ListDataType()
            UI.usForm.FillComboBox(cboQueueType, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Queue Type")
        End Try
    End Sub

    Private Sub prvFillComboStatus()
        Dim dtData As New DataTable
        Try
            dtData = BL.Status.ListDataByModuleID(VO.Modules.Values.Queue)
            UI.usForm.FillComboBox(cboStatus, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Status")
        End Try
    End Sub

    Private Sub prvFillCombo()
        prvFillComboQueueType()
        prvFillComboStatus()
    End Sub

    Private Sub prvFillForm()
        Try
            prvFillCombo()
            If pubIsNew Then
                prvClear()
            Else
                clsData = New VO.Queue
                clsData = BL.Queue.GetDetail(pubID)
                txtID.Text = pubID
                dtpQueueDate.Value = clsData.QueueDate
                txtDriverID.Text = clsData.DriverID
                txtDriverFullName.Text = clsData.DriverFullName
                txtTicketParkingID.Text = clsData.TicketParkingID
                txtPlatNumber.Text = clsData.PlatNumber
                txtQueueNumber.Text = IIf(clsData.QueueNumber = 0, "", clsData.QueueNumber)
                txtSPBNumber.Text = clsData.SPBNumber
                txtRFID.Text = clsData.RFID
                txtRemarks.Text = clsData.Remarks
                cboStatus.SelectedValue = clsData.IDStatus
                cboQueueType.SelectedValue = clsData.QueueType
                txtItemCode.Text = clsData.ItemCode
                txtItemName.Text = clsData.ItemName
                txtQueueFlowID.Text = clsData.QueueFlowID
                txtQueueFlowName.Text = clsData.QueueFlowName
                txtWBProgramID.Text = clsData.WBProgramID
                txtWBProgramName.Text = clsData.WBProgramName
                txtWBNumber.Text = clsData.WBNumber
                txtReferencesID.Text = clsData.ReferencesID
                intComLocDivSubDivIDStorage = clsData.ComLocDivSubDivIDStorage
                strProgramIDStorage = clsData.ProgramIDStorage
                txtStorageGroupID.Text = clsData.StorageGroupID
                txtStorageGroupName.Text = clsData.StorageGroupName
                txtStorageID.Text = clsData.StorageID
                txtStorageName.Text = clsData.StorageName
                chkIsFreePass.Checked = clsData.IsFreePass
                chkIsRepeat.Checked = clsData.IsRepeat
                ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
                ToolStripLogBy.Text = "Last Log : " & clsData.LogBy
                ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Form")
        End Try
    End Sub

    Private Sub prvQuery()
        Try
            grdQueueFlow.DataSource = BL.Queue.ListDataDetail(pubID)
            grdQueueFlowView.BestFitColumns()

            grdStatus.DataSource = BL.Queue.ListDataStatus(pubID)
            grdStatusView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "List Data Queue Flow & Status")
        End Try
    End Sub

    Public Sub prvSave()
        If lblRFIDStatus.Visible = True Then Exit Sub
        txtID.Focus()
        If txtDriverID.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Driver not allow blank")
            tcQueue.SelectedTab = tpMain
            txtDriverID.Focus()
            Exit Sub
        ElseIf txtSPBNumber.Text.Trim = "" Then
            UI.usForm.frmMessageBox("SPB Number not allow blank")
            tcQueue.SelectedTab = tpMain
            txtSPBNumber.Focus()
            Exit Sub
        ElseIf txtRFID.Text.Trim = "" Then
            UI.usForm.frmMessageBox("RFID not allow blank")
            tcQueue.SelectedTab = tpMain
            txtRFID.Focus()
            Exit Sub
        ElseIf txtPlatNumber.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Plat Number not allow blank")
            tcQueue.SelectedTab = tpMain
            txtPlatNumber.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        clsData = New VO.Queue
        clsData.ComLocDivSubDivID = pubCS.ComLocDivSubDivID
        clsData.ID = pubID
        clsData.QueueDate = dtpQueueDate.Value
        clsData.TicketParkingID = txtTicketParkingID.Text.Trim
        clsData.PlatNumber = SharedLib.StringUtility.RemoveWhiteSpace(txtPlatNumber.Text.Trim)
        clsData.DriverID = txtDriverID.Text.Trim
        clsData.DriverFullName = txtDriverFullName.Text.Trim
        clsData.SPBNumber = txtSPBNumber.Text.Trim
        clsData.RFID = txtRFID.Text.Trim
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID

        Try
            BL.Queue.SaveData(pubIsNew, clsData)
            UI.usForm.frmMessageBox("Save data success." & IIf(pubIsNew, " ID: " & clsData.ID, ""))
            If pubIsNew Then
                prvClear()
                frmParent.pubRefresh(clsData.ID)
                prvQuery()
            Else
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        txtID.Text = pubID
        dtpQueueDate.Value = Now
        txtDriverID.Text = ""
        txtDriverFullName.Text = ""
        txtTicketParkingID.Text = "-"
        txtPlatNumber.Text = ""
        txtQueueNumber.Text = ""
        txtSPBNumber.Text = ""
        txtRFID.Text = ""
        txtRemarks.Text = ""
        cboStatus.SelectedValue = VO.Status.Values.Draft
        ToolStripLogInc.Text = "Log Inc : -"
        ToolStripLogBy.Text = "Last Log : -"
        ToolStripLogDate.Text = Format(Now, UI.usDefCons.DateFull)
    End Sub

    Private Sub prvChooseDriver()
        Dim frmDetail As New frmMstDriver
        With frmDetail
            .pubIsLookUp = True
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                txtDriverID.Text = .pubLUdtRow.Item("ID")
                txtDriverFullName.Text = .pubLUdtRow.Item("FullName")
            End If
        End With
    End Sub

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort1.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort1.IsOpen Then
                UI.usForm.usSerialPort1.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimer()
    End Sub

    Public Sub prvStartTimer()
        tmrWeighBridge.Enabled = True
        tmrWeighBridge.Interval = 1000
        tmrWeighBridge.Start()
    End Sub

    Public Sub prvStopTimer()
        tmrWeighBridge.Stop()
    End Sub

    Private Sub prvReadCard()
        Try
            If VO.DefaultServer.IsLinkRFIDDevice1 Then
                If Not UI.usForm.usSerialPort1.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort1 = UI.usForm.usSerialPort1.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort1.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Trim

            Dim clsRFID As VO.RFIDCard = BL.RFIDCard.RFIDExists(VO.DefaultServer.RFIDValueCOMPort1)

            If VO.DefaultServer.IsLinkRFIDDevice1 Then VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Substring(1, VO.DefaultServer.RFIDValueCOMPort1.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort1.Trim = VO.DefaultServer.PrevRFIDValueCOMPort1.Trim And intCount <= 5 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1
            txtRFID.Text = VO.DefaultServer.RFIDValueCOMPort1.Trim
            intCount = 0

            If clsRFID.ID = "" Then
                bolIsRFIDValid = False
                lblRFIDStatus.Text = "RFID not yet register"
                lblRFIDStatus.Visible = True
                UI.usForm.frmMessageBox(lblRFIDStatus.Text)
            ElseIf clsRFID.IDStatus = VO.Status.Values.InActive Then
                bolIsRFIDValid = False
                lblRFIDStatus.Text = "RFID is IN-ACTIVE"
                lblRFIDStatus.Visible = True
                UI.usForm.frmMessageBox(lblRFIDStatus.Text)
            Else
                lblRFIDStatus.Visible = False
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueDet_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        If UI.usForm.usSerialPort1.IsOpen Then
            VO.DefaultServer.RFIDValueCOMPort1 = ""
            tmrWeighBridge.Dispose()
            UI.usForm.usSerialPort1.Dispose()
        End If
    End Sub

    Private Sub frmTraQueueDet_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F1 Then
            tcQueue.SelectedTab = tpMain
        ElseIf e.KeyCode = Keys.F2 Then
            tcQueue.SelectedTab = tpConfirm
        ElseIf e.KeyCode = Keys.F3 Then
            tcQueue.SelectedTab = tpQueueFlow
        ElseIf e.KeyCode = Keys.F4 Then
            tcQueue.SelectedTab = tpStatus
        ElseIf e.KeyCode = Keys.F10 And VO.DefaultServer.IsLinkRFIDDevice1 = False Then
            Dim frmDetail As New frmSysTestInputRFID
            With frmDetail
                .pubPorts = VO.SubStation.Ports.COMPort1
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
            End With
        End If
    End Sub

    Private Sub frmTraQueueDet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, "TRAQUEUE", IIf(pubIsNew, "ADD", "EDIT")))
        prvSetGrid()
        prvSetTitleForm()
        prvFillForm()
        prvQuery()

        If VO.DefaultServer.IsLinkRFIDDevice1 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort1, VO.DefaultServer.COMPort1)
            If bolSuccessSettingSerialPort = False Then MsgBox("False setting serial port")
            prvStartReadRFID()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs)
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

    Private Sub btnDriver_Click(sender As Object, e As EventArgs) Handles btnDriver.Click
        prvChooseDriver()
    End Sub

    Private Sub tmrWeighBridge_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrWeighBridge.Tick
        prvReadCard()
    End Sub

#End Region

End Class