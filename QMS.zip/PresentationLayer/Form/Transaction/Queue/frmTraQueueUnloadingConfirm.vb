﻿Public Class frmTraQueueUnloadingConfirm

#Region "Property Handle"

    Property pubCS As VO.CS
    Property pubID As String
    Property pubQueueID As String
    Property pubComLocDivSubDivIDStorage As Integer = 0
    Property pubProgramIDStorage As String = ""
    Property pubStorageGroupID As String = ""
    Property pubStorageID As String = ""
    Private frmParent As frmTraQueueUnloading
    Private clsData As VO.Queue
    Private clsStation As VO.Station
    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvFillCombo()
        Dim dtStatus As New DataTable, dtSubStation As New DataTable
        Try
            '# Status
            dtStatus = BL.Status.ListDataByModuleID(VO.Modules.Values.QueueDetail)
            UI.usForm.FillComboBox(cboStatus, dtStatus, "ID", "Description")

            '# Substation
            clsStation = BL.Station.GetDetail(VO.Station.Values.Unloading)
            Dim isLinkedTank As VO.SubStation.FilterIsLinkedStorage = IIf(clsStation.IsLinkStorage, VO.SubStation.FilterIsLinkedStorage.IsLinkedStorage, VO.SubStation.FilterIsLinkedStorage.All)
            dtSubStation = BL.SubStation.ListData(pubCS.CompanyID, pubCS.LocationID, clsStation.ID, isLinkedTank, pubComLocDivSubDivIDStorage, pubProgramIDStorage, pubStorageGroupID, pubStorageID)
            UI.usForm.FillComboBox(cboSubstation, dtSubStation, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo")
        End Try
    End Sub

    Private Sub prvFillForm()
        Try
            prvFillCombo()
            clsData = New VO.Queue
            clsData = BL.Queue.GetDetailUnloadingConfirm(pubQueueID, pubID)
            txtPosition.Text = clsData.Position
            If clsData.QueueDetail.IsRequested Then chkOnHold.Checked = clsData.IsHold
            txtArrivalID.Text = clsData.WBNumber
            txtPlatNumber.Text = clsData.PlatNumber
            txtRemarks.Text = clsData.Remarks
            If clsData.QueueDetail.IsDone Then
                cboStatus.SelectedValue = VO.Status.Values.Done
            ElseIf clsData.QueueDetail.IsRequested Then
                cboStatus.SelectedValue = VO.Status.Values.Requested
            End If

            cboSubstation.SelectedValue = clsData.QueueDetail.SubStationID

            If clsData.QueueDetail.IsRequested Then cboSubstation.Enabled = False
            If clsData.Position.Trim <> "UNLOADING" Then btnSave.Enabled = False
            If cboStatus.SelectedValue = VO.Status.Values.Done Then chkOnHold.Enabled = True Else chkOnHold.Enabled = False
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Form")
        End Try
    End Sub

    Private Sub prvSave()
        txtPosition.Focus()

        If cboStatus.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose status first")
            cboStatus.Focus()
            Exit Sub
        ElseIf cboSubstation.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose substation first")
            cboSubstation.Focus()
            Exit Sub
        ElseIf chkOnHold.Checked AndAlso txtRemarks.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please fill remarks if onhold is checked")
            txtRemarks.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        Dim clsDetail As New VO.QueueDet
        clsDetail.ID = pubID
        clsDetail.StationID = VO.Station.Values.Unloading
        clsDetail.SubStationID = cboSubstation.SelectedValue
        clsDetail.SubStationName = cboSubstation.Text.Trim
        clsDetail.LogBy = UI.usUserApp.UserID
        clsDetail.Remarks = txtRemarks.Text.Trim

        clsData = New VO.Queue
        clsData.ID = pubQueueID
        clsData.IsHold = chkOnHold.Checked
        clsData.QueueDetail = clsDetail
        clsData.QueueDetail.IsRequested = IIf(cboStatus.SelectedValue = VO.Status.Values.Requested, True, False)
        clsData.QueueDetail.IsDone = IIf(cboStatus.SelectedValue = VO.Status.Values.Done, True, False)

        Try
            Dim bolSuccess As Boolean = BL.Queue.ConfirmUnloading(clsData)
            If bolSuccess Then
                UI.usForm.frmMessageBox("Save data success!")
                frmParent.pubRefresh(pubID)
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Save Data")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueUnloadingConfirm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvFillForm()
        AddHandler cboStatus.SelectedValueChanged, AddressOf cboStatus_SelectedValueChanged
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        prvSave()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub cboStatus_SelectedValueChanged(sender As Object, e As EventArgs)
        If cboStatus.SelectedValue = VO.Status.Values.Done Then chkOnHold.Enabled = True Else chkOnHold.Enabled = False
    End Sub

#End Region

End Class