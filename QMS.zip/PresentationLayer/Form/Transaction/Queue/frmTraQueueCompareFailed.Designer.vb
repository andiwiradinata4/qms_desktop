﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueCompareFailed
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTraQueueCompareFailed))
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.gboAcknowledge = New System.Windows.Forms.GroupBox()
        Me.txtPlatNumberAcknowledge = New QMS.usTextBox()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtRemarks = New QMS.usTextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnReGet = New DevExpress.XtraEditors.SimpleButton()
        Me.chkStatusLPR = New DevExpress.XtraEditors.CheckEdit()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtMessageLPR = New QMS.usTextBox()
        Me.txtTypeLPR = New QMS.usTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtGarduIDLPR = New QMS.usTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtWBIDLPR = New QMS.usTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpCaptureDateLPR = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPlatNumberLPR = New QMS.usTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtIDLPR = New QMS.usTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtIdx = New QMS.usNumeric()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboSubStation = New QMSLib.usComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboStation = New QMSLib.usComboBox()
        Me.lblStation = New System.Windows.Forms.Label()
        Me.txtPlatNumber = New QMS.usTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtID = New QMS.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.ToolBar = New QMS.usToolBar()
        Me.BarSave = New System.Windows.Forms.ToolBarButton()
        Me.BarClose = New System.Windows.Forms.ToolBarButton()
        Me.pnlMain.SuspendLayout()
        Me.gboAcknowledge.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.chkStatusLPR.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.txtIdx, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 28)
        Me.lblInfo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(1291, 36)
        Me.lblInfo.TabIndex = 0
        Me.lblInfo.Text = "« Validate Plat Number"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlMain
        '
        Me.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlMain.Controls.Add(Me.gboAcknowledge)
        Me.pnlMain.Controls.Add(Me.GroupBox2)
        Me.pnlMain.Controls.Add(Me.GroupBox1)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMain.Location = New System.Drawing.Point(0, 64)
        Me.pnlMain.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(1291, 505)
        Me.pnlMain.TabIndex = 1
        '
        'gboAcknowledge
        '
        Me.gboAcknowledge.Controls.Add(Me.txtPlatNumberAcknowledge)
        Me.gboAcknowledge.Controls.Add(Me.lblRemarks)
        Me.gboAcknowledge.Controls.Add(Me.Label5)
        Me.gboAcknowledge.Controls.Add(Me.txtRemarks)
        Me.gboAcknowledge.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold)
        Me.gboAcknowledge.ForeColor = System.Drawing.SystemColors.GrayText
        Me.gboAcknowledge.Location = New System.Drawing.Point(33, 299)
        Me.gboAcknowledge.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gboAcknowledge.Name = "gboAcknowledge"
        Me.gboAcknowledge.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gboAcknowledge.Size = New System.Drawing.Size(600, 178)
        Me.gboAcknowledge.TabIndex = 1
        Me.gboAcknowledge.TabStop = False
        Me.gboAcknowledge.Text = "Detil Penyesuaian"
        '
        'txtPlatNumberAcknowledge
        '
        Me.txtPlatNumberAcknowledge.BackColor = System.Drawing.Color.LightYellow
        Me.txtPlatNumberAcknowledge.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlatNumberAcknowledge.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold)
        Me.txtPlatNumberAcknowledge.Location = New System.Drawing.Point(154, 32)
        Me.txtPlatNumberAcknowledge.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtPlatNumberAcknowledge.MaxLength = 10
        Me.txtPlatNumberAcknowledge.Name = "txtPlatNumberAcknowledge"
        Me.txtPlatNumberAcknowledge.ReadOnly = True
        Me.txtPlatNumberAcknowledge.Size = New System.Drawing.Size(211, 28)
        Me.txtPlatNumberAcknowledge.TabIndex = 0
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.BackColor = System.Drawing.Color.Transparent
        Me.lblRemarks.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.lblRemarks.ForeColor = System.Drawing.Color.Black
        Me.lblRemarks.Location = New System.Drawing.Point(21, 75)
        Me.lblRemarks.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(99, 22)
        Me.lblRemarks.TabIndex = 101
        Me.lblRemarks.Text = "Keterangan"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(21, 34)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 22)
        Me.Label5.TabIndex = 124
        Me.Label5.Text = "Nomor Plat"
        '
        'txtRemarks
        '
        Me.txtRemarks.BackColor = System.Drawing.Color.White
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtRemarks.Location = New System.Drawing.Point(154, 70)
        Me.txtRemarks.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtRemarks.MaxLength = 250
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(405, 77)
        Me.txtRemarks.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnReGet)
        Me.GroupBox2.Controls.Add(Me.chkStatusLPR)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.txtMessageLPR)
        Me.GroupBox2.Controls.Add(Me.txtTypeLPR)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.txtGarduIDLPR)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txtWBIDLPR)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.dtpCaptureDateLPR)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txtPlatNumberLPR)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.txtIDLPR)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.GrayText
        Me.GroupBox2.Location = New System.Drawing.Point(665, 18)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Size = New System.Drawing.Size(593, 459)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Detil LPR"
        '
        'btnReGet
        '
        Me.btnReGet.Appearance.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.btnReGet.Appearance.Options.UseFont = True
        Me.btnReGet.Image = CType(resources.GetObject("btnReGet.Image"), System.Drawing.Image)
        Me.btnReGet.Location = New System.Drawing.Point(365, 368)
        Me.btnReGet.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnReGet.Name = "btnReGet"
        Me.btnReGet.Size = New System.Drawing.Size(190, 37)
        Me.btnReGet.TabIndex = 137
        Me.btnReGet.Text = "RE-GET"
        '
        'chkStatusLPR
        '
        Me.chkStatusLPR.Enabled = False
        Me.chkStatusLPR.Location = New System.Drawing.Point(376, 74)
        Me.chkStatusLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkStatusLPR.Name = "chkStatusLPR"
        Me.chkStatusLPR.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.chkStatusLPR.Properties.Appearance.ForeColor = System.Drawing.Color.Black
        Me.chkStatusLPR.Properties.Appearance.Options.UseFont = True
        Me.chkStatusLPR.Properties.Appearance.Options.UseForeColor = True
        Me.chkStatusLPR.Properties.Caption = "Status"
        Me.chkStatusLPR.Size = New System.Drawing.Size(92, 25)
        Me.chkStatusLPR.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(21, 269)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 22)
        Me.Label11.TabIndex = 136
        Me.Label11.Text = "Pesan"
        '
        'txtMessageLPR
        '
        Me.txtMessageLPR.BackColor = System.Drawing.Color.LightYellow
        Me.txtMessageLPR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtMessageLPR.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtMessageLPR.Location = New System.Drawing.Point(154, 264)
        Me.txtMessageLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtMessageLPR.MaxLength = 250
        Me.txtMessageLPR.Multiline = True
        Me.txtMessageLPR.Name = "txtMessageLPR"
        Me.txtMessageLPR.ReadOnly = True
        Me.txtMessageLPR.Size = New System.Drawing.Size(401, 94)
        Me.txtMessageLPR.TabIndex = 6
        '
        'txtTypeLPR
        '
        Me.txtTypeLPR.BackColor = System.Drawing.Color.LightYellow
        Me.txtTypeLPR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTypeLPR.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtTypeLPR.Location = New System.Drawing.Point(154, 150)
        Me.txtTypeLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtTypeLPR.MaxLength = 10
        Me.txtTypeLPR.Name = "txtTypeLPR"
        Me.txtTypeLPR.ReadOnly = True
        Me.txtTypeLPR.Size = New System.Drawing.Size(127, 28)
        Me.txtTypeLPR.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(21, 157)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 22)
        Me.Label10.TabIndex = 134
        Me.Label10.Text = "Tipe"
        '
        'txtGarduIDLPR
        '
        Me.txtGarduIDLPR.BackColor = System.Drawing.Color.LightYellow
        Me.txtGarduIDLPR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtGarduIDLPR.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtGarduIDLPR.Location = New System.Drawing.Point(154, 112)
        Me.txtGarduIDLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtGarduIDLPR.MaxLength = 10
        Me.txtGarduIDLPR.Name = "txtGarduIDLPR"
        Me.txtGarduIDLPR.ReadOnly = True
        Me.txtGarduIDLPR.Size = New System.Drawing.Size(127, 28)
        Me.txtGarduIDLPR.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(21, 118)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 22)
        Me.Label9.TabIndex = 132
        Me.Label9.Text = "Gardu ID"
        '
        'txtWBIDLPR
        '
        Me.txtWBIDLPR.BackColor = System.Drawing.Color.LightYellow
        Me.txtWBIDLPR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWBIDLPR.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtWBIDLPR.Location = New System.Drawing.Point(154, 74)
        Me.txtWBIDLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtWBIDLPR.MaxLength = 10
        Me.txtWBIDLPR.Name = "txtWBIDLPR"
        Me.txtWBIDLPR.ReadOnly = True
        Me.txtWBIDLPR.Size = New System.Drawing.Size(211, 28)
        Me.txtWBIDLPR.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(21, 81)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 22)
        Me.Label4.TabIndex = 130
        Me.Label4.Text = "WB ID"
        '
        'dtpCaptureDateLPR
        '
        Me.dtpCaptureDateLPR.CustomFormat = "dd/MM/yyyy HH:mm:ss"
        Me.dtpCaptureDateLPR.Enabled = False
        Me.dtpCaptureDateLPR.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.dtpCaptureDateLPR.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpCaptureDateLPR.Location = New System.Drawing.Point(154, 226)
        Me.dtpCaptureDateLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dtpCaptureDateLPR.Name = "dtpCaptureDateLPR"
        Me.dtpCaptureDateLPR.Size = New System.Drawing.Size(211, 28)
        Me.dtpCaptureDateLPR.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(21, 229)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(114, 22)
        Me.Label6.TabIndex = 128
        Me.Label6.Text = "Tanggal Foto"
        '
        'txtPlatNumberLPR
        '
        Me.txtPlatNumberLPR.BackColor = System.Drawing.Color.LightYellow
        Me.txtPlatNumberLPR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlatNumberLPR.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold)
        Me.txtPlatNumberLPR.Location = New System.Drawing.Point(154, 188)
        Me.txtPlatNumberLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtPlatNumberLPR.MaxLength = 10
        Me.txtPlatNumberLPR.Name = "txtPlatNumberLPR"
        Me.txtPlatNumberLPR.ReadOnly = True
        Me.txtPlatNumberLPR.Size = New System.Drawing.Size(211, 28)
        Me.txtPlatNumberLPR.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(21, 194)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(98, 22)
        Me.Label7.TabIndex = 124
        Me.Label7.Text = "Nomor Plat"
        '
        'txtIDLPR
        '
        Me.txtIDLPR.BackColor = System.Drawing.Color.LightYellow
        Me.txtIDLPR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtIDLPR.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtIDLPR.Location = New System.Drawing.Point(154, 36)
        Me.txtIDLPR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtIDLPR.Name = "txtIDLPR"
        Me.txtIDLPR.ReadOnly = True
        Me.txtIDLPR.Size = New System.Drawing.Size(401, 28)
        Me.txtIDLPR.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(21, 42)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 22)
        Me.Label8.TabIndex = 120
        Me.Label8.Text = "ID"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtIdx)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.cboSubStation)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.cboStation)
        Me.GroupBox1.Controls.Add(Me.lblStation)
        Me.GroupBox1.Controls.Add(Me.txtPlatNumber)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtID)
        Me.GroupBox1.Controls.Add(Me.lblID)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.GrayText
        Me.GroupBox1.Location = New System.Drawing.Point(33, 18)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Size = New System.Drawing.Size(600, 267)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Detil Antrian"
        '
        'txtIdx
        '
        Me.txtIdx.BackColor = System.Drawing.Color.LightYellow
        Me.txtIdx.Enabled = False
        Me.txtIdx.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtIdx.Location = New System.Drawing.Point(181, 112)
        Me.txtIdx.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtIdx.Maximum = New Decimal(New Integer() {-1, -1, -1, 0})
        Me.txtIdx.Minimum = New Decimal(New Integer() {-1, -1, -1, -2147483648})
        Me.txtIdx.Name = "txtIdx"
        Me.txtIdx.Size = New System.Drawing.Size(92, 28)
        Me.txtIdx.TabIndex = 2
        Me.txtIdx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtIdx.ThousandsSeparator = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(21, 115)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(141, 22)
        Me.Label2.TabIndex = 130
        Me.Label2.Text = "No. Flow Antrian"
        '
        'cboSubStation
        '
        Me.cboSubStation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSubStation.Enabled = False
        Me.cboSubStation.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.cboSubStation.FormattingEnabled = True
        Me.cboSubStation.Location = New System.Drawing.Point(181, 189)
        Me.cboSubStation.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cboSubStation.Name = "cboSubStation"
        Me.cboSubStation.Size = New System.Drawing.Size(378, 29)
        Me.cboSubStation.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(21, 192)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 22)
        Me.Label1.TabIndex = 129
        Me.Label1.Text = "Substation"
        '
        'cboStation
        '
        Me.cboStation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStation.Enabled = False
        Me.cboStation.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.cboStation.FormattingEnabled = True
        Me.cboStation.Location = New System.Drawing.Point(181, 150)
        Me.cboStation.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cboStation.Name = "cboStation"
        Me.cboStation.Size = New System.Drawing.Size(378, 29)
        Me.cboStation.TabIndex = 3
        '
        'lblStation
        '
        Me.lblStation.AutoSize = True
        Me.lblStation.BackColor = System.Drawing.Color.Transparent
        Me.lblStation.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.lblStation.ForeColor = System.Drawing.Color.Black
        Me.lblStation.Location = New System.Drawing.Point(21, 153)
        Me.lblStation.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStation.Name = "lblStation"
        Me.lblStation.Size = New System.Drawing.Size(65, 22)
        Me.lblStation.TabIndex = 128
        Me.lblStation.Text = "Station"
        '
        'txtPlatNumber
        '
        Me.txtPlatNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtPlatNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlatNumber.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Bold)
        Me.txtPlatNumber.Location = New System.Drawing.Point(181, 74)
        Me.txtPlatNumber.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtPlatNumber.MaxLength = 10
        Me.txtPlatNumber.Name = "txtPlatNumber"
        Me.txtPlatNumber.ReadOnly = True
        Me.txtPlatNumber.Size = New System.Drawing.Size(211, 28)
        Me.txtPlatNumber.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(21, 81)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 22)
        Me.Label3.TabIndex = 124
        Me.Label3.Text = "Nomor Plat"
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.txtID.Location = New System.Drawing.Point(181, 36)
        Me.txtID.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(211, 28)
        Me.txtID.TabIndex = 0
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(21, 42)
        Me.lblID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(29, 22)
        Me.lblID.TabIndex = 120
        Me.lblID.Text = "ID"
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarSave, Me.BarClose})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(1291, 28)
        Me.ToolBar.TabIndex = 2
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarSave
        '
        Me.BarSave.Name = "BarSave"
        Me.BarSave.Tag = "Save"
        Me.BarSave.Text = "Simpan"
        '
        'BarClose
        '
        Me.BarClose.Name = "BarClose"
        Me.BarClose.Tag = "Close"
        Me.BarClose.Text = "Tutup"
        '
        'frmTraQueueCompareFailed
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1291, 569)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.ToolBar)
        Me.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmTraQueueCompareFailed"
        Me.Text = "Antrian"
        Me.pnlMain.ResumeLayout(False)
        Me.gboAcknowledge.ResumeLayout(False)
        Me.gboAcknowledge.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.chkStatusLPR.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.txtIdx, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtID As QMS.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtPlatNumber As QMS.usTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtIdx As QMS.usNumeric
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cboSubStation As QMSLib.usComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboStation As QMSLib.usComboBox
    Friend WithEvents lblStation As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtPlatNumberLPR As QMS.usTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtIDLPR As QMS.usTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dtpCaptureDateLPR As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents txtRemarks As QMS.usTextBox
    Friend WithEvents gboAcknowledge As System.Windows.Forms.GroupBox
    Friend WithEvents txtPlatNumberAcknowledge As QMS.usTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents chkStatusLPR As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtMessageLPR As QMS.usTextBox
    Friend WithEvents txtTypeLPR As QMS.usTextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtGarduIDLPR As QMS.usTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtWBIDLPR As QMS.usTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnReGet As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents ToolBar As QMS.usToolBar
    Friend WithEvents BarSave As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton
End Class
