﻿Imports System.Data.SqlClient

Public Class frmTraQueue

#Region "Properties Handle"

    Private clsData As VO.Queue
    Private intPos As Integer
    Private intComLocDivSubDivID As Integer = 0
    Private strCompanyID As String = "", strLocationID = ""
    Private clsCS As New VO.CS
    Private Const _
       cNew = 0, cDetail = 1, cDelete = 2, cSep1 = 3, cVerify = 4, cCancelVerify = 5, cConfirm = 6, cCancelConfirm = 7,
       cQueueFlow = 8, cChangeRFID = 9, cComplete = 10, cCancelComplete = 11, cSep2 = 12, cRefresh = 13, cClose = 14

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueNumber", "Queue Number", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "TicketParkingID", "Ticket Parking ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueDate", "Queue Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "PlatNumber", "Plat Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DriverID", "DriverID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DriverFullName", "Driver Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "SPBNumber", "SPB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "RFID", "RFID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivIDStorage", "ComLocDivSubDivID Storage", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ProgramIDStorage", "Program ID Storage", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "StorageGroupID", "Storage Group ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageGroupName", "Storage Group Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageID", "Storage ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageName", "Storage Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueType", "QueueType", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "QueueTypeName", "Queue Type", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueFlowID", "QueueFlowID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ItemCode", "ItemCode", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ItemName", "ItemName", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "IsFreePass", "Free Pass", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "WBNumber", "WB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "WBProgramID", "WB Program ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ContractNumber", "Contract Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsRepeat", "Repeat", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsCompleted", "IsCompleted", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "CompletedBy", "Completed By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CompletedDate", "Completed Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "IsDeleted", "IsDeleted", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "IsHold", "Onhold", 100, UI.usDefGrid.gBoolean)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cDetail).Enabled = bolEnable
            .Item(cDelete).Enabled = bolEnable
            .Item(cVerify).Enabled = bolEnable
            .Item(cCancelVerify).Enabled = bolEnable
            .Item(cConfirm).Enabled = bolEnable
            .Item(cCancelConfirm).Enabled = bolEnable
            .Item(cQueueFlow).Enabled = bolEnable
            .Item(cChangeRFID).Enabled = bolEnable
            .Item(cComplete).Enabled = bolEnable
            .Item(cCancelComplete).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvFillCombo()
        Dim dtData As New DataTable
        Try
            dtData = BL.Status.ListDataByModuleID(VO.Modules.Values.Queue)
            Dim drNew As DataRow
            drNew = dtData.NewRow
            With drNew
                .BeginEdit()
                .Item("ID") = 0
                .Item("Description") = "ALL"
                .EndEdit()
            End With
            dtData.Rows.Add(drNew)
            dtData.AcceptChanges()

            UI.usForm.FillComboBox(cboStatus, dtData, "ID", "Description")
            cboStatus.SelectedValue = VO.Status.Values.All
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSetDefaultFilter()
        intComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID
        strCompanyID = UI.usUserApp.CompanyID
        txtCompanyName.Text = UI.usUserApp.CompanyName
        strLocationID = UI.usUserApp.LocationID
        txtLocationName.Text = UI.usUserApp.LocationName
        txtDivisionName.Text = UI.usUserApp.DivisionName
        txtSubdivisionName.Text = UI.usUserApp.SubDivisionName
        prvUserAccess()
    End Sub

    Private Sub prvGetCS()
        clsCS = New VO.CS
        clsCS.ProgramID = UI.usUserApp.ProgramID
        clsCS.ProgramName = UI.usUserApp.ProgramName
        clsCS.ComLocDivSubDivID = intComLocDivSubDivID
        clsCS.CompanyID = strCompanyID
        clsCS.CompanyName = txtCompanyName.Text.Trim
        clsCS.LocationID = strLocationID
        clsCS.LocationName = txtLocationName.Text.Trim
        clsCS.DivisionName = txtDivisionName.Text.Trim
        clsCS.SubDivisionName = txtSubdivisionName.Text.Trim
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor
        Try
            grdMain.DataSource = BL.Queue.ListData(intComLocDivSubDivID, dtpDateFrom.Value.Date, dtpDateTo.Value.Date, cboStatus.SelectedValue)
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
            Me.Cursor = Cursors.Default
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Function prvGetData() As VO.Queue
        Dim returnValue As New VO.Queue
        returnValue.ComLocDivSubDivID = grdView.GetRowCellValue(intPos, "ComLocDivSubDivID")
        returnValue.ID = grdView.GetRowCellValue(intPos, "ID")
        returnValue.QueueNumber = IIf(grdView.GetRowCellValue(intPos, "QueueNumber").Equals(DBNull.Value), 0, grdView.GetRowCellValue(intPos, "QueueNumber"))
        returnValue.TicketParkingID = grdView.GetRowCellValue(intPos, "TicketParkingID")
        returnValue.QueueDate = grdView.GetRowCellValue(intPos, "QueueDate")
        returnValue.PlatNumber = grdView.GetRowCellValue(intPos, "PlatNumber")
        returnValue.DriverID = grdView.GetRowCellValue(intPos, "DriverID")
        returnValue.DriverFullName = grdView.GetRowCellValue(intPos, "DriverFullName")
        returnValue.SPBNumber = grdView.GetRowCellValue(intPos, "SPBNumber")
        returnValue.RFID = grdView.GetRowCellValue(intPos, "RFID")
        returnValue.ComLocDivSubDivIDStorage = grdView.GetRowCellValue(intPos, "ComLocDivSubDivIDStorage")
        returnValue.ProgramIDStorage = grdView.GetRowCellValue(intPos, "ProgramIDStorage")
        returnValue.StorageGroupID = grdView.GetRowCellValue(intPos, "StorageGroupID")
        returnValue.StorageGroupName = grdView.GetRowCellValue(intPos, "StorageGroupName")
        returnValue.StorageID = grdView.GetRowCellValue(intPos, "StorageID")
        returnValue.StorageName = grdView.GetRowCellValue(intPos, "StorageName")
        returnValue.QueueType = grdView.GetRowCellValue(intPos, "QueueType")
        returnValue.QueueTypeName = grdView.GetRowCellValue(intPos, "QueueTypeName")
        returnValue.ItemCode = grdView.GetRowCellValue(intPos, "ItemCode")
        returnValue.ItemName = grdView.GetRowCellValue(intPos, "ItemName")
        returnValue.QueueFlowID = grdView.GetRowCellValue(intPos, "QueueFlowID")
        returnValue.IsFreePass = grdView.GetRowCellValue(intPos, "IsFreePass")
        returnValue.WBNumber = grdView.GetRowCellValue(intPos, "WBNumber")
        returnValue.WBProgramID = grdView.GetRowCellValue(intPos, "WBProgramID")
        returnValue.ContractNumber = grdView.GetRowCellValue(intPos, "ContractNumber")
        returnValue.IsRepeat = grdView.GetRowCellValue(intPos, "IsRepeat")
        returnValue.ReferencesID = grdView.GetRowCellValue(intPos, "ReferencesID")
        returnValue.IDStatus = grdView.GetRowCellValue(intPos, "IDStatus")
        returnValue.StatusInfo = grdView.GetRowCellValue(intPos, "StatusInfo")
        returnValue.IsCompleted = grdView.GetRowCellValue(intPos, "IsCompleted")
        returnValue.CompletedBy = grdView.GetRowCellValue(intPos, "CompletedBy")
        returnValue.CompletedDate = IIf(grdView.GetRowCellValue(intPos, "CompletedDate").Equals(DBNull.Value), "2000/01/01", grdView.GetRowCellValue(intPos, "CompletedDate"))
        returnValue.IsDeleted = grdView.GetRowCellValue(intPos, "IsDeleted")
        returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnValue.CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvNew()
        prvGetCS()
        Dim frmDetail As New frmTraQueueDet
        With frmDetail
            .pubCS = clsCS
            .pubIsNew = True
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvDetail()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        prvGetCS()
        Dim frmDetail As New frmTraQueueDet
        With frmDetail
            .pubIsNew = False
            .pubCS = clsCS
            .pubID = grdView.GetRowCellValue(intPos, "ID")
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then pubRefresh()
        End With
    End Sub

    Private Sub prvDelete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        If clsData.IsDeleted Then
            UI.usForm.frmMessageBox("Data already deleted")
            Exit Sub
        End If

        Dim frmDetail As New usFormRemarks
        With frmDetail
            .pubTitle = "Delete Queue ID: " & clsData.ID
            .pubInfo = "Delete Queue"
            .pubLabel = "Remarks"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                clsData.Remarks = .pubValue.Trim
                clsData.LogBy = UI.usUserApp.UserID
            Else : Exit Sub
            End If
        End With

        Try
            BL.Queue.DeleteData(clsData)
            UI.usForm.frmMessageBox("Delete data success.")
            pubRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvVerify()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessVerify, clsData.ID)
            End Using

            If Not UI.usForm.frmAskQuestion("Verify Queue ID: " & clsData.ID & "?") Then Exit Sub
            clsData.LogBy = UI.usUserApp.UserID
            clsData.Remarks = ""

            BL.Queue.Verify(clsData)
            UI.usForm.frmMessageBox("Verify data success.")
            pubRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvCancelVerify()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                If VO.DefaultServer.IsAutoConfirm Then
                    BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessCancelConfirm, clsData.ID)
                Else
                    BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessCancelVerify, clsData.ID)
                End If
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Cancel Verify Queue ID: " & clsData.ID
                .pubInfo = "Cancel Verify Queue"
                .pubLabel = "Remarks"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.Remarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            BL.Queue.CancelVerify(clsData)
            UI.usForm.frmMessageBox("Cancel Verify data success.")
            pubRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvConfirm()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessConfirm, clsData.ID)
            End Using
            prvGetCS()
            Dim frmDetail As New frmTraQueueConfirm
            With frmDetail
                .pubCS = clsCS
                .pubClsData = clsData
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
                If .pubIsSave Then
                    pubRefresh(clsData.ID)
                End If
            End With
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvCancelConfirm()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessCancelConfirm, clsData.ID)
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Cancel Confirm Queue ID: " & clsData.ID
                .pubInfo = "Cancel Confirm Queue"
                .pubLabel = "Remarks"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.Remarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            BL.Queue.CancelConfirm(clsData)
            UI.usForm.frmMessageBox("Cancel Confirm data success.")
            pubRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvQueueFlow()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        prvGetCS()
        clsData = prvGetData()
        Dim frmDetail As New frmTraQueueFlow
        With frmDetail
            .pubCS = clsCS
            .pubClsData = clsData
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvComplete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessComplete, clsData.ID)
            End Using

            If Not UI.usForm.frmAskQuestion("Complete Queue ID: " & clsData.ID & "?") Then Exit Sub
            clsData.LogBy = UI.usUserApp.UserID
            clsData.Remarks = ""

            Dim strReturn As String = BL.Queue.Complete(clsData)
            If strReturn <> "" Then
                UI.usForm.frmMessageBox("Complete data success. Generate new ID: " & strReturn)
                pubRefresh(strReturn)
            Else
                UI.usForm.frmMessageBox("Complete data success.")
                pubRefresh(clsData.ID)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvCancelComplete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessCancelComplete, clsData.ID)
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Cancel Complete Queue ID: " & clsData.ID
                .pubInfo = "Cancel Complete Queue"
                .pubLabel = "Remarks"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.Remarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            BL.Queue.CancelComplete(clsData)
            UI.usForm.frmMessageBox("Cancel Complete data success.")
            pubRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
        prvSetButton()
    End Sub

    Private Sub prvChooseCompany()
        Dim frmDetail As New frmMstCompany
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strCompanyID = .pubLUDataRow.Item("CompanyID")
                txtCompanyName.Text = .pubLUDataRow.Item("CompanyName")
            End If
        End With
    End Sub

    Private Sub prvChooseLocation()
        Dim frmDetail As New frmMstCompanyLocation
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = strCompanyID
            .pubLULocationID = clsCS.LocationID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strLocationID = .pubLUDataRow.Item("LocationID")
                txtLocationName.Text = .pubLUDataRow.Item("LocationName")
            End If
        End With
    End Sub

    Private Sub prvChangeRFID()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub

        Dim frmDetail As New frmTraQueueChangeRFID
        With frmDetail
            .pubClsData = prvGetData()
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cNew).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "ADD")
            .Item(cDetail).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "EDIT")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "DELETE")
            .Item(cVerify).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "VERIFY")
            .Item(cCancelVerify).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "CANCELVERIFY")
            .Item(cConfirm).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "CONFIRM")
            .Item(cQueueFlow).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "VIEW")
            .Item(cChangeRFID).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUERFID", "EDIT")
            .Item(cComplete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "COMPLETE")
            .Item(cCancelComplete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "CANCELCOMPLETE")
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueue_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

    End Sub

    Private Sub frmTraQueue_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvFillCombo()
        prvSetDefaultFilter()
        prvSetButton()

        dtpDateFrom.Value = Today.Date.AddDays(-7)
        dtpDateTo.Value = Today.Date

        Me.WindowState = FormWindowState.Maximized
        AddHandler cboStatus.SelectedIndexChanged, AddressOf cboStatus_SelectedIndexChanged
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "New" : prvNew()
            Case "Detail" : prvDetail()
            Case "Delete" : prvDelete()
            Case "Verify" : prvVerify()
            Case "Cancel Verify" : prvCancelVerify()
            Case "Confirm" : prvConfirm()
            Case "Cancel Confirm" : prvCancelConfirm()
            Case "Queue Flow" : prvQueueFlow()
            Case "Change RFID" : prvChangeRFID()
            Case "Complete" : prvComplete()
            Case "Cancel Complete" : prvCancelComplete()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        prvChooseCompany()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        prvChooseLocation()
    End Sub

    Private Sub btnSubDivision_Click(sender As Object, e As EventArgs) Handles btnSubDivision.Click
        If strCompanyID.Trim = "" Then Exit Sub
        Dim frmDetail As New frmMstSubDivision
        With frmDetail
            .pubIsLookUp = True
            .pubLUProgramID = UI.usUserApp.ProgramID
            .pubLUCompanyID = strCompanyID.Trim
            .pubLUComLocDivSubDivID = intComLocDivSubDivID
            .ShowDialog()
            If .pubIsLookUpGet Then
                intComLocDivSubDivID = .pubLUComLocDivSubDivID
                strLocationID = .pubLUDataRow("LocationID")
                txtLocationName.Text = .pubLUDataRow("LocationName")
                txtDivisionName.Text = .pubLUDataRow("DivisionName")
                txtSubdivisionName.Text = .pubLUDataRow("SubDivisionName")
                prvClear()
            End If
        End With
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub cboStatus_SelectedIndexChanged(sender As Object, e As EventArgs)
        prvClear()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim intIDStatus As Integer = View.GetRowCellDisplayText(e.RowHandle, View.Columns("IDStatus"))
            If intIDStatus = VO.Status.Values.Deleted And e.Appearance.BackColor <> Color.Salmon Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

#End Region

End Class