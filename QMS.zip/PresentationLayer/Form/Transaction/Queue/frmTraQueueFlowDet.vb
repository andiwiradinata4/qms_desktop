﻿Public Class frmTraQueueFlowDet

#Region "Property Handle"

    Property pubIsSave As Boolean = False
    Property pubAction As VO.QueueDet.Action
    Property pubCS As VO.CS
    Property pubClsData As New VO.QueueDet
    Property pubQueueID As String
    Property pubComLocDivSubDivIDStorage As Integer = 0
    Property pubProgramIDStorageID As String = ""
    Property pubStorageGroupID As String = ""
    Property pubStorageID As String = ""
    Private frmParent As frmTraQueueFlow
    Private clsData As VO.QueueDet
    Private clsStation As VO.Station
    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetLabelInfoForm()
        If pubAction = VO.QueueDet.Action.Request Then
            lblInfo.Text += " [Request]"
        ElseIf pubAction = VO.QueueDet.Action.Done Then
            lblInfo.Text += " [Done]"
        ElseIf pubAction = VO.QueueDet.Action.Add Then
            lblInfo.Text += " [Add]"
        ElseIf pubAction = VO.QueueDet.Action.Edit Then
            lblInfo.Text += " [Edit]"
        End If
    End Sub

    Private Sub prvFillComboStation()
        Dim dtData As New DataTable
        Try
            dtData = BL.Station.ListData
            UI.usForm.FillComboBox(cboStation, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Station")
        End Try
    End Sub

    Private Sub prvFillComboSubStation()
        Dim dtData As New DataTable
        Try
            clsStation = BL.Station.GetDetail(cboStation.SelectedValue)
            Dim isLinkedTank As VO.SubStation.FilterIsLinkedStorage = IIf(clsStation.IsLinkStorage, VO.SubStation.FilterIsLinkedStorage.IsLinkedStorage, VO.SubStation.FilterIsLinkedStorage.All)
            dtData = BL.SubStation.ListData(pubCS.CompanyID, pubCS.LocationID, cboStation.SelectedValue, isLinkedTank, pubComLocDivSubDivIDStorage, pubProgramIDStorageID, pubStorageGroupID, pubStorageID)
            UI.usForm.FillComboBox(cboSubStation, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Substation")
        End Try
    End Sub

    Private Sub prvFillForm()
        txtIdx.Minimum = 1

        If pubClsData.Idx > 0 Then txtIdx.Value = pubClsData.Idx

        prvFillComboStation()
        If pubClsData.StationID > 0 Then
            cboStation.SelectedValue = pubClsData.StationID
            prvFillComboSubStation()
        End If

        If pubClsData.SubStationID > 0 Then cboSubStation.SelectedValue = pubClsData.SubStationID

        If pubAction = VO.QueueDet.Action.Request Then
            txtIdx.Enabled = False
            cboStation.Enabled = False
            cboSubStation.Enabled = True
        ElseIf pubAction = VO.QueueDet.Action.Done Then
            txtIdx.Enabled = False
            cboStation.Enabled = False
            cboSubStation.Enabled = False
        ElseIf pubAction = VO.QueueDet.Action.Add Then
            txtIdx.Enabled = True
            cboStation.Enabled = True
            cboSubStation.Enabled = True
        ElseIf pubAction = VO.QueueDet.Action.Edit Then
            txtIdx.Enabled = False
            cboStation.Enabled = True
            cboSubStation.Enabled = True
        End If
    End Sub

    Public Sub prvSave()
        If cboStation.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose station first")
            cboStation.Focus()
            Exit Sub
        ElseIf cboSubStation.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose substation first")
            cboSubStation.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub
        Dim strAction As String = ""

        clsData = New VO.QueueDet
        clsData.ComLocDivSubDivID = pubCS.ComLocDivSubDivID
        clsData.QueueID = pubQueueID
        clsData.ID = pubClsData.ID
        clsData.Idx = txtIdx.Value
        clsData.StationID = cboStation.SelectedValue
        clsData.StationName = cboStation.Text.Trim
        clsData.SubStationID = cboSubStation.SelectedValue
        clsData.SubStationName = cboSubStation.Text.Trim
        If pubAction = VO.QueueDet.Action.Request Then
            clsData.IsRequested = True
            strAction = "Request"
        ElseIf pubAction = VO.QueueDet.Action.Done Then
            clsData.IsDone = True
            strAction = "Done"
        ElseIf pubAction = VO.QueueDet.Action.Add Then
            strAction = "Add"
        ElseIf pubAction = VO.QueueDet.Action.Edit Then
            strAction = "Edit"
        End If
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID

        Try
            If BL.Queue.HandleQueueFlow(pubAction, clsData) Then
                UI.usForm.frmMessageBox(strAction & " data success.")
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Function AccessCode()
        Dim strReturn = ""
        If pubAction = VO.QueueDet.Action.Request Then
            strReturn = "REQUEST"
        ElseIf pubAction = VO.QueueDet.Action.Done Then
            strReturn = "DONE"
        ElseIf pubAction = VO.QueueDet.Action.Add Then
            strReturn = "ADD"
        ElseIf pubAction = VO.QueueDet.Action.Edit Then
            strReturn = "EDIT"
        End If
        Return strReturn
    End Function

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueFlowDet_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmTraQueueFlowDet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, "TRAQUEUEFLOW", AccessCode))

        prvSetLabelInfoForm()
        prvFillForm()

        AddHandler cboStation.SelectedIndexChanged, AddressOf cboStation_SelectedIndexChanged
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs)
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

    Private Sub cboStation_SelectedIndexChanged(sender As Object, e As EventArgs)
        prvFillComboSubStation()
    End Sub

#End Region

End Class