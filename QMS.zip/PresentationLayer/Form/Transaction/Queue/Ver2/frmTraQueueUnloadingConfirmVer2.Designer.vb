﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueUnloadingConfirmVer2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTraQueueUnloadingConfirmVer2))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.layoutMain = New DevExpress.XtraLayout.LayoutControl()
        Me.cboSubstation = New QMSLib.usComboBox()
        Me.btnSave = New DevExpress.XtraEditors.SimpleButton()
        Me.btnClose = New DevExpress.XtraEditors.SimpleButton()
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl()
        Me.txtRemarks = New QMSLib.usTextBox()
        Me.txtArrivalID = New QMSLib.usTextBox()
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.txtStatus = New QMSLib.usTextBox()
        Me.txtPlatNumber = New QMSLib.usTextBox()
        Me.txtPosition = New QMSLib.usTextBox()
        Me.LayoutControlGroup1 = New DevExpress.XtraLayout.LayoutControlGroup()
        Me.itemPosition = New DevExpress.XtraLayout.LayoutControlItem()
        Me.itemPlatNumber = New DevExpress.XtraLayout.LayoutControlItem()
        Me.itemStatus = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem5 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.itemArrivalID = New DevExpress.XtraLayout.LayoutControlItem()
        Me.EmptySpaceItem4 = New DevExpress.XtraLayout.EmptySpaceItem()
        Me.EmptySpaceItem1 = New DevExpress.XtraLayout.EmptySpaceItem()
        Me.itemRemarksText = New DevExpress.XtraLayout.LayoutControlItem()
        Me.itemRemarksLabel = New DevExpress.XtraLayout.LayoutControlItem()
        Me.itemClose = New DevExpress.XtraLayout.LayoutControlItem()
        Me.itemStart = New DevExpress.XtraLayout.LayoutControlItem()
        Me.itemSubstation = New DevExpress.XtraLayout.LayoutControlItem()
        Me.Panel1.SuspendLayout()
        CType(Me.layoutMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.layoutMain.SuspendLayout()
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemPosition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemPlatNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemArrivalID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmptySpaceItem4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmptySpaceItem1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemRemarksText, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemRemarksLabel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemStart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.itemSubstation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.Controls.Add(Me.layoutMain)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(395, 353)
        Me.Panel1.TabIndex = 1
        '
        'layoutMain
        '
        Me.layoutMain.Controls.Add(Me.cboSubstation)
        Me.layoutMain.Controls.Add(Me.btnSave)
        Me.layoutMain.Controls.Add(Me.btnClose)
        Me.layoutMain.Controls.Add(Me.LabelControl2)
        Me.layoutMain.Controls.Add(Me.txtRemarks)
        Me.layoutMain.Controls.Add(Me.txtArrivalID)
        Me.layoutMain.Controls.Add(Me.LabelControl1)
        Me.layoutMain.Controls.Add(Me.txtStatus)
        Me.layoutMain.Controls.Add(Me.txtPlatNumber)
        Me.layoutMain.Controls.Add(Me.txtPosition)
        Me.layoutMain.Location = New System.Drawing.Point(8, 13)
        Me.layoutMain.Name = "layoutMain"
        Me.layoutMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = New System.Drawing.Rectangle(387, 446, 919, 350)
        Me.layoutMain.OptionsPrint.AppearanceGroupCaption.BackColor = System.Drawing.Color.LightGray
        Me.layoutMain.OptionsPrint.AppearanceGroupCaption.Font = New System.Drawing.Font("Tahoma", 10.25!)
        Me.layoutMain.OptionsPrint.AppearanceGroupCaption.Options.UseBackColor = True
        Me.layoutMain.OptionsPrint.AppearanceGroupCaption.Options.UseFont = True
        Me.layoutMain.OptionsPrint.AppearanceGroupCaption.Options.UseTextOptions = True
        Me.layoutMain.OptionsPrint.AppearanceGroupCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.layoutMain.OptionsPrint.AppearanceGroupCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center
        Me.layoutMain.OptionsPrint.AppearanceItemCaption.Options.UseTextOptions = True
        Me.layoutMain.OptionsPrint.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
        Me.layoutMain.OptionsPrint.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center
        Me.layoutMain.OptionsView.UseDefaultDragAndDropRendering = False
        Me.layoutMain.Root = Me.LayoutControlGroup1
        Me.layoutMain.Size = New System.Drawing.Size(379, 326)
        Me.layoutMain.TabIndex = 2
        Me.layoutMain.Text = "LayoutControl1"
        '
        'cboSubstation
        '
        Me.cboSubstation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSubstation.FormattingEnabled = True
        Me.cboSubstation.Location = New System.Drawing.Point(73, 143)
        Me.cboSubstation.Name = "cboSubstation"
        Me.cboSubstation.Size = New System.Drawing.Size(294, 21)
        Me.cboSubstation.TabIndex = 16
        '
        'btnSave
        '
        Me.btnSave.Image = CType(resources.GetObject("btnSave.Image"), System.Drawing.Image)
        Me.btnSave.Location = New System.Drawing.Point(131, 251)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(116, 22)
        Me.btnSave.StyleController = Me.layoutMain
        Me.btnSave.TabIndex = 6
        Me.btnSave.Text = "Start"
        '
        'btnClose
        '
        Me.btnClose.Image = CType(resources.GetObject("btnClose.Image"), System.Drawing.Image)
        Me.btnClose.Location = New System.Drawing.Point(251, 251)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(116, 22)
        Me.btnClose.StyleController = Me.layoutMain
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "Close"
        '
        'LabelControl2
        '
        Me.LabelControl2.Location = New System.Drawing.Point(12, 168)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(61, 13)
        Me.LabelControl2.StyleController = Me.layoutMain
        Me.LabelControl2.TabIndex = 15
        Me.LabelControl2.Text = "Remarks"
        '
        'txtRemarks
        '
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Location = New System.Drawing.Point(75, 168)
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(292, 71)
        Me.txtRemarks.TabIndex = 5
        '
        'txtArrivalID
        '
        Me.txtArrivalID.BackColor = System.Drawing.Color.AliceBlue
        Me.txtArrivalID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtArrivalID.Location = New System.Drawing.Point(73, 71)
        Me.txtArrivalID.Name = "txtArrivalID"
        Me.txtArrivalID.Size = New System.Drawing.Size(294, 20)
        Me.txtArrivalID.TabIndex = 1
        '
        'LabelControl1
        '
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Tahoma", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.LabelControl1.Location = New System.Drawing.Point(20, 12)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(115, 23)
        Me.LabelControl1.StyleController = Me.layoutMain
        Me.LabelControl1.TabIndex = 10
        Me.LabelControl1.Text = "Information"
        '
        'txtStatus
        '
        Me.txtStatus.BackColor = System.Drawing.Color.AliceBlue
        Me.txtStatus.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStatus.Location = New System.Drawing.Point(73, 119)
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ReadOnly = True
        Me.txtStatus.Size = New System.Drawing.Size(294, 20)
        Me.txtStatus.TabIndex = 3
        '
        'txtPlatNumber
        '
        Me.txtPlatNumber.BackColor = System.Drawing.Color.AliceBlue
        Me.txtPlatNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlatNumber.Location = New System.Drawing.Point(73, 95)
        Me.txtPlatNumber.Name = "txtPlatNumber"
        Me.txtPlatNumber.ReadOnly = True
        Me.txtPlatNumber.Size = New System.Drawing.Size(294, 20)
        Me.txtPlatNumber.TabIndex = 2
        '
        'txtPosition
        '
        Me.txtPosition.BackColor = System.Drawing.Color.AliceBlue
        Me.txtPosition.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPosition.Location = New System.Drawing.Point(73, 47)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.ReadOnly = True
        Me.txtPosition.Size = New System.Drawing.Size(294, 20)
        Me.txtPosition.TabIndex = 0
        '
        'LayoutControlGroup1
        '
        Me.LayoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.[True]
        Me.LayoutControlGroup1.GroupBordersVisible = False
        Me.LayoutControlGroup1.Items.AddRange(New DevExpress.XtraLayout.BaseLayoutItem() {Me.itemPosition, Me.itemPlatNumber, Me.itemStatus, Me.LayoutControlItem5, Me.itemArrivalID, Me.EmptySpaceItem4, Me.EmptySpaceItem1, Me.itemRemarksText, Me.itemRemarksLabel, Me.itemClose, Me.itemStart, Me.itemSubstation})
        Me.LayoutControlGroup1.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlGroup1.Name = "Root"
        Me.LayoutControlGroup1.Size = New System.Drawing.Size(379, 326)
        Me.LayoutControlGroup1.TextVisible = False
        '
        'itemPosition
        '
        Me.itemPosition.Control = Me.txtPosition
        Me.itemPosition.Location = New System.Drawing.Point(0, 35)
        Me.itemPosition.Name = "itemPosition"
        Me.itemPosition.Size = New System.Drawing.Size(359, 24)
        Me.itemPosition.Text = "Position"
        Me.itemPosition.TextSize = New System.Drawing.Size(58, 13)
        '
        'itemPlatNumber
        '
        Me.itemPlatNumber.Control = Me.txtPlatNumber
        Me.itemPlatNumber.Location = New System.Drawing.Point(0, 83)
        Me.itemPlatNumber.Name = "itemPlatNumber"
        Me.itemPlatNumber.Size = New System.Drawing.Size(359, 24)
        Me.itemPlatNumber.Text = "Plat Number"
        Me.itemPlatNumber.TextSize = New System.Drawing.Size(58, 13)
        '
        'itemStatus
        '
        Me.itemStatus.Control = Me.txtStatus
        Me.itemStatus.Location = New System.Drawing.Point(0, 107)
        Me.itemStatus.Name = "itemStatus"
        Me.itemStatus.Size = New System.Drawing.Size(359, 24)
        Me.itemStatus.Text = "Status"
        Me.itemStatus.TextSize = New System.Drawing.Size(58, 13)
        '
        'LayoutControlItem5
        '
        Me.LayoutControlItem5.Control = Me.LabelControl1
        Me.LayoutControlItem5.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlItem5.Name = "LayoutControlItem5"
        Me.LayoutControlItem5.Padding = New DevExpress.XtraLayout.Utils.Padding(10, 2, 2, 10)
        Me.LayoutControlItem5.Size = New System.Drawing.Size(359, 35)
        Me.LayoutControlItem5.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem5.TextVisible = False
        '
        'itemArrivalID
        '
        Me.itemArrivalID.Control = Me.txtArrivalID
        Me.itemArrivalID.Location = New System.Drawing.Point(0, 59)
        Me.itemArrivalID.Name = "itemArrivalID"
        Me.itemArrivalID.Size = New System.Drawing.Size(359, 24)
        Me.itemArrivalID.Text = "Arrival ID"
        Me.itemArrivalID.TextSize = New System.Drawing.Size(58, 13)
        '
        'EmptySpaceItem4
        '
        Me.EmptySpaceItem4.AllowHotTrack = False
        Me.EmptySpaceItem4.Location = New System.Drawing.Point(65, 231)
        Me.EmptySpaceItem4.Name = "EmptySpaceItem4"
        Me.EmptySpaceItem4.Size = New System.Drawing.Size(54, 75)
        Me.EmptySpaceItem4.TextSize = New System.Drawing.Size(0, 0)
        '
        'EmptySpaceItem1
        '
        Me.EmptySpaceItem1.AllowHotTrack = False
        Me.EmptySpaceItem1.Location = New System.Drawing.Point(0, 173)
        Me.EmptySpaceItem1.Name = "EmptySpaceItem1"
        Me.EmptySpaceItem1.Size = New System.Drawing.Size(65, 133)
        Me.EmptySpaceItem1.TextSize = New System.Drawing.Size(0, 0)
        '
        'itemRemarksText
        '
        Me.itemRemarksText.Control = Me.txtRemarks
        Me.itemRemarksText.Location = New System.Drawing.Point(65, 156)
        Me.itemRemarksText.MaxSize = New System.Drawing.Size(0, 75)
        Me.itemRemarksText.MinSize = New System.Drawing.Size(20, 20)
        Me.itemRemarksText.Name = "itemRemarksText"
        Me.itemRemarksText.Padding = New DevExpress.XtraLayout.Utils.Padding(0, 2, 2, 2)
        Me.itemRemarksText.Size = New System.Drawing.Size(294, 75)
        Me.itemRemarksText.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom
        Me.itemRemarksText.TextSize = New System.Drawing.Size(0, 0)
        Me.itemRemarksText.TextVisible = False
        '
        'itemRemarksLabel
        '
        Me.itemRemarksLabel.Control = Me.LabelControl2
        Me.itemRemarksLabel.Location = New System.Drawing.Point(0, 156)
        Me.itemRemarksLabel.MaxSize = New System.Drawing.Size(65, 17)
        Me.itemRemarksLabel.MinSize = New System.Drawing.Size(60, 17)
        Me.itemRemarksLabel.Name = "itemRemarksLabel"
        Me.itemRemarksLabel.Size = New System.Drawing.Size(65, 17)
        Me.itemRemarksLabel.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom
        Me.itemRemarksLabel.TextSize = New System.Drawing.Size(0, 0)
        Me.itemRemarksLabel.TextVisible = False
        '
        'itemClose
        '
        Me.itemClose.Control = Me.btnClose
        Me.itemClose.Location = New System.Drawing.Point(239, 231)
        Me.itemClose.Name = "itemClose"
        Me.itemClose.Padding = New DevExpress.XtraLayout.Utils.Padding(2, 2, 10, 2)
        Me.itemClose.Size = New System.Drawing.Size(120, 75)
        Me.itemClose.TextSize = New System.Drawing.Size(0, 0)
        Me.itemClose.TextVisible = False
        '
        'itemStart
        '
        Me.itemStart.Control = Me.btnSave
        Me.itemStart.Location = New System.Drawing.Point(119, 231)
        Me.itemStart.Name = "itemStart"
        Me.itemStart.Padding = New DevExpress.XtraLayout.Utils.Padding(2, 2, 10, 2)
        Me.itemStart.Size = New System.Drawing.Size(120, 75)
        Me.itemStart.TextSize = New System.Drawing.Size(0, 0)
        Me.itemStart.TextVisible = False
        '
        'itemSubstation
        '
        Me.itemSubstation.Control = Me.cboSubstation
        Me.itemSubstation.Location = New System.Drawing.Point(0, 131)
        Me.itemSubstation.Name = "itemSubstation"
        Me.itemSubstation.Size = New System.Drawing.Size(359, 25)
        Me.itemSubstation.Text = "Substation"
        Me.itemSubstation.TextSize = New System.Drawing.Size(58, 13)
        '
        'frmTraQueueUnloadingConfirmVer2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 353)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTraQueueUnloadingConfirmVer2"
        Me.Text = "Queue - Unloading [ Confirm ]"
        Me.Panel1.ResumeLayout(False)
        CType(Me.layoutMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.layoutMain.ResumeLayout(False)
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemPosition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemPlatNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemArrivalID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmptySpaceItem4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmptySpaceItem1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemRemarksText, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemRemarksLabel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemStart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.itemSubstation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents layoutMain As DevExpress.XtraLayout.LayoutControl
    Friend WithEvents LayoutControlGroup1 As DevExpress.XtraLayout.LayoutControlGroup
    Friend WithEvents txtPosition As QMSLib.usTextBox
    Friend WithEvents txtStatus As QMSLib.usTextBox
    Friend WithEvents txtPlatNumber As QMSLib.usTextBox
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents itemPosition As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents itemPlatNumber As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents itemStatus As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem5 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents txtArrivalID As QMSLib.usTextBox
    Friend WithEvents itemArrivalID As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents btnClose As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtRemarks As QMSLib.usTextBox
    Friend WithEvents EmptySpaceItem4 As DevExpress.XtraLayout.EmptySpaceItem
    Friend WithEvents EmptySpaceItem1 As DevExpress.XtraLayout.EmptySpaceItem
    Friend WithEvents itemRemarksText As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents itemRemarksLabel As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents itemClose As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents btnSave As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents itemStart As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents cboSubstation As QMSLib.usComboBox
    Friend WithEvents itemSubstation As DevExpress.XtraLayout.LayoutControlItem
End Class
