﻿Public Class frmTraQueueUnloadingConfirmVer2

#Region "Property Handle"

    Property pubCS As VO.CS
    Property pubID As String
    Property pubQueueID As String
    Property pubComLocDivSubDivIDStorage As Integer = 0
    Property pubProgramIDStorage As String = ""
    Property pubStorageGroupID As String = ""
    Property pubStorageID As String = ""
    Private frmParent As frmTraQueueUnloadingVer2
    Private clsData As VO.Queue
    Private clsStation As VO.Station
    Private strButtonText As String = "Save"
    Private Const cSave = 0, cClose = 1
    Property pubAction As VO.QueueDetStatus.StatusAction

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvFillCombo()
        Dim dtStatus As New DataTable, dtSubStation As New DataTable
        Try
            '# Substation
            clsStation = BL.Station.GetDetail(VO.Station.Values.Unloading)
            Dim isLinkedTank As VO.SubStation.FilterIsLinkedStorage = IIf(clsStation.IsLinkStorage, VO.SubStation.FilterIsLinkedStorage.IsLinkedStorage, VO.SubStation.FilterIsLinkedStorage.All)
            dtSubStation = BL.SubStation.ListData(pubCS.CompanyID, pubCS.LocationID, clsStation.ID, isLinkedTank, pubComLocDivSubDivIDStorage, pubProgramIDStorage, pubStorageGroupID, pubStorageID)
            UI.usForm.FillComboBox(cboSubstation, dtSubStation, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo")
        End Try
    End Sub

    Private Sub prvFillForm()
        Try
            prvFillCombo()
            clsData = New VO.Queue
            clsData = BL.Queue.GetDetailUnloadingConfirm(pubQueueID, pubID)
            txtPosition.Text = clsData.Position
            txtArrivalID.Text = clsData.WBNumber
            txtPlatNumber.Text = clsData.PlatNumber
            txtRemarks.Text = clsData.Remarks
            If clsData.QueueDetail.IsRequested And clsData.QueueDetail.IsDone = False Then
                strButtonText = "Selesai"
            ElseIf clsData.QueueDetail.IsRequested = False Then
                strButtonText = "Start"
            Else
                strButtonText = "Save"
            End If

            If clsData.QueueDetail.IsDone Then
                txtStatus.Text = "SELESAI"
            ElseIf clsData.QueueDetail.IsRequested Then
                txtStatus.Text = "ONPROGRESS"
            ElseIf clsData.QueueDetail.IsRequested = False Then
                txtStatus.Text = "READY"
            End If

            btnSave.Text = strButtonText
            cboSubstation.SelectedValue = clsData.QueueDetail.SubStationID

            If clsData.QueueDetail.IsRequested Then cboSubstation.Enabled = False
            If clsData.Position.Trim <> "UNLOADING" And clsData.IsHold = False And pubAction <> VO.QueueDetStatus.StatusAction.CancelDone Then btnSave.Enabled = False
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Form")
        End Try
    End Sub

    Private Sub prvSave()
        txtPosition.Focus()
        If cboSubstation.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose substation first")
            cboSubstation.Focus()
            Exit Sub
        ElseIf (pubAction = VO.QueueDetStatus.StatusAction.OnHold Or pubAction = VO.QueueDetStatus.StatusAction.CancelOnHold) _
            AndAlso txtRemarks.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please fill remarks")
            txtRemarks.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Process this data?") Then Exit Sub

        Dim clsDetail As New VO.QueueDet
        clsDetail.ID = pubID
        clsDetail.QueueID = pubQueueID
        clsDetail.Idx = clsData.QueueDetail.Idx
        clsDetail.StationID = VO.Station.Values.Unloading
        clsDetail.SubStationID = cboSubstation.SelectedValue
        clsDetail.SubStationName = cboSubstation.Text.Trim
        clsDetail.LogBy = UI.usUserApp.UserID
        clsDetail.Remarks = txtRemarks.Text.Trim
        clsDetail.DetailAction = pubAction

        clsData = New VO.Queue
        clsData.ID = pubQueueID
        clsData.IsHold = IIf(pubAction = VO.QueueDetStatus.StatusAction.OnHold, True, False)
        clsData.QueueDetail = clsDetail
        clsData.QueueDetail.IsRequested = If(pubAction = VO.QueueDetStatus.StatusAction.Start, True, False)
        clsData.QueueDetail.IsDone = If(pubAction = VO.QueueDetStatus.StatusAction.Done, True, False)

        Try
            Dim bolSuccess As Boolean = BL.Queue.ConfirmUnloadingVer2(clsData)
            If bolSuccess Then
                UI.usForm.frmMessageBox("Process data success!")
                frmParent.pubRefresh(pubID)
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Save Data")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueUnloadingConfirmVer2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvFillForm()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        prvSave()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

#End Region

End Class