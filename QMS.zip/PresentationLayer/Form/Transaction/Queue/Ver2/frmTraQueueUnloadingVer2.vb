﻿Public Class frmTraQueueUnloadingVer2

#Region "Properties Handle"

    Private WithEvents tmrRFID As New Timer
    Private clsData As VO.Queue
    Private intPos As Integer
    Private intComLocDivSubDivID As Integer = 0
    Private strCompanyID As String = "", strLocationID = ""
    Private clsCS As New VO.CS
    Private dtData As New DataTable
    Private bolSuccessSettingSerialPort As Boolean = False, bolIsRFIDValid As Boolean = True
    Private intCount As Integer = 0
    Private Const _
       cStart = 0, cCancelStart = 1, cSep1 = 2, cDone = 3, cCancelDone = 4, cSep2 = 5, cOnHold = 6, cCancelOnHold = 7, cSep3 = 8, cNewUnloading = 9, cReject = 10, cRefresh = 11, cClose = 12

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "QueueID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "Idx", "Idx", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "Position", "Position", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsHold", "Onhold", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "PlatNumber", "Plat Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "WBNumber", "Arrival ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StationID", "Station ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StationName", "Station", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "SubStationID", "SubStation ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "SubStationName", "Sub Station", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "FactoryInDate", "Factory In Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "StartDate", "Start Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "EndDate", "End Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivIDStorage", "ComLocDivSubDivID Storage", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ProgramIDStorage", "Program ID Storage", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "StorageGroupID", "Storage Group ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "StorageID", "Storage ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "RFID", "RFID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "IsRequested", "IsRequested", 100, UI.usDefGrid.gBoolean, False)
        UI.usForm.SetGrid(grdView, "IsDone", "IsDone", 100, UI.usDefGrid.gBoolean, False)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cStart).Enabled = bolEnable
            .Item(cCancelStart).Enabled = bolEnable
            
            .Item(cDone).Enabled = bolEnable
            .Item(cCancelDone).Enabled = bolEnable

            .Item(cOnHold).Enabled = bolEnable
            .Item(cCancelOnHold).Enabled = bolEnable

            .Item(cNewUnloading).Enabled = bolEnable
            .Item(cReject).Enabled = bolEnable

            '# Tidak ada proses Reject dikarenakan ketika HOLD data sudah selesai
            '.Item(cReject).Visible = False
        End With
    End Sub

    Private Sub prvSetDefaultFilter()
        intComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID
        strCompanyID = UI.usUserApp.CompanyID
        txtCompanyName.Text = UI.usUserApp.CompanyName
        strLocationID = UI.usUserApp.LocationID
        txtLocationName.Text = UI.usUserApp.LocationName
        txtDivisionName.Text = UI.usUserApp.DivisionName
        txtSubdivisionName.Text = UI.usUserApp.SubDivisionName
        prvUserAccess()
    End Sub

    Private Sub prvGetCS()
        clsCS = New VO.CS
        clsCS.ProgramID = UI.usUserApp.ProgramID
        clsCS.ProgramName = UI.usUserApp.ProgramName
        clsCS.ComLocDivSubDivID = intComLocDivSubDivID
        clsCS.CompanyID = strCompanyID
        clsCS.CompanyName = txtCompanyName.Text.Trim
        clsCS.LocationID = strLocationID
        clsCS.LocationName = txtLocationName.Text.Trim
        clsCS.DivisionName = txtDivisionName.Text.Trim
        clsCS.SubDivisionName = txtSubdivisionName.Text.Trim
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor

        Try
            dtData = BL.Queue.ListDataQueueUnloadingV2(intComLocDivSubDivID, dtpDateFrom.Value.Date, dtpDateTo.Value.Date)
            grdMain.DataSource = dtData
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
            Me.Cursor = Cursors.Default
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Function prvGetData() As VO.Queue
        Dim returnDetail As New VO.QueueDet
        returnDetail.ID = grdView.GetRowCellValue(intPos, "ID")
        returnDetail.Idx = grdView.GetRowCellValue(intPos, "Idx")
        returnDetail.StationID = grdView.GetRowCellValue(intPos, "StationID")
        returnDetail.StationName = grdView.GetRowCellValue(intPos, "StationName")
        returnDetail.SubStationID = grdView.GetRowCellValue(intPos, "SubStationID")
        returnDetail.SubStationName = grdView.GetRowCellValue(intPos, "SubStationName")
        returnDetail.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnDetail.IsRequested = grdView.GetRowCellValue(intPos, "IsRequested")
        returnDetail.IsDone = grdView.GetRowCellValue(intPos, "IsDone")

        Dim returnValue As New VO.Queue
        returnValue.ComLocDivSubDivID = grdView.GetRowCellValue(intPos, "ComLocDivSubDivID")
        returnValue.ID = grdView.GetRowCellValue(intPos, "QueueID")
        returnValue.ComLocDivSubDivIDStorage = grdView.GetRowCellValue(intPos, "ComLocDivSubDivIDStorage")
        returnValue.ProgramIDStorage = grdView.GetRowCellValue(intPos, "ProgramIDStorage")
        returnValue.StorageGroupID = grdView.GetRowCellValue(intPos, "StorageGroupID")
        returnValue.StorageID = grdView.GetRowCellValue(intPos, "StorageID")
        returnValue.PlatNumber = grdView.GetRowCellValue(intPos, "PlatNumber")
        returnValue.IsHold = grdView.GetRowCellValue(intPos, "IsHold")
        returnValue.QueueDetail = returnDetail

        Return returnValue
    End Function

    Private Sub prvGetDataByRFID(ByVal strRFID As String)
        pubRefresh()
        Dim drCheck() As DataRow = dtData.Select("RFID='" & strRFID & "'")
        If drCheck.Count = 0 Then UI.usForm.frmMessageBox("Data not available", "Get data by RFID") : Exit Sub
        UI.usForm.GridMoveRow(grdView, "ID", drCheck(0).Item("ID"))
        Dim intGet As Integer = grdView.FocusedRowHandle
        prvRequest(intGet)
    End Sub

    Private Sub prvRequest()
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        prvRequest(intPos)
    End Sub

    Private Sub prvRequest(ByVal intPositionData As Integer)
        clsData = prvGetData()
        Dim frmDetail As New frmTraQueueUnloadingConfirm
        With frmDetail
            .pubCS = clsCS
            .pubID = clsData.QueueDetail.ID
            .pubQueueID = clsData.ID
            .pubComLocDivSubDivIDStorage = clsData.ComLocDivSubDivIDStorage
            .pubProgramIDStorage = clsData.ProgramIDStorage
            .pubStorageGroupID = clsData.StorageGroupID
            .pubStorageID = clsData.StorageID
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Function prvCheckingStatus(ByVal action As VO.QueueDetStatus.StatusAction) As Boolean
        If action = VO.QueueDetStatus.StatusAction.Start Then
            If clsData.QueueDetail.IsDone Then
                UI.usForm.frmMessageBox("Cannot process start. this data already process selesai")
                Return False
            ElseIf clsData.QueueDetail.IsRequested Then
                UI.usForm.frmMessageBox("Cannot process start. this data already process start")
                Return False
            End If

        ElseIf action = VO.QueueDetStatus.StatusAction.CancelStart Then
            If clsData.QueueDetail.IsDone Then
                UI.usForm.frmMessageBox("Cannot process cancel start. this data already process selesai")
                Return False
            ElseIf Not clsData.QueueDetail.IsRequested Then
                UI.usForm.frmMessageBox("Cannot process cancel start. this data not yet process start")
                Return False
            End If

        ElseIf action = VO.QueueDetStatus.StatusAction.Done Then
            If clsData.QueueDetail.IsDone Then
                UI.usForm.frmMessageBox("Cannot process selesai. this data already process selesai")
                Return False
            ElseIf Not clsData.QueueDetail.IsRequested Then
                UI.usForm.frmMessageBox("Cannot process selesai. this data not yet process start")
                Return False
            End If

        ElseIf action = VO.QueueDetStatus.StatusAction.CancelDone Then
            If Not clsData.QueueDetail.IsDone Then
                UI.usForm.frmMessageBox("Cannot process cancel selesai. this data not yet process selesai")
                Return False
            End If

        ElseIf action = VO.QueueDetStatus.StatusAction.OnHold Then
            If Not clsData.QueueDetail.IsRequested Then
                UI.usForm.frmMessageBox("Cannot process onhold. this data not yet process start")
                Return False
            End If

        ElseIf action = VO.QueueDetStatus.StatusAction.CancelOnHold Then
            If Not clsData.IsHold Then
                UI.usForm.frmMessageBox("Cannot process cancel onhold. this data not yet process onhold")
                Return False
            End If
        End If
        Return True
    End Function

    Private Sub prvProcess(ByVal action As VO.QueueDetStatus.StatusAction)
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        clsData = prvGetData()

        If Not prvCheckingStatus(action) Then Exit Sub

        Dim frmDetail As New frmTraQueueUnloadingConfirmVer2
        With frmDetail
            .pubCS = clsCS
            .pubAction = action
            .pubID = clsData.QueueDetail.ID
            .pubQueueID = clsData.ID
            .pubComLocDivSubDivIDStorage = clsData.ComLocDivSubDivIDStorage
            .pubProgramIDStorage = clsData.ProgramIDStorage
            .pubStorageGroupID = clsData.StorageGroupID
            .pubStorageID = clsData.StorageID
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvNewUnloading()
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        clsData = prvGetData()

        If clsData.IsHold = False Then
            UI.usForm.frmMessageBox("Cannot generate new unloading station if Onhold is unchecked")
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Generate new unloading for Plat Number " & clsData.PlatNumber & "?") Then Exit Sub

        Dim clsDetail As New VO.QueueDet
        clsDetail.ComLocDivSubDivID = clsData.ComLocDivSubDivID
        clsDetail.QueueID = clsData.ID
        clsDetail.ID = clsData.QueueDetail.ID
        clsDetail.Idx = clsData.QueueDetail.Idx + 1
        clsDetail.StationID = clsData.QueueDetail.StationID
        clsDetail.StationName = clsData.QueueDetail.StationName
        clsDetail.SubStationID = clsData.QueueDetail.SubStationID
        clsDetail.SubStationName = clsData.QueueDetail.SubStationName
        clsDetail.Remarks = ""
        clsDetail.LogBy = UI.usUserApp.UserID

        Try
            If BL.Queue.GenerateNewUnloadingStation(clsDetail) Then
                UI.usForm.frmMessageBox("Generate new unloading station success.")
                pubRefresh()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvReject()
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        clsData = prvGetData()

        If clsData.IsHold = False Then
            UI.usForm.frmMessageBox("Cannot reject if Onhold is unchecked")
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Reject Plat Number " & clsData.PlatNumber & "?") Then Exit Sub

        Dim frmDetail As New usFormRemarks
        With frmDetail
            .pubTitle = "Reject - Fill Remarks"
            .pubInfo = "Reject"
            .pubLabel = "Remarks"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                Dim clsDetail As New VO.QueueDet
                clsDetail.ComLocDivSubDivID = clsData.ComLocDivSubDivID
                clsDetail.QueueID = clsData.ID
                clsDetail.ID = clsData.QueueDetail.ID
                clsDetail.Idx = clsData.QueueDetail.Idx
                clsDetail.StationID = clsData.QueueDetail.StationID
                clsDetail.StationName = clsData.QueueDetail.StationName
                clsDetail.SubStationID = clsData.QueueDetail.SubStationID
                clsDetail.SubStationName = clsData.QueueDetail.SubStationName
                clsDetail.Remarks = clsData.QueueDetail.Remarks & " | REJECT: " & .pubValue
                clsDetail.LogBy = UI.usUserApp.UserID
                clsDetail.DetailAction = VO.QueueDetStatus.StatusAction.Reject

                Try
                    If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Reject, clsDetail, Nothing) Then
                        UI.usForm.frmMessageBox("Reject data success.")
                        pubRefresh()
                    End If
                Catch ex As Exception
                    UI.usForm.frmMessageBox(ex.Message)
                End Try
            End If
        End With
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
        prvSetButton()
    End Sub

    Private Sub prvChooseCompany()
        Dim frmDetail As New frmMstCompany
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strCompanyID = .pubLUDataRow.Item("CompanyID")
                txtCompanyName.Text = .pubLUDataRow.Item("CompanyName")
            End If
        End With
    End Sub

    Private Sub prvChooseLocation()
        Dim frmDetail As New frmMstCompanyLocation
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = strCompanyID
            .pubLULocationID = clsCS.LocationID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strLocationID = .pubLUDataRow.Item("LocationID")
                txtLocationName.Text = .pubLUDataRow.Item("LocationName")
            End If
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            '.Item(cCheck).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "ADD")
            '.Item(cNewUnloading).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "EDIT")
            '.Item(cResample).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "DELETE")
            '.Item(cReject).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "DELETE")
        End With
    End Sub

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort1.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort1.IsOpen Then
                UI.usForm.usSerialPort1.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimer()
    End Sub

    Public Sub prvStartTimer()
        tmrRFID.Enabled = True
        tmrRFID.Interval = 1000
        tmrRFID.Start()
    End Sub

    Public Sub prvStopTimer()
        tmrRFID.Stop()
    End Sub

    Private Sub prvReadCard()
        Try
            bolIsRFIDValid = True
            If VO.DefaultServer.IsLinkRFIDDevice1 Then
                If Not UI.usForm.usSerialPort1.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort1 = UI.usForm.usSerialPort1.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort1.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Trim

            Dim clsRFID As VO.RFIDCard = BL.RFIDCard.RFIDExists(VO.DefaultServer.RFIDValueCOMPort1)

            If VO.DefaultServer.IsLinkRFIDDevice1 Then VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Substring(1, VO.DefaultServer.RFIDValueCOMPort1.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort1.Trim = VO.DefaultServer.PrevRFIDValueCOMPort1.Trim And intCount <= 5 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1
            intCount = 0

            If clsRFID.ID = "" Then
                bolIsRFIDValid = False
                UI.usForm.frmMessageBox("RFID not yet register")
            ElseIf clsRFID.IDStatus = VO.Status.Values.InActive Then
                bolIsRFIDValid = False
                UI.usForm.frmMessageBox("RFID status is IN-ACTIVE")
            Else
                prvGetDataByRFID(VO.DefaultServer.RFIDValueCOMPort1.Trim)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueUnloadingVer2_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        If UI.usForm.usSerialPort1.IsOpen Then
            VO.DefaultServer.RFIDValueCOMPort1 = ""
            tmrRFID.Dispose()
            UI.usForm.usSerialPort1.Dispose()
        End If
    End Sub

    Private Sub frmTraQueueUnloadingVer2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvSetDefaultFilter()
        prvSetButton()

        dtpDateFrom.Value = Today.Date.AddDays(-7)
        dtpDateTo.Value = Today.Date

        Me.WindowState = FormWindowState.Maximized

        If VO.DefaultServer.IsLinkRFIDDevice1 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort1, VO.DefaultServer.COMPort1)
            If bolSuccessSettingSerialPort = False Then MsgBox("False setting serial port")
            prvStartReadRFID()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Start" : prvProcess(VO.QueueDetStatus.StatusAction.Start)
            Case "Cancel Start" : prvProcess(VO.QueueDetStatus.StatusAction.CancelStart)
            Case "Selesai" : prvProcess(VO.QueueDetStatus.StatusAction.Done)
            Case "Cancel Selesai" : prvProcess(VO.QueueDetStatus.StatusAction.CancelDone)
            Case "OnHold" : prvProcess(VO.QueueDetStatus.StatusAction.OnHold)
            Case "Cancel OnHold" : prvProcess(VO.QueueDetStatus.StatusAction.CancelOnHold)
            Case "New Unloading" : prvNewUnloading()
            Case "Reject" : prvReject()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        prvChooseCompany()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        prvChooseLocation()
    End Sub

    Private Sub btnSubDivision_Click(sender As Object, e As EventArgs) Handles btnSubDivision.Click
        If strCompanyID.Trim = "" Then Exit Sub
        Dim frmDetail As New frmMstSubDivision
        With frmDetail
            .pubIsLookUp = True
            .pubLUProgramID = UI.usUserApp.ProgramID
            .pubLUCompanyID = strCompanyID.Trim
            .pubLUComLocDivSubDivID = intComLocDivSubDivID
            .ShowDialog()
            If .pubIsLookUpGet Then
                intComLocDivSubDivID = .pubLUComLocDivSubDivID
                strLocationID = .pubLUDataRow("LocationID")
                txtLocationName.Text = .pubLUDataRow("LocationName")
                txtDivisionName.Text = .pubLUDataRow("DivisionName")
                txtSubdivisionName.Text = .pubLUDataRow("SubDivisionName")
                prvClear()
            End If
        End With
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub cboStatus_SelectedIndexChanged(sender As Object, e As EventArgs)
        prvClear()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim strIsHold As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("IsHold"))
            If strIsHold = "Checked" And e.Appearance.BackColor <> Color.Yellow Then
                e.Appearance.BackColor = Color.Yellow
                e.Appearance.BackColor2 = Color.LightYellow
            End If
        End If
    End Sub

    Private Sub tmrRFID_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrRFID.Tick
        prvReadCard()
    End Sub

#End Region
   
End Class