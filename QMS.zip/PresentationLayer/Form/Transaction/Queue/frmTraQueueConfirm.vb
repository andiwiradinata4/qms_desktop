﻿Public Class frmTraQueueConfirm

#Region "Property Handle"

    Property pubIsSave As Boolean = False
    Property pubCS As VO.CS
    Property pubClsData As New VO.Queue
    Private frmParent As frmTraQueue
    Private clsData As VO.Queue
    Private dtAllSubStation As New DataTable
    Private intPos As Integer = 0
    Private SelectedColumn As DevExpress.XtraGrid.Columns.GridColumn
    Private intComLocDivSubDivIDStorage As Integer = 0
    Private strProgramIDStorage As String = ""
    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdQueueFlowView, "Idx", "Idx", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "StationID", "StationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "StationName", "Station", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "IsLinkedStorage", "IsLinkedStorage", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "SubStationID", "SubStationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "SubStationName", "Substation", 300, UI.usDefGrid.gString, True, False)

        grdQueueFlowView.Columns("SubStationName").ColumnEdit = btnChangeSubStation
    End Sub

    Private Sub prvFillComboQueueType()
        Dim dtData As New DataTable
        Try
            dtData = BL.QueueFlow.ListDataType()
            UI.usForm.FillComboBox(cboQueueType, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Queue Type")
        End Try
    End Sub

    Private Sub prvFillCombo()
        prvFillComboQueueType()
    End Sub

    Private Sub prvFillForm()
        prvFillCombo()
        txtID.Text = pubClsData.ID
        chkIsFreePass.Checked = pubClsData.IsFreePass
        If pubClsData.QueueType > 0 Then cboQueueType.SelectedValue = pubClsData.QueueType
        txtItemCode.Text = pubClsData.ItemCode
        txtItemName.Text = pubClsData.ItemName
        txtQueueFlowID.Text = pubClsData.QueueFlowID
        txtQueueFlowName.Text = pubClsData.QueueFlowName
        prvGetQueueFlow()
    End Sub

    Private Sub prvQueryQueueFlow()
        'If txtStorageGroupID.Text.Trim = "" Or txtStorageID.Text.Trim = "" Then Exit Sub
        Try
            grdQueueFlow.DataSource = BL.QueueFlow.ListDataStationDefault(txtQueueFlowID.Text.Trim, pubCS.CompanyID, pubCS.LocationID, intComLocDivSubDivIDStorage, strProgramIDStorage, txtStorageGroupID.Text.Trim, txtStorageID.Text.Trim)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "List Data Queue Flow")
        End Try
    End Sub

    Public Sub prvSave()
        txtID.Focus()
        grdQueueFlowView.Columns("Idx").SortOrder = DevExpress.Data.ColumnSortOrder.Ascending

        If txtQueueFlowID.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Queue flow not allow blank")
            txtQueueFlowID.Focus()
            Exit Sub
        ElseIf cboQueueType.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please choose queue type first")
            cboQueueType.Focus()
            Exit Sub
        ElseIf txtStorageGroupID.Text.Trim = "" Or txtStorageGroupName.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please choose tank first")
            txtStorageGroupID.Focus()
            Exit Sub
        ElseIf grdQueueFlowView.RowCount = 0 Then
            UI.usForm.frmMessageBox("Cannot save. Item is empty")
            grdQueueFlowView.Focus()
            Exit Sub
            'ElseIf txtWBProgramID.Text.Trim = "" Then
            '    UI.usForm.frmMessageBox("WB Program not allow blank")
            '    txtWBProgramID.Focus()
            '    Exit Sub
            'ElseIf txtWBNumber.Text.Trim = "" Then
            '    UI.usForm.frmMessageBox("WB Number not allow blank")
            '    txtWBNumber.Focus()
            '    Exit Sub
            'ElseIf txtTankCode.Text.Trim = "" Or txtTankName.Text.Trim = "" Then
            '    UI.usForm.frmMessageBox("Please choose tank first")
            '    txtTankCode.Focus()
            '    Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        clsData = New VO.Queue
        clsData.ComLocDivSubDivID = pubCS.ComLocDivSubDivID
        clsData.ID = pubClsData.ID
        clsData.QueueDate = pubClsData.QueueDate
        clsData.QueueType = cboQueueType.SelectedValue
        clsData.ItemCode = txtItemCode.Text.Trim
        clsData.ItemName = txtItemName.Text.Trim
        clsData.QueueFlowID = txtQueueFlowID.Text.Trim
        clsData.WBProgramID = txtWBProgramID.Text.Trim
        clsData.WBNumber = txtWBNumber.Text.Trim
        clsData.ContractNumber = txtContractNumber.Text.Trim
        clsData.ComLocDivSubDivIDStorage = intComLocDivSubDivIDStorage
        clsData.ProgramIDStorage = strProgramIDStorage
        clsData.StorageGroupID = txtStorageGroupID.Text.Trim
        clsData.StorageGroupName = txtStorageGroupName.Text.Trim
        clsData.StorageID = txtStorageID.Text.Trim
        clsData.StorageName = txtStorageName.Text.Trim
        clsData.IsFreePass = chkIsFreePass.Checked
        clsData.IsRepeat = chkIsRepeat.Checked
        clsData.Remarks = ""
        clsData.LogBy = UI.usUserApp.UserID

        Dim clsQueueDet As New VO.QueueDet
        Dim clsQueueDetAll(grdQueueFlowView.RowCount - 1) As VO.QueueDet
        With grdQueueFlowView
            For i As Integer = 0 To .RowCount - 1
                clsQueueDet = New VO.QueueDet
                clsQueueDet.QueueID = pubClsData.ID
                clsQueueDet.StationID = .GetRowCellValue(i, "StationID")
                clsQueueDet.SubStationID = .GetRowCellValue(i, "SubStationID")
                clsQueueDet.LogBy = UI.usUserApp.UserID
                clsQueueDetAll(i) = clsQueueDet
            Next
        End With

        Try
            BL.Queue.Confirm(clsData, clsQueueDetAll)
            UI.usForm.frmMessageBox("Confirm data success.")
            pubIsSave = True
            Me.Close()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvGetQueueFlow()
        Try
            Dim clsQueueFlow As VO.QueueFlow = BL.QueueFlow.GetDetailForQueue(cboQueueType.SelectedValue, txtItemCode.Text.Trim)
            If clsQueueFlow.ID Is Nothing Then
                txtQueueFlowID.Text = ""
                txtQueueFlowName.Text = ""
            Else
                txtQueueFlowID.Text = clsQueueFlow.ID
                txtQueueFlowName.Text = clsQueueFlow.Name
            End If
            prvQueryQueueFlow()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvChooseItem()
        Dim frmDetail As New frmMstItem
        With frmDetail
            .pubIsLookUp = True
            .pubLUItemCode = txtItemCode.Text.Trim
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                txtItemCode.Text = .pubLUDataRow.Item("ItemCode")
                txtItemName.Text = .pubLUDataRow.Item("ItemName")
                prvGetQueueFlow()
            End If
        End With
    End Sub

    Private Sub prvChooseWBProgramID()
        'Dim frmDetail As New frmMstQueueFlow
        'With frmDetail
        '    .pubIsLookUp = True
        '    .StartPosition = FormStartPosition.CenterScreen
        '    .ShowDialog()
        '    If .pubIsLookUpGet Then
        '        txtQueueFlowID.Text = .pubLUdtRow.Item("ID")
        '        txtQueueFlowName.Text = .pubLUdtRow.Item("Name")
        '    End If
        'End With
    End Sub

    Private Sub prvChooseWBNumber()
        'Dim frmDetail As New frmMstQueueFlow
        'With frmDetail
        '    .pubIsLookUp = True
        '    .StartPosition = FormStartPosition.CenterScreen
        '    .ShowDialog()
        '    If .pubIsLookUpGet Then
        '        txtQueueFlowID.Text = .pubLUdtRow.Item("ID")
        '        txtQueueFlowName.Text = .pubLUdtRow.Item("Name")
        '    End If
        'End With
    End Sub

    Private Sub prvChooseStorage()
        Dim frmDetail As New frmMstStorage
        With frmDetail
            .pubIsLookUp = True
            .pubLUStorageID = txtStorageID.Text.Trim
            .pubCS = pubCS
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                intComLocDivSubDivIDStorage = .pubLUdtRow.Item("ComLocDivSubDivID")
                strProgramIDStorage = .pubLUdtRow.Item("ProgramID")
                txtStorageGroupID.Text = .pubLUdtRow.Item("StorageGroupID")
                txtStorageGroupName.Text = .pubLUdtRow.Item("StorageGroupName")
                txtStorageID.Text = .pubLUdtRow.Item("StorageID")
                txtStorageName.Text = .pubLUdtRow.Item("StorageName")
                prvGetQueueFlow()
            End If
        End With
    End Sub

    Private Sub prvChangeSubStation()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New frmMstSubStation
        With frmDetail
            .pubIsLookUp = True
            .pubCS = pubCS
            .pubStationID = grdQueueFlowView.GetRowCellValue(intPos, "StationID")
            .pubEnumLinkedStorage = grdQueueFlowView.GetRowCellValue(intPos, "IsLinkedStorage")
            .pubComLocDivSubDivIDStorage = intComLocDivSubDivIDStorage
            .pubProgramIDStorage = strProgramIDStorage
            .pubStorageGroupID = txtStorageGroupID.Text.Trim
            .pubStorageID = txtStorageID.Text.Trim
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                grdQueueFlowView.SetRowCellValue(intPos, "SubStationID", .pubLUdtRow.Item("ID"))
                grdQueueFlowView.SetRowCellValue(intPos, "SubStationName", .pubLUdtRow.Item("Description"))
                grdQueueFlowView.UpdateCurrentRow()
                grdQueueFlowView.FocusedColumn = grdQueueFlowView.Columns("StationName")
            End If
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueConfirm_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmTraQueueConfirm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, "TRAQUEUE", "CONFIRM"))
        prvSetGrid()
        prvFillForm()

        AddHandler cboQueueType.SelectedIndexChanged, AddressOf cboQueueType_SelectedIndexChanged
    End Sub

    Private Sub btnItem_Click(sender As Object, e As EventArgs) Handles btnItem.Click
        prvChooseItem()
    End Sub

    Private Sub btnWBProgram_Click(sender As Object, e As EventArgs) Handles btnWBProgram.Click
        prvChooseWBProgramID()
    End Sub

    Private Sub btnWBNumber_Click(sender As Object, e As EventArgs) Handles btnWBNumber.Click
        prvChooseWBNumber()
    End Sub

    Private Sub cboQueueType_SelectedIndexChanged(sender As Object, e As EventArgs)
        prvGetQueueFlow()
    End Sub

    Private Sub txtItemCode_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemCode.KeyDown, txtItemName.KeyDown
        If e.KeyCode = Keys.Delete Or e.KeyCode = Keys.Back Then
            txtItemCode.Text = ""
            txtItemName.Text = ""
            prvGetQueueFlow()
        End If
    End Sub

    Private Sub btnTank_Click(sender As Object, e As EventArgs) Handles btnStorage.Click
        prvChooseStorage()
    End Sub

    Private Sub btnChangeSubStation_Click(sender As Object, e As EventArgs) Handles btnChangeSubStation.Click
        prvChangeSubStation()
    End Sub

    Private Sub grdQueueFlow_Click(sender As Object, e As EventArgs) Handles grdQueueFlow.Click
        SelectedColumn = grdQueueFlowView.FocusedColumn
        If SelectedColumn.Name = "SubStationName" Then
            prvChangeSubStation()
        Else
            Exit Sub
        End If
    End Sub

#End Region

End Class