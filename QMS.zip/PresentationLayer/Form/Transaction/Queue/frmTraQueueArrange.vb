﻿Public Class frmTraQueueArrange

#Region "Properties Handle"

    Private clsData As VO.Queue
    Private intPos As Integer
    Private intComLocDivSubDivID As Integer = 0
    Private strCompanyID As String = "", strLocationID = ""
    Private clsCS As New VO.CS
    Private dtOutStanding As New DataTable, dtOnProgress As New DataTable
    Private Const cSave = 0, cClose = 1

    Private Enum MoveData
        Left = 0
        Right = 1
    End Enum

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        '# On Progress
        UI.usForm.SetGrid(grdOnProgressView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOnProgressView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "QueueNumber", "Queue Number", 100, UI.usDefGrid.gIntNum, True, False)
        UI.usForm.SetGrid(grdOnProgressView, "TicketParkingID", "Ticket Parking ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "QueueDate", "Queue Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdOnProgressView, "PlatNumber", "Plat Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "DriverID", "DriverID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "DriverFullName", "Driver Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "SPBNumber", "SPB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "RFID", "RFID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOnProgressView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "ComLocDivSubDivIDStorage", "ComLocDivSubDivID Storage", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOnProgressView, "ProgramIDStorage", "Program ID Storage", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdOnProgressView, "StorageGroupID", "Storage Group ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "StorageGroupName", "Storage Group Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "StorageID", "Storage ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "StorageName", "Storage Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "QueueType", "QueueType", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOnProgressView, "QueueTypeName", "Queue Type", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "QueueFlowID", "QueueFlowID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdOnProgressView, "ItemCode", "ItemCode", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdOnProgressView, "ItemName", "ItemName", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdOnProgressView, "IsFreePass", "Free Pass", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdOnProgressView, "WBNumber", "WB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "WBProgramID", "WB Program ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "IsRepeat", "Repeat", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdOnProgressView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdOnProgressView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOnProgressView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdOnProgressView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        grdOnProgressView.Columns("QueueNumber").SortOrder = DevExpress.Data.ColumnSortOrder.Ascending
        grdOnProgressView.Columns("QueueNumber").ColumnEdit = rpiAutoNumber

        '# Outstanding
        UI.usForm.SetGrid(grdOutstandingView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOutstandingView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "QueueNumber", "Queue Number", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdOutstandingView, "TicketParkingID", "Ticket Parking ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "QueueDate", "Queue Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdOutstandingView, "PlatNumber", "Plat Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "DriverID", "DriverID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "DriverFullName", "Driver Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "SPBNumber", "SPB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "RFID", "RFID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOutstandingView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "ComLocDivSubDivIDStorage", "ComLocDivSubDivID Storage", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOutstandingView, "ProgramIDStorage", "Program ID Storage", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdOutstandingView, "StorageGroupID", "Storage Group ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "StorageGroupName", "Storage Group Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "StorageID", "Storage ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "StorageName", "Storage Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "QueueType", "QueueType", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdOutstandingView, "QueueTypeName", "Queue Type", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "ItemCode", "ItemCode", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdOutstandingView, "ItemName", "ItemName", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdOutstandingView, "IsFreePass", "Free Pass", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdOutstandingView, "WBNumber", "WB Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "WBProgramID", "WB Program ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "IsRepeat", "Repeat", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdOutstandingView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdOutstandingView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdOutstandingView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdOnProgressView.RowCount > 0, True, False)
        ToolBar.Buttons.Item(cSave).Enabled = bolEnable

        btnMoveRight.Enabled = bolEnable
        btnCountOnProgress.Enabled = bolEnable

        Dim bolMoveLeft As Boolean = IIf(grdOutstandingView.RowCount > 0, True, False)
        btnMoveLeft.Enabled = bolMoveLeft
    End Sub

    Private Sub prvSetDefaultFilter()
        intComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID
        strCompanyID = UI.usUserApp.CompanyID
        txtCompanyName.Text = UI.usUserApp.CompanyName
        strLocationID = UI.usUserApp.LocationID
        txtLocationName.Text = UI.usUserApp.LocationName
        txtDivisionName.Text = UI.usUserApp.DivisionName
        txtSubdivisionName.Text = UI.usUserApp.SubDivisionName
        prvUserAccess()
    End Sub

    Private Sub prvGetCS()
        clsCS = New VO.CS
        clsCS.ProgramID = UI.usUserApp.ProgramID
        clsCS.ProgramName = UI.usUserApp.ProgramName
        clsCS.ComLocDivSubDivID = intComLocDivSubDivID
        clsCS.CompanyID = strCompanyID
        clsCS.CompanyName = txtCompanyName.Text.Trim
        clsCS.LocationID = strLocationID
        clsCS.LocationName = txtLocationName.Text.Trim
        clsCS.DivisionName = txtDivisionName.Text.Trim
        clsCS.SubDivisionName = txtSubdivisionName.Text.Trim
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor
        progressBar.Visible = True

        Try
            dtOnProgress = BL.Queue.ListDataArrange(intComLocDivSubDivID, dtpDateFrom.Value.Date, dtpDateFrom.Value.Date, True)
            grdOnProgress.DataSource = dtOnProgress
            grdOnProgressView.BestFitColumns()

            dtOutStanding = BL.Queue.ListDataArrange(intComLocDivSubDivID, dtpDateFrom.Value.Date, dtpDateFrom.Value.Date, False)
            grdOutstanding.DataSource = dtOutStanding
            grdOutstandingView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
            Me.Cursor = Cursors.Default
            progressBar.Visible = False
        End Try
    End Sub

    Private Sub prvClear()
        grdOnProgress.DataSource = Nothing
        grdOnProgressView.Columns.Clear()
        grdOutstanding.DataSource = Nothing
        grdOutstandingView.Columns.Clear()
        prvSetGrid()
        prvSetButton()
    End Sub

    Private Sub prvChooseCompany()
        Dim frmDetail As New frmMstCompany
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strCompanyID = .pubLUDataRow.Item("CompanyID")
                txtCompanyName.Text = .pubLUDataRow.Item("CompanyName")
            End If
        End With
    End Sub

    Private Sub prvChooseLocation()
        Dim frmDetail As New frmMstCompanyLocation
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = strCompanyID
            .pubLULocationID = clsCS.LocationID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strLocationID = .pubLUDataRow.Item("LocationID")
                txtLocationName.Text = .pubLUDataRow.Item("LocationName")
            End If
        End With
    End Sub

    Private Sub prvMoveData(ByVal moveData As MoveData)
        If intPos < 0 Then Exit Sub
        Dim dr As DataRow
        If moveData = moveData.Left Then
            Dim intLastQueueNumber As Integer = grdOnProgressView.GetRowCellValue(grdOnProgressView.RowCount - 1, "QueueNumber")

            dr = grdOutstandingView.GetDataRow(intPos)

            dr.BeginEdit()
            dr.Item("QueueNumber") = intLastQueueNumber + 1
            dr.EndEdit()

            dtOnProgress.ImportRow(dr)
            grdOnProgress.DataSource = dtOnProgress
            dr.Delete()
            dtOutStanding.AcceptChanges()
            grdOnProgressView.BestFitColumns()
        ElseIf moveData = moveData.Right Then
            dr = grdOnProgressView.GetDataRow(intPos)
            dr.BeginEdit()
            dr.Item("QueueNumber") = DBNull.Value
            dr.EndEdit()

            dtOutStanding.ImportRow(dr)
            grdOutstanding.DataSource = dtOutStanding

            If intPos = grdOnProgressView.RowCount - 1 Then GoTo NextProcess

            For i As Integer = intPos + 1 To grdOnProgressView.RowCount - 1
                Dim intQueueNumber As Integer = grdOnProgressView.GetRowCellValue(i, "QueueNumber")
                grdOnProgressView.SetRowCellValue(i, "QueueNumber", intQueueNumber - 1)
            Next

NextProcess:
            dr.Delete()
            dtOnProgress.AcceptChanges()
            grdOutstandingView.BestFitColumns()
        End If
        prvSetButton()
    End Sub

    Private Sub prvSave()
        ToolBar.Focus()
        If grdOnProgressView.RowCount = 0 Then
            UI.usForm.frmMessageBox("Please add item on progress first")
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        Me.Cursor = Cursors.WaitCursor
        progressBar.Visible = True
        Me.Refresh()

        Dim clsData As New VO.Queue
        Dim clsDataAllOnProgress(grdOnProgressView.RowCount - 1) As VO.Queue
        With grdOnProgressView
            For i As Integer = 0 To .RowCount - 1
                clsData = New VO.Queue
                clsData.ComLocDivSubDivID = .GetRowCellValue(i, "ComLocDivSubDivID")
                clsData.ID = .GetRowCellValue(i, "ID")
                clsData.QueueNumber = .GetRowCellValue(i, "QueueNumber")
                clsData.IsArrange = True
                clsData.LogBy = UI.usUserApp.UserID
                clsData.Remarks = ""
                clsDataAllOnProgress(i) = clsData
            Next
        End With

        Dim clsDataAllOutStanding As New List(Of VO.Queue)
        With grdOutstandingView
            For i As Integer = 0 To .RowCount - 1
                clsData = New VO.Queue
                clsData.ComLocDivSubDivID = .GetRowCellValue(i, "ComLocDivSubDivID")
                clsData.ID = .GetRowCellValue(i, "ID")
                clsData.QueueNumber = 0
                clsData.IsArrange = False
                clsData.LogBy = UI.usUserApp.UserID
                clsData.Remarks = ""
                clsDataAllOutStanding.Add(clsData)
            Next
        End With

        Try
            If BL.Queue.ArrangeData(clsDataAllOnProgress, clsDataAllOutStanding) Then
                UI.usForm.frmMessageBox("Arrange data success.")
                prvQuery()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            Me.Cursor = Cursors.Default
            progressBar.Visible = False
            Me.Refresh()
        End Try
    End Sub

    Private Sub prvUpRow()
        With grdOnProgressView
            intPos = .FocusedRowHandle
            If intPos > 0 Then
                .SetRowCellValue(intPos, "QueueNumber", .GetRowCellValue(intPos, "QueueNumber") - 1)
                .SetRowCellValue(intPos - 1, "QueueNumber", .GetRowCellValue(intPos - 1, "QueueNumber") + 1)
            End If
        End With
    End Sub

    Private Sub prvDownRow()
        With grdOnProgressView
            intPos = .FocusedRowHandle
            If intPos < .RowCount - 1 Then
                .SetRowCellValue(intPos, "QueueNumber", .GetRowCellValue(intPos, "QueueNumber") + 1)
                .SetRowCellValue(intPos + 1, "QueueNumber", .GetRowCellValue(intPos + 1, "QueueNumber") - 1)
            End If
        End With
    End Sub

    Private Sub prvCountOnProgress()
        With grdOnProgressView
            For i As Integer = 0 To .RowCount - 1
                .SetRowCellValue(i, "QueueNumber", i + 1)
            Next
        End With
    End Sub

    Private Function prvGetDataOnProgress() As VO.Queue
        Dim returnValue As New VO.Queue
        returnValue.ComLocDivSubDivID = grdOnProgressView.GetRowCellValue(intPos, "ComLocDivSubDivID")
        returnValue.ID = grdOnProgressView.GetRowCellValue(intPos, "ID")
        returnValue.QueueNumber = IIf(grdOnProgressView.GetRowCellValue(intPos, "QueueNumber").Equals(DBNull.Value), 0, grdOnProgressView.GetRowCellValue(intPos, "QueueNumber"))
        returnValue.TicketParkingID = grdOnProgressView.GetRowCellValue(intPos, "TicketParkingID")
        returnValue.QueueDate = grdOnProgressView.GetRowCellValue(intPos, "QueueDate")
        returnValue.PlatNumber = grdOnProgressView.GetRowCellValue(intPos, "PlatNumber")
        returnValue.DriverID = grdOnProgressView.GetRowCellValue(intPos, "DriverID")
        returnValue.DriverFullName = grdOnProgressView.GetRowCellValue(intPos, "DriverFullName")
        returnValue.SPBNumber = grdOnProgressView.GetRowCellValue(intPos, "SPBNumber")
        returnValue.RFID = grdOnProgressView.GetRowCellValue(intPos, "RFID")
        returnValue.StorageID = grdOnProgressView.GetRowCellValue(intPos, "TankCode")
        returnValue.StorageName = grdOnProgressView.GetRowCellValue(intPos, "TankName")
        returnValue.QueueType = grdOnProgressView.GetRowCellValue(intPos, "QueueType")
        returnValue.QueueTypeName = grdOnProgressView.GetRowCellValue(intPos, "QueueTypeName")
        returnValue.ItemCode = grdOnProgressView.GetRowCellValue(intPos, "ItemCode")
        returnValue.ItemName = grdOnProgressView.GetRowCellValue(intPos, "ItemName")
        returnValue.QueueFlowID = grdOnProgressView.GetRowCellValue(intPos, "QueueFlowID")
        returnValue.IsFreePass = grdOnProgressView.GetRowCellValue(intPos, "IsFreePass")
        returnValue.WBNumber = grdOnProgressView.GetRowCellValue(intPos, "WBNumber")
        returnValue.WBProgramID = grdOnProgressView.GetRowCellValue(intPos, "WBProgramID")
        returnValue.ContractNumber = grdOnProgressView.GetRowCellValue(intPos, "ContractNumber")
        returnValue.IsRepeat = grdOnProgressView.GetRowCellValue(intPos, "IsRepeat")
        returnValue.ReferencesID = grdOnProgressView.GetRowCellValue(intPos, "ReferencesID")
        returnValue.IDStatus = grdOnProgressView.GetRowCellValue(intPos, "IDStatus")
        returnValue.StatusInfo = grdOnProgressView.GetRowCellValue(intPos, "StatusInfo")
        returnValue.IsCompleted = grdOnProgressView.GetRowCellValue(intPos, "IsCompleted")
        returnValue.CompletedBy = grdOnProgressView.GetRowCellValue(intPos, "CompletedBy")
        returnValue.IsDeleted = grdOnProgressView.GetRowCellValue(intPos, "IsDeleted")
        returnValue.Remarks = grdOnProgressView.GetRowCellValue(intPos, "Remarks")
        returnValue.CreatedBy = grdOnProgressView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdOnProgressView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cSave).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "ARRANGE")
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueArrange_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvSetDefaultFilter()
        prvSetButton()
        dtpDateFrom.Value = Today.Date

        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Save" : prvSave()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        prvChooseCompany()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        prvChooseLocation()
    End Sub

    Private Sub btnSubDivision_Click(sender As Object, e As EventArgs) Handles btnSubDivision.Click
        If strCompanyID.Trim = "" Then Exit Sub
        Dim frmDetail As New frmMstSubDivision
        With frmDetail
            .pubIsLookUp = True
            .pubLUProgramID = UI.usUserApp.ProgramID
            .pubLUCompanyID = strCompanyID.Trim
            .pubLUComLocDivSubDivID = intComLocDivSubDivID
            .ShowDialog()
            If .pubIsLookUpGet Then
                intComLocDivSubDivID = .pubLUComLocDivSubDivID
                strLocationID = .pubLUDataRow("LocationID")
                txtLocationName.Text = .pubLUDataRow("LocationName")
                txtDivisionName.Text = .pubLUDataRow("DivisionName")
                txtSubdivisionName.Text = .pubLUDataRow("SubDivisionName")
                prvClear()
            End If
        End With
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub btnMoveLeft_Click(sender As Object, e As EventArgs) Handles btnMoveLeft.Click
        intPos = grdOutstandingView.FocusedRowHandle
        prvMoveData(MoveData.Left)
    End Sub

    Private Sub btnMoveRight_Click(sender As Object, e As EventArgs) Handles btnMoveRight.Click
        intPos = grdOnProgressView.FocusedRowHandle
        prvMoveData(MoveData.Right)
    End Sub

    Private Sub rpiAutoNumber_ButtonClick(sender As Object, e As DevExpress.XtraEditors.Controls.ButtonPressedEventArgs) Handles rpiAutoNumber.ButtonClick
        Select Case e.Button.Index
            Case 0 : prvUpRow()
            Case 1 : prvDownRow()
        End Select
    End Sub

    Private Sub rpiAutoNumber_KeyPress(sender As Object, e As KeyPressEventArgs) Handles rpiAutoNumber.KeyPress
        If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnCountOnProgress_Click(sender As Object, e As EventArgs) Handles btnCountOnProgress.Click
        prvCountOnProgress()
    End Sub

#End Region

End Class