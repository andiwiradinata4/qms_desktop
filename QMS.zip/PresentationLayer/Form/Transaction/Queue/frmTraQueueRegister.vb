﻿Imports System.Data.SqlClient

Public Class frmTraQueueRegister

#Region "Properties Handle"

    Private WithEvents tmrRFID As New Timer
    Private clsData As VO.Queue
    Private intPos As Integer
    Private intComLocDivSubDivID As Integer = 0
    Private strCompanyID As String = "", strLocationID = ""
    Private clsCS As New VO.CS
    Private bolIsNew As Boolean = True, bolStartReadLPR As Boolean = False
    Private strID As String = ""
    Private bolSuccessSettingSerialPort As Boolean = False, bolIsRFIDValid As Boolean = True
    Private intCount As Integer = 0, intCountLPR As Integer = 0
    Private clsLPRGet As New VO.LPRGet

    Private Const _
        cSave = 0, cClose = 1,
        cDetail = 0, cDelete = 1, cSep1 = 2, cVerify = 3, cCancelVerify = 4, cSep2 = 5, cFactoryIn = 6, cFactoryOut = 7, cSep3 = 8, cComplete = 9, cCancelComplete = 10, cSep4 = 11, cRefresh = 12

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueNumber", "Nomor Antrian", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "TicketParkingID", "Nomor Tiket Parkir", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "QueueDate", "Tanggal Antrian", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "PlatNumber", "Nomor Plat", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DriverID", "Kode Supir", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DriverFullName", "Nama Supir", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "SPBNumber", "Nomor SPB", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "RFID", "RFID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "TankCode", "Tank Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "TankName", "Tank Name", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "QueueType", "QueueType", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "QueueTypeName", "Queue Type", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "QueueFlowID", "QueueFlowID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ItemCode", "ItemCode", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ItemName", "ItemName", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "IsFreePass", "Free Pass", 100, UI.usDefGrid.gBoolean, False)
        UI.usForm.SetGrid(grdView, "WBNumber", "WB Number", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "WBProgramID", "WB Program ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ContractNumber", "Contract Number", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "IsRepeat", "Repeat", 100, UI.usDefGrid.gBoolean, False)
        UI.usForm.SetGrid(grdView, "ReferencesID", "Nomor Referensi", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsCompleted", "Selesai?", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "CompletedBy", "Diselesaikan Oleh", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CompletedDate", "Tanggal Selesai", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "IsDeleted", "Dihapus?", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "Remarks", "Keterangan", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Dibuat Oleh", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Tanggal Buat", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Diedit Oleh", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Tanggal Edit", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Jumlah Edit", 100, UI.usDefGrid.gIntNum)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBarList.Buttons
            .Item(cDetail).Enabled = bolEnable
            .Item(cDelete).Enabled = bolEnable
            .Item(cVerify).Enabled = bolEnable
            .Item(cCancelVerify).Enabled = bolEnable
            .Item(cFactoryIn).Enabled = bolEnable
            .Item(cFactoryOut).Enabled = bolEnable
            .Item(cCancelVerify).Enabled = bolEnable
            .Item(cComplete).Enabled = bolEnable
            .Item(cCancelComplete).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvFillCombo()
        Dim dtData As New DataTable
        Try
            dtData = BL.Status.ListDataByModuleID(VO.Modules.Values.Queue)
            UI.usForm.FillComboBox(cboStatus, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Status")
        End Try
    End Sub

    Private Sub prvFillForm()
        Try
            If bolIsNew Then
                prvClear()
            Else
                clsData = New VO.Queue
                clsData = BL.Queue.GetDetail(strID)
                txtID.Text = strID
                dtpQueueDate.Value = clsData.QueueDate
                txtDriverID.Text = clsData.DriverID
                txtDriverFullName.Text = clsData.DriverFullName
                txtTicketParkingID.Text = clsData.TicketParkingID
                txtPlatNumber.Text = clsData.PlatNumber
                txtSPBNumber.Text = clsData.SPBNumber
                txtRFID.Text = clsData.RFID
                txtRemarks.Text = clsData.Remarks
                cboStatus.SelectedValue = clsData.IDStatus
                txtReferencesID.Text = clsData.ReferencesID
                lblRFIDStatus.Visible = False
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Form")
        End Try
    End Sub

    Private Sub prvQuery()
        txtID.Focus()
        Me.Cursor = Cursors.WaitCursor
        progressBar.Visible = True
        Try
            grdMain.DataSource = BL.Queue.ListData(UI.usUserApp.ComLocDivSubDivID, dtpDateFrom.Value.Date, dtpDateTo.Value.Date, VO.Status.Values.All)
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
            Me.Cursor = Cursors.Default
            progressBar.Visible = False
        End Try
    End Sub

    Public Sub prvRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
            prvClear()
            bolIsNew = True
        End With
    End Sub

    Private Sub prvSave()
        If lblRFIDStatus.Visible = True Then Exit Sub
        dtpQueueDate.Value = Now
        If txtDriverID.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Pilih supir terlebih dahulu")
            txtDriverID.Focus()
            Exit Sub
        ElseIf txtSPBNumber.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Nomor SPB harus diisi")
            txtSPBNumber.Focus()
            Exit Sub
            'ElseIf txtRFID.Text.Trim = "" Then '# Disable because device RFID Reader not yet ready
            '    UI.usForm.frmMessageBox("RFID harus diisi")
            '    txtRFID.Focus()
            '    Exit Sub
        ElseIf txtPlatNumber.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Nomor Plat harus diisi")
            txtPlatNumber.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Simpan data yang telah diinput?") Then Exit Sub

        clsData = New VO.Queue With {
            .ComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID,
            .ID = txtID.Text.Trim,
            .QueueDate = dtpQueueDate.Value,
            .TicketParkingID = txtTicketParkingID.Text.Trim,
            .PlatNumber = SharedLib.StringUtility.RemoveWhiteSpace(txtPlatNumber.Text.Trim),
            .DriverID = txtDriverID.Text.Trim,
            .DriverFullName = txtDriverFullName.Text.Trim,
            .SPBNumber = txtSPBNumber.Text.Trim,
            .RFID = txtRFID.Text.Trim,
            .Remarks = txtRemarks.Text.Trim,
            .LogBy = UI.usUserApp.UserID
        }

        Try
            BL.Queue.SaveData(bolIsNew, clsData)
            UI.usForm.frmMessageBox("Simpan data berhasil." & IIf(bolIsNew, " ID: " & clsData.ID, ""))
            If Not bolIsNew Then
                bolIsNew = True
                strID = ""
            End If
            prvClear()
            prvRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        txtID.Text = ""
        dtpQueueDate.Value = Now
        txtDriverID.Text = ""
        txtDriverFullName.Text = ""
        txtTicketParkingID.Text = "-"
        txtPlatNumber.Text = ""
        txtSPBNumber.Text = ""
        txtRFID.Text = ""
        txtRemarks.Text = ""
        cboStatus.SelectedValue = VO.Status.Values.Draft
    End Sub

    Private Sub prvChooseDriver()
        Dim frmDetail As New frmMstDriver
        With frmDetail
            .pubIsLookUp = True
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                txtDriverID.Text = .pubLUdtRow.Item("ID")
                txtDriverFullName.Text = .pubLUdtRow.Item("FullName")
            End If
        End With
    End Sub

    Private Function prvGetData() As VO.Queue
        Dim returnValue As New VO.Queue With {
            .ComLocDivSubDivID = grdView.GetRowCellValue(intPos, "ComLocDivSubDivID"),
            .ID = grdView.GetRowCellValue(intPos, "ID"),
            .QueueNumber = IIf(grdView.GetRowCellValue(intPos, "QueueNumber").Equals(DBNull.Value), 0, grdView.GetRowCellValue(intPos, "QueueNumber")),
            .TicketParkingID = grdView.GetRowCellValue(intPos, "TicketParkingID"),
            .QueueDate = grdView.GetRowCellValue(intPos, "QueueDate"),
            .PlatNumber = grdView.GetRowCellValue(intPos, "PlatNumber"),
            .DriverID = grdView.GetRowCellValue(intPos, "DriverID"),
            .DriverFullName = grdView.GetRowCellValue(intPos, "DriverFullName"),
            .SPBNumber = grdView.GetRowCellValue(intPos, "SPBNumber"),
            .RFID = grdView.GetRowCellValue(intPos, "RFID"),
            .StorageID = grdView.GetRowCellValue(intPos, "TankCode"),
            .StorageName = grdView.GetRowCellValue(intPos, "TankName"),
            .QueueType = grdView.GetRowCellValue(intPos, "QueueType"),
            .QueueTypeName = grdView.GetRowCellValue(intPos, "QueueTypeName"),
            .ItemCode = grdView.GetRowCellValue(intPos, "ItemCode"),
            .ItemName = grdView.GetRowCellValue(intPos, "ItemName"),
            .QueueFlowID = grdView.GetRowCellValue(intPos, "QueueFlowID"),
            .IsFreePass = grdView.GetRowCellValue(intPos, "IsFreePass"),
            .WBNumber = grdView.GetRowCellValue(intPos, "WBNumber"),
            .WBProgramID = grdView.GetRowCellValue(intPos, "WBProgramID"),
            .ContractNumber = grdView.GetRowCellValue(intPos, "ContractNumber"),
            .IsRepeat = grdView.GetRowCellValue(intPos, "IsRepeat"),
            .ReferencesID = grdView.GetRowCellValue(intPos, "ReferencesID"),
            .IDStatus = grdView.GetRowCellValue(intPos, "IDStatus"),
            .StatusInfo = grdView.GetRowCellValue(intPos, "StatusInfo"),
            .IsCompleted = grdView.GetRowCellValue(intPos, "IsCompleted"),
            .CompletedBy = grdView.GetRowCellValue(intPos, "CompletedBy"),
            .CompletedDate = IIf(grdView.GetRowCellValue(intPos, "CompletedDate").Equals(DBNull.Value), "2000/01/01", grdView.GetRowCellValue(intPos, "CompletedDate")),
            .IsDeleted = grdView.GetRowCellValue(intPos, "IsDeleted"),
            .Remarks = grdView.GetRowCellValue(intPos, "Remarks"),
            .CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy"),
            .CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        }
        Return returnValue
    End Function

    Private Sub prvDetail()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        strID = grdView.GetRowCellValue(intPos, "ID")
        bolIsNew = False
        prvUserAccess()
        prvFillForm()
    End Sub

    Private Sub prvDelete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        If clsData.IsDeleted Then
            UI.usForm.frmMessageBox("Data telah dihapus sebelumnya")
            Exit Sub
        End If

        Dim frmDetail As New usFormRemarks
        With frmDetail
            .pubTitle = "Hapus ID Antrian: " & clsData.ID
            .pubInfo = "Hapus Data Antrian"
            .pubLabel = "Keterangan"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                clsData.Remarks = .pubValue.Trim
                clsData.LogBy = UI.usUserApp.UserID
            Else : Exit Sub
            End If
        End With

        Try
            BL.Queue.DeleteData(clsData)
            UI.usForm.frmMessageBox("Hapus data berhasil.")
            prvRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvVerify()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessVerify, clsData.ID)
            End Using

            If Not UI.usForm.frmAskQuestion("Verifikasi ID Antrian: " & clsData.ID & "?") Then Exit Sub
            clsData.LogBy = UI.usUserApp.UserID
            clsData.Remarks = ""

            BL.Queue.Verify(clsData)
            UI.usForm.frmMessageBox("Verifikasi data berhasil.")
            prvRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvCancelVerify()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                If VO.DefaultServer.IsAutoConfirm Then
                    BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessCancelConfirm, clsData.ID)
                Else
                    BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessCancelVerify, clsData.ID)
                End If
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Batal Verifikasi ID Antrian: " & clsData.ID
                .pubInfo = "Batal Verifikasi Data Antrian"
                .pubLabel = "Keterangan"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.Remarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            BL.Queue.CancelVerify(clsData)
            UI.usForm.frmMessageBox("Proses Batal Verifikasi berhasil.")
            prvRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvFactoryInOut(ByVal bolIn As Boolean)
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Try
            clsData = prvGetData()
            If clsData.IDStatus <> VO.Status.Values.Confirm Then
                UI.usForm.frmMessageBox("Data " & clsData.ID & " harus dilakukan verifikasi terlebih dahulu")
                Exit Sub
            End If

            If bolIn Then prvReGetLPRValue()

            Dim dt As DataTable = BL.Queue.ListDataDetail(clsData.ID, VO.Station.Values.Security)
            If dt.Rows.Count = 1 Then UI.usForm.frmMessageBox("Data security tidak valid, data security harus 2 baris (masuk dan keluar)") : Exit Sub
            If dt.Rows.Count = 0 Then UI.usForm.frmMessageBox("Queue Flow tidak tersedia") : Exit Sub
            If dt.Rows.Count = 1 And Not bolIn Then UI.usForm.frmMessageBox("Queue Flow keluar pabrik tidak tersedia") : Exit Sub
            Dim intRow As Integer = IIf(bolIn, 0, dt.Rows.Count - 1)

            If bolIn And clsLPRGet.InternalID Is Nothing Then Exit Sub
            If bolIn Then BL.LPRHistory.UpdateReferencesID(clsLPRGet.InternalID, dt.Rows(intRow).Item("ID"))

            If dt.Rows.Count > 1 Then
                Dim clsQueueDet As VO.QueueDet = BL.Queue.GetDetailDet(dt.Rows(intRow).Item("ID"))
                clsQueueDet.PlatNumber = clsData.PlatNumber
                If Not bolIn Then '# Keluar pabrik tidak perlu panggil LPR REGET
                    '# Request
                    clsQueueDet.Remarks = ""
                    clsQueueDet.IsRequested = True
                    clsQueueDet.LogBy = UI.usUserApp.UserID
                    BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Request, clsQueueDet)

                    '# Done
                    If clsQueueDet.StationID = VO.DefaultServer.AutoDoneStationID Then
                        clsQueueDet.Remarks = ""
                        clsQueueDet.IsDone = True
                        clsQueueDet.LogBy = UI.usUserApp.UserID
                        BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Done, clsQueueDet)
                    End If
                    UI.usForm.frmMessageBox("Proses " & IIf(bolIn, "Masuk ", "Keluar ") & " Pabrik berhasil.")
                Else
                    If clsData.PlatNumber.Trim.ToUpper = clsLPRGet.PlatNo.Trim.ToUpper Then
                        '# Request
                        clsQueueDet.Remarks = ""
                        clsQueueDet.IsRequested = True
                        clsQueueDet.LogBy = UI.usUserApp.UserID
                        BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Request, clsQueueDet)

                        '# Done
                        If clsQueueDet.StationID = VO.DefaultServer.AutoDoneStationID Then
                            clsQueueDet.Remarks = ""
                            clsQueueDet.IsDone = True
                            clsQueueDet.LogBy = UI.usUserApp.UserID
                            BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Done, clsQueueDet)
                        End If
                        UI.usForm.frmMessageBox("Proses " & IIf(bolIn, "Masuk ", "Keluar ") & " Pabrik berhasil.")
                    Else
                        Dim frmDetail As New frmTraQueueCompareFailed
                        With frmDetail
                            .pubCompanyID = UI.usUserApp.CompanyID
                            .pubLocationID = UI.usUserApp.LocationID
                            .pubLPRGet = clsLPRGet
                            .pubData = clsQueueDet
                            .StartPosition = FormStartPosition.CenterScreen
                            .ShowDialog()
                        End With
                    End If
                End If
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            bolStartReadLPR = False
            intCountLPR = 0
        End Try
    End Sub

    Private Sub prvComplete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessComplete, clsData.ID)
            End Using

            If Not UI.usForm.frmAskQuestion("Proses Selesai ID Antrian: " & clsData.ID & "?") Then Exit Sub
            clsData.LogBy = UI.usUserApp.UserID
            clsData.Remarks = ""

            Dim strReturn As String = BL.Queue.Complete(clsData)
            If strReturn <> "" Then
                UI.usForm.frmMessageBox("Set Selesai Data Antrian Berhasil. ID Lanjutan : " & strReturn)
                prvRefresh(strReturn)
            Else
                UI.usForm.frmMessageBox("Set Selesai Data Antrian Berhasil.")
                prvRefresh(clsData.ID)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvCancelComplete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatus(sqlCon, Nothing, BL.Queue.cProcessCancelComplete, clsData.ID)
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Proses Batal Selesai ID Antrian: " & clsData.ID
                .pubInfo = "Batal Selesai Data Antrian"
                .pubLabel = "Keterangan"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.Remarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            BL.Queue.CancelComplete(clsData)
            UI.usForm.frmMessageBox("Set Batal Selesai Data Antrian Berhasil.")
            prvRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cSave).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", IIf(bolIsNew, "ADD", "EDIT"))
        End With

        With ToolBarList.Buttons
            .Item(cDetail).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "EDIT")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "DELETE")
            .Item(cVerify).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "VERIFY")
            .Item(cCancelVerify).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "CANCELVERIFY")
            .Item(cComplete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "COMPLETE")
            .Item(cCancelComplete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "CANCELCOMPLETE")
        End With
    End Sub

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort1.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort1.IsOpen Then
                UI.usForm.usSerialPort1.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimer()
    End Sub

    Public Sub prvStartTimer()
        tmrRFID.Enabled = True
        tmrRFID.Interval = 1000
        tmrRFID.Start()
    End Sub

    Public Sub prvStopTimer()
        tmrRFID.Stop()
    End Sub

    Private Sub prvReadCard()
        Try
            bolIsRFIDValid = True
            If VO.DefaultServer.IsLinkRFIDDevice1 Then
                If Not UI.usForm.usSerialPort1.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort1 = UI.usForm.usSerialPort1.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort1.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Trim

            Dim clsRFID As VO.RFIDCard = BL.RFIDCard.RFIDExists(VO.DefaultServer.RFIDValueCOMPort1)

            If VO.DefaultServer.IsLinkRFIDDevice1 Then VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Substring(1, VO.DefaultServer.RFIDValueCOMPort1.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort1.Trim = VO.DefaultServer.PrevRFIDValueCOMPort1.Trim And intCount <= 5 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1
            txtRFID.Text = VO.DefaultServer.RFIDValueCOMPort1.Trim
            intCount = 0

            If clsRFID.ID = "" Then
                bolIsRFIDValid = False
                lblRFIDStatus.Text = "RFID tidak terdaftar"
                lblRFIDStatus.Visible = True
                UI.usForm.frmMessageBox(lblRFIDStatus.Text)
            ElseIf clsRFID.IDStatus = VO.Status.Values.InActive Then
                bolIsRFIDValid = False
                lblRFIDStatus.Text = "RFID sudah tidak aktif"
                lblRFIDStatus.Visible = True
                UI.usForm.frmMessageBox(lblRFIDStatus.Text)
            Else
                lblRFIDStatus.Visible = False
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

    Private Sub prvGetLPRValue()
        Try
            clsLPRGet = BL.Queue.LPRGet(VO.DefaultServer.InitialID)
            If Not clsLPRGet.Status Then UI.usForm.frmMessageBox("GET data LPR fail!" & vbNewLine & clsLPRGet.Message, "GET LPR Value")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "GET LPR Value")
        End Try
    End Sub

    Private Sub prvReGetLPRValue()
        Try
            clsLPRGet = BL.Queue.LPRReGet(VO.DefaultServer.InitialID, False, clsData.ID, clsData.PlatNumber)
            If Not clsLPRGet.Status Then UI.usForm.frmMessageBox("REGET data LPR fail!" & vbNewLine & clsLPRGet.Message, "REGET LPR Value")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "REGET LPR Value")
        End Try
    End Sub

    Private Sub prvCompareRFIDvsLPR()
        Dim clsQueueDet As VO.QueueDet
        Try
            clsQueueDet = BL.Queue.CompareRFID(UI.usUserApp.ComLocDivSubDivID, VO.DefaultServer.RFIDValueCOMPort2, VO.DefaultServer.InitialID, clsLPRGet)
            BL.LPRHistory.UpdateReferencesIDAndPlatNumber(clsLPRGet.InternalID, clsQueueDet.ID, clsQueueDet.PlatNumber, clsLPRGet.PlatNo)
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Request, clsQueueDet.QueueID, clsQueueDet.ID, clsQueueDet, False)
            End Using
            If clsQueueDet.IsRequested Then
                UI.usForm.frmMessageBox("Plat Number " & clsQueueDet.PlatNumber & " already requested Queue Flow")
                Exit Sub
            End If

            If clsQueueDet.IsSuccessCompareLPR Then
                '# Request
                clsQueueDet.Remarks = ""
                clsQueueDet.IsRequested = True
                clsQueueDet.LogBy = "SYSTEM"
                BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Request, clsQueueDet)

                '# Done
                If clsQueueDet.StationID = VO.DefaultServer.AutoDoneStationID Then
                    clsQueueDet.Remarks = ""
                    clsQueueDet.IsDone = True
                    clsQueueDet.LogBy = "SYSTEM"
                    BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Done, clsQueueDet)
                End If
            Else
                Dim frmDetail As New frmTraQueueCompareFailed
                With frmDetail
                    .pubCompanyID = UI.usUserApp.CompanyID
                    .pubLocationID = UI.usUserApp.LocationID
                    .pubLPRGet = clsLPRGet
                    .pubData = clsQueueDet
                    .StartPosition = FormStartPosition.CenterScreen
                    .ShowDialog()
                End With
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Compare RFID vs LPR")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueRegister_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        If UI.usForm.usSerialPort1.IsOpen Then
            VO.DefaultServer.RFIDValueCOMPort1 = ""
            tmrRFID.Dispose()
            UI.usForm.usSerialPort1.Dispose()
        End If
    End Sub

    Private Sub frmTraQueueRegister_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F10 And VO.DefaultServer.IsLinkRFIDDevice1 = False Then
            Dim frmDetail As New frmSysTestInputRFID
            With frmDetail
                .pubPorts = VO.SubStation.Ports.COMPort1
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
            End With
        End If
    End Sub

    Private Sub frmTraQueueRegister_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        ToolBarList.SetIcon(Me)
        prvSetGrid()
        prvFillCombo()
        prvFillForm()
        dtpDateFrom.Value = Today.Date
        dtpDateTo.Value = Today.Date
        prvQuery()
        Me.WindowState = FormWindowState.Maximized

        If VO.DefaultServer.IsLinkRFIDDevice1 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort1, VO.DefaultServer.COMPort1)
            If bolSuccessSettingSerialPort = False Then MsgBox("False setting serial port")
            prvStartReadRFID()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Simpan" : prvSave()
            Case "Tutup" : Me.Close()
        End Select
    End Sub

    Private Sub ToolBarList_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarList.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Edit" : prvDetail()
            Case "Hapus" : prvDelete()
            Case "Verifikasi" : prvVerify()
            Case "Batal Verifikasi" : prvCancelVerify()
            Case "Masuk Pabrik" : prvFactoryInOut(True)
            Case "Keluar Pabrik" : prvFactoryInOut(False)
            Case "Selesai" : prvComplete()
            Case "Batal Selesai" : prvCancelComplete()
            Case "Refresh" : prvRefresh()
        End Select
    End Sub

    Private Sub btnDriver_Click(sender As Object, e As EventArgs) Handles btnDriver.Click
        prvChooseDriver()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim intIDStatus As Integer = View.GetRowCellDisplayText(e.RowHandle, View.Columns("IDStatus"))
            If intIDStatus = VO.Status.Values.Deleted And e.Appearance.BackColor <> Color.Salmon Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

    Private Sub tmrRFID_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrRFID.Tick
        prvReadCard()
    End Sub

#End Region

End Class