﻿Imports System.Data.SqlClient

Public Class frmTraQueueFlow

#Region "Property Handle"

    Property pubClsData As New VO.Queue
    Property pubCS As VO.CS
    Private frmParent As frmTraQueue
    Private clsData As VO.QueueDet
    Private intPos As Integer = 0
    Private Const _
        cClose = 0,
        cAdd = 0, cEdit = 1, cDelete = 2, cSep1 = 3, cRequest = 4, cCancelRequest = 5, cSep2 = 6, cDone = 7, cCancelDone = 8, cSep3 = 9, cRefresh = 10

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdQueueFlowView, "ID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdQueueFlowView, "QueueID", "QueueID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdQueueFlowView, "IsLinkStorage", "IsLinkStorage", 100, UI.usDefGrid.gBoolean, False)
        UI.usForm.SetGrid(grdQueueFlowView, "Idx", "No", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdQueueFlowView, "StationID", "StationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "StationName", "Station", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "SubStationID", "SubStationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdQueueFlowView, "SubStationName", "Substation", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "IsRequested", "Requested", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdQueueFlowView, "RequestedBy", "Requested By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "RequestedDate", "Requested Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdQueueFlowView, "IsDone", "Done", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdQueueFlowView, "DoneBy", "Done By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "DoneDate", "Done Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdQueueFlowView, "InternalRemarks", "Internal Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdQueueFlowView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdQueueFlowView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        grdQueueFlowView.BestFitColumns()
    End Sub

    Private Sub prvSetButton()
        Dim bolEnabled As Boolean = grdQueueFlowView.RowCount > 0
        With ToolBarDetail
            .Buttons(cRequest).Enabled = bolEnabled
            .Buttons(cCancelRequest).Enabled = bolEnabled
            .Buttons(cDone).Enabled = bolEnabled
            .Buttons(cCancelDone).Enabled = bolEnabled
        End With
    End Sub

    Private Sub prvFillCombo()
        Dim dtData As New DataTable
        Try
            dtData = BL.QueueFlow.ListDataType()
            UI.usForm.FillComboBox(cboQueueType, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Queue Type")
        End Try
    End Sub

    Private Sub prvFillForm()
        prvFillCombo()
        txtID.Text = pubClsData.ID
        chkIsFreePass.Checked = pubClsData.IsFreePass
        chkIsRepeat.Checked = pubClsData.IsRepeat
        txtSPBNumber.Text = pubClsData.SPBNumber
        txtRFID.Text = pubClsData.RFID
        cboQueueType.SelectedValue = pubClsData.QueueType
        txtTicketParkingID.Text = pubClsData.TicketParkingID
        txtPlatNumber.Text = pubClsData.PlatNumber
        txtQueueNumber.Text = pubClsData.QueueNumber
        prvQuery()
    End Sub

    Private Sub prvQuery()
        Try
            grdQueueFlow.DataSource = BL.Queue.ListDataDetail(pubClsData.ID)
            grdQueueFlowView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "List Data Queue Flow")
        Finally
            prvSetButton()
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdQueueFlowView
            If Not .FocusedValue Is Nothing And strSearch = "" Then
                strSearch = .GetDataRow(.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If .RowCount > 0 Then UI.usForm.GridMoveRow(grdQueueFlowView, "ID", strSearch)
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBarDetail.Buttons
            .Item(cAdd).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "ADD")
            .Item(cEdit).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "EDIT")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "DELETE")
            If .Item(cAdd).Visible = False And .Item(cAdd).Visible = False And .Item(cAdd).Visible = False Then
                .Item(cSep1).Visible = False
            End If
            .Item(cRequest).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "REQUEST")
            .Item(cCancelRequest).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "CANCELREQUEST")
            .Item(cDone).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "DONE")
            .Item(cCancelDone).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFLOW", "CANCELDONE")
        End With
    End Sub

#Region "Detail"

    Private Function prvGetData() As VO.QueueDet
        Dim returnValue As New VO.QueueDet
        returnValue.ComLocDivSubDivID = pubCS.ComLocDivSubDivID
        returnValue.ID = grdQueueFlowView.GetRowCellValue(intPos, "ID")
        returnValue.QueueID = grdQueueFlowView.GetRowCellValue(intPos, "QueueID")
        returnValue.IsLinkedTank = grdQueueFlowView.GetRowCellValue(intPos, "IsLinkStorage")
        returnValue.Idx = grdQueueFlowView.GetRowCellValue(intPos, "Idx")
        returnValue.StationID = grdQueueFlowView.GetRowCellValue(intPos, "StationID")
        returnValue.StationName = grdQueueFlowView.GetRowCellValue(intPos, "StationName")
        returnValue.SubStationID = grdQueueFlowView.GetRowCellValue(intPos, "SubStationID")
        returnValue.SubStationName = grdQueueFlowView.GetRowCellValue(intPos, "SubStationName")
        returnValue.IsRequested = grdQueueFlowView.GetRowCellValue(intPos, "IsRequested")
        returnValue.RequestedBy = grdQueueFlowView.GetRowCellValue(intPos, "RequestedBy")
        returnValue.RequestedDate = IIf(grdQueueFlowView.GetRowCellValue(intPos, "RequestedDate").Equals(DBNull.Value), "2000/01/01", grdQueueFlowView.GetRowCellValue(intPos, "RequestedDate"))
        returnValue.IsDone = grdQueueFlowView.GetRowCellValue(intPos, "IsDone")
        returnValue.DoneBy = grdQueueFlowView.GetRowCellValue(intPos, "DoneBy")
        returnValue.DoneDate = IIf(grdQueueFlowView.GetRowCellValue(intPos, "DoneDate").Equals(DBNull.Value), "2000/01/01", grdQueueFlowView.GetRowCellValue(intPos, "DoneDate"))
        returnValue.InternalRemarks = grdQueueFlowView.GetRowCellValue(intPos, "InternalRemarks")
        returnValue.Remarks = grdQueueFlowView.GetRowCellValue(intPos, "Remarks")
        returnValue.LogBy = grdQueueFlowView.GetRowCellValue(intPos, "LogBy")
        returnValue.LogDate = grdQueueFlowView.GetRowCellValue(intPos, "LogDate")
        returnValue.LogInc = grdQueueFlowView.GetRowCellValue(intPos, "LogInc")
        Return returnValue
    End Function

    Private Sub prvUp()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        If intPos = 0 Then
            UI.usForm.frmMessageBox("Cannot move up. Data already on the first row")
            Exit Sub
        End If
        clsData = prvGetData()
        intPos = grdQueueFlowView.FocusedRowHandle - 1
        Dim clsReference As VO.QueueDet = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Up, pubClsData.ID, clsData.ID, Nothing, False)
            End Using
            If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Up, clsData, clsReference) Then
                pubRefresh()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvDown()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        If intPos = grdQueueFlowView.RowCount - 1 Then
            UI.usForm.frmMessageBox("Cannot move down. Data already on the last row")
            Exit Sub
        End If
        clsData = prvGetData()
        intPos = grdQueueFlowView.FocusedRowHandle + 1
        Dim clsReference As VO.QueueDet = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Down, pubClsData.ID, clsData.ID, Nothing, False)
            End Using

            If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Down, clsData, clsReference) Then
                pubRefresh()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvAdd()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Add, pubClsData.ID, Nothing, Nothing, False)
            End Using

            Dim frmDetail As New frmTraQueueFlowDet
            With frmDetail
                .pubAction = VO.QueueDet.Action.Add
                .pubCS = pubCS
                .pubQueueID = pubClsData.ID
                .pubComLocDivSubDivIDStorage = pubClsData.ComLocDivSubDivIDStorage
                .pubProgramIDStorageID = pubClsData.ProgramIDStorage
                .pubStorageGroupID = pubClsData.StorageGroupID
                .pubStorageID = pubClsData.StorageID
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
                If .pubIsSave Then
                    pubRefresh()
                End If
            End With
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvEdit()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Edit, pubClsData.ID, clsData.ID, Nothing, False)
            End Using

            Dim frmDetail As New frmTraQueueFlowDet
            With frmDetail
                .pubAction = VO.QueueDet.Action.Edit
                .pubCS = pubCS
                .pubQueueID = pubClsData.ID
                .pubComLocDivSubDivIDStorage = pubClsData.ComLocDivSubDivIDStorage
                .pubProgramIDStorageID = pubClsData.ProgramIDStorage
                .pubStorageGroupID = pubClsData.StorageGroupID
                .pubStorageID = pubClsData.StorageID
                .pubClsData = clsData
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
                If .pubIsSave Then
                    pubRefresh(clsData.ID)
                End If
            End With
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvDelete()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Delete, pubClsData.ID, clsData.ID, Nothing, False)
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Delete Queue Flow No. " & clsData.Idx
                .pubInfo = "Delete Queue Flow"
                .pubLabel = "Internal Remarks"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.InternalRemarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Delete, clsData) Then
                UI.usForm.frmMessageBox("Delete data success.")
                pubRefresh()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvRequest()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Request, pubClsData.ID, clsData.ID, Nothing, False)
            End Using

            Dim frmDetail As New frmTraQueueFlowDet
            With frmDetail
                .pubAction = VO.QueueDet.Action.Request
                .pubCS = pubCS
                .pubQueueID = pubClsData.ID
                .pubComLocDivSubDivIDStorage = pubClsData.ComLocDivSubDivIDStorage
                .pubProgramIDStorageID = pubClsData.ProgramIDStorage
                .pubStorageGroupID = pubClsData.StorageGroupID
                .pubStorageID = pubClsData.StorageID
                .pubClsData = clsData
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
                If .pubIsSave Then
                    pubRefresh(clsData.ID)
                End If
            End With
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvCancelRequest()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.CancelRequest, pubClsData.ID, clsData.ID, Nothing, False)
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Cancel Request Queue Flow No. " & clsData.Idx
                .pubInfo = "Cancel Request Queue Flow"
                .pubLabel = "Internal Remarks"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.InternalRemarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.CancelRequest, clsData) Then
                UI.usForm.frmMessageBox("Cancel Request data success.")
                pubRefresh(clsData.ID)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvDone()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Done, pubClsData.ID, clsData.ID, Nothing, False)
            End Using

            Dim frmDetail As New frmTraQueueFlowDet
            With frmDetail
                .pubAction = VO.QueueDet.Action.Done
                .pubCS = pubCS
                .pubQueueID = pubClsData.ID
                .pubComLocDivSubDivIDStorage = pubClsData.ComLocDivSubDivIDStorage
                .pubProgramIDStorageID = pubClsData.ProgramIDStorage
                .pubStorageGroupID = pubClsData.StorageGroupID
                .pubStorageID = pubClsData.StorageID
                .pubClsData = clsData
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
                If .pubIsSave Then
                    pubRefresh(clsData.ID)
                End If
            End With
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvCancelDone()
        intPos = grdQueueFlowView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        Try
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.CancelDone, pubClsData.ID, clsData.ID, Nothing, False)
            End Using

            Dim frmDetail As New usFormRemarks
            With frmDetail
                .pubTitle = "Cancel Done Queue Flow No. " & clsData.Idx
                .pubInfo = "Cancel Done Queue Flow"
                .pubLabel = "Internal Remarks"
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
                If .pubIsSave Then
                    clsData.InternalRemarks = .pubValue.Trim
                    clsData.LogBy = UI.usUserApp.UserID
                Else : Exit Sub
                End If
            End With

            If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.CancelDone, clsData) Then
                UI.usForm.frmMessageBox("Cancel Done data success.")
                pubRefresh(clsData.ID)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

#End Region

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueFlow_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmTraQueueFlow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Close", UI.usUserApp.ProgramID, "", ""))
        ToolBarDetail.SetIcon(Me)
        prvSetGrid()
        prvFillForm()
    End Sub

    Private Sub ToolBarDetail_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarDetail.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Up" : prvUp()
            Case "Down" : prvDown()
            Case "Add" : prvAdd()
            Case "Edit" : prvEdit()
            Case "Delete" : prvDelete()
            Case "Request" : prvRequest()
            Case "Cancel Request" : prvCancelRequest()
            Case "Done" : prvDone()
            Case "Cancel Done" : prvCancelDone()
            Case "Refresh" : pubRefresh()
        End Select
    End Sub

#End Region

End Class