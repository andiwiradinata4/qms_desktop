﻿Public Class frmTraQueueUnloading

#Region "Properties Handle"

    Private WithEvents tmrRFID As New Timer
    Private clsData As VO.Queue
    Private intPos As Integer
    Private intComLocDivSubDivID As Integer = 0
    Private strCompanyID As String = "", strLocationID = ""
    Private clsCS As New VO.CS
    Private dtData As New DataTable
    Private bolSuccessSettingSerialPort As Boolean = False, bolIsRFIDValid As Boolean = True
    Private intCount As Integer = 0
    Private Const _
       cCheck = 0, cNewUnloading = 1, cResample = 2, cReject = 3, cSep1 = 4, cRefresh = 5, cClose = 6

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "QueueID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "Idx", "Idx", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "Position", "Position", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsHold", "Onhold", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "PlatNumber", "Plat Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "WBNumber", "Arrival ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StationID", "Station ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StationName", "Station", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "SubStationID", "SubStation ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "SubStationName", "Sub Station", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "FactoryInDate", "Factory In Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "StartDate", "Start Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "EndDate", "End Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivIDStorage", "ComLocDivSubDivID Storage", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ProgramIDStorage", "Program ID Storage", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "StorageGroupID", "Storage Group ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "StorageID", "Storage ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "RFID", "RFID", 100, UI.usDefGrid.gString, False)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cNewUnloading).Enabled = bolEnable
            .Item(cResample).Enabled = bolEnable
            .Item(cReject).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvSetDefaultFilter()
        intComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID
        strCompanyID = UI.usUserApp.CompanyID
        txtCompanyName.Text = UI.usUserApp.CompanyName
        strLocationID = UI.usUserApp.LocationID
        txtLocationName.Text = UI.usUserApp.LocationName
        txtDivisionName.Text = UI.usUserApp.DivisionName
        txtSubdivisionName.Text = UI.usUserApp.SubDivisionName
        prvUserAccess()
    End Sub

    Private Sub prvGetCS()
        clsCS = New VO.CS
        clsCS.ProgramID = UI.usUserApp.ProgramID
        clsCS.ProgramName = UI.usUserApp.ProgramName
        clsCS.ComLocDivSubDivID = intComLocDivSubDivID
        clsCS.CompanyID = strCompanyID
        clsCS.CompanyName = txtCompanyName.Text.Trim
        clsCS.LocationID = strLocationID
        clsCS.LocationName = txtLocationName.Text.Trim
        clsCS.DivisionName = txtDivisionName.Text.Trim
        clsCS.SubDivisionName = txtSubdivisionName.Text.Trim
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor

        Try
            dtData = BL.Queue.ListDataQueueUnloading(intComLocDivSubDivID, dtpDateFrom.Value.Date, dtpDateTo.Value.Date)
            grdMain.DataSource = dtData
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
            Me.Cursor = Cursors.Default
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Function prvGetData() As VO.Queue
        Dim returnDetail As New VO.QueueDet
        returnDetail.ID = grdView.GetRowCellValue(intPos, "ID")
        returnDetail.Idx = grdView.GetRowCellValue(intPos, "Idx")
        returnDetail.StationID = grdView.GetRowCellValue(intPos, "StationID")
        returnDetail.StationName = grdView.GetRowCellValue(intPos, "StationName")
        returnDetail.SubStationID = grdView.GetRowCellValue(intPos, "SubStationID")
        returnDetail.SubStationName = grdView.GetRowCellValue(intPos, "SubStationName")
        returnDetail.Remarks = grdView.GetRowCellValue(intPos, "Remarks")

        Dim returnValue As New VO.Queue
        returnValue.ComLocDivSubDivID = grdView.GetRowCellValue(intPos, "ComLocDivSubDivID")
        returnValue.ID = grdView.GetRowCellValue(intPos, "QueueID")
        returnValue.ComLocDivSubDivIDStorage = grdView.GetRowCellValue(intPos, "ComLocDivSubDivIDStorage")
        returnValue.ProgramIDStorage = grdView.GetRowCellValue(intPos, "ProgramIDStorage")
        returnValue.StorageGroupID = grdView.GetRowCellValue(intPos, "StorageGroupID")
        returnValue.StorageID = grdView.GetRowCellValue(intPos, "StorageID")
        returnValue.PlatNumber = grdView.GetRowCellValue(intPos, "PlatNumber")
        returnValue.IsHold = grdView.GetRowCellValue(intPos, "IsHold")
        returnValue.QueueDetail = returnDetail
        
        'returnValue.StatusInfo = grdView.GetRowCellValue(intPos, "StatusInfo")
        'returnValue.IsHold = grdView.GetRowCellValue(intPos, "IsHold")
        'returnValue.QueueDate = grdView.GetRowCellValue(intPos, "QueueDate")
        'returnValue.PlatNumber = grdView.GetRowCellValue(intPos, "PlatNumber")
        'returnValue.DriverID = grdView.GetRowCellValue(intPos, "DriverID")
        'returnValue.DriverFullName = grdView.GetRowCellValue(intPos, "DriverFullName")
        'returnValue.SPBNumber = grdView.GetRowCellValue(intPos, "SPBNumber")
        'returnValue.RFID = grdView.GetRowCellValue(intPos, "RFID")
        'returnValue.IDStatus = grdView.GetRowCellValue(intPos, "IDStatus")
        'returnValue.StorageGroupName = grdView.GetRowCellValue(intPos, "StorageGroupName")
        'returnValue.StorageID = grdView.GetRowCellValue(intPos, "StorageID")
        'returnValue.StorageName = grdView.GetRowCellValue(intPos, "StorageName")
        'returnValue.QueueType = grdView.GetRowCellValue(intPos, "QueueType")
        'returnValue.QueueTypeName = grdView.GetRowCellValue(intPos, "QueueTypeName")
        'returnValue.QueueFlowID = grdView.GetRowCellValue(intPos, "QueueFlowID")
        'returnValue.IsFreePass = grdView.GetRowCellValue(intPos, "IsFreePass")
        'returnValue.WBNumber = grdView.GetRowCellValue(intPos, "WBNumber")
        'returnValue.WBProgramID = grdView.GetRowCellValue(intPos, "WBProgramID")
        'returnValue.ContractNumber = grdView.GetRowCellValue(intPos, "ContractNumber")
        'returnValue.IsRepeat = grdView.GetRowCellValue(intPos, "IsRepeat")
        'returnValue.ReferencesID = grdView.GetRowCellValue(intPos, "ReferencesID")
        'returnValue.IsCompleted = grdView.GetRowCellValue(intPos, "IsCompleted")
        'returnValue.CompletedBy = grdView.GetRowCellValue(intPos, "CompletedBy")
        'returnValue.CompletedDate = IIf(grdView.GetRowCellValue(intPos, "CompletedDate").Equals(DBNull.Value), "2000/01/01", grdView.GetRowCellValue(intPos, "CompletedDate"))
        'returnValue.IsDeleted = grdView.GetRowCellValue(intPos, "IsDeleted")
        'returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        'returnValue.QueueDetail.IsRequested = grdView.GetRowCellValue(intPos, "IsRequested")
        'returnValue.QueueDetail.RequestedBy = grdView.GetRowCellValue(intPos, "RequestedBy")
        'returnValue.QueueDetail.RequestedDate = IIf(grdView.GetRowCellValue(intPos, "RequestedDate").Equals(DBNull.Value), "2000/01/01", grdView.GetRowCellValue(intPos, "RequestedDate"))
        'returnValue.QueueDetail.IsDone = grdView.GetRowCellValue(intPos, "IsDone")
        'returnValue.QueueDetail.DoneBy = grdView.GetRowCellValue(intPos, "DoneBy")
        'returnValue.QueueDetail.DoneDate = IIf(grdView.GetRowCellValue(intPos, "DoneDate").Equals(DBNull.Value), "2000/01/01", grdView.GetRowCellValue(intPos, "DoneDate"))
        Return returnValue
    End Function

    Private Sub prvGetDataByRFID(ByVal strRFID As String)
        pubRefresh()
        Dim drCheck() As DataRow = dtData.Select("RFID='" & strRFID & "'")
        If drCheck.Count = 0 Then UI.usForm.frmMessageBox("Data not available", "Get data by RFID") : Exit Sub
        UI.usForm.GridMoveRow(grdView, "ID", drCheck(0).Item("ID"))
        Dim intGet As Integer = grdView.FocusedRowHandle
        prvRequest(intGet)
    End Sub

    Private Sub prvRequest()
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        prvRequest(intPos)
    End Sub

    Private Sub prvRequest(ByVal intPositionData As Integer)
        clsData = prvGetData()
        Dim frmDetail As New frmTraQueueUnloadingConfirm
        With frmDetail
            .pubCS = clsCS
            .pubID = clsData.QueueDetail.ID
            .pubQueueID = clsData.ID
            .pubComLocDivSubDivIDStorage = clsData.ComLocDivSubDivIDStorage
            .pubProgramIDStorage = clsData.ProgramIDStorage
            .pubStorageGroupID = clsData.StorageGroupID
            .pubStorageID = clsData.StorageID
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvNewUnloading()
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        clsData = prvGetData()

        If clsData.IsHold = False Then
            UI.usForm.frmMessageBox("Cannot generate new unloading station if Onhold is unchecked")
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Generate new unloading for Plat Number " & clsData.PlatNumber & "?") Then Exit Sub

        Dim clsDetail As New VO.QueueDet
        clsDetail.ComLocDivSubDivID = clsData.ComLocDivSubDivID
        clsDetail.QueueID = clsData.ID
        clsDetail.ID = clsData.QueueDetail.ID
        clsDetail.Idx = clsData.QueueDetail.Idx + 1
        clsDetail.StationID = clsData.QueueDetail.StationID
        clsDetail.StationName = clsData.QueueDetail.StationName
        clsDetail.SubStationID = clsData.QueueDetail.SubStationID
        clsDetail.SubStationName = clsData.QueueDetail.SubStationName
        clsDetail.Remarks = ""
        clsDetail.LogBy = UI.usUserApp.UserID

        Try
            If BL.Queue.GenerateNewUnloadingStation(clsDetail) Then
                UI.usForm.frmMessageBox("Generate new unloading station success.")
                pubRefresh()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvResampling()
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        clsData = prvGetData()

        If clsData.IsHold = False Then
            UI.usForm.frmMessageBox("Cannot process resampling if Onhold is unchecked")
            Exit Sub
        End If

        Dim frmDetail As New frmTraQueueUnloadingResampling
        With frmDetail
            .pubCS = clsCS
            .pubPlatNumber = clsData.PlatNumber
            .pubComLocDivSubDivIDStorage = clsData.ComLocDivSubDivIDStorage
            .pubProgramIDStorageID = clsData.ProgramIDStorage
            .pubStorageGroupID = clsData.StorageGroupID
            .pubStorageID = clsData.StorageID
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then

                Dim clsDetailAll(1) As VO.QueueDet

                '# Sampling
                Dim clsDetail As New VO.QueueDet
                clsDetail.ComLocDivSubDivID = clsData.ComLocDivSubDivID
                clsDetail.QueueID = clsData.ID
                clsDetail.ID = clsData.QueueDetail.ID
                clsDetail.Idx = clsData.QueueDetail.Idx + 1
                clsDetail.StationID = .pubStationID
                clsDetail.StationName = .pubStationName
                clsDetail.SubStationID = .pubSubStationID
                clsDetail.SubStationName = .pubSubStationName
                clsDetail.Remarks = ""
                clsDetail.LogBy = UI.usUserApp.UserID
                clsDetailAll(0) = clsDetail

                '# Unloading
                clsDetail = New VO.QueueDet
                clsDetail.ComLocDivSubDivID = clsData.ComLocDivSubDivID
                clsDetail.QueueID = clsData.ID
                clsDetail.ID = clsData.QueueDetail.ID
                clsDetail.Idx = clsData.QueueDetail.Idx + 2
                clsDetail.StationID = clsData.QueueDetail.StationID
                clsDetail.StationName = clsData.QueueDetail.StationName
                clsDetail.SubStationID = clsData.QueueDetail.SubStationID
                clsDetail.SubStationName = clsData.QueueDetail.SubStationName
                clsDetail.Remarks = ""
                clsDetail.LogBy = UI.usUserApp.UserID
                clsDetailAll(1) = clsDetail

                Try
                    If BL.Queue.GenerateResamplingStation(clsDetailAll) Then
                        UI.usForm.frmMessageBox("Process resampling success.")
                        pubRefresh()
                    End If
                Catch ex As Exception
                    UI.usForm.frmMessageBox(ex.Message)
                End Try
            End If
        End With

    End Sub

    Private Sub prvReject()
        pubRefresh()
        prvGetCS()
        intPos = grdView.FocusedRowHandle
        clsData = prvGetData()

        If clsData.IsHold = False Then
            UI.usForm.frmMessageBox("Cannot reject if Onhold is unchecked")
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Reject Plat Number " & clsData.PlatNumber & "?") Then Exit Sub

        Dim frmDetail As New usFormRemarks
        With frmDetail
            .pubTitle = "Reject - Fill Remarks"
            .pubInfo = "Reject"
            .pubLabel = "Remarks"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                Dim clsDetail As New VO.QueueDet
                clsDetail.ComLocDivSubDivID = clsData.ComLocDivSubDivID
                clsDetail.QueueID = clsData.ID
                clsDetail.ID = clsData.QueueDetail.ID
                clsDetail.Idx = clsData.QueueDetail.Idx
                clsDetail.StationID = clsData.QueueDetail.StationID
                clsDetail.StationName = clsData.QueueDetail.StationName
                clsDetail.SubStationID = clsData.QueueDetail.SubStationID
                clsDetail.SubStationName = clsData.QueueDetail.SubStationName
                clsDetail.Remarks = clsData.QueueDetail.Remarks & " | REJECT: " & .pubValue
                clsDetail.LogBy = UI.usUserApp.UserID

                Try
                    If BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Reject, clsDetail) Then
                        UI.usForm.frmMessageBox("Reject data success.")
                        pubRefresh()
                    End If
                Catch ex As Exception
                    UI.usForm.frmMessageBox(ex.Message)
                End Try
            End If
        End With
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
        prvSetButton()
    End Sub

    Private Sub prvChooseCompany()
        Dim frmDetail As New frmMstCompany
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strCompanyID = .pubLUDataRow.Item("CompanyID")
                txtCompanyName.Text = .pubLUDataRow.Item("CompanyName")
            End If
        End With
    End Sub

    Private Sub prvChooseLocation()
        Dim frmDetail As New frmMstCompanyLocation
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = strCompanyID
            .pubLULocationID = clsCS.LocationID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strLocationID = .pubLUDataRow.Item("LocationID")
                txtLocationName.Text = .pubLUDataRow.Item("LocationName")
            End If
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            '.Item(cCheck).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "ADD")
            '.Item(cNewUnloading).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "EDIT")
            '.Item(cResample).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "DELETE")
            '.Item(cReject).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "DELETE")
        End With
    End Sub

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort1.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort1.IsOpen Then
                UI.usForm.usSerialPort1.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimer()
    End Sub

    Public Sub prvStartTimer()
        tmrRFID.Enabled = True
        tmrRFID.Interval = 1000
        tmrRFID.Start()
    End Sub

    Public Sub prvStopTimer()
        tmrRFID.Stop()
    End Sub

    Private Sub prvReadCard()
        Try
            bolIsRFIDValid = True
            If VO.DefaultServer.IsLinkRFIDDevice1 Then
                If Not UI.usForm.usSerialPort1.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort1 = UI.usForm.usSerialPort1.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort1.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Trim

            Dim clsRFID As VO.RFIDCard = BL.RFIDCard.RFIDExists(VO.DefaultServer.RFIDValueCOMPort1)

            If VO.DefaultServer.IsLinkRFIDDevice1 Then VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Substring(1, VO.DefaultServer.RFIDValueCOMPort1.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort1.Trim = VO.DefaultServer.PrevRFIDValueCOMPort1.Trim And intCount <= 5 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1
            intCount = 0

            If clsRFID.ID = "" Then
                bolIsRFIDValid = False
                UI.usForm.frmMessageBox("RFID not yet register")
            ElseIf clsRFID.IDStatus = VO.Status.Values.InActive Then
                bolIsRFIDValid = False
                UI.usForm.frmMessageBox("RFID status is IN-ACTIVE")
            Else
                prvGetDataByRFID(VO.DefaultServer.RFIDValueCOMPort1.Trim)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmTraQueueUnloading_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        If UI.usForm.usSerialPort1.IsOpen Then
            VO.DefaultServer.RFIDValueCOMPort1 = ""
            tmrRFID.Dispose()
            UI.usForm.usSerialPort1.Dispose()
        End If
    End Sub

    Private Sub frmTraQueueUnloading_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown

    End Sub

    Private Sub frmTraQueueUnloading_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvSetDefaultFilter()
        prvSetButton()

        dtpDateFrom.Value = Today.Date.AddDays(-7)
        dtpDateTo.Value = Today.Date

        Me.WindowState = FormWindowState.Maximized

        If VO.DefaultServer.IsLinkRFIDDevice1 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort1, VO.DefaultServer.COMPort1)
            If bolSuccessSettingSerialPort = False Then MsgBox("False setting serial port")
            prvStartReadRFID()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Request" : prvRequest()
            Case "New Unloading" : prvNewUnloading()
            Case "Resampling" : prvResampling()
            Case "Reject" : prvReject()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        prvChooseCompany()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        prvChooseLocation()
    End Sub

    Private Sub btnSubDivision_Click(sender As Object, e As EventArgs) Handles btnSubDivision.Click
        If strCompanyID.Trim = "" Then Exit Sub
        Dim frmDetail As New frmMstSubDivision
        With frmDetail
            .pubIsLookUp = True
            .pubLUProgramID = UI.usUserApp.ProgramID
            .pubLUCompanyID = strCompanyID.Trim
            .pubLUComLocDivSubDivID = intComLocDivSubDivID
            .ShowDialog()
            If .pubIsLookUpGet Then
                intComLocDivSubDivID = .pubLUComLocDivSubDivID
                strLocationID = .pubLUDataRow("LocationID")
                txtLocationName.Text = .pubLUDataRow("LocationName")
                txtDivisionName.Text = .pubLUDataRow("DivisionName")
                txtSubdivisionName.Text = .pubLUDataRow("SubDivisionName")
                prvClear()
            End If
        End With
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub cboStatus_SelectedIndexChanged(sender As Object, e As EventArgs)
        prvClear()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim strIsHold As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("IsHold"))
            If strIsHold = "Checked" And e.Appearance.BackColor <> Color.Yellow Then
                e.Appearance.BackColor = Color.Yellow
                e.Appearance.BackColor2 = Color.LightYellow
            End If
        End If
    End Sub

    Private Sub tmrRFID_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrRFID.Tick
        prvReadCard()
    End Sub

#End Region

End Class