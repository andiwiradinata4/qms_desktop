﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraQueueConfirm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTraQueueConfirm))
        Dim SerializableAppearanceObject1 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.txtWBProgramID = New QMSLib.usTextBox()
        Me.chkIsRepeat = New DevExpress.XtraEditors.CheckEdit()
        Me.chkIsFreePass = New DevExpress.XtraEditors.CheckEdit()
        Me.txtWBProgramName = New QMSLib.usTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtWBNumber = New QMSLib.usTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtContractNumber = New QMSLib.usTextBox()
        Me.btnStorage = New System.Windows.Forms.Button()
        Me.txtStorageGroupID = New QMSLib.usTextBox()
        Me.txtStorageGroupName = New QMSLib.usTextBox()
        Me.cboQueueType = New QMSLib.usComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtItemCode = New QMSLib.usTextBox()
        Me.txtItemName = New QMSLib.usTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtID = New QMSLib.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.btnItem = New System.Windows.Forms.Button()
        Me.txtQueueFlowID = New QMSLib.usTextBox()
        Me.txtQueueFlowName = New QMSLib.usTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnWBNumber = New System.Windows.Forms.Button()
        Me.btnWBProgram = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.grdQueueFlow = New DevExpress.XtraGrid.GridControl()
        Me.grdQueueFlowView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.btnChangeSubStation = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.txtStorageID = New QMSLib.usTextBox()
        Me.txtStorageName = New QMSLib.usTextBox()
        CType(Me.chkIsRepeat.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkIsFreePass.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlMain.SuspendLayout()
        CType(Me.grdQueueFlow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdQueueFlowView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnChangeSubStation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(501, 22)
        Me.lblInfo.TabIndex = 0
        Me.lblInfo.Text = "« Queue Confirm"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWBProgramID
        '
        Me.txtWBProgramID.BackColor = System.Drawing.Color.LightYellow
        Me.txtWBProgramID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWBProgramID.Location = New System.Drawing.Point(121, 110)
        Me.txtWBProgramID.Name = "txtWBProgramID"
        Me.txtWBProgramID.ReadOnly = True
        Me.txtWBProgramID.Size = New System.Drawing.Size(74, 21)
        Me.txtWBProgramID.TabIndex = 9
        '
        'chkIsRepeat
        '
        Me.chkIsRepeat.Location = New System.Drawing.Point(391, 13)
        Me.chkIsRepeat.Name = "chkIsRepeat"
        Me.chkIsRepeat.Properties.Caption = "Repeat?"
        Me.chkIsRepeat.Size = New System.Drawing.Size(65, 19)
        Me.chkIsRepeat.TabIndex = 2
        '
        'chkIsFreePass
        '
        Me.chkIsFreePass.Location = New System.Drawing.Point(304, 13)
        Me.chkIsFreePass.Name = "chkIsFreePass"
        Me.chkIsFreePass.Properties.Caption = "Free Pass?"
        Me.chkIsFreePass.Size = New System.Drawing.Size(75, 19)
        Me.chkIsFreePass.TabIndex = 1
        '
        'txtWBProgramName
        '
        Me.txtWBProgramName.BackColor = System.Drawing.Color.LightYellow
        Me.txtWBProgramName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWBProgramName.Location = New System.Drawing.Point(194, 110)
        Me.txtWBProgramName.Name = "txtWBProgramName"
        Me.txtWBProgramName.ReadOnly = True
        Me.txtWBProgramName.Size = New System.Drawing.Size(262, 21)
        Me.txtWBProgramName.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(20, 114)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(66, 13)
        Me.Label10.TabIndex = 153
        Me.Label10.Text = "WB Program"
        '
        'txtWBNumber
        '
        Me.txtWBNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtWBNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWBNumber.Location = New System.Drawing.Point(121, 134)
        Me.txtWBNumber.Name = "txtWBNumber"
        Me.txtWBNumber.ReadOnly = True
        Me.txtWBNumber.Size = New System.Drawing.Size(335, 21)
        Me.txtWBNumber.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(20, 138)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(63, 13)
        Me.Label9.TabIndex = 152
        Me.Label9.Text = "WB Number"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(20, 186)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 151
        Me.Label8.Text = "Storage"
        '
        'pnlMain
        '
        Me.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlMain.Controls.Add(Me.txtStorageID)
        Me.pnlMain.Controls.Add(Me.txtStorageName)
        Me.pnlMain.Controls.Add(Me.Label5)
        Me.pnlMain.Controls.Add(Me.txtContractNumber)
        Me.pnlMain.Controls.Add(Me.btnStorage)
        Me.pnlMain.Controls.Add(Me.txtStorageGroupID)
        Me.pnlMain.Controls.Add(Me.txtStorageGroupName)
        Me.pnlMain.Controls.Add(Me.cboQueueType)
        Me.pnlMain.Controls.Add(Me.Label4)
        Me.pnlMain.Controls.Add(Me.txtItemCode)
        Me.pnlMain.Controls.Add(Me.txtItemName)
        Me.pnlMain.Controls.Add(Me.Label3)
        Me.pnlMain.Controls.Add(Me.txtID)
        Me.pnlMain.Controls.Add(Me.lblID)
        Me.pnlMain.Controls.Add(Me.btnItem)
        Me.pnlMain.Controls.Add(Me.txtQueueFlowID)
        Me.pnlMain.Controls.Add(Me.txtQueueFlowName)
        Me.pnlMain.Controls.Add(Me.Label1)
        Me.pnlMain.Controls.Add(Me.btnWBNumber)
        Me.pnlMain.Controls.Add(Me.btnWBProgram)
        Me.pnlMain.Controls.Add(Me.txtWBProgramID)
        Me.pnlMain.Controls.Add(Me.Label8)
        Me.pnlMain.Controls.Add(Me.chkIsRepeat)
        Me.pnlMain.Controls.Add(Me.chkIsFreePass)
        Me.pnlMain.Controls.Add(Me.Label9)
        Me.pnlMain.Controls.Add(Me.txtWBProgramName)
        Me.pnlMain.Controls.Add(Me.txtWBNumber)
        Me.pnlMain.Controls.Add(Me.Label10)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlMain.Location = New System.Drawing.Point(0, 22)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(501, 240)
        Me.pnlMain.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(20, 162)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 13)
        Me.Label5.TabIndex = 167
        Me.Label5.Text = "Contract Number"
        '
        'txtContractNumber
        '
        Me.txtContractNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtContractNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContractNumber.Location = New System.Drawing.Point(121, 158)
        Me.txtContractNumber.Name = "txtContractNumber"
        Me.txtContractNumber.ReadOnly = True
        Me.txtContractNumber.Size = New System.Drawing.Size(335, 21)
        Me.txtContractNumber.TabIndex = 14
        '
        'btnStorage
        '
        Me.btnStorage.BackColor = System.Drawing.Color.Transparent
        Me.btnStorage.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStorage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStorage.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStorage.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnStorage.Image = CType(resources.GetObject("btnStorage.Image"), System.Drawing.Image)
        Me.btnStorage.Location = New System.Drawing.Point(458, 181)
        Me.btnStorage.Name = "btnStorage"
        Me.btnStorage.Size = New System.Drawing.Size(19, 20)
        Me.btnStorage.TabIndex = 19
        Me.btnStorage.TabStop = False
        Me.btnStorage.UseVisualStyleBackColor = False
        '
        'txtStorageGroupID
        '
        Me.txtStorageGroupID.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageGroupID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageGroupID.Location = New System.Drawing.Point(121, 182)
        Me.txtStorageGroupID.Name = "txtStorageGroupID"
        Me.txtStorageGroupID.ReadOnly = True
        Me.txtStorageGroupID.Size = New System.Drawing.Size(74, 21)
        Me.txtStorageGroupID.TabIndex = 15
        '
        'txtStorageGroupName
        '
        Me.txtStorageGroupName.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageGroupName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageGroupName.Location = New System.Drawing.Point(194, 182)
        Me.txtStorageGroupName.Name = "txtStorageGroupName"
        Me.txtStorageGroupName.ReadOnly = True
        Me.txtStorageGroupName.Size = New System.Drawing.Size(262, 21)
        Me.txtStorageGroupName.TabIndex = 16
        '
        'cboQueueType
        '
        Me.cboQueueType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQueueType.FormattingEnabled = True
        Me.cboQueueType.Location = New System.Drawing.Point(121, 37)
        Me.cboQueueType.Name = "cboQueueType"
        Me.cboQueueType.Size = New System.Drawing.Size(169, 21)
        Me.cboQueueType.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(20, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 165
        Me.Label4.Text = "Queue Type"
        '
        'txtItemCode
        '
        Me.txtItemCode.BackColor = System.Drawing.Color.LightYellow
        Me.txtItemCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtItemCode.Location = New System.Drawing.Point(121, 62)
        Me.txtItemCode.Name = "txtItemCode"
        Me.txtItemCode.ReadOnly = True
        Me.txtItemCode.Size = New System.Drawing.Size(74, 21)
        Me.txtItemCode.TabIndex = 4
        '
        'txtItemName
        '
        Me.txtItemName.BackColor = System.Drawing.Color.LightYellow
        Me.txtItemName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtItemName.Location = New System.Drawing.Point(194, 62)
        Me.txtItemName.Name = "txtItemName"
        Me.txtItemName.ReadOnly = True
        Me.txtItemName.Size = New System.Drawing.Size(262, 21)
        Me.txtItemName.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(20, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 13)
        Me.Label3.TabIndex = 164
        Me.Label3.Text = "Item"
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Location = New System.Drawing.Point(121, 13)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(169, 21)
        Me.txtID.TabIndex = 0
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(20, 16)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(18, 13)
        Me.lblID.TabIndex = 161
        Me.lblID.Text = "ID"
        '
        'btnItem
        '
        Me.btnItem.BackColor = System.Drawing.Color.Transparent
        Me.btnItem.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnItem.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnItem.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnItem.Image = CType(resources.GetObject("btnItem.Image"), System.Drawing.Image)
        Me.btnItem.Location = New System.Drawing.Point(458, 61)
        Me.btnItem.Name = "btnItem"
        Me.btnItem.Size = New System.Drawing.Size(19, 20)
        Me.btnItem.TabIndex = 6
        Me.btnItem.TabStop = False
        Me.btnItem.UseVisualStyleBackColor = False
        '
        'txtQueueFlowID
        '
        Me.txtQueueFlowID.BackColor = System.Drawing.Color.LightYellow
        Me.txtQueueFlowID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtQueueFlowID.Location = New System.Drawing.Point(121, 86)
        Me.txtQueueFlowID.Name = "txtQueueFlowID"
        Me.txtQueueFlowID.ReadOnly = True
        Me.txtQueueFlowID.Size = New System.Drawing.Size(74, 21)
        Me.txtQueueFlowID.TabIndex = 7
        '
        'txtQueueFlowName
        '
        Me.txtQueueFlowName.BackColor = System.Drawing.Color.LightYellow
        Me.txtQueueFlowName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtQueueFlowName.Location = New System.Drawing.Point(194, 86)
        Me.txtQueueFlowName.Name = "txtQueueFlowName"
        Me.txtQueueFlowName.ReadOnly = True
        Me.txtQueueFlowName.Size = New System.Drawing.Size(262, 21)
        Me.txtQueueFlowName.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(20, 90)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 13)
        Me.Label1.TabIndex = 158
        Me.Label1.Text = "Queue Flow"
        '
        'btnWBNumber
        '
        Me.btnWBNumber.BackColor = System.Drawing.Color.Transparent
        Me.btnWBNumber.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnWBNumber.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWBNumber.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWBNumber.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnWBNumber.Image = CType(resources.GetObject("btnWBNumber.Image"), System.Drawing.Image)
        Me.btnWBNumber.Location = New System.Drawing.Point(458, 133)
        Me.btnWBNumber.Name = "btnWBNumber"
        Me.btnWBNumber.Size = New System.Drawing.Size(19, 20)
        Me.btnWBNumber.TabIndex = 13
        Me.btnWBNumber.TabStop = False
        Me.btnWBNumber.UseVisualStyleBackColor = False
        '
        'btnWBProgram
        '
        Me.btnWBProgram.BackColor = System.Drawing.Color.Transparent
        Me.btnWBProgram.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnWBProgram.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWBProgram.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWBProgram.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnWBProgram.Image = CType(resources.GetObject("btnWBProgram.Image"), System.Drawing.Image)
        Me.btnWBProgram.Location = New System.Drawing.Point(458, 109)
        Me.btnWBProgram.Name = "btnWBProgram"
        Me.btnWBProgram.Size = New System.Drawing.Size(19, 20)
        Me.btnWBProgram.TabIndex = 11
        Me.btnWBProgram.TabStop = False
        Me.btnWBProgram.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.CadetBlue
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(0, 262)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(501, 22)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "« Queue Flow"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grdQueueFlow
        '
        Me.grdQueueFlow.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdQueueFlow.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdQueueFlow.Location = New System.Drawing.Point(0, 284)
        Me.grdQueueFlow.MainView = Me.grdQueueFlowView
        Me.grdQueueFlow.Name = "grdQueueFlow"
        Me.grdQueueFlow.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.btnChangeSubStation})
        Me.grdQueueFlow.Size = New System.Drawing.Size(501, 241)
        Me.grdQueueFlow.TabIndex = 3
        Me.grdQueueFlow.UseEmbeddedNavigator = True
        Me.grdQueueFlow.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdQueueFlowView})
        '
        'grdQueueFlowView
        '
        Me.grdQueueFlowView.GridControl = Me.grdQueueFlow
        Me.grdQueueFlowView.Name = "grdQueueFlowView"
        Me.grdQueueFlowView.OptionsCustomization.AllowColumnMoving = False
        Me.grdQueueFlowView.OptionsCustomization.AllowGroup = False
        Me.grdQueueFlowView.OptionsView.ColumnAutoWidth = False
        Me.grdQueueFlowView.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never
        Me.grdQueueFlowView.OptionsView.ShowGroupPanel = False
        '
        'btnChangeSubStation
        '
        Me.btnChangeSubStation.AutoHeight = False
        Me.btnChangeSubStation.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Search, "", -1, True, True, False, DevExpress.XtraEditors.ImageLocation.MiddleCenter, Nothing, New DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), SerializableAppearanceObject1, "Change Substation", Nothing, Nothing, True)})
        Me.btnChangeSubStation.Name = "btnChangeSubStation"
        '
        'txtStorageID
        '
        Me.txtStorageID.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageID.Location = New System.Drawing.Point(121, 203)
        Me.txtStorageID.Name = "txtStorageID"
        Me.txtStorageID.ReadOnly = True
        Me.txtStorageID.Size = New System.Drawing.Size(74, 21)
        Me.txtStorageID.TabIndex = 17
        '
        'txtStorageName
        '
        Me.txtStorageName.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageName.Location = New System.Drawing.Point(194, 203)
        Me.txtStorageName.Name = "txtStorageName"
        Me.txtStorageName.ReadOnly = True
        Me.txtStorageName.Size = New System.Drawing.Size(262, 21)
        Me.txtStorageName.TabIndex = 18
        '
        'frmTraQueueConfirm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(501, 525)
        Me.Controls.Add(Me.grdQueueFlow)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.lblInfo)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTraQueueConfirm"
        Me.Text = "Queue"
        CType(Me.chkIsRepeat.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkIsFreePass.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlMain.ResumeLayout(False)
        Me.pnlMain.PerformLayout()
        CType(Me.grdQueueFlow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdQueueFlowView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnChangeSubStation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents txtWBProgramID As QMSLib.usTextBox
    Friend WithEvents chkIsRepeat As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkIsFreePass As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents txtWBProgramName As QMSLib.usTextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtWBNumber As QMSLib.usTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents btnWBNumber As System.Windows.Forms.Button
    Friend WithEvents btnWBProgram As System.Windows.Forms.Button
    Friend WithEvents btnItem As System.Windows.Forms.Button
    Friend WithEvents txtQueueFlowID As QMSLib.usTextBox
    Friend WithEvents txtQueueFlowName As QMSLib.usTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents grdQueueFlow As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdQueueFlowView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents txtID As QMSLib.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtItemCode As QMSLib.usTextBox
    Friend WithEvents txtItemName As QMSLib.usTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboQueueType As QMSLib.usComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnStorage As System.Windows.Forms.Button
    Friend WithEvents txtStorageGroupID As QMSLib.usTextBox
    Friend WithEvents txtStorageGroupName As QMSLib.usTextBox
    Friend WithEvents btnChangeSubStation As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtContractNumber As QMSLib.usTextBox
    Friend WithEvents txtStorageID As QMSLib.usTextBox
    Friend WithEvents txtStorageName As QMSLib.usTextBox
End Class
