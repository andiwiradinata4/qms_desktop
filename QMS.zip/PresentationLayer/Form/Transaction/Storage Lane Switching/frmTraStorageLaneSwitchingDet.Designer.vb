﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTraStorageLaneSwitchingDet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTraStorageLaneSwitchingDet))
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.tcStorage = New System.Windows.Forms.TabControl()
        Me.tpMain = New System.Windows.Forms.TabPage()
        Me.txtStorageID = New QMS.usTextBox()
        Me.txtStorageName = New QMS.usTextBox()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.txtRemarks = New QMS.usTextBox()
        Me.btnStorage = New System.Windows.Forms.Button()
        Me.txtStorageGroupID = New QMS.usTextBox()
        Me.txtStorageGroupName = New QMS.usTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpCreatedDate = New System.Windows.Forms.DateTimePicker()
        Me.txtID = New QMS.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.tpStatus = New System.Windows.Forms.TabPage()
        Me.grdStatusHistory = New DevExpress.XtraGrid.GridControl()
        Me.grdHistoryView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolBarDetail = New QMS.usToolBar()
        Me.BarAdd = New System.Windows.Forms.ToolBarButton()
        Me.BarDelete = New System.Windows.Forms.ToolBarButton()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripEmpty = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogInc = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogBy = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogDate = New System.Windows.Forms.ToolStripStatusLabel()
        Me.grdItem = New DevExpress.XtraGrid.GridControl()
        Me.grdItemView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.tcStorage.SuspendLayout()
        Me.tpMain.SuspendLayout()
        Me.tpStatus.SuspendLayout()
        CType(Me.grdStatusHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdHistoryView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip.SuspendLayout()
        CType(Me.grdItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdItemView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(585, 22)
        Me.lblInfo.TabIndex = 0
        Me.lblInfo.Text = "« Storage - Lane Switching Detail"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tcStorage
        '
        Me.tcStorage.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tcStorage.Controls.Add(Me.tpMain)
        Me.tcStorage.Controls.Add(Me.tpStatus)
        Me.tcStorage.Dock = System.Windows.Forms.DockStyle.Top
        Me.tcStorage.Location = New System.Drawing.Point(0, 22)
        Me.tcStorage.Name = "tcStorage"
        Me.tcStorage.SelectedIndex = 0
        Me.tcStorage.Size = New System.Drawing.Size(585, 197)
        Me.tcStorage.TabIndex = 1
        '
        'tpMain
        '
        Me.tpMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpMain.Controls.Add(Me.txtStorageID)
        Me.tpMain.Controls.Add(Me.txtStorageName)
        Me.tpMain.Controls.Add(Me.lblRemarks)
        Me.tpMain.Controls.Add(Me.txtRemarks)
        Me.tpMain.Controls.Add(Me.btnStorage)
        Me.tpMain.Controls.Add(Me.txtStorageGroupID)
        Me.tpMain.Controls.Add(Me.txtStorageGroupName)
        Me.tpMain.Controls.Add(Me.Label8)
        Me.tpMain.Controls.Add(Me.Label1)
        Me.tpMain.Controls.Add(Me.dtpCreatedDate)
        Me.tpMain.Controls.Add(Me.txtID)
        Me.tpMain.Controls.Add(Me.lblID)
        Me.tpMain.Location = New System.Drawing.Point(4, 25)
        Me.tpMain.Name = "tpMain"
        Me.tpMain.Size = New System.Drawing.Size(577, 168)
        Me.tpMain.TabIndex = 0
        Me.tpMain.Text = "Main - F1"
        Me.tpMain.UseVisualStyleBackColor = True
        '
        'txtStorageID
        '
        Me.txtStorageID.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageID.Location = New System.Drawing.Point(90, 65)
        Me.txtStorageID.Name = "txtStorageID"
        Me.txtStorageID.ReadOnly = True
        Me.txtStorageID.Size = New System.Drawing.Size(74, 21)
        Me.txtStorageID.TabIndex = 3
        '
        'txtStorageName
        '
        Me.txtStorageName.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageName.Location = New System.Drawing.Point(163, 65)
        Me.txtStorageName.Name = "txtStorageName"
        Me.txtStorageName.ReadOnly = True
        Me.txtStorageName.Size = New System.Drawing.Size(375, 21)
        Me.txtStorageName.TabIndex = 4
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.BackColor = System.Drawing.Color.Transparent
        Me.lblRemarks.ForeColor = System.Drawing.Color.Black
        Me.lblRemarks.Location = New System.Drawing.Point(26, 95)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(48, 13)
        Me.lblRemarks.TabIndex = 157
        Me.lblRemarks.Text = "Remarks"
        '
        'txtRemarks
        '
        Me.txtRemarks.BackColor = System.Drawing.Color.White
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Location = New System.Drawing.Point(90, 92)
        Me.txtRemarks.MaxLength = 250
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(448, 60)
        Me.txtRemarks.TabIndex = 5
        '
        'btnStorage
        '
        Me.btnStorage.BackColor = System.Drawing.Color.Transparent
        Me.btnStorage.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStorage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStorage.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStorage.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnStorage.Image = CType(resources.GetObject("btnStorage.Image"), System.Drawing.Image)
        Me.btnStorage.Location = New System.Drawing.Point(541, 43)
        Me.btnStorage.Name = "btnStorage"
        Me.btnStorage.Size = New System.Drawing.Size(19, 20)
        Me.btnStorage.TabIndex = 7
        Me.btnStorage.TabStop = False
        Me.btnStorage.UseVisualStyleBackColor = False
        '
        'txtStorageGroupID
        '
        Me.txtStorageGroupID.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageGroupID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageGroupID.Location = New System.Drawing.Point(90, 44)
        Me.txtStorageGroupID.Name = "txtStorageGroupID"
        Me.txtStorageGroupID.ReadOnly = True
        Me.txtStorageGroupID.Size = New System.Drawing.Size(74, 21)
        Me.txtStorageGroupID.TabIndex = 1
        '
        'txtStorageGroupName
        '
        Me.txtStorageGroupName.BackColor = System.Drawing.Color.LightYellow
        Me.txtStorageGroupName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStorageGroupName.Location = New System.Drawing.Point(163, 44)
        Me.txtStorageGroupName.Name = "txtStorageGroupName"
        Me.txtStorageGroupName.ReadOnly = True
        Me.txtStorageGroupName.Size = New System.Drawing.Size(375, 21)
        Me.txtStorageGroupName.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(26, 48)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 155
        Me.Label8.Text = "Storage"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(306, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 123
        Me.Label1.Text = "Created Date"
        '
        'dtpCreatedDate
        '
        Me.dtpCreatedDate.CustomFormat = "dd/MM/yyyy HH:mm:ss"
        Me.dtpCreatedDate.Enabled = False
        Me.dtpCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpCreatedDate.Location = New System.Drawing.Point(386, 14)
        Me.dtpCreatedDate.Name = "dtpCreatedDate"
        Me.dtpCreatedDate.Size = New System.Drawing.Size(152, 21)
        Me.dtpCreatedDate.TabIndex = 6
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Location = New System.Drawing.Point(90, 17)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(152, 21)
        Me.txtID.TabIndex = 0
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(26, 20)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(18, 13)
        Me.lblID.TabIndex = 122
        Me.lblID.Text = "ID"
        '
        'tpStatus
        '
        Me.tpStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpStatus.Controls.Add(Me.grdStatusHistory)
        Me.tpStatus.Location = New System.Drawing.Point(4, 25)
        Me.tpStatus.Name = "tpStatus"
        Me.tpStatus.Size = New System.Drawing.Size(577, 168)
        Me.tpStatus.TabIndex = 1
        Me.tpStatus.Text = "Status - F2"
        Me.tpStatus.UseVisualStyleBackColor = True
        '
        'grdStatusHistory
        '
        Me.grdStatusHistory.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdStatusHistory.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdStatusHistory.Location = New System.Drawing.Point(0, 0)
        Me.grdStatusHistory.MainView = Me.grdHistoryView
        Me.grdStatusHistory.Name = "grdStatusHistory"
        Me.grdStatusHistory.Size = New System.Drawing.Size(573, 164)
        Me.grdStatusHistory.TabIndex = 1
        Me.grdStatusHistory.UseEmbeddedNavigator = True
        Me.grdStatusHistory.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdHistoryView})
        '
        'grdHistoryView
        '
        Me.grdHistoryView.GridControl = Me.grdStatusHistory
        Me.grdHistoryView.Name = "grdHistoryView"
        Me.grdHistoryView.OptionsCustomization.AllowColumnMoving = False
        Me.grdHistoryView.OptionsCustomization.AllowGroup = False
        Me.grdHistoryView.OptionsView.ColumnAutoWidth = False
        Me.grdHistoryView.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never
        Me.grdHistoryView.OptionsView.ShowGroupPanel = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.CadetBlue
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(0, 219)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(585, 22)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "« Unloading Slot"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolBarDetail
        '
        Me.ToolBarDetail.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBarDetail.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarAdd, Me.BarDelete})
        Me.ToolBarDetail.DropDownArrows = True
        Me.ToolBarDetail.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolBarDetail.Location = New System.Drawing.Point(0, 241)
        Me.ToolBarDetail.Name = "ToolBarDetail"
        Me.ToolBarDetail.ShowToolTips = True
        Me.ToolBarDetail.Size = New System.Drawing.Size(585, 28)
        Me.ToolBarDetail.TabIndex = 3
        Me.ToolBarDetail.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarAdd
        '
        Me.BarAdd.Name = "BarAdd"
        Me.BarAdd.Tag = "Add"
        Me.BarAdd.Text = "Add"
        '
        'BarDelete
        '
        Me.BarDelete.Name = "BarDelete"
        Me.BarDelete.Tag = "Delete"
        Me.BarDelete.Text = "Delete"
        '
        'StatusStrip
        '
        Me.StatusStrip.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripEmpty, Me.ToolStripLogInc, Me.ToolStripLogBy, Me.ToolStripStatusLabel1, Me.ToolStripLogDate})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 478)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(585, 22)
        Me.StatusStrip.TabIndex = 7
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'ToolStripEmpty
        '
        Me.ToolStripEmpty.Name = "ToolStripEmpty"
        Me.ToolStripEmpty.Size = New System.Drawing.Size(462, 17)
        Me.ToolStripEmpty.Spring = True
        '
        'ToolStripLogInc
        '
        Me.ToolStripLogInc.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogInc.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogInc.Name = "ToolStripLogInc"
        Me.ToolStripLogInc.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogInc.Text = "Log Inc : "
        '
        'ToolStripLogBy
        '
        Me.ToolStripLogBy.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogBy.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogBy.Name = "ToolStripLogBy"
        Me.ToolStripLogBy.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogBy.Text = "Last Log :"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripLogDate
        '
        Me.ToolStripLogDate.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogDate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogDate.Name = "ToolStripLogDate"
        Me.ToolStripLogDate.Size = New System.Drawing.Size(12, 17)
        Me.ToolStripLogDate.Text = "-"
        '
        'grdItem
        '
        Me.grdItem.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdItem.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdItem.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdItem.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdItem.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdItem.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdItem.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdItem.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdItem.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdItem.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdItem.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdItem.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdItem.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdItem.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdItem.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdItem.Location = New System.Drawing.Point(0, 269)
        Me.grdItem.MainView = Me.grdItemView
        Me.grdItem.Name = "grdItem"
        Me.grdItem.Size = New System.Drawing.Size(585, 209)
        Me.grdItem.TabIndex = 4
        Me.grdItem.UseEmbeddedNavigator = True
        Me.grdItem.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdItemView})
        '
        'grdItemView
        '
        Me.grdItemView.GridControl = Me.grdItem
        Me.grdItemView.Name = "grdItemView"
        Me.grdItemView.OptionsCustomization.AllowColumnMoving = False
        Me.grdItemView.OptionsCustomization.AllowGroup = False
        Me.grdItemView.OptionsView.ColumnAutoWidth = False
        Me.grdItemView.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never
        Me.grdItemView.OptionsView.ShowGroupPanel = False
        '
        'frmTraStorageLaneSwitchingDet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(585, 500)
        Me.Controls.Add(Me.grdItem)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.ToolBarDetail)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tcStorage)
        Me.Controls.Add(Me.lblInfo)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTraStorageLaneSwitchingDet"
        Me.Text = "Storage - Lane Switching"
        Me.tcStorage.ResumeLayout(False)
        Me.tpMain.ResumeLayout(False)
        Me.tpMain.PerformLayout()
        Me.tpStatus.ResumeLayout(False)
        CType(Me.grdStatusHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdHistoryView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        CType(Me.grdItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdItemView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents tcStorage As System.Windows.Forms.TabControl
    Friend WithEvents tpMain As System.Windows.Forms.TabPage
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents txtRemarks As QMS.usTextBox
    Friend WithEvents btnStorage As System.Windows.Forms.Button
    Friend WithEvents txtStorageGroupID As QMS.usTextBox
    Friend WithEvents txtStorageGroupName As QMS.usTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpCreatedDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtID As QMS.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents tpStatus As System.Windows.Forms.TabPage
    Friend WithEvents grdStatusHistory As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdHistoryView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ToolBarDetail As QMS.usToolBar
    Friend WithEvents BarAdd As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarDelete As System.Windows.Forms.ToolBarButton
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripEmpty As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogInc As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogBy As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogDate As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents grdItem As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdItemView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents txtStorageID As QMS.usTextBox
    Friend WithEvents txtStorageName As QMS.usTextBox
End Class
