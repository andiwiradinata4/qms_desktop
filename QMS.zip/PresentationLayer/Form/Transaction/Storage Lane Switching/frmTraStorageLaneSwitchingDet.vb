﻿Public Class frmTraStorageLaneSwitchingDet

#Region "Property Handle"

    Private frmParent As frmTraStorageLaneSwitching
    Private clsData As VO.StorageLaneSwitching
    Private dtUnloadingSlot As New DataTable
    Private intComLocDivSubDivIDStorage As Integer = 0
    Private strProgramIDStorage As String = ""
    Property pubID As String
    Property pubIsNew As Boolean = False
    Property pubIsSave As Boolean = False
    Property pubCS As New VO.CS
    Private Const _
        cSave = 0, cClose = 1, _
        cAdd = 0, cDelete = 1
    Private intPos As Integer

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        '# Unloading Slot
        UI.usForm.SetGrid(grdItemView, "ID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdItemView, "StorageLaneSwitchingID", "StorageLaneSwitchingID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdItemView, "SubStationID", "SubStationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdItemView, "SubStationName", "Substation Name", 300, UI.usDefGrid.gString)

        '# Status
        UI.usForm.SetGrid(grdHistoryView, "Status", "Status", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdHistoryView, "StatusBy", "Status By", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdHistoryView, "StatusDate", "Status Date", 150, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdHistoryView, "Remarks", "Remarks", 300, UI.usDefGrid.gString)
    End Sub

    Private Sub prvSetTitleForm()
        If pubIsNew Then
            Me.Text += " [new] "
        Else
            Me.Text += " [edit] "
        End If
    End Sub

    Private Sub prvFillForm()
        Try
            If pubIsNew Then
                prvClear()
            Else
                clsData = New VO.StorageLaneSwitching
                clsData = BL.StorageLaneSwitching.GetDetail(pubID)
                intComLocDivSubDivIDStorage = clsData.ComLocDivSubDivID
                strProgramIDStorage = clsData.ProgramID
                txtID.Text = clsData.ID
                txtStorageGroupID.Text = clsData.StorageGroupID
                txtStorageGroupName.Text = clsData.StorageGroupName
                txtStorageID.Text = clsData.StorageID
                txtStorageName.Text = clsData.StorageName
                dtpCreatedDate.Value = clsData.CreatedDate
                txtRemarks.Text = clsData.Remarks
                ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
                ToolStripLogBy.Text = "Last Log : " & clsData.LogBy
                ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvQueryStatus()
        Try
            grdStatusHistory.DataSource = BL.StorageLaneSwitching.ListDataStatus(txtID.Text.Trim)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvChooseStorage()
        Dim frmDetail As New frmMstStorage
        With frmDetail
            .pubIsLookUp = True
            .pubLUStorageID = txtStorageID.Text.Trim
            .pubCS = pubCS
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                intComLocDivSubDivIDStorage = .pubLUdtRow.Item("ComLocDivSubDivID")
                strProgramIDStorage = .pubLUdtRow.Item("ProgramID")
                txtStorageGroupID.Text = .pubLUdtRow.Item("StorageGroupID")
                txtStorageGroupName.Text = .pubLUdtRow.Item("StorageGroupName")
                txtStorageID.Text = .pubLUdtRow.Item("StorageID")
                txtStorageName.Text = .pubLUdtRow.Item("StorageName")
            End If
        End With
    End Sub

    Public Sub prvSave()
        If txtStorageID.Text.Trim = "" Or txtStorageName.Text.Trim = "" _
            Or txtStorageGroupID.Text.Trim = "" Or txtStorageGroupName.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Storage not allow blank")
            txtStorageID.Focus()
            Exit Sub
        ElseIf grdItemView.RowCount = 0 Then
            UI.usForm.frmMessageBox("Please input unloading slot first")
            grdItemView.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        clsData = New VO.StorageLaneSwitching
        clsData.ComLocDivSubDivID = intComLocDivSubDivIDStorage
        clsData.ProgramID = strProgramIDStorage
        clsData.CompanyID = pubCS.CompanyID
        clsData.CompanyName = pubCS.CompanyName
        clsData.LocationID = pubCS.LocationID
        clsData.LocationName = pubCS.LocationName
        clsData.ID = txtID.Text.Trim
        clsData.StorageGroupID = txtStorageGroupID.Text.Trim
        clsData.StorageGroupName = txtStorageGroupName.Text.Trim
        clsData.StorageID = txtStorageID.Text.Trim
        clsData.StorageName = txtStorageName.Text.Trim
        clsData.CreatedDate = Now
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID

        Dim clsDetail As VO.StorageLaneSwitchingDet
        Dim clsDetailAll(grdItemView.RowCount - 1) As VO.StorageLaneSwitchingDet

        With grdItemView
            For i As Integer = 0 To .RowCount - 1
                clsDetail = New VO.StorageLaneSwitchingDet
                clsDetail.StorageLaneSwitchingID = txtID.Text.Trim
                clsDetail.SubStationID = .GetRowCellValue(i, "SubStationID")
                clsDetail.SubStationName = .GetRowCellValue(i, "SubStationName")
                clsDetailAll(i) = clsDetail
            Next
        End With
        Try
            BL.StorageLaneSwitching.SaveData(pubIsNew, clsData, clsDetailAll)
            UI.usForm.frmMessageBox("Save data success." & IIf(pubIsNew, " ID: " & clsData.ID, ""))
            If pubIsNew Then
                frmParent.pubRefresh(clsData.ID)
                prvClear()
                prvQueryUnloadingSlot()
                prvQueryStatus()
            Else
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        txtID.Text = ""
        txtStorageGroupID.Text = ""
        txtStorageGroupName.Text = ""
        txtStorageID.Text = ""
        txtStorageName.Text = ""
        dtpCreatedDate.Value = Now
        txtRemarks.Text = ""
        ToolStripLogInc.Text = "Log Inc : -"
        ToolStripLogBy.Text = "Last Log : -"
        ToolStripLogDate.Text = Format(Now, UI.usDefCons.DateFull)
    End Sub

#Region "Unloading Slot"

    Private Sub prvSetButtonUnloadingSlot()
        Dim bolEnable As Boolean = IIf(grdItemView.RowCount > 0, True, False)
        With ToolBarDetail.Buttons
            .Item(cDelete).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQueryUnloadingSlot()
        Try
            dtUnloadingSlot = BL.StorageLaneSwitching.ListDataDetail(txtID.Text.Trim)
            grdItem.DataSource = dtUnloadingSlot
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButtonUnloadingSlot()
        End Try
    End Sub

    Private Sub prvAddUnloadingSlot()
        If txtStorageID.Text.Trim = "" Or txtStorageName.Text.Trim = "" _
            Or txtStorageGroupID.Text.Trim = "" Or txtStorageGroupName.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please choose Storage first")
            txtStorageID.Focus()
            Exit Sub
        End If
        Dim frmDetail As New frmMstSubStation
        With frmDetail
            .pubIsLookUp = True
            .pubIsLookGetMulti = True
            .pubIsEnabledChangeComLoc = False
            .pubCS = pubCS
            .pubEnumLinkedStorage = VO.SubStation.FilterIsLinkedStorage.IsLinkedStorage
            .pubComLocDivSubDivIDStorage = intComLocDivSubDivIDStorage
            .pubProgramIDStorage = strProgramIDStorage
            .pubStorageGroupID = txtStorageGroupID.Text.Trim
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                Dim drUnloadingSlot As DataRow
                Dim bolExist As Boolean = False
                For Each dr As DataRow In .pubLUdtRowMulti
                    Dim drRowExists() As DataRow = dtUnloadingSlot.Select("SubStationID=" & dr.Item("ID"))
                    If drRowExists.Count > 0 Then
                        UI.usForm.frmMessageBox(dr.Item("Description") & " already exists")
                        Exit Sub
                    End If
                Next

                For Each dr As DataRow In .pubLUdtRowMulti
                    drUnloadingSlot = dtUnloadingSlot.NewRow
                    With drUnloadingSlot
                        .BeginEdit()
                        .Item("ID") = ""
                        .Item("StorageLaneSwitchingID") = txtID.Text.Trim
                        .Item("SubStationID") = dr.Item("ID")
                        .Item("SubStationName") = dr.Item("Description")
                        .EndEdit()
                    End With
                    dtUnloadingSlot.Rows.Add(drUnloadingSlot)
                Next
                dtUnloadingSlot.AcceptChanges()
            End If
        End With
    End Sub

    Private Sub prvDeleteUnloadingSlot()
        intPos = grdItemView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        For Each drItem As DataRow In dtUnloadingSlot.Rows
            With drItem
                If .Item("SubStationID") = grdItemView.GetRowCellValue(intPos, "SubStationID") Then
                    drItem.Delete()
                    Exit For
                End If
            End With
        Next
        dtUnloadingSlot.AcceptChanges()
        prvSetButtonUnloadingSlot()
    End Sub

#End Region

#End Region

#Region "Form Handle"

    Private Sub frmStorageLaneSwitchingDet_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F1 Then
            tcStorage.SelectedTab = tpMain
        ElseIf e.KeyCode = Keys.F2 Then
            tcStorage.SelectedTab = tpStatus
        End If
    End Sub

    Private Sub frmStorageLaneSwitchingDet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, "TRASTORAGELANESWTCHING", IIf(pubIsNew, "ADD", "EDIT")))
        ToolBarDetail.SetIcon(Me)
        prvSetTitleForm()
        prvSetGrid()
        prvFillForm()
        prvQueryUnloadingSlot()
        prvQueryStatus()
    End Sub

    Private Sub btnStorage_Click(sender As Object, e As EventArgs) Handles btnStorage.Click
        prvChooseStorage()
    End Sub

    Private Sub ToolBarDetail_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarDetail.ButtonClick
        Select Case e.Button.Text
            Case "Add" : prvAddUnloadingSlot()
            Case "Delete" : prvDeleteUnloadingSlot()
        End Select
    End Sub

#End Region

End Class