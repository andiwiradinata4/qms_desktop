﻿Public Class frmTraStorageLaneSwitching

#Region "Properties Handle"

    Private clsData As VO.StorageLaneSwitching
    Private intPos As Integer
    Private strCompanyID As String = "", strLocationID = ""
    Private clsCS As New VO.CS
    Private Const _
       cNew = 0, cDetail = 1, cDelete = 2, cSep1 = 3, cRefresh = 4, cClose = 5

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ProgramID", "Program ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "CompanyID", "Company ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CompanyName", "Company Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LocationID", "Location ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LocationName", "Location Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageGroupID", "Storage Group ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageGroupName", "Storage Group Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageID", "Storage ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StorageName", "Storage Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsDeleted", "IsDeleted", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cDetail).Enabled = bolEnable
            .Item(cDelete).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvSetDefaultFilter()
        strCompanyID = UI.usUserApp.CompanyID
        txtCompanyName.Text = UI.usUserApp.CompanyName
        strLocationID = UI.usUserApp.LocationID
        txtLocationName.Text = UI.usUserApp.LocationName
        prvUserAccess()
    End Sub

    Private Sub prvGetCS()
        clsCS = New VO.CS
        clsCS.ProgramID = UI.usUserApp.ProgramID
        clsCS.ProgramName = UI.usUserApp.ProgramName
        clsCS.CompanyID = strCompanyID
        clsCS.CompanyName = txtCompanyName.Text.Trim
        clsCS.LocationID = strLocationID
        clsCS.LocationName = txtLocationName.Text.Trim
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor
        progressBar.Visible = True

        Try
            grdMain.DataSource = BL.StorageLaneSwitching.ListData(strCompanyID.Trim, strLocationID.Trim, dtpDateFrom.Value.Date, dtpDateTo.Value.Date)
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
            Me.Cursor = Cursors.Default
            progressBar.Visible = False
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Function prvGetData() As VO.StorageLaneSwitching
        Dim returnValue As New VO.StorageLaneSwitching
        returnValue.ComLocDivSubDivID = grdView.GetRowCellValue(intPos, "ComLocDivSubDivID")
        returnValue.ProgramID = grdView.GetRowCellValue(intPos, "ProgramID")
        returnValue.CompanyID = grdView.GetRowCellValue(intPos, "CompanyID")
        returnValue.CompanyName = grdView.GetRowCellValue(intPos, "CompanyName")
        returnValue.LocationID = grdView.GetRowCellValue(intPos, "LocationID")
        returnValue.LocationName = grdView.GetRowCellValue(intPos, "LocationName")
        returnValue.ID = grdView.GetRowCellValue(intPos, "ID")
        returnValue.StorageGroupID = grdView.GetRowCellValue(intPos, "StorageGroupID")
        returnValue.StorageGroupName = grdView.GetRowCellValue(intPos, "StorageGroupName")
        returnValue.StorageID = grdView.GetRowCellValue(intPos, "StorageID")
        returnValue.StorageName = grdView.GetRowCellValue(intPos, "StorageName")
        returnValue.IsDeleted = grdView.GetRowCellValue(intPos, "IsDeleted")
        returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnValue.CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvNew()
        prvGetCS()
        Dim frmDetail As New frmTraStorageLaneSwitchingDet
        With frmDetail
            .pubCS = clsCS
            .pubIsNew = True
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvDetail()
        Dim intPos As Integer = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        prvGetCS()
        Dim frmDetail As New frmTraStorageLaneSwitchingDet
        With frmDetail
            .pubIsNew = False
            .pubCS = clsCS
            .pubID = grdView.GetRowCellValue(intPos, "ID")
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then pubRefresh()
        End With
    End Sub

    Private Sub prvDelete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()

        If clsData.IsDeleted Then
            UI.usForm.frmMessageBox("Data already deleted")
            Exit Sub
        End If

        Dim frmDetail As New usFormRemarks
        With frmDetail
            .pubTitle = "Delete Storage Lane Switching ID: " & clsData.ID
            .pubInfo = "Delete Storage Lane Switching"
            .pubLabel = "Remarks"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                clsData.Remarks = .pubValue.Trim
                clsData.LogBy = UI.usUserApp.UserID
            Else : Exit Sub
            End If
        End With

        Try
            BL.StorageLaneSwitching.DeleteData(clsData)
            UI.usForm.frmMessageBox("Delete data success.")
            pubRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cNew).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRASTORAGELANESWTCHING", "ADD")
            .Item(cDetail).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRASTORAGELANESWTCHING", "EDIT")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRASTORAGELANESWTCHING", "DELETE")
        End With
    End Sub

    Private Sub prvChooseCompany()
        Dim frmDetail As New frmMstCompany
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strCompanyID = .pubLUDataRow.Item("CompanyID")
                txtCompanyName.Text = .pubLUDataRow.Item("CompanyName")
            End If
        End With
    End Sub

    Private Sub prvChooseLocation()
        Dim frmDetail As New frmMstCompanyLocation
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = strCompanyID
            .pubLULocationID = clsCS.LocationID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                strLocationID = .pubLUDataRow.Item("LocationID")
                txtLocationName.Text = .pubLUDataRow.Item("LocationName")
            End If
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmStorageLaneSwitching_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvSetDefaultFilter()
        prvSetButton()
        prvUserAccess()
        dtpDateFrom.Value = Today.Date.AddDays(-30)
        dtpDateTo.Value = Today.Date
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "New" : prvNew()
            Case "Detail" : prvDetail()
            Case "Delete" : prvDelete()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        prvChooseCompany()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        prvChooseLocation()
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

#End Region

End Class