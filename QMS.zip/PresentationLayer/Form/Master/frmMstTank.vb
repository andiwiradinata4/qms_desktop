﻿Public Class frmMstTank

#Region "Properties Handle"

    Public pubLUdtRow As DataRow
    Public pubIsLookUp As Boolean = False
    Public pubIsLookUpGet As Boolean = False
    Public pubLUTankCode As String = ""

    Private intPos As Integer
    Private Const _
       cGet = 0, cSep1 = 1, cRefresh = 2, cClose = 3

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Get,2,Refresh,3,Close")
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "TankCode", "Tank Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "TankName", "Tank Name", 100, UI.usDefGrid.gString)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Visible = pubIsLookUp
            .Item(cSep1).Visible = pubIsLookUp
            .Item(cGet).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            grdMain.DataSource = BL.Tank.ListData()
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("TankCode")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "TankCode", strSearch)
        End With
    End Sub

    Private Sub prvGet()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        If Not pubIsLookUp Then Exit Sub
        pubLUdtRow = grdView.GetDataRow(grdView.FocusedRowHandle)
        pubIsLookUpGet = True
        Me.Close()
    End Sub

    Private Sub prvSetLookUp()
        If pubIsLookUp Then
            Me.Text += " [Lookup] "
            UI.usForm.GridMoveRow(grdView, "TankCode", pubLUTankCode)
        End If
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstTank_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstTank_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvSetIcon()
        prvSetGrid()
        prvQuery()
        prvSetLookUp()

        If Not pubIsLookUp Then Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text
            Case "Get" : prvGet()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub grdView_DoubleClick(sender As Object, e As EventArgs) Handles grdView.DoubleClick
        If pubIsLookUp Then prvGet()
    End Sub

#End Region
 
End Class