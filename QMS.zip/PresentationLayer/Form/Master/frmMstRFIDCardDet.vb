Public Class frmMstRFIDCardDet

#Region "Property Handle"

    Private WithEvents tmrWeighBridge As New Timer
    Private frmParent As frmMstRFIDCard
    Private clsData As VO.RFIDCard
    Property pubID As String
    Property pubIsNew As Boolean = False
    Property pubIsSave As Boolean = False
    Private bolSuccessSettingSerialPort As Boolean = False
    Private intCount As Integer = 0

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetTitleForm()
        If pubIsNew Then
            Me.Text += " [new] "
        Else
            Me.Text += " [edit] "
        End If
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdHistoryView, "Status", "Status", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdHistoryView, "StatusBy", "Status By", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdHistoryView, "StatusDate", "Status Date", 150, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdHistoryView, "Remarks", "Remarks", 300, UI.usDefGrid.gString)
    End Sub

    Private Sub prvFillCombo()
        Dim dtStatus As New DataTable
        Try
            dtStatus = BL.Status.ListDataByModuleID(VO.Modules.Values.RFID)
            UI.usForm.FillComboBox(cboStatus, dtStatus, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvFillForm()
        Try
            prvFillCombo()
            If pubIsNew Then
                prvClear()
            Else
                clsData = New VO.RFIDCard
                clsData = BL.RFIDCard.GetDetail(pubID)
                txtID.Text = clsData.ID
                txtRFID.Text = clsData.RFID
                cboStatus.SelectedValue = clsData.IDStatus
                txtRemarks.Text = clsData.Remarks
                ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
                ToolStripLogBy.Text = "Last Log : -" & clsData.LogBy
                ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)

                If (clsData.IDStatus = VO.Status.Values.InActive) Then
                    cboStatus.Enabled = True
                Else
                    cboStatus.Enabled = False
                End If
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Form")
        End Try
    End Sub

    Private Sub prvQuery()
        Try
            grdHistory.DataSource = BL.RFIDCard.ListDataStatus(txtID.Text.Trim)
            grdHistoryView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Query")
        End Try
    End Sub

    Public Sub prvSave()
        If txtRFID.Text.Trim = "" Then
            UI.usForm.frmMessageBox("RFID not allow blank")
            tcMain.SelectedTab = tpMain
            txtRFID.Focus()
            Exit Sub
        End If

        clsData = New VO.RFIDCard
        clsData.CompanyID = UI.usUserApp.CompanyID
        clsData.LocationID = UI.usUserApp.LocationID
        clsData.ID = txtID.Text.Trim
        clsData.RFID = txtRFID.Text.Trim
        clsData.InitialCode = ""
        clsData.IDStatus = cboStatus.SelectedValue
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID

        Try
            BL.RFIDCard.SaveData(pubIsNew, clsData)
            If pubIsNew Then
                UI.usForm.frmMessageBox("Save data success.")
                frmParent.pubRefresh(clsData.ID)
                prvClear()
            Else
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Save Data")
        End Try
    End Sub

    Private Sub prvClear()
        txtID.Text = ""
        txtRFID.Text = ""
        cboStatus.SelectedValue = VO.Status.Values.Active
        txtRemarks.Text = ""
        ToolStripLogInc.Text = "Log Inc : -"
        ToolStripLogBy.Text = "Last Log : -"
        ToolStripLogDate.Text = Format(Now, UI.usDefCons.DateFull)
    End Sub

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort1.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort1.IsOpen Then
                UI.usForm.usSerialPort1.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimer()
    End Sub

    Public Sub prvStartTimer()
        tmrWeighBridge.Enabled = True
        tmrWeighBridge.Interval = 1000
        tmrWeighBridge.Start()
    End Sub

    Public Sub prvStopTimer()
        tmrWeighBridge.Stop()
    End Sub

    Private Sub prvReadCard()
        Try

            If VO.DefaultServer.IsLinkRFIDDevice1 Then
                If Not UI.usForm.usSerialPort1.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort1 = UI.usForm.usSerialPort1.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort1.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Trim

            If VO.DefaultServer.IsLinkRFIDDevice1 Then VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Substring(1, VO.DefaultServer.RFIDValueCOMPort1.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort1.Trim = VO.DefaultServer.PrevRFIDValueCOMPort1.Trim And intCount <= 5 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1
            txtRFID.Text = VO.DefaultServer.RFIDValueCOMPort1.Trim
            intCount = 0
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstRFIDCardDet_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        If UI.usForm.usSerialPort1.IsOpen Then
            VO.DefaultServer.RFIDValueCOMPort1 = ""
            tmrWeighBridge.Dispose()
            UI.usForm.usSerialPort1.Dispose()
        End If
    End Sub

    Private Sub frmMstRFIDCardDet_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F1 Then
            tcMain.SelectedTab = tpMain
        ElseIf e.KeyCode = Keys.F2 Then
            tcMain.SelectedTab = tpStatusHistory
        ElseIf e.KeyCode = Keys.F10 And VO.DefaultServer.IsLinkRFIDDevice1 = False Then
            Dim frmDetail As New frmSysTestInputRFID
            With frmDetail
                .pubPorts = VO.SubStation.Ports.COMPort1
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
            End With
        End If
    End Sub

    Private Sub frmMstRFIDCardDet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(New usToolBar(Me, "0,Save,1,Close", UI.usUserApp.ProgramID, "MSTRFID", IIf(pubIsNew, "ADD", "EDIT")))
        prvSetTitleForm()
        prvSetGrid()
        prvFillForm()
        prvQuery()

        If VO.DefaultServer.IsLinkRFIDDevice1 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort1, VO.DefaultServer.COMPort1)
            If bolSuccessSettingSerialPort = False Then MsgBox("False setting serial port")
            prvStartReadRFID()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs)
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

    Private Sub tmrWeighBridge_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrWeighBridge.Tick
        prvReadCard()
    End Sub

#End Region

End Class


