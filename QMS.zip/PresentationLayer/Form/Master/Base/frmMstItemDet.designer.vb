﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMstItemDet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.cboToleranceType = New System.Windows.Forms.ComboBox()
        Me.lblRefPriceCurrID = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.lblRefPrice = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.chkIsCriticalFuel = New System.Windows.Forms.CheckBox()
        Me.chkIsCriticalChemical = New System.Windows.Forms.CheckBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.txtToleranceValue = New QMS.usNumeric()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripEmpty = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogInc = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogBy = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogDate = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbDetail = New System.Windows.Forms.GroupBox()
        Me.pnlDetail = New System.Windows.Forms.Panel()
        Me.txtItemName = New QMS.usTextBox()
        Me.txtHSCode = New QMS.usTextBox()
        Me.txtItemCode = New QMS.usTextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnUpdateWeight = New System.Windows.Forms.Button()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtWeight = New QMS.usNumericDevExpress()
        Me.chkContract = New System.Windows.Forms.CheckBox()
        Me.txtRefPrice = New QMS.usNumeric()
        Me.txtStatusDate = New QMS.usTextBox()
        Me.txtStatusBy = New QMS.usTextBox()
        Me.txtStatusRemarks = New QMS.usTextBox()
        Me.txtAccSubCategoryName = New QMS.usTextBox()
        Me.txtAccCategoryName = New QMS.usTextBox()
        Me.txtAccGroupName = New QMS.usTextBox()
        Me.txtRemarks = New QMS.usTextBox()
        Me.txtUomCode = New QMS.usTextBox()
        Me.txtSubCategory2Name = New QMS.usTextBox()
        Me.txtSubCategory1Name = New QMS.usTextBox()
        Me.txtCategoryName = New QMS.usTextBox()
        Me.txtGroupName = New QMS.usTextBox()
        Me.txtClassName = New QMS.usTextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtPartNumber = New QMS.usTextBox()
        Me.txtGNName = New QMS.usTextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtGNCode = New QMS.usTextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtxCountry = New QMS.usTextBox()
        Me.txtxBrand = New QMS.usTextBox()
        Me.txtxSpec = New QMS.usTextBox()
        Me.txtxType = New QMS.usTextBox()
        Me.txtxName = New QMS.usTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbLocalDesc = New System.Windows.Forms.TabPage()
        Me.txtSpanishName = New QMS.usTextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtChineseName = New QMS.usTextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ToolBar = New System.Windows.Forms.ToolBar()
        Me.BarRefresh = New System.Windows.Forms.ToolBarButton()
        Me.BarClose = New System.Windows.Forms.ToolBarButton()
        Me.chkLocationItem = New System.Windows.Forms.CheckBox()
        Me.TabPage4.SuspendLayout()
        CType(Me.txtToleranceValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip.SuspendLayout()
        Me.gbDetail.SuspendLayout()
        Me.pnlDetail.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.txtWeight.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRefPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.tbLocalDesc.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(205, 307)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(64, 13)
        Me.Label29.TabIndex = 157
        Me.Label29.Text = "Status Date"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(0, 17)
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(9, 308)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(53, 13)
        Me.Label28.TabIndex = 155
        Me.Label28.Text = "Status By"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboToleranceType
        '
        Me.cboToleranceType.BackColor = System.Drawing.Color.LightYellow
        Me.cboToleranceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboToleranceType.Enabled = False
        Me.cboToleranceType.FormattingEnabled = True
        Me.cboToleranceType.Items.AddRange(New Object() {"Quantity", "Percentage"})
        Me.cboToleranceType.Location = New System.Drawing.Point(112, 68)
        Me.cboToleranceType.Name = "cboToleranceType"
        Me.cboToleranceType.Size = New System.Drawing.Size(103, 21)
        Me.cboToleranceType.TabIndex = 145
        '
        'lblRefPriceCurrID
        '
        Me.lblRefPriceCurrID.AutoSize = True
        Me.lblRefPriceCurrID.BackColor = System.Drawing.Color.Transparent
        Me.lblRefPriceCurrID.ForeColor = System.Drawing.Color.Black
        Me.lblRefPriceCurrID.Location = New System.Drawing.Point(71, 253)
        Me.lblRefPriceCurrID.Name = "lblRefPriceCurrID"
        Me.lblRefPriceCurrID.Size = New System.Drawing.Size(24, 13)
        Me.lblRefPriceCurrID.TabIndex = 153
        Me.lblRefPriceCurrID.Text = "Rp."
        Me.lblRefPriceCurrID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(13, 71)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(81, 13)
        Me.Label31.TabIndex = 144
        Me.Label31.Text = "Tolerance Type"
        '
        'lblRefPrice
        '
        Me.lblRefPrice.AutoSize = True
        Me.lblRefPrice.BackColor = System.Drawing.Color.Transparent
        Me.lblRefPrice.ForeColor = System.Drawing.Color.Black
        Me.lblRefPrice.Location = New System.Drawing.Point(10, 253)
        Me.lblRefPrice.Name = "lblRefPrice"
        Me.lblRefPrice.Size = New System.Drawing.Size(54, 13)
        Me.lblRefPrice.TabIndex = 152
        Me.lblRefPrice.Text = "Ref. Price"
        Me.lblRefPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(10, 166)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(48, 13)
        Me.Label22.TabIndex = 150
        Me.Label22.Text = "Remarks"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(15, 22)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(91, 13)
        Me.Label30.TabIndex = 143
        Me.Label30.Text = "Monitoring Status"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(12, 9)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(57, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Item Code"
        '
        'chkIsCriticalFuel
        '
        Me.chkIsCriticalFuel.AutoSize = True
        Me.chkIsCriticalFuel.Enabled = False
        Me.chkIsCriticalFuel.Location = New System.Drawing.Point(112, 38)
        Me.chkIsCriticalFuel.Name = "chkIsCriticalFuel"
        Me.chkIsCriticalFuel.Size = New System.Drawing.Size(95, 17)
        Me.chkIsCriticalFuel.TabIndex = 142
        Me.chkIsCriticalFuel.Text = "Critical Energy"
        Me.chkIsCriticalFuel.UseVisualStyleBackColor = True
        '
        'chkIsCriticalChemical
        '
        Me.chkIsCriticalChemical.AutoSize = True
        Me.chkIsCriticalChemical.Enabled = False
        Me.chkIsCriticalChemical.Location = New System.Drawing.Point(112, 21)
        Me.chkIsCriticalChemical.Name = "chkIsCriticalChemical"
        Me.chkIsCriticalChemical.Size = New System.Drawing.Size(103, 17)
        Me.chkIsCriticalChemical.TabIndex = 141
        Me.chkIsCriticalChemical.Text = "Critical Chemical"
        Me.chkIsCriticalChemical.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage4.Controls.Add(Me.txtToleranceValue)
        Me.TabPage4.Controls.Add(Me.Label32)
        Me.TabPage4.Controls.Add(Me.cboToleranceType)
        Me.TabPage4.Controls.Add(Me.Label31)
        Me.TabPage4.Controls.Add(Me.Label30)
        Me.TabPage4.Controls.Add(Me.chkIsCriticalFuel)
        Me.TabPage4.Controls.Add(Me.chkIsCriticalChemical)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(817, 350)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Other - F3"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'txtToleranceValue
        '
        Me.txtToleranceValue.BackColor = System.Drawing.Color.LightYellow
        Me.txtToleranceValue.Increment = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtToleranceValue.Location = New System.Drawing.Point(112, 88)
        Me.txtToleranceValue.Maximum = New Decimal(New Integer() {-1, -1, -1, 0})
        Me.txtToleranceValue.Minimum = New Decimal(New Integer() {-1, -1, -1, -2147483648})
        Me.txtToleranceValue.Name = "txtToleranceValue"
        Me.txtToleranceValue.ReadOnly = True
        Me.txtToleranceValue.Size = New System.Drawing.Size(103, 21)
        Me.txtToleranceValue.TabIndex = 155
        Me.txtToleranceValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtToleranceValue.ThousandsSeparator = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(13, 90)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(83, 13)
        Me.Label32.TabIndex = 154
        Me.Label32.Text = "Tolerance Value"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.DimGray
        Me.Label21.Location = New System.Drawing.Point(419, 12)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(141, 13)
        Me.Label21.TabIndex = 140
        Me.Label21.Text = "ACCOUNTING CATEGORY"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(10, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 100
        Me.Label4.Text = "Uom Code"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.DimGray
        Me.Label17.Location = New System.Drawing.Point(9, 12)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(122, 13)
        Me.Label17.TabIndex = 132
        Me.Label17.Text = "PRODUCT CATEGORY"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(10, 287)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 97
        Me.Label3.Text = "Status"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label36.BackColor = System.Drawing.Color.CadetBlue
        Me.Label36.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.White
        Me.Label36.Location = New System.Drawing.Point(7, 12)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(839, 22)
        Me.Label36.TabIndex = 1
        Me.Label36.Text = "« Item Information"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboStatus
        '
        Me.cboStatus.BackColor = System.Drawing.Color.LightYellow
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.Enabled = False
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(105, 284)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(94, 21)
        Me.cboStatus.TabIndex = 28
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(419, 79)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(76, 13)
        Me.Label20.TabIndex = 139
        Me.Label20.Text = "Sub Category "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(12, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Item Name"
        '
        'StatusStrip
        '
        Me.StatusStrip.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripEmpty, Me.ToolStripLogInc, Me.ToolStripLogBy, Me.ToolStripStatusLabel3, Me.ToolStripLogDate})
        Me.StatusStrip.Location = New System.Drawing.Point(3, 592)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(846, 22)
        Me.StatusStrip.TabIndex = 97
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'ToolStripEmpty
        '
        Me.ToolStripEmpty.Name = "ToolStripEmpty"
        Me.ToolStripEmpty.Size = New System.Drawing.Size(723, 17)
        Me.ToolStripEmpty.Spring = True
        '
        'ToolStripLogInc
        '
        Me.ToolStripLogInc.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogInc.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogInc.Name = "ToolStripLogInc"
        Me.ToolStripLogInc.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogInc.Text = "Log Inc : "
        '
        'ToolStripLogBy
        '
        Me.ToolStripLogBy.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogBy.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogBy.Name = "ToolStripLogBy"
        Me.ToolStripLogBy.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogBy.Text = "Last Log :"
        '
        'ToolStripLogDate
        '
        Me.ToolStripLogDate.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogDate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogDate.Name = "ToolStripLogDate"
        Me.ToolStripLogDate.Size = New System.Drawing.Size(12, 17)
        Me.ToolStripLogDate.Text = "-"
        '
        'gbDetail
        '
        Me.gbDetail.Controls.Add(Me.pnlDetail)
        Me.gbDetail.Controls.Add(Me.StatusStrip)
        Me.gbDetail.Controls.Add(Me.Label36)
        Me.gbDetail.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbDetail.Location = New System.Drawing.Point(0, 28)
        Me.gbDetail.Name = "gbDetail"
        Me.gbDetail.Size = New System.Drawing.Size(852, 617)
        Me.gbDetail.TabIndex = 4
        Me.gbDetail.TabStop = False
        '
        'pnlDetail
        '
        Me.pnlDetail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlDetail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlDetail.Controls.Add(Me.txtItemName)
        Me.pnlDetail.Controls.Add(Me.txtHSCode)
        Me.pnlDetail.Controls.Add(Me.txtItemCode)
        Me.pnlDetail.Controls.Add(Me.Label27)
        Me.pnlDetail.Controls.Add(Me.TabControl1)
        Me.pnlDetail.Controls.Add(Me.Label15)
        Me.pnlDetail.Controls.Add(Me.Label1)
        Me.pnlDetail.Location = New System.Drawing.Point(7, 34)
        Me.pnlDetail.Name = "pnlDetail"
        Me.pnlDetail.Size = New System.Drawing.Size(839, 548)
        Me.pnlDetail.TabIndex = 0
        '
        'txtItemName
        '
        Me.txtItemName.BackColor = System.Drawing.Color.LightYellow
        Me.txtItemName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtItemName.Location = New System.Drawing.Point(117, 26)
        Me.txtItemName.Multiline = True
        Me.txtItemName.Name = "txtItemName"
        Me.txtItemName.ReadOnly = True
        Me.txtItemName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtItemName.Size = New System.Drawing.Size(698, 125)
        Me.txtItemName.TabIndex = 5
        '
        'txtHSCode
        '
        Me.txtHSCode.BackColor = System.Drawing.Color.LightYellow
        Me.txtHSCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtHSCode.Location = New System.Drawing.Point(276, 6)
        Me.txtHSCode.Name = "txtHSCode"
        Me.txtHSCode.ReadOnly = True
        Me.txtHSCode.Size = New System.Drawing.Size(120, 21)
        Me.txtHSCode.TabIndex = 3
        '
        'txtItemCode
        '
        Me.txtItemCode.BackColor = System.Drawing.Color.LightYellow
        Me.txtItemCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtItemCode.Location = New System.Drawing.Point(117, 6)
        Me.txtItemCode.Name = "txtItemCode"
        Me.txtItemCode.ReadOnly = True
        Me.txtItemCode.Size = New System.Drawing.Size(97, 21)
        Me.txtItemCode.TabIndex = 1
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(222, 9)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(48, 13)
        Me.Label27.TabIndex = 2
        Me.Label27.Text = "HS Code"
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.tbLocalDesc)
        Me.TabControl1.Location = New System.Drawing.Point(6, 162)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(825, 379)
        Me.TabControl1.TabIndex = 3
        '
        'TabPage1
        '
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage1.Controls.Add(Me.chkLocationItem)
        Me.TabPage1.Controls.Add(Me.btnUpdateWeight)
        Me.TabPage1.Controls.Add(Me.Label33)
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.txtWeight)
        Me.TabPage1.Controls.Add(Me.chkContract)
        Me.TabPage1.Controls.Add(Me.txtRefPrice)
        Me.TabPage1.Controls.Add(Me.txtStatusDate)
        Me.TabPage1.Controls.Add(Me.txtStatusBy)
        Me.TabPage1.Controls.Add(Me.txtStatusRemarks)
        Me.TabPage1.Controls.Add(Me.txtAccSubCategoryName)
        Me.TabPage1.Controls.Add(Me.txtAccCategoryName)
        Me.TabPage1.Controls.Add(Me.txtAccGroupName)
        Me.TabPage1.Controls.Add(Me.txtRemarks)
        Me.TabPage1.Controls.Add(Me.txtUomCode)
        Me.TabPage1.Controls.Add(Me.txtSubCategory2Name)
        Me.TabPage1.Controls.Add(Me.txtSubCategory1Name)
        Me.TabPage1.Controls.Add(Me.txtCategoryName)
        Me.TabPage1.Controls.Add(Me.txtGroupName)
        Me.TabPage1.Controls.Add(Me.txtClassName)
        Me.TabPage1.Controls.Add(Me.Label29)
        Me.TabPage1.Controls.Add(Me.Label28)
        Me.TabPage1.Controls.Add(Me.lblRefPriceCurrID)
        Me.TabPage1.Controls.Add(Me.lblRefPrice)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Controls.Add(Me.Label21)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.cboStatus)
        Me.TabPage1.Controls.Add(Me.Label20)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(817, 350)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Category - F1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnUpdateWeight
        '
        Me.btnUpdateWeight.Location = New System.Drawing.Point(642, 97)
        Me.btnUpdateWeight.Name = "btnUpdateWeight"
        Me.btnUpdateWeight.Size = New System.Drawing.Size(114, 23)
        Me.btnUpdateWeight.TabIndex = 175
        Me.btnUpdateWeight.Text = "Update Weight"
        Me.btnUpdateWeight.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(617, 100)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(19, 13)
        Me.Label33.TabIndex = 174
        Me.Label33.Text = "Kg"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(419, 99)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(41, 13)
        Me.Label26.TabIndex = 173
        Me.Label26.Text = "Weight"
        '
        'txtWeight
        '
        Me.txtWeight.EditValue = "0.0000"
        Me.txtWeight.Location = New System.Drawing.Point(505, 97)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Properties.Appearance.Options.UseTextOptions = True
        Me.txtWeight.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.txtWeight.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.LightYellow
        Me.txtWeight.Properties.AppearanceReadOnly.ForeColor = System.Drawing.Color.Black
        Me.txtWeight.Properties.AppearanceReadOnly.Options.UseBackColor = True
        Me.txtWeight.Properties.AppearanceReadOnly.Options.UseForeColor = True
        Me.txtWeight.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.txtWeight.Properties.Mask.EditMask = "n4"
        Me.txtWeight.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtWeight.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtWeight.Size = New System.Drawing.Size(110, 20)
        Me.txtWeight.TabIndex = 172

        '
        'chkContract
        '
        Me.chkContract.AutoSize = True
        Me.chkContract.Enabled = False
        Me.chkContract.Location = New System.Drawing.Point(505, 123)
        Me.chkContract.Name = "chkContract"
        Me.chkContract.Size = New System.Drawing.Size(68, 17)
        Me.chkContract.TabIndex = 171
        Me.chkContract.Text = "Contract"
        Me.chkContract.UseVisualStyleBackColor = True
        '
        'txtRefPrice
        '
        Me.txtRefPrice.BackColor = System.Drawing.Color.LightYellow
        Me.txtRefPrice.DecimalPlaces = 2
        Me.txtRefPrice.Enabled = False
        Me.txtRefPrice.Location = New System.Drawing.Point(105, 251)
        Me.txtRefPrice.Maximum = New Decimal(New Integer() {-1, -1, -1, 0})
        Me.txtRefPrice.Minimum = New Decimal(New Integer() {-1, -1, -1, -2147483648})
        Me.txtRefPrice.Name = "txtRefPrice"
        Me.txtRefPrice.Size = New System.Drawing.Size(136, 21)
        Me.txtRefPrice.TabIndex = 170
        Me.txtRefPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtRefPrice.ThousandsSeparator = True
        '
        'txtStatusDate
        '
        Me.txtStatusDate.BackColor = System.Drawing.Color.LightYellow
        Me.txtStatusDate.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStatusDate.Location = New System.Drawing.Point(293, 305)
        Me.txtStatusDate.Name = "txtStatusDate"
        Me.txtStatusDate.ReadOnly = True
        Me.txtStatusDate.Size = New System.Drawing.Size(110, 21)
        Me.txtStatusDate.TabIndex = 169
        '
        'txtStatusBy
        '
        Me.txtStatusBy.BackColor = System.Drawing.Color.LightYellow
        Me.txtStatusBy.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStatusBy.Location = New System.Drawing.Point(105, 305)
        Me.txtStatusBy.Name = "txtStatusBy"
        Me.txtStatusBy.ReadOnly = True
        Me.txtStatusBy.Size = New System.Drawing.Size(94, 21)
        Me.txtStatusBy.TabIndex = 168
        '
        'txtStatusRemarks
        '
        Me.txtStatusRemarks.BackColor = System.Drawing.Color.LightYellow
        Me.txtStatusRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStatusRemarks.Location = New System.Drawing.Point(293, 284)
        Me.txtStatusRemarks.Name = "txtStatusRemarks"
        Me.txtStatusRemarks.ReadOnly = True
        Me.txtStatusRemarks.Size = New System.Drawing.Size(490, 21)
        Me.txtStatusRemarks.TabIndex = 167
        '
        'txtAccSubCategoryName
        '
        Me.txtAccSubCategoryName.BackColor = System.Drawing.Color.LightYellow
        Me.txtAccSubCategoryName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtAccSubCategoryName.Location = New System.Drawing.Point(505, 76)
        Me.txtAccSubCategoryName.Name = "txtAccSubCategoryName"
        Me.txtAccSubCategoryName.ReadOnly = True
        Me.txtAccSubCategoryName.Size = New System.Drawing.Size(251, 21)
        Me.txtAccSubCategoryName.TabIndex = 166
        '
        'txtAccCategoryName
        '
        Me.txtAccCategoryName.BackColor = System.Drawing.Color.LightYellow
        Me.txtAccCategoryName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtAccCategoryName.Location = New System.Drawing.Point(505, 56)
        Me.txtAccCategoryName.Name = "txtAccCategoryName"
        Me.txtAccCategoryName.ReadOnly = True
        Me.txtAccCategoryName.Size = New System.Drawing.Size(251, 21)
        Me.txtAccCategoryName.TabIndex = 165
        '
        'txtAccGroupName
        '
        Me.txtAccGroupName.BackColor = System.Drawing.Color.LightYellow
        Me.txtAccGroupName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtAccGroupName.Location = New System.Drawing.Point(505, 36)
        Me.txtAccGroupName.Name = "txtAccGroupName"
        Me.txtAccGroupName.ReadOnly = True
        Me.txtAccGroupName.Size = New System.Drawing.Size(251, 21)
        Me.txtAccGroupName.TabIndex = 164
        '
        'txtRemarks
        '
        Me.txtRemarks.BackColor = System.Drawing.Color.LightYellow
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Location = New System.Drawing.Point(105, 163)
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.ReadOnly = True
        Me.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtRemarks.Size = New System.Drawing.Size(677, 89)
        Me.txtRemarks.TabIndex = 163
        '
        'txtUomCode
        '
        Me.txtUomCode.BackColor = System.Drawing.Color.LightYellow
        Me.txtUomCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtUomCode.Location = New System.Drawing.Point(105, 143)
        Me.txtUomCode.Name = "txtUomCode"
        Me.txtUomCode.ReadOnly = True
        Me.txtUomCode.Size = New System.Drawing.Size(106, 21)
        Me.txtUomCode.TabIndex = 162
        '
        'txtSubCategory2Name
        '
        Me.txtSubCategory2Name.BackColor = System.Drawing.Color.LightYellow
        Me.txtSubCategory2Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSubCategory2Name.Location = New System.Drawing.Point(105, 116)
        Me.txtSubCategory2Name.Name = "txtSubCategory2Name"
        Me.txtSubCategory2Name.ReadOnly = True
        Me.txtSubCategory2Name.Size = New System.Drawing.Size(251, 21)
        Me.txtSubCategory2Name.TabIndex = 161
        '
        'txtSubCategory1Name
        '
        Me.txtSubCategory1Name.BackColor = System.Drawing.Color.LightYellow
        Me.txtSubCategory1Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSubCategory1Name.Location = New System.Drawing.Point(105, 96)
        Me.txtSubCategory1Name.Name = "txtSubCategory1Name"
        Me.txtSubCategory1Name.ReadOnly = True
        Me.txtSubCategory1Name.Size = New System.Drawing.Size(251, 21)
        Me.txtSubCategory1Name.TabIndex = 160
        '
        'txtCategoryName
        '
        Me.txtCategoryName.BackColor = System.Drawing.Color.LightYellow
        Me.txtCategoryName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCategoryName.Location = New System.Drawing.Point(105, 76)
        Me.txtCategoryName.Name = "txtCategoryName"
        Me.txtCategoryName.ReadOnly = True
        Me.txtCategoryName.Size = New System.Drawing.Size(251, 21)
        Me.txtCategoryName.TabIndex = 159
        '
        'txtGroupName
        '
        Me.txtGroupName.BackColor = System.Drawing.Color.LightYellow
        Me.txtGroupName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtGroupName.Location = New System.Drawing.Point(105, 56)
        Me.txtGroupName.Name = "txtGroupName"
        Me.txtGroupName.ReadOnly = True
        Me.txtGroupName.Size = New System.Drawing.Size(251, 21)
        Me.txtGroupName.TabIndex = 158
        '
        'txtClassName
        '
        Me.txtClassName.BackColor = System.Drawing.Color.LightYellow
        Me.txtClassName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtClassName.Location = New System.Drawing.Point(105, 36)
        Me.txtClassName.Name = "txtClassName"
        Me.txtClassName.ReadOnly = True
        Me.txtClassName.Size = New System.Drawing.Size(251, 21)
        Me.txtClassName.TabIndex = 101
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(419, 39)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(36, 13)
        Me.Label18.TabIndex = 137
        Me.Label18.Text = "Group"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(205, 287)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 95
        Me.Label2.Text = "Status Remarks"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label6.Location = New System.Drawing.Point(10, 99)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(85, 13)
        Me.Label6.TabIndex = 123
        Me.Label6.Text = "Sub Category 1 "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(419, 59)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(52, 13)
        Me.Label19.TabIndex = 138
        Me.Label19.Text = "Category"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(10, 59)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 13)
        Me.Label7.TabIndex = 121
        Me.Label7.Text = "Group"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(10, 119)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 13)
        Me.Label9.TabIndex = 127
        Me.Label9.Text = "Sub Category 2"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label5.Location = New System.Drawing.Point(10, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 13)
        Me.Label5.TabIndex = 122
        Me.Label5.Text = "Category "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(10, 39)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 120
        Me.Label8.Text = "Class"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TabPage2
        '
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage2.Controls.Add(Me.Label34)
        Me.TabPage2.Controls.Add(Me.txtPartNumber)
        Me.TabPage2.Controls.Add(Me.txtGNName)
        Me.TabPage2.Controls.Add(Me.Label24)
        Me.TabPage2.Controls.Add(Me.txtGNCode)
        Me.TabPage2.Controls.Add(Me.Label23)
        Me.TabPage2.Controls.Add(Me.txtxCountry)
        Me.TabPage2.Controls.Add(Me.txtxBrand)
        Me.TabPage2.Controls.Add(Me.txtxSpec)
        Me.TabPage2.Controls.Add(Me.txtxType)
        Me.TabPage2.Controls.Add(Me.txtxName)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(817, 350)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detail - F2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(13, 117)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(67, 13)
        Me.Label34.TabIndex = 8
        Me.Label34.Text = "Part Number"
        '
        'txtPartNumber
        '
        Me.txtPartNumber.BackColor = System.Drawing.Color.LightYellow
        Me.txtPartNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPartNumber.Location = New System.Drawing.Point(105, 114)
        Me.txtPartNumber.Name = "txtPartNumber"
        Me.txtPartNumber.ReadOnly = True
        Me.txtPartNumber.Size = New System.Drawing.Size(404, 21)
        Me.txtPartNumber.TabIndex = 9
        '
        'txtGNName
        '
        Me.txtGNName.BackColor = System.Drawing.Color.LightYellow
        Me.txtGNName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtGNName.Location = New System.Drawing.Point(105, 35)
        Me.txtGNName.Name = "txtGNName"
        Me.txtGNName.ReadOnly = True
        Me.txtGNName.Size = New System.Drawing.Size(404, 21)
        Me.txtGNName.TabIndex = 3
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(13, 38)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(51, 13)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "GN Name"
        '
        'txtGNCode
        '
        Me.txtGNCode.BackColor = System.Drawing.Color.LightYellow
        Me.txtGNCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtGNCode.Location = New System.Drawing.Point(105, 15)
        Me.txtGNCode.Name = "txtGNCode"
        Me.txtGNCode.ReadOnly = True
        Me.txtGNCode.Size = New System.Drawing.Size(59, 21)
        Me.txtGNCode.TabIndex = 1
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(13, 18)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(49, 13)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "GN Code"
        '
        'txtxCountry
        '
        Me.txtxCountry.BackColor = System.Drawing.Color.LightYellow
        Me.txtxCountry.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtxCountry.Location = New System.Drawing.Point(105, 227)
        Me.txtxCountry.Name = "txtxCountry"
        Me.txtxCountry.ReadOnly = True
        Me.txtxCountry.Size = New System.Drawing.Size(404, 21)
        Me.txtxCountry.TabIndex = 15
        '
        'txtxBrand
        '
        Me.txtxBrand.BackColor = System.Drawing.Color.LightYellow
        Me.txtxBrand.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtxBrand.Location = New System.Drawing.Point(105, 206)
        Me.txtxBrand.Name = "txtxBrand"
        Me.txtxBrand.ReadOnly = True
        Me.txtxBrand.Size = New System.Drawing.Size(404, 21)
        Me.txtxBrand.TabIndex = 13
        '
        'txtxSpec
        '
        Me.txtxSpec.BackColor = System.Drawing.Color.LightYellow
        Me.txtxSpec.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtxSpec.Location = New System.Drawing.Point(105, 135)
        Me.txtxSpec.Multiline = True
        Me.txtxSpec.Name = "txtxSpec"
        Me.txtxSpec.ReadOnly = True
        Me.txtxSpec.Size = New System.Drawing.Size(679, 71)
        Me.txtxSpec.TabIndex = 11
        '
        'txtxType
        '
        Me.txtxType.BackColor = System.Drawing.Color.LightYellow
        Me.txtxType.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtxType.Location = New System.Drawing.Point(105, 93)
        Me.txtxType.Name = "txtxType"
        Me.txtxType.ReadOnly = True
        Me.txtxType.Size = New System.Drawing.Size(404, 21)
        Me.txtxType.TabIndex = 7
        '
        'txtxName
        '
        Me.txtxName.BackColor = System.Drawing.Color.LightYellow
        Me.txtxName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtxName.Location = New System.Drawing.Point(105, 73)
        Me.txtxName.Name = "txtxName"
        Me.txtxName.ReadOnly = True
        Me.txtxName.Size = New System.Drawing.Size(404, 21)
        Me.txtxName.TabIndex = 5
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(13, 76)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 13)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Name"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(13, 230)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(46, 13)
        Me.Label14.TabIndex = 14
        Me.Label14.Text = "Country"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(13, 138)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(67, 13)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "Specification"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(13, 209)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Brand"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(13, 96)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(31, 13)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "Type"
        '
        'tbLocalDesc
        '
        Me.tbLocalDesc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tbLocalDesc.Controls.Add(Me.txtSpanishName)
        Me.tbLocalDesc.Controls.Add(Me.Label25)
        Me.tbLocalDesc.Controls.Add(Me.txtChineseName)
        Me.tbLocalDesc.Controls.Add(Me.Label16)
        Me.tbLocalDesc.Location = New System.Drawing.Point(4, 25)
        Me.tbLocalDesc.Name = "tbLocalDesc"
        Me.tbLocalDesc.Size = New System.Drawing.Size(817, 350)
        Me.tbLocalDesc.TabIndex = 4
        Me.tbLocalDesc.Text = "Local Description - F4"
        Me.tbLocalDesc.UseVisualStyleBackColor = True
        '
        'txtSpanishName
        '
        Me.txtSpanishName.BackColor = System.Drawing.Color.LightYellow
        Me.txtSpanishName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSpanishName.Location = New System.Drawing.Point(105, 140)
        Me.txtSpanishName.Multiline = True
        Me.txtSpanishName.Name = "txtSpanishName"
        Me.txtSpanishName.ReadOnly = True
        Me.txtSpanishName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSpanishName.Size = New System.Drawing.Size(698, 125)
        Me.txtSpanishName.TabIndex = 104
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(10, 143)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(74, 13)
        Me.Label25.TabIndex = 103
        Me.Label25.Text = "Spanish Name"
        '
        'txtChineseName
        '
        Me.txtChineseName.BackColor = System.Drawing.Color.LightYellow
        Me.txtChineseName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtChineseName.Location = New System.Drawing.Point(105, 15)
        Me.txtChineseName.Multiline = True
        Me.txtChineseName.Name = "txtChineseName"
        Me.txtChineseName.ReadOnly = True
        Me.txtChineseName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtChineseName.Size = New System.Drawing.Size(698, 125)
        Me.txtChineseName.TabIndex = 102
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(10, 18)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(75, 13)
        Me.Label16.TabIndex = 101
        Me.Label16.Text = "Chinese Name"
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarRefresh, Me.BarClose})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(852, 28)
        Me.ToolBar.TabIndex = 15
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarRefresh
        '
        Me.BarRefresh.Name = "BarRefresh"
        Me.BarRefresh.Text = "Refresh"
        '
        'BarClose
        '
        Me.BarClose.Name = "BarClose"
        Me.BarClose.Text = "Close"
        '
        'chkLocationItem
        '
        Me.chkLocationItem.AutoSize = True
        Me.chkLocationItem.Enabled = False
        Me.chkLocationItem.Location = New System.Drawing.Point(505, 140)
        Me.chkLocationItem.Name = "chkLocationItem"
        Me.chkLocationItem.Size = New System.Drawing.Size(91, 17)
        Me.chkLocationItem.TabIndex = 176
        Me.chkLocationItem.Text = "Location Item"
        Me.chkLocationItem.UseVisualStyleBackColor = True
        '
        'frmMstItemDet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(852, 645)
        Me.Controls.Add(Me.gbDetail)
        Me.Controls.Add(Me.ToolBar)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMstItemDet"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Master Item Detail"
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.txtToleranceValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.gbDetail.ResumeLayout(False)
        Me.gbDetail.PerformLayout()
        Me.pnlDetail.ResumeLayout(False)
        Me.pnlDetail.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.txtWeight.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRefPrice, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.tbLocalDesc.ResumeLayout(False)
        Me.tbLocalDesc.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents cboToleranceType As System.Windows.Forms.ComboBox
    Friend WithEvents lblRefPriceCurrID As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents lblRefPrice As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents chkIsCriticalFuel As System.Windows.Forms.CheckBox
    Friend WithEvents chkIsCriticalChemical As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripEmpty As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogInc As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogBy As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogDate As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents gbDetail As System.Windows.Forms.GroupBox
    Friend WithEvents pnlDetail As System.Windows.Forms.Panel
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ToolBar As System.Windows.Forms.ToolBar
    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarRefresh As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtItemName As QMS.usTextBox
    Friend WithEvents txtHSCode As QMS.usTextBox
    Friend WithEvents txtItemCode As QMS.usTextBox
    Friend WithEvents txtStatusDate As QMS.usTextBox
    Friend WithEvents txtStatusBy As QMS.usTextBox
    Friend WithEvents txtStatusRemarks As QMS.usTextBox
    Friend WithEvents txtAccSubCategoryName As QMS.usTextBox
    Friend WithEvents txtAccCategoryName As QMS.usTextBox
    Friend WithEvents txtAccGroupName As QMS.usTextBox
    Friend WithEvents txtRemarks As QMS.usTextBox
    Friend WithEvents txtUomCode As QMS.usTextBox
    Friend WithEvents txtSubCategory2Name As QMS.usTextBox
    Friend WithEvents txtSubCategory1Name As QMS.usTextBox
    Friend WithEvents txtCategoryName As QMS.usTextBox
    Friend WithEvents txtGroupName As QMS.usTextBox
    Friend WithEvents txtClassName As QMS.usTextBox
    Friend WithEvents txtxCountry As QMS.usTextBox
    Friend WithEvents txtxBrand As QMS.usTextBox
    Friend WithEvents txtxSpec As QMS.usTextBox
    Friend WithEvents txtxType As QMS.usTextBox
    Friend WithEvents txtxName As QMS.usTextBox
    Friend WithEvents txtToleranceValue As QMS.usNumeric
    Friend WithEvents txtRefPrice As QMS.usNumeric
    Friend WithEvents txtGNName As QMS.usTextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtGNCode As QMS.usTextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents chkContract As System.Windows.Forms.CheckBox
    Friend WithEvents tbLocalDesc As System.Windows.Forms.TabPage
    Friend WithEvents txtSpanishName As QMS.usTextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtChineseName As QMS.usTextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtWeight As QMS.usNumericDevExpress
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtPartNumber As QMS.usTextBox
    Friend WithEvents btnUpdateWeight As System.Windows.Forms.Button
    Friend WithEvents chkLocationItem As System.Windows.Forms.CheckBox
End Class
