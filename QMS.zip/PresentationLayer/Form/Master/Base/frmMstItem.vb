﻿Public Class frmMstItem

#Region "Property Handle"

    Private bolLookUp As Boolean = False
    Private bolLookUpGet As Boolean = False
    Private strLUItemCode As String = ""
    Private bolGetAllItem As Boolean = False
    Private dtrLUDataRow As DataRow

    Public WriteOnly Property pubIsLookUp() As Boolean
        Set(ByVal Value As Boolean)
            bolLookUp = Value
        End Set
    End Property

    Public ReadOnly Property pubIsLookUpGet() As String
        Get
            Return bolLookUpGet
        End Get
    End Property

    Public Property pubLUItemCode() As String
        Get
            Return strLUItemCode
        End Get
        Set(ByVal Value As String)
            strLUItemCode = Value
        End Set
    End Property

    Public WriteOnly Property pubGetAllItem() As Boolean
        Set(value As Boolean)
            bolGetAllItem = value
        End Set
    End Property

    Public ReadOnly Property pubLUDataRow() As DataRow
        Get
            Return dtrLUDataRow
        End Get
    End Property

    Private Const cGet = 0, cSep1 = 1, cDetail = 2, cSep2 = 3, cRefresh = 4, cExit = 5
    Private intPos As Integer

#End Region

#Region "Function Handle"

    Private Sub prvSetTitleForm()
        If bolLookUp Then
            Me.Text += " [look up] "
        End If
    End Sub

    Private Sub prvSetLookUp()
        If bolLookUp Then
            UI.usForm.GridMoveRow(grdView, "ItemCode", strLUItemCode)
        Else
            With ToolBar.Buttons
                .Item(cGet).Visible = False
                .Item(cGet + 1).Visible = False
            End With
        End If
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ItemID", "ItemID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ItemCode", "Item Code", 80, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ItemName", "Item Name", 400, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsAltName", "Alt Name", 65, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "IsContract", "Contract", 75, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "LocationItem", "Location Item", 85, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "UomCode", "Uom Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Subs", "Subs", 60, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "HSCode", "HS Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "HSCodeBy", "HS Code By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "HSCodeDate", "HS Code Date", 120, UI.usDefGrid.gSmallDate)
        UI.usForm.SetGrid(grdView, "ClassID", "ClassID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ClassCode", "Class Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ClassName", "Class Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "GroupID", "GroupID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "GroupCode", "Group Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "GroupName", "Group Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "CategoryID", "CategoryID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "CategoryCode", "Category Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "CategoryName", "Category Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "SubCategory1ID", "SubCategory1ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "SubCategory1Code", "Sub Category 1 Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "SubCategory1Name", "Sub Category 1 Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "SubCategory2ID", "SubCategory2ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "SubCategory2Code", "Sub Category 2 Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "SubCategory2Name", "Sub Category 2 Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AccGroupID", "Acc GroupID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "AccGroupCode", "Acc Group Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AccGroupName", "Acc Group Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AccCategoryID", "Acc CategoryID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "AccCategoryCode", "Acc Category Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AccCategoryName", "Acc Category Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AccSubCategoryID", "Acc SubCategoryID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "AccSubCategoryCode", "Acc Sub Category Code", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AccSubCategoryName", "Acc Sub Category Name", 200, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "WeightInKg", "Weight [Kg]", 80, UI.usDefGrid.gReal2Num)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StatusBy", "Status By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StatusDate", "Status Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "IsCriticalChemical", "C.Chemical", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "IsCriticalFuel", "C.Fuel", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "IsImport", "Import", 60, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "IsSourcingItem", "Sourcing", 60, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "LogInc", "LogInc", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "LogBy", "LogBy", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "LogDate", 100, UI.usDefGrid.gFullDate)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Enabled = bolEnable
            .Item(cDetail).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvClear()
        txtItemCode.Text = ""
        txtItemName.Text = ""
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
    End Sub

    Private Sub prvGet()
        intPos = grdView.FocusedRowHandle
        If bolLookUp And intPos >= 0 Then
            If grdView.GetDataRow(intPos).Item("Status") = 1 Then
                UI.usForm.frmMessageBox("Cannot choose this data because data is not active")
            Else
                strLUItemCode = grdView.GetDataRow(intPos).Item("ItemCode")
                dtrLUDataRow = grdView.GetDataRow(grdView.FocusedRowHandle)
                bolLookUpGet = True
                Me.Close()
            End If
        End If
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor
        progressBar.Visible = True
        Try
            grdMain.DataSource = BL.Item.ListAllData(chkShowAll.Checked, txtItemCode.Text.Trim, txtItemName.Text.Trim, chkHideInactive.Checked)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            Me.Cursor = Cursors.Default
            progressBar.Visible = False
            prvSetButton()
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ItemCode")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ItemCode", strSearch)
        End With
    End Sub

    Private Sub prvDetail()
        intPos = grdView.FocusedRowHandle
        Dim frmDetail As New frmMstItemDet
        With frmDetail
            .pubIsNew = False
            .pubIsCopy = False
            .pubItemID = grdView.GetDataRow(intPos).Item("ItemID")
            .ShowDialog()
            If .pubIsSave Then pubRefresh()
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetTitleForm()
        prvSetGrid()
        prvQuery()
        prvSetLookUp()
        AddHandler chkShowAll.CheckedChanged, AddressOf chkShowAll_CheckedChanged
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Refresh" Then
            pubRefresh()
        ElseIf e.Button.Text = "Close" Then
            Me.Close()
        ElseIf grdView.FocusedRowHandle >= 0 Then
            Select Case e.Button.Text
                Case "Get" : prvGet()
                Case "Detail" : prvDetail()
            End Select
        End If
    End Sub

    Private Sub chkShowAll_CheckedChanged(sender As Object, e As EventArgs)
        If chkShowAll.Checked Then
            If Not UI.usForm.frmAskQuestion("Sure want to show all Item ?") Then
                chkShowAll.Checked = False
            Else
                txtItemName.Enabled = False
                txtItemCode.Enabled = False
                chkHideInactive.Checked = False
                chkHideInactive.Enabled = False
                btnExecute.Focus()
            End If
        Else
            txtItemCode.Enabled = True
            txtItemName.Enabled = True
            chkHideInactive.Enabled = True
        End If
        prvClear()
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim InActive As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("StatusInfo"))
            If InActive = "IN-ACTIVE" Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

    Private Sub grdMain_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdMain.DoubleClick
        prvGet()
    End Sub

#End Region

End Class