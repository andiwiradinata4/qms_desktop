﻿Public Class frmMstItemClass

#Region "Properties Handle"
    Private bolLookUp As Boolean = False
    Private bolLookUpGet As Boolean = False
    Private intLUClassID As Integer
    Private strLUClassCode As String
    Private dtrLUDataRow As DataRow

    Public WriteOnly Property pubIsLookUp() As Boolean
        Set(ByVal Value As Boolean)
            bolLookUp = Value
        End Set
    End Property

    Public ReadOnly Property pubIsLookUpGet() As String
        Get
            Return bolLookUpGet
        End Get
    End Property

    Public Property pubLUClassID() As Integer
        Get
            Return intLUClassID
        End Get
        Set(ByVal Value As Integer)
            intLUClassID = Value
        End Set
    End Property

    Public Property pubLUClassCode() As String
        Get
            Return strLUClassCode
        End Get
        Set(ByVal Value As String)
            strLUClassCode = Value
        End Set
    End Property

    Public ReadOnly Property pubLUDataRow() As DataRow
        Get
            Return dtrLUDataRow
        End Get
    End Property

    Private Const cGet = 0, cRefresh = 1, cExit = 2
    Private intPos As Integer

#End Region

#Region "Function Handle"

    Private Sub prvSetTitleForm()
        If bolLookUp Then
            Me.Text += " [look up] "
        End If
    End Sub

    Private Sub prvSetLookUp()
        If bolLookUp Then
            UI.usForm.GridMoveRow(grdView, "ClassCode", strLUClassCode)
        Else
            With ToolBar.Buttons
                .Item(cGet).Visible = False
            End With
        End If
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ClassID", "ClassID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ClassCode", "Class Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ClassName", "Class Name", 200, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogInc", "LogInc", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "LogBy", "LogBy", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "LogDate", 100, UI.usDefGrid.gFullDate)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            grdMain.DataSource = BL.ItemClass.ListData
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
        prvSetButton()
    End Sub

    Private Sub prvGet()
        intPos = grdView.FocusedRowHandle
        If bolLookUp And intPos >= 0 Then
            If grdView.GetDataRow(intPos).Item("Status") = 1 Then
                UI.usForm.frmMessageBox("Cannot choose this data because data is not active")
            Else
                intLUClassID = grdView.GetDataRow(intPos).Item("ClassID")
                dtrLUDataRow = grdView.GetDataRow(grdView.FocusedRowHandle)
                bolLookUpGet = True
                Me.Close()
            End If
        End If
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ClassCode")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ClassCode", strSearch)
        End With
    End Sub

#End Region
    
#Region "Form Handle"

    Private Sub frmMstItemClass_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ToolBar.SetIcon(Me)
        prvSetTitleForm()
        prvSetGrid()
        prvQuery()
        prvSetLookUp()
    End Sub

    Private Sub frmMstItemClass_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F5 Then
            pubRefresh()
        ElseIf e.KeyCode = Keys.Escape And bolLookUp Then
            Me.Close()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Refresh" Then
            pubRefresh()
        ElseIf e.Button.Text = "Close" Then
            Me.Close()
        ElseIf grdView.FocusedRowHandle >= 0 Then
            Select Case e.Button.Text
                Case "Get" : prvGet()
            End Select
        End If
    End Sub

    Private Sub grdMain_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdMain.DoubleClick
        prvGet()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim InActive As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("StatusInfo"))
            If InActive = "IN-ACTIVE" Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

#End Region

End Class