﻿Public Class frmMstItemSubCategory1

#Region "Properties Handle"

    Private bolLookUp As Boolean = False
    Private bolLookUpGet As Boolean = False

    Private bolInherit As Boolean = False
    Private intLUCategoryID As Integer = -1
    Private strLUCategoryCode As String = ""

    Private intLUSubCategory1ID As Integer
    Private strLUSubCategory1Code As String

    Private dtrLUDataRow As DataRow

    Public WriteOnly Property pubIsLookUp() As Boolean
        Set(ByVal Value As Boolean)
            bolLookUp = Value
        End Set
    End Property

    Public ReadOnly Property pubIsLookUpGet() As String
        Get
            Return bolLookUpGet
        End Get
    End Property

    Public WriteOnly Property pubIsInherit() As Boolean
        Set(ByVal Value As Boolean)
            bolInherit = Value
        End Set
    End Property

    Public Property pubLUCategoryID() As Integer
        Get
            Return intLUCategoryID
        End Get
        Set(ByVal Value As Integer)
            intLUCategoryID = Value
        End Set
    End Property

    Public Property pubLUCategoryCode() As String
        Get
            Return strLUCategoryCode
        End Get
        Set(ByVal Value As String)
            strLUCategoryCode = Value
        End Set
    End Property

    Public Property pubLUSubCategory1ID() As Integer
        Get
            Return intLUSubCategory1ID
        End Get
        Set(ByVal Value As Integer)
            intLUSubCategory1ID = Value
        End Set
    End Property

    Public Property pubLUSubCategory1Code() As String
        Get
            Return strLUSubCategory1Code
        End Get
        Set(ByVal Value As String)
            strLUSubCategory1Code = Value
        End Set
    End Property

    Public Property pubLUDataRow() As DataRow
        Get
            Return dtrLUDataRow
        End Get
        Set(ByVal Value As DataRow)
            dtrLUDataRow = Value
        End Set
    End Property

    Private Const cGet = 0, cRefresh = 2

    Private intPos As Integer

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Get,2,Refresh")
    End Sub

    Private Sub prvSetTitleForm()
        If bolLookUp Then
            Me.Text += " [look up] "
        End If
        If bolInherit Then
            Me.Text += " [Category : " & strLUCategoryCode & "]"
        End If
    End Sub

    Private Sub prvSetLookUp()
        If bolLookUp Then
            UI.usForm.GridMoveRow(grdView, "SubCategory1Code", strLUSubCategory1Code)
        Else
            With ToolBar.Buttons
                .Item(cGet).Visible = False
                .Item(cGet + 1).Visible = False
            End With
        End If
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "SubCategory1ID", "SubCategory1ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "SubCategory1Code", "Sub Category 1 Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "SubCategory1Name", "Sub Category 1 Name", 200, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ClassID", "ClassID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ClassCode", "Class Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ClassName", "Class Name", 200, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "GroupID", "GroupID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "GroupCode", "Group Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "GroupName", "Group Name", 200, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CategoryID", "CategoryID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "CategoryCode", "Category Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CategoryName", "Category Name", 200, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogInc", "LogInc", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "LogBy", "LogBy", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "LogDate", 100, UI.usDefGrid.gFullDate)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            grdMain.DataSource = BL.ItemSubCategory1.ListData(intLUCategoryID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
        prvSetButton()
    End Sub

    Private Sub prvGet()
        intPos = grdView.FocusedRowHandle
        If bolLookUp And intPos >= 0 Then
            If grdView.GetDataRow(intPos).Item("Status") = 1 Then
                UI.usForm.frmMessageBox("Cannot choose this data because data is not active")
            Else
                intLUCategoryID = grdView.GetDataRow(intPos).Item("CategoryID")
                intLUSubCategory1ID = grdView.GetDataRow(intPos).Item("SubCategory1ID")
                dtrLUDataRow = grdView.GetDataRow(grdView.FocusedRowHandle)
                bolLookUpGet = True
                Me.Close()
            End If
        End If
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("SubCategory1Code")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "SubCategory1Code", strSearch)
        End With
    End Sub

#End Region
#Region "Form Handle"

    Private Sub Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        prvSetIcon()
        prvSetTitleForm()
        prvSetGrid()
        prvQuery()
        prvSetLookUp()
    End Sub

    Private Sub Form_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            pubRefresh()
        ElseIf e.KeyCode = Keys.Escape And (bolLookUp Or bolInherit) Then
            Me.Close()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Refresh" Then
            pubRefresh()
        ElseIf grdView.FocusedRowHandle >= 0 Then
            Select Case e.Button.Text
                Case "Get" : prvGet()
            End Select
        End If
    End Sub

    Private Sub grdMain_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdMain.DoubleClick
        prvGet()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim InActive As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("StatusInfo"))
            If InActive = "IN-ACTIVE" Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

#End Region

End Class