﻿Public Class frmMstItemDet

#Region "Property Handle"

    Private frmParent As frmMstItem
    Private bolNew, bolSave, bolCopy As Boolean
    Private intItemID As Integer
    Private strItemCode As String

    Public WriteOnly Property pubIsNew() As Boolean
        Set(ByVal Value As Boolean)
            bolNew = Value
        End Set
    End Property

    Public WriteOnly Property pubIsCopy() As Boolean
        Set(ByVal Value As Boolean)
            bolCopy = Value
        End Set
    End Property

    Public ReadOnly Property pubIsSave() As Boolean
        Get
            Return bolSave
        End Get
    End Property

    Public Property pubItemID() As Integer
        Get
            Return intItemID
        End Get
        Set(ByVal Value As Integer)
            intItemID = Value
        End Set
    End Property

    Public Property pubItemCode() As String
        Get
            Return strItemCode
        End Get
        Set(ByVal Value As String)
            strItemCode = Value
        End Set
    End Property

    Private Const cRefresh = 0, cClose = 1
    Private clsData As New VO.Item
    Private bolSAPLockPrice As Boolean = False

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Refresh,1,Close")
    End Sub

    Private Sub prvFillForm()
        Try
            clsData = BL.Item.GetDetail(intItemID, bolSAPLockPrice)

            txtItemCode.Text = clsData.ItemCode
            txtItemName.Text = clsData.ItemName
            txtUomCode.Text = clsData.UomCode

            txtClassName.Text = clsData.ClassName
            txtGroupName.Text = clsData.GroupName

            txtCategoryName.Text = clsData.CategoryName
            txtSubCategory1Name.Text = clsData.SubCategory1Name

            txtSubCategory2Name.Text = clsData.SubCategory2Name

            txtAccGroupName.Text = clsData.AccGroupName
            txtAccCategoryName.Text = clsData.AccCategoryName

            txtAccSubCategoryName.Text = clsData.AccSubCategoryName
            txtWeight.EditValue = clsData.WeightInKg

            txtxName.Text = IIf(clsData.xName = "GENERIC", "", clsData.xName)
            txtxBrand.Text = IIf(clsData.xBrand = "GENERIC", "", clsData.xBrand)
            txtxType.Text = IIf(clsData.xType = "GENERIC", "", clsData.xType)
            txtxSpec.Text = IIf(clsData.xSpec = "GENERIC", "", clsData.xSpec)
            txtxCountry.Text = IIf(clsData.xCountry = "GENERIC", "", clsData.xCountry)

            txtHSCode.Text = clsData.HSCode
            txtRefPrice.Value = clsData.RefPrice
            txtRemarks.Text = clsData.Remarks
            cboStatus.SelectedIndex = clsData.Status
            txtStatusBy.Text = clsData.StatusBy
            If txtStatusBy.Text <> "" Then txtStatusDate.Text = Format(clsData.StatusDate, UI.usDefCons.DateFull)

            txtStatusRemarks.Text = clsData.StatusRemarks
            ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
            ToolStripLogBy.Text = "Last Log : " & clsData.LogBy
            ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)

            chkIsCriticalChemical.Checked = IIf(clsData.IsCriticalChemical = 1, True, False)
            chkIsCriticalFuel.Checked = IIf(clsData.IsCriticalFuel = 1, True, False)

            cboToleranceType.SelectedIndex = clsData.xToleranceType
            txtToleranceValue.Value = clsData.xToleranceValue

            txtGNCode.Text = clsData.GNCode
            txtGNName.Text = clsData.GNName
            chkContract.Checked = clsData.IsContract
            chkLocationItem.Checked = clsData.LocationItem

            If UI.usUserApp.ProgramID = "CPS.X.1" Then
                Me.lblRefPrice.Visible = False
                Me.lblRefPriceCurrID.Visible = False
                Me.txtRefPrice.Visible = False
            Else
                Me.lblRefPrice.Visible = True
                Me.lblRefPriceCurrID.Visible = True
                Me.txtRefPrice.Visible = True
            End If

            txtChineseName.Text = clsData.ItemChineseName
            txtSpanishName.Text = clsData.ItemSpanishName
            txtPartNumber.Text = clsData.PartNumber
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        prvSetIcon()
        cboStatus.Items.Add("ACTIVE")
        cboStatus.Items.Add("IN-ACTIVE")
        bolSAPLockPrice = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "SAPITEMHISTORYPRICE2", "VIEW")
        prvFillForm()
        btnUpdateWeight.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "UPDATEITEMWEIGHT", "EDIT")
    End Sub

    Private Sub Form_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close This Form ?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F1 Then
            TabControl1.SelectedTab = TabPage1
        ElseIf e.KeyCode = Keys.F2 Then
            TabControl1.SelectedTab = TabPage2
        ElseIf e.KeyCode = Keys.F3 Then
            TabControl1.SelectedTab = TabPage4
            'update RH20160408
        ElseIf e.KeyCode = Keys.F4 Then
            TabControl1.SelectedTab = tbLocalDesc
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Refresh" Then
            prvFillForm()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub txtWeight_LostFocus(sender As Object, e As EventArgs) Handles txtWeight.LostFocus
        txtWeight.EditValue = System.Math.Round(CDec(txtWeight.EditValue), 4, MidpointRounding.AwayFromZero)
    End Sub

#End Region

End Class