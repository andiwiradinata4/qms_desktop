﻿Public Class frmMstCompanyLocation

#Region "Properties Handle"

    Private bolLookUp As Boolean = False
    Private bolLookUpGet As Boolean = False
    Private strLUProgramID As String = "QMS"
    Private strLUCompanyID As String
    Private strLULocationID As String
    Private dtrLUDataRow As DataRow
    Private intPos As Integer
    Private Const cGet = 0, cRefresh = 1, cClose = 2

    Public WriteOnly Property pubIsLookUp() As Boolean
        Set(ByVal Value As Boolean)
            bolLookUp = Value
        End Set
    End Property

    Public ReadOnly Property pubIsLookUpGet() As String
        Get
            Return bolLookUpGet
        End Get
    End Property

    Public Property pubLUProgramID() As String
        Get
            Return strLUProgramID
        End Get
        Set(ByVal Value As String)
            strLUProgramID = Value
        End Set
    End Property

    Public Property pubLUCompanyID() As String
        Get
            Return strLUCompanyID
        End Get
        Set(ByVal Value As String)
            strLUCompanyID = Value
        End Set
    End Property

    Public Property pubLULocationID() As String
        Get
            Return strLULocationID
        End Get
        Set(ByVal Value As String)
            strLULocationID = Value
        End Set
    End Property

    Public ReadOnly Property pubLUDataRow() As DataRow
        Get
            Return dtrLUDataRow
        End Get
    End Property

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "LocationID", "Location ID", 120, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LocationName", "Location Name", 380, UI.usDefGrid.gString)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            Dim bolFound As Boolean = False
            Dim dtQuery As New DataTable
            dtQuery = UI.usUserApp.AccessList.Clone
            For Each dRow1 As DataRow In UI.usUserApp.AccessList.Rows
                If dRow1.Item("ProgramID") = strLUProgramID Then
                    For Each dRow2 As DataRow In dtQuery.Rows
                        If dRow1.Item("CompanyID") = strLUCompanyID And dRow1.Item("LocationID") = dRow2.Item("LocationID") Then
                            bolFound = True
                        Else
                            bolFound = False
                        End If
                    Next
                    If Not bolFound Then
                        dtQuery.ImportRow(dRow1)
                    End If
                End If
            Next
            grdMain.DataSource = dtQuery
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("LocationID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "LocationID", strSearch)
        End With
    End Sub

    Private Sub prvGet()
        intPos = grdView.FocusedRowHandle
        If bolLookUp And intPos >= 0 Then
            strLULocationID = grdView.GetRowCellValue(intPos, "LocationID")
            dtrLUDataRow = grdView.GetDataRow(grdView.FocusedRowHandle)
            bolLookUpGet = True
            Me.Close()
        End If
    End Sub

    Private Sub prvSetLookUp()
        If bolLookUp Then
            Me.Text += " [Lookup] "
        End If
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstCompanyLocation_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstCompanyLocation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvQuery()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text
            Case "Get" : prvGet()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub grdMain_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdMain.DoubleClick
        prvGet()
    End Sub

#End Region

End Class