Public Class frmMstImageTypeDet

#Region "Property Handle"

    Private frmParent As frmMstImageType
    Private clsData As VO.ImageType
    Property pubID As Integer
    Property pubIsNew As Boolean = False
    Property pubIsSave As Boolean = False
    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Save,1,Close")
    End Sub

    Private Sub prvSetTitleForm()
        If pubIsNew Then
            Me.Text += " [new] "
        Else
            Me.Text += " [edit] "
        End If
    End Sub

    Private Sub prvFillCombo()
        Dim dtData As New DataTable
        Try
            dtData = BL.Status.ListDataByModuleID(VO.Modules.Values.ImageType)
            UI.usForm.FillComboBox(cboStatus, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvFillForm()
        Try
            prvFillCombo()
            If pubIsNew Then
                prvClear()
            Else
                clsData = New VO.ImageType
                clsData = BL.ImageType.GetDetail(pubID)
                txtDescription.Text = clsData.Description
                cboStatus.SelectedValue = clsData.IDStatus
                txtRemarks.Text = clsData.Remarks
                ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
                ToolStripLogBy.Text = "Last Log : " & clsData.LogBy
                ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)

                cboStatus.Enabled = IIf(clsData.IDStatus = VO.Status.Values.InActive, True, False)
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSave()
        If txtDescription.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Description not allow blank")
            txtDescription.Focus()
            Exit Sub
        End If

        clsData = New VO.ImageType
        clsData.ID = pubID
        clsData.Description = txtDescription.Text.Trim
        clsData.IDStatus = cboStatus.SelectedValue
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID
        Try
            BL.ImageType.SaveData(pubIsNew, clsData)
            If pubIsNew Then
                UI.usForm.frmMessageBox("Save data success.")
                frmParent.pubRefresh(clsData.Description)
                prvClear()
            Else
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        txtDescription.Text = ""
        txtRemarks.Text = ""
        cboStatus.SelectedValue = VO.Status.Values.Active
        ToolStripLogInc.Text = "Log Inc : -"
        ToolStripLogBy.Text = "Last Log : -"
        ToolStripLogDate.Text = Format(Now, UI.usDefCons.DateFull)
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cSave).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTIMAGETYPE", IIf(pubIsNew, "ADD", "EDIT"))
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstImageTypeDet_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstImageTypeDet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvSetIcon()
        prvSetTitleForm()
        prvFillForm()
        prvUserAccess()
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

#End Region

End Class


