﻿Imports System.Data.SqlClient
Imports Microsoft.Office.Interop.Excel
Public Class frmMstDriverImportExcel

#Region "Property Handle"

    Private WithEvents ofd As New OpenFileDialog
    Private strExcelSheetName As String = "Driver"
    Private frmParent As frmMstDriver
    Private clsData As VO.Driver
    Private dtData As New System.Data.DataTable
    Property pubIsSave As Boolean = False
    Private Const cChooseFile = 0, cSave = 1, cClose = 2

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetProgressBar(ByVal intMax As Integer)
        pbMain.Maximum = intMax
        pbMain.Value = 0
    End Sub

    Private Sub prvRefreshProgressBar()
        pbMain.Value += 1
        Me.Refresh()
    End Sub

    Private Sub prvSetButton()
        Dim bolEnabled As Boolean = IIf(grdView.RowCount = 0, False, True)
        With ToolBar
            .Buttons(cSave).Enabled = bolEnabled
        End With
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "IdentityCardNumber", "NIK No.", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DrivingLicenseNumber", "SIM No.", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "FullName", "Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "PlaceOfBirth", "Place of Birth", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DateOfBirth", "Date of Birth", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "AddressOfIdentityCard", "Address [KTP]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "AddressOfDrivingLicense", "Address [SIM]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ValidThruOfIdentityCard", "Valid Thru [KTP]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "ValidThruOfDrivingLicense", "Valid Thru [SIM]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeID", "DrivingLicenseTypeID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeName", "Tipe SIM", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "InternalRemarks", "Internal Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Status", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
    End Sub

    Private Sub prvLoadExcel(ByVal strFilePath As String)
        If strFilePath = "" Then Exit Sub
        Dim bolValid As Boolean = True
        'Dim strFilePath As String = ofd.FileName
        Dim MyConnection As New System.Data.OleDb.OleDbConnection
        Dim DtSet As System.Data.DataSet
        Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
        Try
            If BL.Server.IsServerAlpa Then
                MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strFilePath & ";Extended Properties=Excel 12.0;")
            Else
                MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strFilePath & ";Extended Properties=Excel 8.0;")
            End If
            MyCommand = New System.Data.OleDb.OleDbDataAdapter _
                (
                    "SELECT " &
                     "  FullName, PlaceOfBirth, DateOfBirth, NIKNo AS IdentityCardNumber, KTPAddress AS AddressOfIdentityCard, KTPValidThru AS ValidThruOfIdentityCard, " &
                     "  InternalRemarks, Remarks, SIMAddress AS AddressOfDrivingLicense, SIMNo AS DrivingLicenseNumber, SIMValidThru AS ValidThruOfDrivingLicense, " &
                     "  TipeSIM AS DrivingLicenseTypeName, Status, IDTipeSIM AS DrivingLicenseTypeID, IDStatus " &
                     "FROM [" & strExcelSheetName & "$]", MyConnection
                 )
            MyCommand.TableMappings.Add("Table", "Net-informations.com")
            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)
            dtData = DtSet.Tables(0)

            With dtData
                Dim strIdentityCardNumber As String = "", strDrivingLicenseNumber As String = ""
                For i As Integer = 0 To .Rows.Count - 1
                    strIdentityCardNumber = IIf(IsDBNull(.Rows(i).Item("IdentityCardNumber")), "", .Rows(i).Item("IdentityCardNumber"))
                    strDrivingLicenseNumber = IIf(IsDBNull(.Rows(i).Item("DrivingLicenseNumber")), "", .Rows(i).Item("DrivingLicenseNumber"))
                    '# Checking Exists
                    If i < .Rows.Count - 1 Then
                        For ii As Integer = i + 1 To .Rows.Count - 1
                            If strIdentityCardNumber.Trim <> "" And
                                strIdentityCardNumber.Trim = IIf(IsDBNull(.Rows(ii).Item("IdentityCardNumber")), "", .Rows(ii).Item("IdentityCardNumber")) Then
                                UI.usForm.frmMessageBox("Data tidak dapat di import. NIK No " & strIdentityCardNumber & " lebih dari 1")
                                Exit Sub
                            End If

                            If strDrivingLicenseNumber.Trim <> "" And
                                strDrivingLicenseNumber.Trim = IIf(IsDBNull(.Rows(ii).Item("DrivingLicenseNumber")), "", .Rows(ii).Item("DrivingLicenseNumber")) Then
                                UI.usForm.frmMessageBox("Data tidak dapat di import. SIM No " & strDrivingLicenseNumber & " lebih dari 1")
                                Exit Sub
                            End If
                        Next
                    End If

                    'If IsDBNull(.Rows(i).Item("DrivingLicenseTypeID")) Then
                    '    UI.usForm.frmMessageBox("Column IDTipeSIM on row " & i + 2 & " not allow blank")
                    '    bolValid = False
                    '    Exit For
                    'ElseIf IsDBNull(.Rows(i).Item("IDStatus")) Then
                    '    UI.usForm.frmMessageBox("Column IDStatus on row " & i + 2 & " not allow blank")
                    '    bolValid = False
                    '    Exit For
                    'Else
                    If IsDBNull(.Rows(i).Item("FullName")) Or .Rows(i).Item("FullName").ToString.Trim = "" Then
                        UI.usForm.frmMessageBox("Column FullName on row " & i + 2 & " not allow blank")
                        bolValid = False
                        Exit For
                        'ElseIf IsDBNull(.Rows(i).Item("PlaceOfBirth")) Or .Rows(i).Item("PlaceOfBirth").ToString.Trim = "" Then
                        '    UI.usForm.frmMessageBox("Column PlaceOfBirth on row " & i + 2 & " not allow blank")
                        '    bolValid = False
                        '    Exit For
                        'ElseIf IsDBNull(.Rows(i).Item("DateOfBirth")) Then
                        '    UI.usForm.frmMessageBox("Column DateOfBirth on row " & i + 2 & " not allow blank")
                        '    bolValid = False
                        '    Exit For
                        'ElseIf IsDBNull(.Rows(i).Item("IdentityCardNumber")) Or .Rows(i).Item("IdentityCardNumber").ToString.Trim = "" Then
                        '    UI.usForm.frmMessageBox("Column NIKNo on row " & i + 2 & " not allow blank")
                        '    bolValid = False
                        '    Exit For
                        'ElseIf IsDBNull(.Rows(i).Item("AddressOfIdentityCard")) Or .Rows(i).Item("AddressOfIdentityCard").ToString.Trim = "" Then
                        '    UI.usForm.frmMessageBox("Column KTPAddress on row " & i + 2 & " not allow blank")
                        '    bolValid = False
                        '    Exit For
                        'ElseIf IsDBNull(.Rows(i).Item("ValidThruOfIdentityCard")) Then
                        '    UI.usForm.frmMessageBox("Column KTPValidThru on row " & i + 2 & " not allow blank")
                        '    bolValid = False
                        '    Exit For
                        'ElseIf IsDBNull(.Rows(i).Item("AddressOfDrivingLicense")) Or .Rows(i).Item("AddressOfDrivingLicense").ToString.Trim = "" Then
                        '    UI.usForm.frmMessageBox("Column SIMAddress on row " & i + 2 & " not allow blank")
                        '    bolValid = False
                        '    Exit For
                    ElseIf IsDBNull(.Rows(i).Item("DrivingLicenseNumber")) Or .Rows(i).Item("DrivingLicenseNumber").ToString.Trim = "" Then
                        UI.usForm.frmMessageBox("Column SIMNo on row " & i + 2 & " not allow blank")
                        bolValid = False
                        Exit For
                        'ElseIf IsDBNull(.Rows(i).Item("ValidThruOfDrivingLicense")) Then
                        '    UI.usForm.frmMessageBox("Column SIMValidThru on row " & i + 2 & " not allow blank")
                        '    bolValid = False
                        '    Exit For
                    End If
                Next
            End With

            If bolValid = False Then Exit Sub

            grdMain.DataSource = dtData
            grdView.BestFitColumns()
            UI.usForm.frmMessageBox("Import Excel to Grid Succeed")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            MyConnection.Close()
            prvSetButton()
        End Try
    End Sub

    Private Sub prvLoadExcelToSpreadSheet(ByVal strFilePath As String)
        If strFilePath = "" Then Exit Sub
        Dim bolValid As Boolean = True

        dtData = New System.Data.DataTable
        Dim excelApp As New Application()
        Dim workbook As Workbook = excelApp.Workbooks.Open(strFilePath)
        Try
            Dim worksheet As Worksheet = workbook.Worksheets(strExcelSheetName)
            Dim range As Range = worksheet.UsedRange

            For c As Integer = 1 To range.Columns.Count
                dtData.Columns.Add(New DataColumn(CType(range.Cells(1, c), Range).Value2))
            Next

            For r As Integer = 2 To range.Rows.Count
                Dim dataRow As DataRow = dtData.NewRow()
                For c As Integer = 1 To range.Columns.Count
                    Dim value = CType(range.Cells(r, c), Range).Value2
                    Console.WriteLine(value.GetType())
                    dataRow(c - 1) = CType(range.Cells(r, c), Range).Value2.ToString
                Next
                dtData.Rows.Add(dataRow)
            Next

            grdMain.DataSource = dtData
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            workbook.Close()
            excelApp.Quit()
        End Try

        ''Dim strFilePath As String = ofd.FileName
        'Dim MyConnection As New System.Data.OleDb.OleDbConnection
        'Dim DtSet As System.Data.DataSet
        'Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
        'Try
        '    If BL.Server.IsServerAlpa Then
        '        MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strFilePath & ";Extended Properties=Excel 12.0;")
        '    Else
        '        MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strFilePath & ";Extended Properties=Excel 8.0;")
        '    End If
        '    MyCommand = New System.Data.OleDb.OleDbDataAdapter _
        '        ( _
        '            "SELECT " & _
        '             "  FullName, PlaceOfBirth, DateOfBirth, NIKNo AS IdentityCardNumber, KTPAddress AS AddressOfIdentityCard, KTPValidThru AS ValidThruOfIdentityCard, " & _
        '             "  InternalRemarks, Remarks, SIMAddress AS AddressOfDrivingLicense, SIMNo AS DrivingLicenseNumber, SIMValidThru AS ValidThruOfDrivingLicense, " & _
        '             "  TipeSIM AS DrivingLicenseTypeName, Status, IDTipeSIM AS DrivingLicenseTypeID, IDStatus " & _
        '             "FROM [" & strExcelSheetName & "$]", MyConnection _
        '         )
        '    MyCommand.TableMappings.Add("Table", "Net-informations.com")
        '    DtSet = New System.Data.DataSet
        '    MyCommand.Fill(DtSet)
        '    dtData = DtSet.Tables(0)

        '    With dtData
        '        Dim strIdentityCardNumber As String = "", strDrivingLicenseNumber As String = ""
        '        For i As Integer = 0 To .Rows.Count - 1
        '            strIdentityCardNumber = IIf(IsDBNull(.Rows(i).Item("IdentityCardNumber")), "", .Rows(i).Item("IdentityCardNumber"))
        '            strDrivingLicenseNumber = IIf(IsDBNull(.Rows(i).Item("DrivingLicenseNumber")), "", .Rows(i).Item("DrivingLicenseNumber"))
        '            '# Checking Exists
        '            If i < .Rows.Count - 1 Then
        '                For ii As Integer = i + 1 To .Rows.Count - 1
        '                    If strIdentityCardNumber.Trim <> "" And _
        '                        strIdentityCardNumber.Trim = IIf(IsDBNull(.Rows(ii).Item("IdentityCardNumber")), "", .Rows(ii).Item("IdentityCardNumber")) Then
        '                        UI.usForm.frmMessageBox("Data tidak dapat di import. NIK No " & strIdentityCardNumber & " lebih dari 1")
        '                        Exit Sub
        '                    End If

        '                    If strDrivingLicenseNumber.Trim <> "" And _
        '                        strDrivingLicenseNumber.Trim = IIf(IsDBNull(.Rows(ii).Item("DrivingLicenseNumber")), "", .Rows(ii).Item("DrivingLicenseNumber")) Then
        '                        UI.usForm.frmMessageBox("Data tidak dapat di import. SIM No " & strDrivingLicenseNumber & " lebih dari 1")
        '                        Exit Sub
        '                    End If
        '                Next
        '            End If

        '            'If IsDBNull(.Rows(i).Item("DrivingLicenseTypeID")) Then
        '            '    UI.usForm.frmMessageBox("Column IDTipeSIM on row " & i + 2 & " not allow blank")
        '            '    bolValid = False
        '            '    Exit For
        '            'ElseIf IsDBNull(.Rows(i).Item("IDStatus")) Then
        '            '    UI.usForm.frmMessageBox("Column IDStatus on row " & i + 2 & " not allow blank")
        '            '    bolValid = False
        '            '    Exit For
        '            'Else
        '            If IsDBNull(.Rows(i).Item("FullName")) Or .Rows(i).Item("FullName").ToString.Trim = "" Then
        '                UI.usForm.frmMessageBox("Column FullName on row " & i + 2 & " not allow blank")
        '                bolValid = False
        '                Exit For
        '                'ElseIf IsDBNull(.Rows(i).Item("PlaceOfBirth")) Or .Rows(i).Item("PlaceOfBirth").ToString.Trim = "" Then
        '                '    UI.usForm.frmMessageBox("Column PlaceOfBirth on row " & i + 2 & " not allow blank")
        '                '    bolValid = False
        '                '    Exit For
        '                'ElseIf IsDBNull(.Rows(i).Item("DateOfBirth")) Then
        '                '    UI.usForm.frmMessageBox("Column DateOfBirth on row " & i + 2 & " not allow blank")
        '                '    bolValid = False
        '                '    Exit For
        '                'ElseIf IsDBNull(.Rows(i).Item("IdentityCardNumber")) Or .Rows(i).Item("IdentityCardNumber").ToString.Trim = "" Then
        '                '    UI.usForm.frmMessageBox("Column NIKNo on row " & i + 2 & " not allow blank")
        '                '    bolValid = False
        '                '    Exit For
        '                'ElseIf IsDBNull(.Rows(i).Item("AddressOfIdentityCard")) Or .Rows(i).Item("AddressOfIdentityCard").ToString.Trim = "" Then
        '                '    UI.usForm.frmMessageBox("Column KTPAddress on row " & i + 2 & " not allow blank")
        '                '    bolValid = False
        '                '    Exit For
        '                'ElseIf IsDBNull(.Rows(i).Item("ValidThruOfIdentityCard")) Then
        '                '    UI.usForm.frmMessageBox("Column KTPValidThru on row " & i + 2 & " not allow blank")
        '                '    bolValid = False
        '                '    Exit For
        '                'ElseIf IsDBNull(.Rows(i).Item("AddressOfDrivingLicense")) Or .Rows(i).Item("AddressOfDrivingLicense").ToString.Trim = "" Then
        '                '    UI.usForm.frmMessageBox("Column SIMAddress on row " & i + 2 & " not allow blank")
        '                '    bolValid = False
        '                '    Exit For
        '            ElseIf IsDBNull(.Rows(i).Item("DrivingLicenseNumber")) Or .Rows(i).Item("DrivingLicenseNumber").ToString.Trim = "" Then
        '                UI.usForm.frmMessageBox("Column SIMNo on row " & i + 2 & " not allow blank")
        '                bolValid = False
        '                Exit For
        '                'ElseIf IsDBNull(.Rows(i).Item("ValidThruOfDrivingLicense")) Then
        '                '    UI.usForm.frmMessageBox("Column SIMValidThru on row " & i + 2 & " not allow blank")
        '                '    bolValid = False
        '                '    Exit For
        '            End If
        '        Next
        '    End With

        '    If bolValid = False Then Exit Sub

        '    grdMain.DataSource = dtData
        '    grdView.BestFitColumns()
        '    UI.usForm.frmMessageBox("Import Excel to Grid Succeed")
        'Catch ex As Exception
        '    UI.usForm.frmMessageBox(ex.Message)
        'Finally
        '    MyConnection.Close()
        '    prvSetButton()
        'End Try
    End Sub

    Private Sub prvSave()
        Dim bolSuccess As Boolean = True
        ToolBar.Focus()
        If Not UI.usForm.frmAskQuestion("Save all data?") Then Exit Sub

        Dim clsDataAllImage As New List(Of VO.DriverImage)

        Me.Cursor = Cursors.WaitCursor
        BL.Server.ServerDefault()
        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
            Try
                prvSetProgressBar(dtData.Rows.Count)
                For Each dr As DataRow In dtData.Rows
                    'Main - F1
                    'Identity Card - F2
                    'Driving License Card - F3
                    clsData = New VO.Driver With {
                    .ID = "",
                    .FullName = UCase(dr.Item("FullName").ToString.Trim),
                    .PlaceOfBirth = IIf(IsDBNull(dr.Item("PlaceOfBirth")), "", UCase(dr.Item("PlaceOfBirth").ToString.Trim)),
                    .DateOfBirth = IIf(IsDBNull(dr.Item("DateOfBirth")), New Date(1900, 1, 1), dr.Item("DateOfBirth")),
                    .IDStatus = IIf(IsDBNull(dr.Item("IDStatus")), 1, dr.Item("IDStatus")),
                    .InternalRemarks = IIf(IsDBNull(dr.Item("InternalRemarks")), "", UCase(dr.Item("InternalRemarks").ToString.Trim)),
                    .Remarks = IIf(IsDBNull(dr.Item("Remarks")), "", UCase(dr.Item("Remarks").ToString.Trim)),
                    .ComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID,
                    .LogBy = UI.usUserApp.UserID,
                    .IdentityCardNumber = IIf(IsDBNull(dr.Item("IdentityCardNumber")), "", UCase(dr.Item("IdentityCardNumber").ToString.Trim)),
                    .GenderID = VO.Gender.Values.None,
                    .BloodTypeID = VO.BloodType.Values.None,
                    .AddressOfIdentityCard = IIf(IsDBNull(dr.Item("AddressOfIdentityCard")), "", UCase(dr.Item("AddressOfIdentityCard").ToString.Trim)),
                    .ReligionID = VO.Religion.Values.None,
                    .MaritalStatusID = VO.MaritalStatus.Values.None,
                    .OccupationsIDOfIdentityCard = VO.Occupations.Values.None,
                    .OccupationsOthersOfIdentityCard = "",
                    .NationalityID = VO.Nationality.Values.WNI,
                    .ValidThruOfIdentityCard = IIf(IsDBNull(dr.Item("DateOfBirth")), New Date(3000, 1, 1), dr.Item("ValidThruOfIdentityCard")),
                    .AddressOfDrivingLicense = IIf(IsDBNull(dr.Item("AddressOfDrivingLicense")), "", UCase(dr.Item("AddressOfDrivingLicense").ToString.Trim)),
                    .Height = 0,
                    .OccupationsIDOfDrivingLicense = VO.Occupations.Values.None,
                    .OccupationsOthersOfDrivingLicense = "",
                    .DrivingLicenseNumber = IIf(IsDBNull(dr.Item("DrivingLicenseNumber")), "", UCase(dr.Item("DrivingLicenseNumber").ToString.Trim)),
                    .ValidThruOfDrivingLicense = IIf(IsDBNull(dr.Item("ValidThruOfDrivingLicense")), New Date(1900, 1, 1), dr.Item("ValidThruOfDrivingLicense")),
                    .DrivingLicenseTypeID = IIf(IsDBNull(dr.Item("DrivingLicenseTypeID")), VO.DrivingLicenseType.Values.None, dr.Item("DrivingLicenseTypeID"))
                }
                    BL.Driver.SaveDataDefault(sqlCon, sqlTrans, True, clsData, clsDataAllImage)
                    prvRefreshProgressBar()
                Next

                sqlTrans.Commit()
                UI.usForm.frmMessageBox("Save data success")
            Catch ex As Exception
                sqlTrans.Rollback()
                UI.usForm.frmMessageBox(ex.Message)
                bolSuccess = False
                pbMain.Value = 0
            Finally
                Me.Cursor = Cursors.Default
                prvSetButton()
                If bolSuccess Then pubIsSave = True : Me.Close()
            End Try
        End Using

    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstDriverImportExcel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvSetButton()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Choose File" : prvLoadExcelToSpreadSheet(UI.usForm.ChooseFile().Trim) ' prvLoadExcel(UI.usForm.ChooseFile().Trim)
            Case "Save" : prvSave()
            Case "Close" : Me.Close()
        End Select
    End Sub

    'Private Sub ofd_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ofd.FileOk
    '    prvLoadExcel()
    'End Sub

#End Region

End Class