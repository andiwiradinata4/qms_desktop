﻿Public Class frmMstQueueFlowStation

#Region "Property Handle"

    Private frmParent As frmMstQueueFlowDet
    Property pubTableParent As DataTable
    Private Const cAdd = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Add,1,Close")
    End Sub

    Private Sub prvFillCombo()
        Dim dtData As New DataTable
        Try
            dtData = BL.Station.ListData
            UI.usForm.FillComboBox(cboStation, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvAdd()
        If cboStation.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose station first")
            cboStation.Focus()
            Exit Sub
        End If
       
        Dim drNew As DataRow
        drNew = pubTableParent.NewRow
        With drNew
            .BeginEdit()
            .Item("QueueFlowID") = ""
            .Item("Idx") = pubTableParent.Rows.Count + 1
            .Item("StationID") = cboStation.SelectedValue
            .Item("StationName") = cboStation.Text.Trim
            .EndEdit()
        End With
        pubTableParent.Rows.Add(drNew)
        pubTableParent.AcceptChanges()
        cboStation.SelectedIndex = -1
    End Sub

#End Region
  
#Region "Form Handle"

    Private Sub frmMstQueueFlowStation_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstQueueFlowStation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvSetIcon()
        prvFillCombo()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Add" : prvAdd()
            Case "Close" : Me.Close()
        End Select
    End Sub

#End Region

End Class