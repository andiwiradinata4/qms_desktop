﻿Public Class frmMstDriverMerge

#Region "Property Handle"

    Private frmParent As frmMstDriver
    Private clsData As VO.Driver
    Private dtData As New DataTable
    Property pubIsSave As Boolean = False
    Private Const cSave = 0, cClose = 1, cSep1 = 2, cRefresh = 3

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "Mark", "Mark", 100, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdView, "Pick", "Pick", 100, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IdentityCardNumber", "Identity Card Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DrivingLicenseNumber", "Driving License Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "FullName", "Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "PlaceOfBirth", "Place of Birth", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DateOfBirth", "Date of Birth", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "GenderID", "GenderID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "GenderName", "Gender", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "BloodTypeID", "BloodTypeID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "BloodTypeName", "Blood Type", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "AddressOfIdentityCard", "Address [Identity Card]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "AddressOfDrivingLicense", "Address [Driving License]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ReligionID", "ReligionID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ReligionName", "Religion", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "MaritalStatusID", "MaritalStatusID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "MaritalStatusName", "Marital Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "NationalityID", "NationalityID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "NationalityName", "Nationality", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "OccuptionsIDOfIdentityCard", "OccuptionsID [Identity Card]", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "OccuptionsNameOfIdentityCard", "Occuptions [Identity Card]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "OccupationsOthersOfIdentityCard", "Occupations Others [Identity Card]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "OccuptionsIDOfDrivingLicense", "OccuptionsIDOfDrivingLicense", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "OccuptionsNameOfDrivingLicense", "Occuptions [Driving License]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "OccupationsOthersOfDrivingLicense", "Occupations Others [Driving License]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ValidThruOfIdentityCard", "Valid Thru [Identity Card]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "ValidThruOfDrivingLicense", "Valid Thru [Driving License]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeID", "DrivingLicenseTypeID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeName", "Driving License Type", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Height", "Height", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedFromComLocID", "CreatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "LastUpdatedFromComLocID", "LastUpdatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "CreatedFromComLoc", "Created From ComLoc", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LastUpdatedFromComLoc", "Last Updated From ComLoc", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "InternalRemarks", "Internal Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
    End Sub

    Private Sub prvQuery()
        Try
            dtData = BL.Driver.ListDataForMerge()
            grdMain.DataSource = dtData
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSave()
        ToolBar.Focus()

        If Not UI.usForm.frmAskQuestion("Merge all selected driver?") Then Exit Sub

        grdView.ClearColumnsFilter()
        Dim drMark() As DataRow = dtData.Select("Mark=True")
        Dim drPick() As DataRow = dtData.Select("Mark=True AND Pick=True")

        If drMark.Count = 0 Then
            UI.usForm.frmMessageBox("Please mark item first")
            Exit Sub
        ElseIf drMark.Count = 1 Then
            UI.usForm.frmMessageBox("Please mark item more than one")
            Exit Sub
        ElseIf drPick.Count <> 1 Then
            UI.usForm.frmMessageBox("Please mark and pick one item")
            Exit Sub
        End If

        For Each dr As DataRow In drPick
            clsData = New VO.Driver With {
                .ID = dr.Item("ID"),
                .IdentityCardNumber = dr.Item("IdentityCardNumber"),
                .DrivingLicenseNumber = dr.Item("DrivingLicenseNumber"),
                .FullName = dr.Item("FullName"),
                .PlaceOfBirth = dr.Item("PlaceOfBirth"),
                .DateOfBirth = dr.Item("DateOfBirth"),
                .GenderID = dr.Item("GenderID"),
                .BloodTypeID = dr.Item("BloodTypeID"),
                .AddressOfIdentityCard = dr.Item("AddressOfIdentityCard"),
                .AddressOfDrivingLicense = dr.Item("AddressOfDrivingLicense"),
                .ReligionID = dr.Item("ReligionID"),
                .MaritalStatusID = dr.Item("MaritalStatusID"),
                .NationalityID = dr.Item("NationalityID"),
                .OccupationsIDOfIdentityCard = dr.Item("OccupationsIDOfIdentityCard"),
                .OccupationsOthersOfIdentityCard = dr.Item("OccupationsOthersOfIdentityCard"),
                .OccupationsIDOfDrivingLicense = dr.Item("OccupationsIDOfDrivingLicense"),
                .OccupationsOthersOfDrivingLicense = dr.Item("OccupationsOthersOfDrivingLicense"),
                .ValidThruOfIdentityCard = dr.Item("ValidThruOfIdentityCard"),
                .ValidThruOfDrivingLicense = dr.Item("ValidThruOfDrivingLicense"),
                .DrivingLicenseTypeID = dr.Item("DrivingLicenseTypeID"),
                .Height = dr.Item("Height"),
                .IDStatus = dr.Item("IDStatus"),
                .InternalRemarks = dr.Item("InternalRemarks"),
                .Remarks = dr.Item("Remarks"),
                .LastUpdatedFromComLocID = dr.Item("LastUpdatedFromComLocID"),
                .LogBy = UI.usUserApp.UserID
            }
        Next

        drMark = dtData.Select("Mark=True AND Pick=False")
        Dim clsDataAll(drMark.Count - 1) As VO.Driver
        For i As Integer = 0 To drMark.Count - 1
            clsDataAll(i) = New VO.Driver With {
                .ID = drMark(i).Item("ID"),
                .IdentityCardNumber = drMark(i).Item("IdentityCardNumber"),
                .DrivingLicenseNumber = drMark(i).Item("DrivingLicenseNumber"),
                .FullName = drMark(i).Item("FullName"),
                .PlaceOfBirth = drMark(i).Item("PlaceOfBirth"),
                .DateOfBirth = drMark(i).Item("DateOfBirth"),
                .GenderID = drMark(i).Item("GenderID"),
                .BloodTypeID = drMark(i).Item("BloodTypeID"),
                .AddressOfIdentityCard = drMark(i).Item("AddressOfIdentityCard"),
                .AddressOfDrivingLicense = drMark(i).Item("AddressOfDrivingLicense"),
                .ReligionID = drMark(i).Item("ReligionID"),
                .MaritalStatusID = drMark(i).Item("MaritalStatusID"),
                .NationalityID = drMark(i).Item("NationalityID"),
                .OccupationsIDOfIdentityCard = drMark(i).Item("OccupationsIDOfIdentityCard"),
                .OccupationsOthersOfIdentityCard = drMark(i).Item("OccupationsOthersOfIdentityCard"),
                .OccupationsIDOfDrivingLicense = drMark(i).Item("OccupationsIDOfDrivingLicense"),
                .OccupationsOthersOfDrivingLicense = drMark(i).Item("OccupationsOthersOfDrivingLicense"),
                .ValidThruOfIdentityCard = drMark(i).Item("ValidThruOfIdentityCard"),
                .ValidThruOfDrivingLicense = drMark(i).Item("ValidThruOfDrivingLicense"),
                .DrivingLicenseTypeID = drMark(i).Item("DrivingLicenseTypeID"),
                .Height = drMark(i).Item("Height"),
                .IDStatus = VO.Status.Values.InActive,
                .InternalRemarks = drMark(i).Item("InternalRemarks"),
                .Remarks = drMark(i).Item("Remarks"),
                .ReferencesID = clsData.ID,
                .LogBy = UI.usUserApp.UserID
            }
        Next

        Try
            If BL.Driver.MergeData(clsData, clsDataAll) Then
                UI.usForm.frmMessageBox("Merge data success.")
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstDriverMerge_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstDriverMerge_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvQuery()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Save" : prvSave()
            Case "Close" : Me.Close()
            Case "Refresh" : prvQuery()
        End Select
    End Sub

#End Region

End Class