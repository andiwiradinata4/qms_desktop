﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMstRFIDCardSetStatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim SerializableAppearanceObject1 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim SerializableAppearanceObject2 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Me.pnlLeft = New System.Windows.Forms.Panel()
        Me.grdOutstanding = New DevExpress.XtraGrid.GridControl()
        Me.grdOutstandingView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.rpiAutoNumber = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.pnlRight = New System.Windows.Forms.Panel()
        Me.grdValid = New DevExpress.XtraGrid.GridControl()
        Me.grdValidView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.RepositoryItemButtonEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.tlpMain = New System.Windows.Forms.TableLayoutPanel()
        Me.ToolBar = New QMS.usToolBar()
        Me.BarSave = New System.Windows.Forms.ToolBarButton()
        Me.BarClose = New System.Windows.Forms.ToolBarButton()
        Me.pnlLeft.SuspendLayout()
        CType(Me.grdOutstanding, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdOutstandingView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rpiAutoNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlRight.SuspendLayout()
        CType(Me.grdValid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdValidView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tlpMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlLeft
        '
        Me.pnlLeft.Controls.Add(Me.grdOutstanding)
        Me.pnlLeft.Controls.Add(Me.lblInfo)
        Me.pnlLeft.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlLeft.Location = New System.Drawing.Point(2, 2)
        Me.pnlLeft.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlLeft.Name = "pnlLeft"
        Me.pnlLeft.Size = New System.Drawing.Size(531, 613)
        Me.pnlLeft.TabIndex = 0
        '
        'grdOutstanding
        '
        Me.grdOutstanding.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdOutstanding.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdOutstanding.EmbeddedNavigator.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.grdOutstanding.Location = New System.Drawing.Point(0, 36)
        Me.grdOutstanding.MainView = Me.grdOutstandingView
        Me.grdOutstanding.Margin = New System.Windows.Forms.Padding(0)
        Me.grdOutstanding.Name = "grdOutstanding"
        Me.grdOutstanding.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.rpiAutoNumber})
        Me.grdOutstanding.Size = New System.Drawing.Size(531, 577)
        Me.grdOutstanding.TabIndex = 1
        Me.grdOutstanding.UseEmbeddedNavigator = True
        Me.grdOutstanding.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdOutstandingView, Me.GridView1})
        '
        'grdOutstandingView
        '
        Me.grdOutstandingView.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.grdOutstandingView.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.grdOutstandingView.Appearance.EvenRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.EvenRow.Options.UseFont = True
        Me.grdOutstandingView.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.FilterCloseButton.Options.UseFont = True
        Me.grdOutstandingView.Appearance.FilterPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.FilterPanel.Options.UseFont = True
        Me.grdOutstandingView.Appearance.FixedLine.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.FixedLine.Options.UseFont = True
        Me.grdOutstandingView.Appearance.FocusedCell.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.FocusedCell.Options.UseFont = True
        Me.grdOutstandingView.Appearance.FocusedRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.FocusedRow.Options.UseFont = True
        Me.grdOutstandingView.Appearance.FooterPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.FooterPanel.Options.UseFont = True
        Me.grdOutstandingView.Appearance.GroupButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.GroupButton.Options.UseFont = True
        Me.grdOutstandingView.Appearance.GroupFooter.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.GroupFooter.Options.UseFont = True
        Me.grdOutstandingView.Appearance.GroupPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.GroupPanel.Options.UseFont = True
        Me.grdOutstandingView.Appearance.GroupRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.GroupRow.Options.UseFont = True
        Me.grdOutstandingView.Appearance.HeaderPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.HeaderPanel.Options.UseFont = True
        Me.grdOutstandingView.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.HideSelectionRow.Options.UseFont = True
        Me.grdOutstandingView.Appearance.HorzLine.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.HorzLine.Options.UseFont = True
        Me.grdOutstandingView.Appearance.OddRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.OddRow.Options.UseFont = True
        Me.grdOutstandingView.Appearance.Preview.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.Preview.Options.UseFont = True
        Me.grdOutstandingView.Appearance.Row.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.Row.Options.UseFont = True
        Me.grdOutstandingView.Appearance.RowSeparator.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.RowSeparator.Options.UseFont = True
        Me.grdOutstandingView.Appearance.SelectedRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.SelectedRow.Options.UseFont = True
        Me.grdOutstandingView.Appearance.TopNewRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.TopNewRow.Options.UseFont = True
        Me.grdOutstandingView.Appearance.VertLine.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.VertLine.Options.UseFont = True
        Me.grdOutstandingView.Appearance.ViewCaption.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdOutstandingView.Appearance.ViewCaption.Options.UseFont = True
        Me.grdOutstandingView.GridControl = Me.grdOutstanding
        Me.grdOutstandingView.Name = "grdOutstandingView"
        Me.grdOutstandingView.OptionsCustomization.AllowColumnMoving = False
        Me.grdOutstandingView.OptionsCustomization.AllowGroup = False
        Me.grdOutstandingView.OptionsView.ColumnAutoWidth = False
        Me.grdOutstandingView.OptionsView.ShowAutoFilterRow = True
        Me.grdOutstandingView.OptionsView.ShowGroupPanel = False
        '
        'rpiAutoNumber
        '
        Me.rpiAutoNumber.AutoHeight = False
        Me.rpiAutoNumber.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Up, "", -1, True, True, True, DevExpress.XtraEditors.ImageLocation.MiddleCenter, Nothing, New DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), SerializableAppearanceObject1, "", Nothing, Nothing, True), New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Down)})
        Me.rpiAutoNumber.Name = "rpiAutoNumber"
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.grdOutstanding
        Me.GridView1.Name = "GridView1"
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 0)
        Me.lblInfo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(531, 36)
        Me.lblInfo.TabIndex = 0
        Me.lblInfo.Text = "« Kartu yang belum di Scan"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlRight
        '
        Me.pnlRight.Controls.Add(Me.grdValid)
        Me.pnlRight.Controls.Add(Me.Label2)
        Me.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlRight.Location = New System.Drawing.Point(535, 2)
        Me.pnlRight.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlRight.Name = "pnlRight"
        Me.pnlRight.Size = New System.Drawing.Size(531, 613)
        Me.pnlRight.TabIndex = 2
        '
        'grdValid
        '
        Me.grdValid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdValid.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdValid.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdValid.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdValid.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdValid.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdValid.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdValid.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdValid.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdValid.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdValid.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdValid.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdValid.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdValid.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdValid.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdValid.EmbeddedNavigator.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.grdValid.Location = New System.Drawing.Point(0, 36)
        Me.grdValid.MainView = Me.grdValidView
        Me.grdValid.Margin = New System.Windows.Forms.Padding(0)
        Me.grdValid.Name = "grdValid"
        Me.grdValid.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemButtonEdit1})
        Me.grdValid.Size = New System.Drawing.Size(531, 577)
        Me.grdValid.TabIndex = 1
        Me.grdValid.UseEmbeddedNavigator = True
        Me.grdValid.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdValidView})
        '
        'grdValidView
        '
        Me.grdValidView.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.grdValidView.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.grdValidView.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.grdValidView.Appearance.DetailTip.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.DetailTip.Options.UseFont = True
        Me.grdValidView.Appearance.Empty.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.Empty.Options.UseFont = True
        Me.grdValidView.Appearance.EvenRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.EvenRow.Options.UseFont = True
        Me.grdValidView.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.FilterCloseButton.Options.UseFont = True
        Me.grdValidView.Appearance.FilterPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.FilterPanel.Options.UseFont = True
        Me.grdValidView.Appearance.FixedLine.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.FixedLine.Options.UseFont = True
        Me.grdValidView.Appearance.FocusedCell.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.FocusedCell.Options.UseFont = True
        Me.grdValidView.Appearance.FocusedRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.FocusedRow.Options.UseFont = True
        Me.grdValidView.Appearance.FooterPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.FooterPanel.Options.UseFont = True
        Me.grdValidView.Appearance.GroupButton.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.GroupButton.Options.UseFont = True
        Me.grdValidView.Appearance.GroupFooter.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.GroupFooter.Options.UseFont = True
        Me.grdValidView.Appearance.GroupPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.GroupPanel.Options.UseFont = True
        Me.grdValidView.Appearance.GroupRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.GroupRow.Options.UseFont = True
        Me.grdValidView.Appearance.HeaderPanel.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.HeaderPanel.Options.UseFont = True
        Me.grdValidView.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.HideSelectionRow.Options.UseFont = True
        Me.grdValidView.Appearance.HorzLine.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.HorzLine.Options.UseFont = True
        Me.grdValidView.Appearance.OddRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.OddRow.Options.UseFont = True
        Me.grdValidView.Appearance.Preview.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.Preview.Options.UseFont = True
        Me.grdValidView.Appearance.Row.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.Row.Options.UseFont = True
        Me.grdValidView.Appearance.RowSeparator.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.RowSeparator.Options.UseFont = True
        Me.grdValidView.Appearance.SelectedRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.SelectedRow.Options.UseFont = True
        Me.grdValidView.Appearance.TopNewRow.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.TopNewRow.Options.UseFont = True
        Me.grdValidView.Appearance.VertLine.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.VertLine.Options.UseFont = True
        Me.grdValidView.Appearance.ViewCaption.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.grdValidView.Appearance.ViewCaption.Options.UseFont = True
        Me.grdValidView.GridControl = Me.grdValid
        Me.grdValidView.Name = "grdValidView"
        Me.grdValidView.OptionsCustomization.AllowColumnMoving = False
        Me.grdValidView.OptionsCustomization.AllowGroup = False
        Me.grdValidView.OptionsView.ColumnAutoWidth = False
        Me.grdValidView.OptionsView.ShowAutoFilterRow = True
        Me.grdValidView.OptionsView.ShowGroupPanel = False
        '
        'RepositoryItemButtonEdit1
        '
        Me.RepositoryItemButtonEdit1.AutoHeight = False
        Me.RepositoryItemButtonEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Up, "", -1, True, True, True, DevExpress.XtraEditors.ImageLocation.MiddleCenter, Nothing, New DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), SerializableAppearanceObject2, "", Nothing, Nothing, True), New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Down)})
        Me.RepositoryItemButtonEdit1.Name = "RepositoryItemButtonEdit1"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.CadetBlue
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(531, 36)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "« Kartu yang telah di Scan"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GridView2
        '
        Me.GridView2.Name = "GridView2"
        '
        'tlpMain
        '
        Me.tlpMain.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset
        Me.tlpMain.ColumnCount = 2
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.tlpMain.Controls.Add(Me.pnlRight, 1, 0)
        Me.tlpMain.Controls.Add(Me.pnlLeft, 0, 0)
        Me.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpMain.Location = New System.Drawing.Point(0, 28)
        Me.tlpMain.Margin = New System.Windows.Forms.Padding(0)
        Me.tlpMain.Name = "tlpMain"
        Me.tlpMain.RowCount = 1
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMain.Size = New System.Drawing.Size(1068, 617)
        Me.tlpMain.TabIndex = 4
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarSave, Me.BarClose})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(1068, 28)
        Me.ToolBar.TabIndex = 0
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarSave
        '
        Me.BarSave.Name = "BarSave"
        Me.BarSave.Tag = "Save"
        Me.BarSave.Text = "Simpan"
        '
        'BarClose
        '
        Me.BarClose.Name = "BarClose"
        Me.BarClose.Tag = "Close"
        Me.BarClose.Text = "Tutup"
        '
        'frmMstRFIDCardSetStatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1068, 645)
        Me.Controls.Add(Me.tlpMain)
        Me.Controls.Add(Me.ToolBar)
        Me.Font = New System.Drawing.Font("Tahoma", 13.0!)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmMstRFIDCardSetStatus"
        Me.Text = "Set Status"
        Me.pnlLeft.ResumeLayout(False)
        CType(Me.grdOutstanding, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdOutstandingView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rpiAutoNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlRight.ResumeLayout(False)
        CType(Me.grdValid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdValidView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tlpMain.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlLeft As System.Windows.Forms.Panel
    Friend WithEvents grdOutstanding As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdOutstandingView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents rpiAutoNumber As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents pnlRight As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents tlpMain As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents grdValid As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdValidView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents RepositoryItemButtonEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents ToolBar As QMS.usToolBar
    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSave As System.Windows.Forms.ToolBarButton
End Class
