﻿Public Class frmMstQueueFlowItem

#Region "Property Handle"

    Private frmParent As frmMstQueueFlowDet
    Property pubTableParent As DataTable
    Property pubIsSave As Boolean = False
    Private Const cAdd = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Add,1,Close")
    End Sub

    Private Sub prvAdd()
        If txtItemCode.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please choose item first")
            txtItemCode.Focus()
            Exit Sub
        End If

        Dim drExists() As DataRow = pubTableParent.Select("ItemCode='" & txtItemCode.Text.Trim & "'")
        If drExists.Count > 0 Then
            UI.usForm.frmMessageBox("Item code (" & txtItemCode.Text.Trim & ") already exists")
            txtItemCode.Focus()
            Exit Sub
        End If

        Dim drNew As DataRow
        drNew = pubTableParent.NewRow
        With drNew
            .BeginEdit()
            .Item("ItemCode") = txtItemCode.Text.Trim
            .Item("ItemName") = txtItemName.Text.Trim
            .Item("QueueFlowID") = ""
            .EndEdit()
        End With
        pubTableParent.Rows.Add(drNew)
        pubTableParent.AcceptChanges()
        txtItemCode.Text = ""
        txtItemName.Text = ""
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstQueueFlowItem_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstQueueFlowItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvSetIcon()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Add" : prvAdd()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnItem_Click(sender As Object, e As EventArgs) Handles btnItem.Click
        Dim frmDetail As New frmMstItem
        With frmDetail
            .pubIsLookUp = True
            .pubLUItemCode = txtItemCode.Text.Trim
            .pubGetAllItem = True
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                txtItemCode.Text = .pubLUItemCode
                txtItemName.Text = .pubLUDataRow.Item("ItemName")
            End If
        End With
    End Sub

#End Region

End Class