Public Class frmMstStatus

#Region "Property Handle"

    Public pubLUdtRow() As DataRow
    Public pubIsLookUp As Boolean = False
    Public pubIsLookUpGet As Boolean = False
    Public pubLUTableParent As DataTable

    Private dtData As New DataTable
    Private clsData As VO.Status
    Private intPos As Integer
    Private Const _
       cGet = 0, cSep1 = 1, cNew = 2, cDetail = 3, cDelete = 4, cModule = 5, cSep2 = 6, cRefresh = 7, cClose = 8

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Get,2,New,3,Detail,4,Delete,5,Approved,7,Refresh,8,Close")
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "Pick", "Pick", 100, UI.usDefGrid.gBoolean, pubIsLookUp, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsActive", "IsActive", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Visible = pubIsLookUp
            .Item(cSep1).Visible = pubIsLookUp
            .Item(cGet).Enabled = bolEnable
            .Item(cDetail).Enabled = bolEnable
            .Item(cDelete).Enabled = bolEnable
            .Item(cModule).Visible = Not pubIsLookUp
            .Item(cModule).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            dtData = BL.Status.ListData
            grdMain.DataSource = dtData
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("Description")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "Description", strSearch)
        End With
    End Sub

    Private Sub prvGet()
        ToolBar.Focus()
        Dim drPick() As DataRow = dtData.Select("Pick=true")

        If drPick.Count = 0 Then
            UI.usForm.frmMessageBox("Please pick item first")
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Get all selected item?") Then Exit Sub

        For Each drRow As DataRow In drPick
            If drRow.Item("IsActive") = 0 Then
                UI.usForm.frmMessageBox("Cannot choose this data because data is not active")
                Exit Sub
            End If
            For Each drParent As DataRow In pubLUTableParent.Rows
                With drParent
                    If .Item("IDStatus") = drRow.Item("ID") Then
                        UI.usForm.frmMessageBox("Status " & drRow.Item("Description") & " already exist")
                        Exit Sub
                    End If
                End With
            Next
        Next
        pubLUdtRow = drPick
        pubIsLookUpGet = True
        Me.Close()
    End Sub

    Private Sub prvSetLookUp()
        If pubIsLookUp Then
            Me.Text += " [look up] "
        End If
    End Sub

    Private Function prvGetData() As VO.Status
        Dim returnValue As New VO.Status
        returnValue.ID = grdView.GetRowCellValue(intPos, "ID")
        returnValue.Description = grdView.GetRowCellValue(intPos, "Description")
        returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnValue.IsActive = grdView.GetRowCellValue(intPos, "IsActive")
        returnValue.CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvNew()
        Dim frmDetail As New frmMstStatusDet
        With frmDetail
            .pubIsNew = True
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvDetail()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New frmMstStatusDet
        With frmDetail
            .pubIsNew = False
            .pubID = grdView.GetRowCellValue(intPos, "ID")
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then pubRefresh()
        End With
    End Sub

    Private Sub prvDelete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        If Not UI.usForm.frmAskQuestion("Delete Description " & grdView.GetRowCellValue(intPos, "Description") & "?") Then Exit Sub
        Try
            clsData = prvGetData()
            clsData.LogBy = UI.usUserApp.UserID
            BL.Status.DeleteData(clsData)
            UI.usForm.frmMessageBox("Delete data success.")
            pubRefresh(grdView.GetRowCellValue(intPos, "Description"))
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvModule()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New frmMstStatusModule
        With frmDetail
            .pubClsData = prvGetData()
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cNew).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSTATUS", "ADD")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSTATUS", "DELETE")
            If Not pubIsLookUp Then .Item(cModule).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTMODULES", "MAP")
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstStatus_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstStatus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvSetIcon()
        prvSetGrid()
        prvQuery()
        prvUserAccess()
        prvSetLookUp()

        If Not pubIsLookUp Then Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text
            Case "Get" : prvGet()
            Case "New" : prvNew()
            Case "Detail" : prvDetail()
            Case "Delete" : prvDelete()
            Case "Module" : prvModule()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim strIsActive As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("IsActive"))
            If strIsActive = "Unchecked" And e.Appearance.BackColor <> Color.Salmon And e.Appearance.BackColor2 <> Color.SeaShell Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

#End Region

End Class


