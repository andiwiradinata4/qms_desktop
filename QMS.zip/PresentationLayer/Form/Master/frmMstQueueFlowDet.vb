Public Class frmMstQueueFlowDet

#Region "Property Handle"

    Private frmParent As frmMstQueueFlow
    Private clsData As VO.QueueFlow
    Private dtStation As New DataTable, dtItem As New DataTable
    Property pubID As String
    Property pubIsNew As Boolean = False
    Property pubIsSave As Boolean = False
    Private Const _
        cSave = 0, cClose = 1, _
        cAddStation = 0, cDeleteStation = 1, cSep1Station = 2, cCountStation = 3, _
        cAddItem = 0, cDeleteItem = 1
    Private intPos As Integer

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        '# Station
        UI.usForm.SetGrid(grdStationView, "ID", "ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdStationView, "QueueFlowID", "QueueFlowID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdStationView, "Idx", "No", 80, UI.usDefGrid.gIntNum, True, False)
        UI.usForm.SetGrid(grdStationView, "StationID", "StationID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdStationView, "StationName", "StationName", 300, UI.usDefGrid.gString)
        grdStationView.Columns("Idx").SortOrder = DevExpress.Data.ColumnSortOrder.Ascending
        grdStationView.Columns("Idx").ColumnEdit = rpiAutoNumber

        '# Item
        UI.usForm.SetGrid(grdItemView, "ItemCode", "ItemCode", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdItemView, "ItemName", "ItemName", 300, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdItemView, "QueueFlowID", "QueueFlowID", 100, UI.usDefGrid.gString, False)
    End Sub

    Private Sub prvSetTitleForm()
        If pubIsNew Then
            Me.Text += " [new] "
        Else
            Me.Text += " [edit] "
        End If
    End Sub

    Private Sub prvFillComboType()
        Dim dtData As New DataTable
        Try
            dtData = BL.QueueFlow.ListDataType()
            UI.usForm.FillComboBox(cboType, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Fill Combo Type")
        End Try
    End Sub

    Private Sub prvFillComboStatus()
        Dim dtData As New DataTable
        Try
            dtData = BL.Status.ListDataByModuleID(VO.Modules.Values.QueueFlow)
            UI.usForm.FillComboBox(cboStatus, dtData, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvFillCombo()
        prvFillComboType()
        prvFillComboStatus()
    End Sub

    Private Sub prvFillForm()
        Try
            prvFillCombo()
            If pubIsNew Then
                prvClear()
            Else
                clsData = New VO.QueueFlow
                clsData = BL.QueueFlow.GetDetail(pubID)
                txtID.Text = clsData.ID
                txtName.Text = clsData.Name
                cboType.SelectedValue = clsData.Type
                chkIsDefault.Checked = clsData.IsDefault
                cboStatus.SelectedValue = clsData.IDStatus
                txtRemarks.Text = clsData.Remarks
                ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
                ToolStripLogBy.Text = "Last Log : " & clsData.LogBy
                ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)

                cboStatus.Enabled = IIf(clsData.IDStatus = VO.Status.Values.InActive, True, False)
                ToolBarItem.Enabled = Not chkIsDefault.Checked
            End If
            prvQueryStation()
            prvQueryItem()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSave()
        If txtName.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Name not allow blank")
            txtName.Focus()
            Exit Sub
        ElseIf cboType.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose type first")
            cboType.Focus()
            Exit Sub
        ElseIf grdStationView.RowCount = 0 Then
            UI.usForm.frmMessageBox("Please input station first")
            tcDetail.SelectedIndex = 0
            grdStationView.Focus()
            Exit Sub
        ElseIf chkIsDefault.Checked = False And grdItemView.RowCount = 0 Then
            UI.usForm.frmMessageBox("Please input item if IsDefault is unchecked")
            tcDetail.SelectedIndex = 1
            grdItemView.Focus()
            Exit Sub
        End If

        prvCountStation()
        clsData = New VO.QueueFlow
        clsData.ID = txtID.Text.Trim
        clsData.Name = txtName.Text.Trim
        clsData.Type = cboType.SelectedValue
        clsData.IsDefault = chkIsDefault.Checked
        clsData.IDStatus = cboStatus.SelectedValue
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID

        '# Station
        Dim clsStation As VO.QueueFlowStation
        Dim clsStationAll(grdStationView.RowCount - 1) As VO.QueueFlowStation
        With grdStationView
            For i As Integer = 0 To .RowCount - 1
                clsStation = New VO.QueueFlowStation
                clsStation.QueueFlowID = txtID.Text.Trim
                clsStation.Idx = .GetRowCellValue(i, "Idx")
                clsStation.StationID = .GetRowCellValue(i, "StationID")
                clsStationAll(i) = clsStation
            Next
        End With

        '# Item
        Dim clsItem As VO.QueueFlowItem
        Dim clsItemAll(grdItemView.RowCount - 1) As VO.QueueFlowItem
        With grdItemView
            For i As Integer = 0 To .RowCount - 1
                clsItem = New VO.QueueFlowItem
                clsItem.QueueFlowID = txtID.Text.Trim
                clsItem.ItemCode = .GetRowCellValue(i, "ItemCode")
                clsItemAll(i) = clsItem
            Next
        End With

        Try
            BL.QueueFlow.SaveData(pubIsNew, clsData, clsStationAll, clsItemAll)
            If pubIsNew Then
                UI.usForm.frmMessageBox("Save data success.")
                frmParent.pubRefresh(clsData.ID)
                prvClear()
                prvQueryStation()
                prvQueryItem()
            Else
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        txtID.Text = ""
        txtName.Text = ""
        cboType.SelectedIndex = -1
        chkIsDefault.Checked = False
        cboStatus.SelectedValue = VO.Status.Values.Active
        txtRemarks.Text = ""
        ToolStripLogInc.Text = "Log Inc : -"
        ToolStripLogBy.Text = "Last Log : -"
        ToolStripLogDate.Text = Format(Now, UI.usDefCons.DateFull)
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cSave).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTQUEUEFLOW", IIf(pubIsNew, "ADD", "EDIT"))
        End With
    End Sub

#Region "Station"

    Private Sub prvSetButtonStation()
        Dim bolEnable As Boolean = IIf(grdStationView.RowCount > 0, True, False)
        With ToolBarStation.Buttons
            .Item(cDeleteStation).Enabled = bolEnable
            .Item(cCountStation).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQueryStation()
        Try
            dtStation = BL.QueueFlow.ListDataStation(txtID.Text.Trim)
            grdStation.DataSource = dtStation
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButtonStation()
        End Try
    End Sub

    Private Sub prvAddStation()
        Dim frmDetail As New frmMstStation
        With frmDetail
            .pubIsLookGetMulti = True
            .pubIsLookUp = True
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                Dim drStation As DataRow
                For Each dr As DataRow In .pubLUdtRowMulti
                    drStation = dtStation.NewRow
                    With drStation
                        .BeginEdit()
                        .Item("ID") = ""
                        .Item("QueueFlowID") = txtID.Text.Trim
                        .Item("Idx") = dtStation.Rows.Count + 1
                        .Item("StationID") = dr.Item("ID")
                        .Item("StationName") = dr.Item("Description")
                        .EndEdit()
                    End With
                    dtStation.Rows.Add(drStation)
                Next
                dtStation.AcceptChanges()
            End If
            prvSetButtonStation()
        End With
    End Sub

    Private Sub prvDeleteStation()
        intPos = grdStationView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        For Each drItem As DataRow In dtStation.Rows
            With drItem
                If .Item("QueueFlowID") = grdStationView.GetRowCellValue(intPos, "QueueFlowID") _
                    And .Item("Idx") = grdStationView.GetRowCellValue(intPos, "Idx") _
                    And .Item("StationID") = grdStationView.GetRowCellValue(intPos, "StationID") Then
                    drItem.Delete()
                    Exit For
                End If
            End With
        Next
        dtStation.AcceptChanges()
        prvSetButtonStation()
    End Sub

    Private Sub prvUpRow()
        With grdStationView
            intPos = .FocusedRowHandle
            If intPos > 0 Then
                .SetRowCellValue(intPos, "Idx", .GetRowCellValue(intPos, "Idx") - 1)
                .SetRowCellValue(intPos - 1, "Idx", .GetRowCellValue(intPos - 1, "Idx") + 1)
            End If
        End With
    End Sub

    Private Sub prvDownRow()
        With grdStationView
            intPos = .FocusedRowHandle
            If intPos < .RowCount - 1 Then
                .SetRowCellValue(intPos, "Idx", .GetRowCellValue(intPos, "Idx") + 1)
                .SetRowCellValue(intPos + 1, "Idx", .GetRowCellValue(intPos + 1, "Idx") - 1)
            End If
        End With
    End Sub

    Private Sub prvCountStation()
        With grdStationView
            For i As Integer = 0 To .RowCount - 1
                .SetRowCellValue(i, "Idx", i + 1)
            Next
        End With
    End Sub

#End Region

#Region "Item"

    Private Sub prvSetButtonItem()
        Dim bolEnable As Boolean = IIf(grdItemView.RowCount > 0, True, False)
        With ToolBarItem.Buttons
            .Item(cDeleteItem).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQueryItem()
        Try
            dtItem = BL.QueueFlow.ListDataItem(txtID.Text.Trim)
            grdItem.DataSource = dtItem
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButtonItem()
        End Try
    End Sub

    Private Sub prvAddItem()
        Dim frmDetail As New frmMstQueueFlowItem
        With frmDetail
            .pubTableParent = dtItem
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            prvSetButtonItem()
        End With
    End Sub

    Private Sub prvDeleteItem()
        intPos = grdItemView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        For Each drItem As DataRow In dtItem.Rows
            With drItem
                If .Item("ItemCode") = grdItemView.GetRowCellValue(intPos, "ItemCode") Then
                    drItem.Delete()
                    Exit For
                End If
            End With
        Next
        dtItem.AcceptChanges()
        prvSetButtonItem()
    End Sub

#End Region

#End Region
 
#Region "Form Handle"

    Private Sub frmMstQueueFlowDet_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F1 Then
            tcDetail.SelectedIndex = 0
        ElseIf e.KeyCode = Keys.F2 Then
            tcDetail.SelectedIndex = 1
        End If
    End Sub

    Private Sub frmMstQueueFlowDet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        ToolBarStation.SetIcon(Me)
        ToolBarItem.SetIcon(Me)
        prvSetGrid()
        prvSetTitleForm()
        prvFillForm()
        prvUserAccess()
        AddHandler chkIsDefault.CheckedChanged, AddressOf chkIsDefault_CheckedChanged
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

    Private Sub ToolBarStation_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarStation.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Add" : prvAddStation()
            Case "Delete" : prvDeleteStation()
            Case "Count" : prvCountStation()
        End Select
    End Sub

    Private Sub ToolBarItem_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarItem.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Add" : prvAddItem()
            Case "Delete" : prvDeleteItem()
        End Select
    End Sub

    Private Sub rpiAutoNumber_ButtonClick(sender As Object, e As DevExpress.XtraEditors.Controls.ButtonPressedEventArgs) Handles rpiAutoNumber.ButtonClick
        Select Case e.Button.Index
            Case 0 : prvUpRow()
            Case 1 : prvDownRow()
        End Select
    End Sub

    Private Sub rpiAutoNumber_KeyPress(sender As Object, e As KeyPressEventArgs) Handles rpiAutoNumber.KeyPress
        If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub chkIsDefault_CheckedChanged(sender As Object, e As EventArgs)
        If dtItem.Rows.Count > 0 And chkIsDefault.Checked Then
            If UI.usForm.frmAskQuestion("Delete all selected item?") Then
                dtItem.Clear()
                dtItem.AcceptChanges()
            Else
                chkIsDefault.Checked = False
            End If
        End If
        ToolBarItem.Enabled = Not chkIsDefault.Checked
    End Sub

#End Region

End Class


