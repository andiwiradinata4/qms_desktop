Public Class frmMstRFIDCard

#Region "Property Handle"

    Dim intPos As Integer = 0

    Private Const _
       cNew = 0, cDetail = 1, cDelete = 2, cSetStatus = 3, cSep1 = 4, cRefresh = 5, cClose = 6

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "CompanyID", "Company ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "LocationID", "Location ID", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "RFID", "RFID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "InitialCode", "Initial Code", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cDetail).Enabled = bolEnable
            .Item(cDelete).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            grdMain.DataSource = BL.RFIDCard.ListData
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
        prvSetButton()
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Function prvGetData() As VO.RFIDCard
        Dim returnValue As New VO.RFIDCard
        returnValue.CompanyID = grdView.GetRowCellValue(intPos, "CompanyID")
        returnValue.LocationID = grdView.GetRowCellValue(intPos, "LocationID")
        returnValue.ID = grdView.GetRowCellValue(intPos, "ID")
        returnValue.RFID = grdView.GetRowCellValue(intPos, "RFID")
        returnValue.InitialCode = grdView.GetRowCellValue(intPos, "InitialCode")
        returnValue.IDStatus = grdView.GetRowCellValue(intPos, "IDStatus")
        returnValue.StatusInfo = grdView.GetRowCellValue(intPos, "StatusInfo")
        returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnValue.CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvNew()
        Dim frmDetail As New frmMstRFIDCardDet
        With frmDetail
            .pubIsNew = True
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvDetail()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New frmMstRFIDCardDet
        With frmDetail
            .pubIsNew = False
            .pubID = grdView.GetRowCellValue(intPos, "ID")
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then pubRefresh()
        End With
    End Sub

    Private Sub prvDelete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim clsData As VO.RFIDCard = prvGetData()

        If clsData.IDStatus = VO.Status.Values.InActive Then
            UI.usForm.frmMessageBox("Data already deleted")
            Exit Sub
        End If

        Dim frmDetail As New usFormRemarks
        With frmDetail
            .pubTitle = "Delete ID: " & clsData.ID
            .pubInfo = "Delete RFID"
            .pubLabel = "Remarks"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                clsData.Remarks = .pubValue.Trim
                clsData.LogBy = UI.usUserApp.UserID
            Else : Exit Sub
            End If
        End With

        Try
            BL.RFIDCard.DeleteData(clsData)
            UI.usForm.frmMessageBox("Delete data success.")
            pubRefresh(grdView.GetRowCellValue(intPos, "ID"))
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSetStatus()
        Dim frmDetail As New frmMstRFIDCardSetStatus
        With frmDetail
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cNew).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTRFID", "ADD")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTRFID", "DELETE")
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstRFIDCard_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstRFIDCard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvQuery()
        prvUserAccess()

        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "New" Then
            prvNew()
        ElseIf e.Button.Text = "Refresh" Then
            pubRefresh()
        ElseIf grdView.FocusedRowHandle >= 0 Then
            Select Case e.Button.Text
                Case "Detail" : prvDetail()
                Case "Delete" : prvDelete()
                Case "Set Status" : prvSetStatus()
            End Select
        End If
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim strResult As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("StatusInfo"))
            If strResult = "IN-ACTIVE" And e.Appearance.BackColor <> Color.Salmon Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

#End Region

End Class


