﻿Public Class frmMstRFIDCardSetStatus

#Region "Property Handle"

    Private WithEvents tmrWeighBridge As New Timer
    Dim dtOutstanding As New DataTable, dtValid As New DataTable
    Private bolSuccessSettingSerialPort As Boolean = False
    Private intCount As Integer = 0
    Private frmParent As frmMstRFIDCard
    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetButton()
        Dim bolEnabled As Boolean = IIf(dtOutstanding.Rows.Count = 0, False, True)
        With ToolBar
            .Buttons(cSave).Enabled = bolEnabled
        End With
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdOutstandingView, "Pick", "Pilih", 150, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdOutstandingView, "ID", "ID", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "RFID", "RFID", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdOutstandingView, "Remarks", "Keterangan", 150, UI.usDefGrid.gString, True, False)

        UI.usForm.SetGrid(grdValidView, "ID", "ID", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdValidView, "RFID", "RFID", 150, UI.usDefGrid.gString)
    End Sub

    Private Sub prvQuery()
        Try
            '# Outstanding
            dtOutstanding = BL.RFIDCard.ListData(VO.Status.Values.Active)
            grdOutstanding.DataSource = dtOutstanding

            '# Valid -> Get Dummy / Just Create Table Structure
            dtValid = BL.RFIDCard.ListData(VO.Status.Values.Blacklist)
            grdValid.DataSource = dtValid
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
        End Try
    End Sub

    Private Sub prvMoveValidData(ByVal strRFID As String)
        Dim bolExists As Boolean = False
        For Each drOutstanding As DataRow In dtOutstanding.Rows
            If drOutstanding.Item("RFID") = strRFID.Trim Then
                '# Adding to table Valid
                Dim drValid As DataRow = dtValid.NewRow
                drValid.BeginEdit()
                drValid.Item("ID") = drOutstanding.Item("ID")
                drValid.Item("RFID") = drOutstanding.Item("RFID")
                drValid.EndEdit()
                dtValid.Rows.Add(drValid)
                dtValid.AcceptChanges()

                '# Delete row on table Outstanding
                drOutstanding.Delete()
                dtOutstanding.AcceptChanges()
                bolExists = True
                Exit For
            End If
        Next

        prvSetButton()

        If Not bolExists Then UI.usForm.frmMessageBox("RFID : " & strRFID & " tidak terdapat di list kartu yang belum di Scan")
    End Sub

    Public Sub prvSave()
        ToolBar.Focus()
        Dim drPick() As DataRow = dtOutstanding.Select("Pick=True")
        If drPick.Count = 0 Then Exit Sub

        If Not UI.usForm.frmAskQuestion("Simpan data?") Then Exit Sub

        Dim clsData As New VO.RFIDCard
        Dim clsDataAll(drPick.Count - 1) As VO.RFIDCard
        Dim bolError As Boolean = False
        For i As Integer = 0 To drPick.Count - 1
            If drPick(i).Item("Remarks") = "" Then
                UI.usForm.frmMessageBox("Kolom keterangan pada setiap RFID yang dicentang harus diisi")
                bolError = True
                Exit For
            End If
        Next

        If bolError Then Exit Sub

        For i As Integer = 0 To drPick.Count - 1
            clsData = New VO.RFIDCard
            clsData.ID = drPick(i).Item("ID")
            clsData.RFID = drPick(i).Item("RFID")
            clsData.Remarks = UCase(drPick(i).Item("Remarks"))
            clsData.LogBy = UI.usUserApp.UserID
            clsDataAll(i) = clsData
        Next

        Try
            BL.RFIDCard.DeleteData(clsDataAll)
            UI.usForm.frmMessageBox("Set data berhasil.")
            frmParent.pubRefresh()
            Me.Close()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Save")
        End Try
    End Sub

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort1.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort1.IsOpen Then
                UI.usForm.usSerialPort1.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimer()
    End Sub

    Public Sub prvStartTimer()
        tmrWeighBridge.Enabled = True
        tmrWeighBridge.Interval = 1000
        tmrWeighBridge.Start()
    End Sub

    Public Sub prvStopTimer()
        tmrWeighBridge.Stop()
    End Sub

    Private Sub prvReadCard()
        Try

            If VO.DefaultServer.IsLinkRFIDDevice1 Then
                If Not UI.usForm.usSerialPort1.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort1 = UI.usForm.usSerialPort1.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort1.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Trim

            If VO.DefaultServer.IsLinkRFIDDevice1 Then VO.DefaultServer.RFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1.Substring(1, VO.DefaultServer.RFIDValueCOMPort1.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort1.Trim = VO.DefaultServer.PrevRFIDValueCOMPort1.Trim And intCount <= 5 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort1 = VO.DefaultServer.RFIDValueCOMPort1
            prvMoveValidData(VO.DefaultServer.RFIDValueCOMPort1)
            intCount = 0
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstRFIDCardSetStatus_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        If UI.usForm.usSerialPort1.IsOpen Then
            VO.DefaultServer.RFIDValueCOMPort1 = ""
            tmrWeighBridge.Dispose()
            UI.usForm.usSerialPort1.Dispose()
        End If
    End Sub

    Private Sub frmMstRFIDCardSetStatus_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F10 And VO.DefaultServer.IsLinkRFIDDevice2 = False Then
            Dim frmDetail As New frmSysTestInputRFID
            With frmDetail
                .pubPorts = VO.SubStation.Ports.COMPort1
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
            End With
        End If
    End Sub

    Private Sub frmMstRFIDCardSetStatus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvQuery()
        Me.WindowState = FormWindowState.Maximized

        If VO.DefaultServer.IsLinkRFIDDevice1 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort1, VO.DefaultServer.COMPort1)
            If bolSuccessSettingSerialPort = False Then MsgBox("False setting serial port")
            prvStartReadRFID()
        End If
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Simpan" : prvSave()
            Case "Tutup" : Me.Close()
        End Select
    End Sub

    Private Sub tmrWeighBridge_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrWeighBridge.Tick
        prvReadCard()
    End Sub

    Private Sub grdOutstandingView_CellValueChanged(sender As Object, e As DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs) Handles grdOutstandingView.CellValueChanged
        If e.Column.Name = "Pick" Then
            prvSetButton()
        End If
    End Sub

#End Region

End Class