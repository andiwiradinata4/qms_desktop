﻿Public Class frmMstSubStationConfigurationRFIDReader

#Region "Property Handle"

    Private frmParent As frmMstSubStation
    Private clsData As VO.SubStation
    Property pubID As Integer
    Property pubIsSave As Boolean = False
    Private Const cSave = 0, cClose = 1

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Save,1,Close")
    End Sub

    Private Sub prvFillForm()
        Try
            clsData = New VO.SubStation
            clsData = BL.SubStation.GetDetail(pubID)
            txtComputerName.Text = clsData.ComputerName
            txtInitial.Text = clsData.InitialID
            txtCOMPort1.Text = clsData.COMPort1
            txtCOMPort2.Text = clsData.COMPort2
            txtBaudRate.Value = clsData.BaudRate
            txtDataBits.Value = clsData.DataBits
            cboComParity.Text = clsData.Comparity
            cboComStopBits.Text = clsData.ComStopBits
            ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
            ToolStripLogBy.Text = "Last Log : " & clsData.LogBy
            ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSave()
        If txtComputerName.Text = "" Then
            UI.usForm.frmMessageBox("Please fill Computer Name first")
            txtComputerName.Focus()
            Exit Sub
        ElseIf txtCOMPort1.Text = "" Then
            UI.usForm.frmMessageBox("Please fill COM Port 1 first")
            txtCOMPort1.Focus()
            Exit Sub
        ElseIf txtCOMPort2.Text = "" Then
            UI.usForm.frmMessageBox("Please fill COM Port 2 first")
            txtCOMPort2.Focus()
            Exit Sub
        ElseIf txtInitial.Text = "" Then
            UI.usForm.frmMessageBox("Please fill Initial first")
            txtInitial.Focus()
            Exit Sub
        ElseIf txtBaudRate.Value <= 0 Then
            UI.usForm.frmMessageBox("Baud Rate must more than 0")
            txtBaudRate.Focus()
            Exit Sub
        ElseIf txtDataBits.Value <= 0 Then
            UI.usForm.frmMessageBox("Data Bits must more than 0")
            txtDataBits.Focus()
            Exit Sub
        ElseIf cboComParity.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please choose Parity first")
            cboComParity.Focus()
            Exit Sub
        ElseIf cboComStopBits.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please choose Stop Bits first")
            cboComStopBits.Focus()
            Exit Sub
        End If

        clsData = New VO.SubStation
        clsData.ID = pubID
        clsData.ComputerName = txtComputerName.Text.Trim
        clsData.InitialID = txtInitial.Text
        clsData.COMPort1 = txtCOMPort1.Text
        clsData.COMPort2 = txtCOMPort2.Text
        clsData.BaudRate = txtBaudRate.Value
        clsData.DataBits = txtDataBits.Value
        clsData.Comparity = cboComParity.Text.Trim
        clsData.ComStopBits = cboComStopBits.Text.Trim
        clsData.LogBy = UI.usUserApp.UserID

        Try
            If BL.SubStation.SaveConfigurationRFIDReader(clsData) Then
                UI.usForm.frmMessageBox("Setup Configuration RFID Reader success.")
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cSave).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSUBSTATION", "CONFIGURATION")
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstSubStationConfigurationRFIDReader_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstSubStationConfigurationRFIDReader_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prvSetIcon()
        prvFillForm()
        prvUserAccess()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

#End Region


End Class