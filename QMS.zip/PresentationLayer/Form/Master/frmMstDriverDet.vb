Public Class frmMstDriverDet

#Region "Property Handle"

    Private frmParent As frmMstDriver
    Private clsData As VO.Driver
    Private intPos As Integer = 0
    Private dtImage As New DataTable
    Property pubID As String
    Property pubIsNew As Boolean = False
    Property pubIsSave As Boolean = False
    Private Const cSave = 0, cClose = 1, cAddImage = 0, cEditImage = 1, cDeleteImage = 2

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdHistoryView, "Status", "Status", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdHistoryView, "StatusBy", "Status By", 150, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdHistoryView, "StatusDate", "Status Date", 150, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdHistoryView, "Remarks", "Remarks", 300, UI.usDefGrid.gString)
    End Sub

    Private Sub prvSetTitleForm()
        If pubIsNew Then
            Me.Text += " [new] "
        Else
            Me.Text += " [edit] "
        End If
    End Sub

    Private Sub prvFillCombo()
        prvFillComboStatus()
        prvFillComboGender()
        prvFillComboBloodType()
        prvFillComboReligion()
        prvFillComboMaritalStatus()
        prvFillComboOccupations()
        prvFillComboNationality()
        prvFillComboDrivingLicenseType()
    End Sub

    Private Sub prvFillComboStatus()
        Dim dtStatus As New DataTable
        Try
            dtStatus = BL.Status.ListDataByModuleID(VO.Modules.Values.Driver)
            UI.usForm.FillComboBox(cboStatus, dtStatus, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvFillComboGender()
        'Dim dtGender As New DataTable
        'Try
        '    dtGender = BL.Gender.ListData(VO.Status.Values.Active)
        '    UI.usForm.FillComboBox(cboGender, dtGender, "ID", "Description")
        'Catch ex As Exception
        '    UI.usForm.frmMessageBox(ex.Message)
        'End Try
    End Sub

    Private Sub prvFillComboBloodType()
        'Dim dtBloodType As New DataTable
        'Try
        '    dtBloodType = BL.BloodType.ListData(VO.Status.Values.Active)
        '    UI.usForm.FillComboBox(cboBloodType, dtBloodType, "ID", "Description")
        'Catch ex As Exception
        '    UI.usForm.frmMessageBox(ex.Message)
        'End Try
    End Sub

    Private Sub prvFillComboReligion()
        'Dim dtReligion As New DataTable
        'Try
        '    dtReligion = BL.Religion.ListData(VO.Status.Values.Active)
        '    UI.usForm.FillComboBox(cboReligion, dtReligion, "ID", "Description")
        'Catch ex As Exception
        '    UI.usForm.frmMessageBox(ex.Message)
        'End Try
    End Sub

    Private Sub prvFillComboMaritalStatus()
        'Dim dtMaritalStatus As New DataTable
        'Try
        '    dtMaritalStatus = BL.MaritalStatus.ListData(VO.Status.Values.Active)
        '    UI.usForm.FillComboBox(cboMaritalStatus, dtMaritalStatus, "ID", "Description")
        'Catch ex As Exception
        '    UI.usForm.frmMessageBox(ex.Message)
        'End Try
    End Sub

    Private Sub prvFillComboOccupations()
        'Dim dtOccuptions As New DataTable
        'Try
        '    dtOccuptions = BL.Occupations.ListData(VO.Status.Values.Active)
        '    UI.usForm.FillComboBox(cboOccupationsOfIdentityCard, dtOccuptions, "ID", "Description", True)
        '    UI.usForm.FillComboBox(cboOccupationsOfDrivingLicense, dtOccuptions, "ID", "Description", True)
        'Catch ex As Exception
        '    UI.usForm.frmMessageBox(ex.Message)
        'End Try
    End Sub

    Private Sub prvFillComboNationality()
        Dim dtNationality As New DataTable
        Try
            dtNationality = BL.Nationality.ListData(VO.Status.Values.Active)
            UI.usForm.FillComboBox(cboNationality, dtNationality, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvFillComboDrivingLicenseType()
        Dim dtDrivingLicenseType As New DataTable
        Try
            dtDrivingLicenseType = BL.DrivingLicenseType.ListData(VO.Status.Values.Active)
            UI.usForm.FillComboBox(cboDrivingLicenseType, dtDrivingLicenseType, "ID", "Description")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvFillForm()
        'txtHeight.Maximum = 250
        'txtHeight.Minimum = 0
        Dim idFace As String = ""
        Try
            prvFillCombo()
            If pubIsNew Then
                prvClear()
            Else
                clsData = New VO.Driver
                clsData = BL.Driver.GetDetail(pubID)

                'Main - F1
                txtID.Text = clsData.ID
                txtFullName.Text = clsData.FullName
                txtPlaceOfBirth.Text = clsData.PlaceOfBirth
                dtpDateOfBirth.Value = clsData.DateOfBirth
                cboStatus.SelectedValue = clsData.IDStatus
                txtInternalRemarks.Text = clsData.InternalRemarks
                txtRemarks.Text = clsData.Remarks
                txtCreatedFromCompany.Text = clsData.CreatedFromCompany
                txtCreatedFromLocation.Text = clsData.CreatedFromLocation
                txtLastUpdatedFromCompany.Text = clsData.LastUpdatedFromCompany
                txtLastUpdatedFromLocation.Text = clsData.LastUpdatedFromLocation
                txtReferencesID.Text = clsData.ReferencesID
                ToolStripLogInc.Text = "Log Inc : " & clsData.LogInc
                ToolStripLogBy.Text = "Last Log : " & clsData.LogBy
                ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)

                'Identity Card - F2
                txtIdentityCardNumber.Text = clsData.IdentityCardNumber
                'cboGender.SelectedValue = clsData.GenderID
                'cboBloodType.SelectedValue = clsData.BloodTypeID
                txtAddressOfIdentityCard.Text = clsData.AddressOfIdentityCard
                'cboReligion.SelectedValue = clsData.ReligionID
                'cboMaritalStatus.SelectedValue = clsData.MaritalStatusID
                'cboOccupationsOfIdentityCard.SelectedValue = clsData.OccupationsIDOfIdentityCard
                'txtOccupationsOthersOfIdentityCard.Text = clsData.OccupationsOthersOfIdentityCard
                cboNationality.SelectedValue = clsData.NationalityID
                dtpValidThruOfIdentityCard.Value = clsData.ValidThruOfIdentityCard

                'Driving License - F3
                txtAddressOfDrivingLicense.Text = clsData.AddressOfDrivingLicense
                'txtHeight.Value = clsData.Height
                'cboOccupationsOfDrivingLicense.SelectedValue = clsData.OccupationsIDOfDrivingLicense
                'txtOccupationsOthersOfDrivingLicense.Text = clsData.OccupationsOthersOfDrivingLicense
                txtDrivingLicenseNumber.Text = clsData.DrivingLicenseNumber
                dtpValidThruOfDrivingLicense.Value = clsData.ValidThruOfDrivingLicense
                cboDrivingLicenseType.SelectedValue = clsData.DrivingLicenseTypeID

                If (clsData.IDStatus = VO.Status.Values.Active) Or _
                    (clsData.IDStatus = VO.Status.Values.Blacklist) Then
                    cboStatus.Enabled = False
                Else
                    cboStatus.Enabled = True
                End If

                Dim dtImage As DataTable = BL.Driver.ListDataImage(txtID.Text.Trim)
                For Each dr As DataRow In dtImage.Rows
                    If dr.Item("ImageTypeID") = VO.ImageType.Values.FaceRecognation Then
                        txtPathFaceRecognation.Text = SharedLib.DirectoryUtility.CopyFile(dr.Item("ImagePath"), VO.DefaultServer.DSTempPath, dr.Item("ID"))
                    ElseIf dr.Item("ImageTypeID") = VO.ImageType.Values.IdentityCard Then
                        txtPathIdentityCard.Text = SharedLib.DirectoryUtility.CopyFile(dr.Item("ImagePath"), VO.DefaultServer.DSTempPath, dr.Item("ID"))
                    ElseIf dr.Item("ImageTypeID") = VO.ImageType.Values.DrivingLicense Then
                        txtPathDrivingLicense.Text = SharedLib.DirectoryUtility.CopyFile(dr.Item("ImagePath"), VO.DefaultServer.DSTempPath, dr.Item("ID"))
                    End If
                Next
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            If txtPathFaceRecognation.Text.Trim <> "" Then
                peFaceRecognation.Image = UI.usForm.ConvertBytetoImage(SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathFaceRecognation.Text.Trim))
            End If
            If txtPathFaceRecognation.Text.Trim = "" Then
                peFaceRecognation.Visible = False
            Else
                peFaceRecognation.Visible = True
            End If

            If txtPathIdentityCard.Text.Trim <> "" Then
                peIdentityCard.Image = UI.usForm.ConvertBytetoImage(SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathIdentityCard.Text.Trim))
            End If
            If txtPathIdentityCard.Text.Trim = "" Then
                peIdentityCard.Visible = False
            Else
                peIdentityCard.Visible = True
            End If

            If txtPathDrivingLicense.Text.Trim <> "" Then
                peDrivingLicense.Image = UI.usForm.ConvertBytetoImage(SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathDrivingLicense.Text.Trim))
            End If
            If txtPathDrivingLicense.Text.Trim = "" Then
                peDrivingLicense.Visible = False
            Else
                peDrivingLicense.Visible = True
            End If

            'If cboOccupationsOfIdentityCard.SelectedValue = VO.Occupations.Values.Others Then
            '    txtOccupationsOthersOfIdentityCard.ReadOnly = False
            '    txtOccupationsOthersOfIdentityCard.BackColor = Color.White
            'Else
            '    txtOccupationsOthersOfIdentityCard.ReadOnly = True
            '    txtOccupationsOthersOfIdentityCard.BackColor = Color.LightYellow
            'End If

            'If cboOccupationsOfDrivingLicense.SelectedValue = VO.Occupations.Values.Others Then
            '    txtOccupationsOthersOfDrivingLicense.ReadOnly = False
            '    txtOccupationsOthersOfDrivingLicense.BackColor = Color.White
            'Else
            '    txtOccupationsOthersOfDrivingLicense.ReadOnly = True
            '    txtOccupationsOthersOfDrivingLicense.BackColor = Color.LightYellow
            'End If

            If cboNationality.Items.Count = 1 Then
                cboNationality.SelectedIndex = 0
                cboNationality.Enabled = False
            End If
        End Try
    End Sub

    Private Sub prvQuery()
        Try
            grdHistory.DataSource = BL.Driver.ListDataStatus(txtID.Text.Trim)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSave()
        ToolBar.Focus()

        If txtFullName.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Full name not allow blank")
            tcDriver.SelectedTab = tpMain
            txtFullName.Focus()
            Exit Sub
            '# Disable, request OM (Andrew) 17 Maret 2022
            'ElseIf txtPlaceOfBirth.Text.Trim = "" Then
            '    UI.usForm.frmMessageBox("Place of birth not allow blank")
            '    tcDriver.SelectedTab = tpMain
            '    txtPlaceOfBirth.Focus()
            '    Exit Sub
            'ElseIf dtpDateOfBirth.Value = "1900/01/01" Then
            '    UI.usForm.frmMessageBox("Please set birth date first")
            '    tcDriver.SelectedTab = tpMain
            '    dtpDateOfBirth.Focus()
            '    Exit Sub
        ElseIf pubIsNew = False Then
            If clsData.IDStatus = VO.Status.Values.Blacklist And clsData.IDStatus <> cboStatus.SelectedValue Then
                UI.usForm.frmMessageBox("Cannot change status if blacklist, please use feature Revert Blacklist")
                tcDriver.SelectedTab = tpMain
                cboStatus.Focus()
                Exit Sub
            End If
        End If

        '# Checking if identity card available
        If txtIdentityCardNumber.Text.Trim <> "" Then
            If txtAddressOfIdentityCard.Text.Trim = "" Then
                UI.usForm.frmMessageBox("Address of identity card not allow blank")
                tcDriver.SelectedTab = tpIdentityCard
                txtAddressOfIdentityCard.Focus()
                Exit Sub
                'ElseIf cboGender.SelectedIndex = -1 Then
                '    UI.usForm.frmMessageBox("Please choose gender first")
                '    tcDriver.SelectedTab = tpIdentityCard
                '    cboGender.Focus()
                '    Exit Sub
                'ElseIf cboBloodType.SelectedIndex = -1 Then
                '    UI.usForm.frmMessageBox("Please choose blood type first")
                '    tcDriver.SelectedTab = tpIdentityCard
                '    cboBloodType.Focus()
                '    Exit Sub
                'ElseIf cboReligion.SelectedIndex = -1 Then
                '    UI.usForm.frmMessageBox("Please choose religion first")
                '    tcDriver.SelectedTab = tpIdentityCard
                '    cboReligion.Focus()
                '    Exit Sub
                'ElseIf cboMaritalStatus.SelectedIndex = -1 Then
                '    UI.usForm.frmMessageBox("Please choose marital status first")
                '    tcDriver.SelectedTab = tpIdentityCard
                '    cboMaritalStatus.Focus()
                '    Exit Sub
                'ElseIf cboOccupationsOfIdentityCard.SelectedIndex = -1 Then
                '    UI.usForm.frmMessageBox("Please choose occupations first")
                '    tcDriver.SelectedTab = tpIdentityCard
                '    cboOccupationsOfIdentityCard.Focus()
                '    Exit Sub
                'ElseIf cboOccupationsOfIdentityCard.SelectedValue = VO.Occupations.Values.Others And txtOccupationsOthersOfIdentityCard.Text.Trim = "" Then
                '    UI.usForm.frmMessageBox("Occuptions remarks not allow blank if occupations is others")
                '    tcDriver.SelectedTab = tpIdentityCard
                '    txtOccupationsOthersOfIdentityCard.Focus()
                '    Exit Sub
            ElseIf cboNationality.SelectedIndex = -1 Then
                UI.usForm.frmMessageBox("Please choose nationality first")
                tcDriver.SelectedTab = tpIdentityCard
                cboNationality.Focus()
                Exit Sub
            End If
        End If

        '# Checking Driving License if availaible
        If txtDrivingLicenseNumber.Text.Trim <> "" Then
            If cboDrivingLicenseType.SelectedIndex = -1 Then
                UI.usForm.frmMessageBox("Please choose driving license type first")
                tcDriver.SelectedTab = tpDrivingLicense
                cboDrivingLicenseType.Focus()
                Exit Sub
            End If
            '# Disable, request OM (Andrew) 17 Maret 2022
            'If txtAddressOfDrivingLicense.Text.Trim = "" Then
            '    UI.usForm.frmMessageBox("Address of driving license not allow blank")
            '    tcDriver.SelectedTab = tpDrivingLicense
            '    txtAddressOfDrivingLicense.Focus()
            '    Exit Sub
            '    'ElseIf txtHeight.Value = 0 Then
            '    '    UI.usForm.frmMessageBox("Height must more than zero")
            '    '    tcDriver.SelectedTab = tpDrivingLicense
            '    '    txtHeight.Focus()
            '    '    Exit Sub
            '    'ElseIf cboOccupationsOfDrivingLicense.SelectedIndex = -1 Then
            '    '    UI.usForm.frmMessageBox("Please choose occupations first")
            '    '    tcDriver.SelectedTab = tpDrivingLicense
            '    '    cboOccupationsOfDrivingLicense.Focus()
            '    '    Exit Sub
            '    'ElseIf cboOccupationsOfDrivingLicense.SelectedValue = VO.Occupations.Values.Others And txtOccupationsOthersOfDrivingLicense.Text.Trim = "" Then
            '    '    UI.usForm.frmMessageBox("Occuptions remarks not allow blank if occupations is others")
            '    '    tcDriver.SelectedTab = tpDrivingLicense
            '    '    txtOccupationsOthersOfDrivingLicense.Focus()
            '    '    Exit Sub
            'ElseIf dtpValidThruOfDrivingLicense.Value = "2000/01/01" Then
            '    UI.usForm.frmMessageBox("Please set valid thru of driving license first")
            '    tcDriver.SelectedTab = tpDrivingLicense
            '    dtpValidThruOfDrivingLicense.Focus()
            '    Exit Sub
            'ElseIf cboDrivingLicenseType.SelectedIndex = -1 Then
            '    UI.usForm.frmMessageBox("Please choose driving license type first")
            '    tcDriver.SelectedTab = tpDrivingLicense
            '    cboDrivingLicenseType.Focus()
            '    Exit Sub
            'End If
        End If

        If txtDrivingLicenseNumber.Text.Trim = "" And txtIdentityCardNumber.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Please fill NIK No. or SIM No. first")
            tcDriver.SelectedTab = tpIdentityCard
            txtIdentityCardNumber.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        clsData = New VO.Driver

        'Main - F1
        clsData.ID = txtID.Text.Trim
        clsData.FullName = txtFullName.Text.Trim
        clsData.PlaceOfBirth = txtPlaceOfBirth.Text.Trim
        clsData.DateOfBirth = dtpDateOfBirth.Value
        clsData.IDStatus = cboStatus.SelectedValue
        clsData.InternalRemarks = txtInternalRemarks.Text.Trim
        clsData.Remarks = txtRemarks.Text.Trim
        clsData.ComLocDivSubDivID = UI.usUserApp.ComLocDivSubDivID
        clsData.LogBy = UI.usUserApp.UserID

        'Identity Card - F2
        clsData.IdentityCardNumber = txtIdentityCardNumber.Text.Trim
        clsData.GenderID = VO.Gender.Values.None
        clsData.BloodTypeID = VO.BloodType.Values.None
        clsData.AddressOfIdentityCard = txtAddressOfIdentityCard.Text.Trim
        clsData.ReligionID = VO.Religion.Values.None
        clsData.MaritalStatusID = VO.MaritalStatus.Values.None
        clsData.OccupationsIDOfIdentityCard = VO.Occupations.Values.None
        clsData.OccupationsOthersOfIdentityCard = ""
        clsData.NationalityID = cboNationality.SelectedValue
        clsData.ValidThruOfIdentityCard = dtpValidThruOfIdentityCard.Value

        'Identity Card - F3
        clsData.AddressOfDrivingLicense = txtAddressOfDrivingLicense.Text.Trim
        clsData.Height = 0
        clsData.OccupationsIDOfDrivingLicense = VO.Occupations.Values.None
        clsData.OccupationsOthersOfDrivingLicense = ""
        clsData.DrivingLicenseNumber = txtDrivingLicenseNumber.Text.Trim
        clsData.ValidThruOfDrivingLicense = dtpValidThruOfDrivingLicense.Value
        clsData.DrivingLicenseTypeID = cboDrivingLicenseType.SelectedValue

        Dim clsDataImage As VO.DriverImage
        Dim clsDataAllImage As New List(Of VO.DriverImage)
        If txtPathFaceRecognation.Text.Trim <> "" Then
            clsDataImage = New VO.DriverImage()
            clsDataImage.DriverID = txtID.Text.Trim
            clsDataImage.ImagePath = txtPathFaceRecognation.Text.Trim
            clsDataImage.ImageTypeID = VO.ImageType.Values.FaceRecognation
            clsDataImage.ByteOfImage = SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathFaceRecognation.Text.Trim)
            clsDataAllImage.Add(clsDataImage)
        End If

        If txtPathIdentityCard.Text.Trim <> "" Then
            clsDataImage = New VO.DriverImage()
            clsDataImage.DriverID = txtID.Text.Trim
            clsDataImage.ImagePath = txtPathIdentityCard.Text.Trim
            clsDataImage.ImageTypeID = VO.ImageType.Values.IdentityCard
            clsDataImage.ByteOfImage = SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathIdentityCard.Text.Trim)
            clsDataAllImage.Add(clsDataImage)
        End If

        If txtPathDrivingLicense.Text.Trim <> "" Then
            clsDataImage = New VO.DriverImage()
            clsDataImage.DriverID = txtID.Text.Trim
            clsDataImage.ImagePath = txtPathDrivingLicense.Text.Trim
            clsDataImage.ImageTypeID = VO.ImageType.Values.DrivingLicense
            clsDataImage.ByteOfImage = SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathDrivingLicense.Text.Trim)
            clsDataAllImage.Add(clsDataImage)
        End If

        Try
            BL.Driver.SaveData(pubIsNew, clsData, clsDataAllImage)
            If pubIsNew Then
                UI.usForm.frmMessageBox("Save data success.")
                frmParent.pubRefresh(clsData.ID)
                prvClear()
            Else
                pubIsSave = True
                Me.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvClear()
        'Main - F1
        tcDriver.SelectedTab = tpMain
        txtID.Text = ""
        txtFullName.Text = ""
        txtPlaceOfBirth.Text = ""
        dtpDateOfBirth.Value = "1900/01/01"
        txtPathFaceRecognation.Text = ""
        cboStatus.SelectedValue = VO.Status.Values.Active
        txtInternalRemarks.Text = ""
        txtRemarks.Text = ""
        txtReferencesID.Text = ""
        txtCreatedFromCompany.Text = UI.usUserApp.CompanyName
        txtCreatedFromLocation.Text = UI.usUserApp.LocationName
        txtLastUpdatedFromCompany.Text = UI.usUserApp.CompanyName
        txtLastUpdatedFromLocation.Text = UI.usUserApp.LocationName
        ToolStripLogInc.Text = "Log Inc : -"
        ToolStripLogBy.Text = "Last Log : -"
        ToolStripLogDate.Text = Format(Now, UI.usDefCons.DateFull)

        'Identity Card - F2
        txtIdentityCardNumber.Text = ""
        txtAddressOfIdentityCard.Text = ""
        dtpValidThruOfIdentityCard.Value = "3000/01/01"
        txtPathIdentityCard.Text = ""

        'Driving License - F3
        txtAddressOfDrivingLicense.Text = ""
        txtDrivingLicenseNumber.Text = ""
        dtpValidThruOfDrivingLicense.Value = "2000/01/01"
        cboDrivingLicenseType.SelectedIndex = -1
        txtPathDrivingLicense.Text = ""
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cSave).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVER", IIf(pubIsNew, "ADD", "EDIT"))
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstDriverDet_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        ElseIf e.KeyCode = Keys.F1 Then
            tcDriver.SelectedTab = tpMain
        ElseIf e.KeyCode = Keys.F2 Then
            tcDriver.SelectedTab = tpIdentityCard
        ElseIf e.KeyCode = Keys.F3 Then
            tcDriver.SelectedTab = tpDrivingLicense
        ElseIf e.KeyCode = Keys.F4 Then
            tcDriver.SelectedTab = tpHistory
        ElseIf e.KeyCode = Keys.F5 Then
            tcDriver.SelectedTab = tpAdditionalInfo
        End If
    End Sub

    Private Sub frmMstDriverDet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetTitleForm()
        prvSetGrid()
        prvFillForm()
        prvQuery()
        prvUserAccess()

        AddHandler txtPathFaceRecognation.TextChanged, AddressOf txtPathFaceRecognation_TextChanged
        AddHandler txtPathIdentityCard.TextChanged, AddressOf txtPathIdentityCard_TextChanged
        AddHandler txtPathDrivingLicense.TextChanged, AddressOf txtPathDrivingLicense_TextChanged
        'AddHandler cboOccupationsOfIdentityCard.SelectedValueChanged, AddressOf cboOccuptionsOfIdentityCard_SelectedValueChanged
        'AddHandler txtOccupationsOthersOfIdentityCard.LostFocus, AddressOf txtOccuptionsOthersOfIdentityCard_LostFocus
        'AddHandler cboOccupationsOfDrivingLicense.SelectedValueChanged, AddressOf cboOccuptionsOfDrivingLicense_SelectedValueChanged
        'AddHandler txtOccupationsOthersOfDrivingLicense.LostFocus, AddressOf txtOccuptionsOthersOfDrivingLicense_LostFocus
        AddHandler txtAddressOfIdentityCard.LostFocus, AddressOf txtAddressOfIdentityCard_LostFocus
        AddHandler txtAddressOfDrivingLicense.LostFocus, AddressOf txtAddressOfDrivingLicense_LostFocus
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

    'Private Sub cboOccuptionsOfIdentityCard_SelectedValueChanged(sender As Object, e As EventArgs)
    '    If cboOccupationsOfIdentityCard.SelectedIndex = -1 Then Exit Sub
    '    If cboOccupationsOfIdentityCard.SelectedValue = VO.Occupations.Values.Others Then
    '        txtOccupationsOthersOfIdentityCard.Focus()
    '        txtOccupationsOthersOfIdentityCard.ReadOnly = False
    '        txtOccupationsOthersOfIdentityCard.BackColor = Color.White
    '    Else
    '        txtOccupationsOthersOfIdentityCard.Text = ""
    '        txtOccupationsOthersOfIdentityCard.ReadOnly = True
    '        txtOccupationsOthersOfIdentityCard.BackColor = Color.LightYellow
    '    End If

    '    If cboOccupationsOfDrivingLicense.SelectedValue = 0 Then
    '        cboOccupationsOfDrivingLicense.SelectedValue = cboOccupationsOfIdentityCard.SelectedValue
    '    End If
    'End Sub

    'Private Sub txtOccuptionsOthersOfIdentityCard_LostFocus(sender As Object, e As EventArgs)
    '    If txtOccupationsOthersOfDrivingLicense.Text.Trim = "" Then
    '        txtOccupationsOthersOfDrivingLicense.Text = txtOccupationsOthersOfIdentityCard.Text.Trim
    '    End If
    'End Sub

    'Private Sub cboOccuptionsOfDrivingLicense_SelectedValueChanged(sender As Object, e As EventArgs)
    '    If cboOccupationsOfDrivingLicense.SelectedIndex = -1 Then Exit Sub
    '    If cboOccupationsOfDrivingLicense.SelectedValue = VO.Occupations.Values.Others Then
    '        txtOccupationsOthersOfDrivingLicense.Focus()
    '        txtOccupationsOthersOfDrivingLicense.ReadOnly = False
    '        txtOccupationsOthersOfDrivingLicense.BackColor = Color.White
    '    Else
    '        txtOccupationsOthersOfDrivingLicense.Text = ""
    '        txtOccupationsOthersOfDrivingLicense.ReadOnly = True
    '        txtOccupationsOthersOfDrivingLicense.BackColor = Color.LightYellow
    '    End If

    '    If cboOccupationsOfIdentityCard.SelectedValue = 0 Then
    '        cboOccupationsOfIdentityCard.SelectedValue = cboOccupationsOfDrivingLicense.SelectedValue
    '    End If
    'End Sub

    'Private Sub txtOccuptionsOthersOfDrivingLicense_LostFocus(sender As Object, e As EventArgs)
    '    If txtOccupationsOthersOfIdentityCard.Text.Trim = "" Then
    '        txtOccupationsOthersOfIdentityCard.Text = txtOccupationsOthersOfDrivingLicense.Text.Trim
    '    End If
    'End Sub

    Private Sub txtAddressOfIdentityCard_LostFocus(sender As Object, e As EventArgs)
        If txtAddressOfDrivingLicense.Text.Trim = "" Then
            txtAddressOfDrivingLicense.Text = txtAddressOfIdentityCard.Text.Trim
        End If
    End Sub

    Private Sub txtAddressOfDrivingLicense_LostFocus(sender As Object, e As EventArgs)
        If txtAddressOfIdentityCard.Text.Trim = "" Then
            txtAddressOfIdentityCard.Text = txtAddressOfDrivingLicense.Text.Trim
        End If
    End Sub

    Private Sub btnChooseFaceRecognation_Click(sender As Object, e As EventArgs) Handles btnChooseFaceRecognation.Click
        Dim strPath As String = UI.usForm.ChooseImage
        If strPath.Trim <> "" Then txtPathFaceRecognation.Text = strPath
        If txtPathFaceRecognation.Text.Trim <> "" Then
            peFaceRecognation.Image = UI.usForm.ConvertBytetoImage(SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathFaceRecognation.Text.Trim))
        End If
    End Sub

    Private Sub btnChooseIdentityCard_Click(sender As Object, e As EventArgs) Handles btnChooseIdentityCard.Click
        Dim strPath As String = UI.usForm.ChooseImage
        If strPath.Trim <> "" Then txtPathIdentityCard.Text = strPath
        If txtPathIdentityCard.Text.Trim <> "" Then
            peIdentityCard.Image = UI.usForm.ConvertBytetoImage(SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathIdentityCard.Text.Trim))
        End If
    End Sub

    Private Sub btnChooseDrivingLicense_Click(sender As Object, e As EventArgs) Handles btnChooseDrivingLicense.Click
        Dim strPath As String = UI.usForm.ChooseImage
        If strPath.Trim <> "" Then txtPathDrivingLicense.Text = strPath
        If txtPathDrivingLicense.Text.Trim <> "" Then
            peDrivingLicense.Image = UI.usForm.ConvertBytetoImage(SharedLib.DirectoryUtility.ConvertImagetoByte(txtPathDrivingLicense.Text.Trim))
        End If
    End Sub

    Private Sub txtPathFaceRecognation_TextChanged(sender As Object, e As EventArgs)
        If txtPathFaceRecognation.Text.Trim = "" Then
            peFaceRecognation.Visible = False
        Else
            peFaceRecognation.Visible = True
        End If
    End Sub

    Private Sub txtPathIdentityCard_TextChanged(sender As Object, e As EventArgs)
        If txtPathIdentityCard.Text.Trim = "" Then
            peIdentityCard.Visible = False
        Else
            peIdentityCard.Visible = True
        End If
    End Sub

    Private Sub txtPathDrivingLicense_TextChanged(sender As Object, e As EventArgs)
        If txtPathDrivingLicense.Text.Trim = "" Then
            peDrivingLicense.Visible = False
        Else
            peDrivingLicense.Visible = True
        End If
    End Sub

#End Region

End Class