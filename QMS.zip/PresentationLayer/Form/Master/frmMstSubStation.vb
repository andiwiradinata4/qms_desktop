Public Class frmMstSubStation

#Region "Properties Handle"

    Public pubLUdtRow As DataRow
    Public pubIsLookUp As Boolean = False
    Public pubIsLookUpGet As Boolean = False
    Public pubLUDescription As String = ""
    Public pubIsLookGetMulti As Boolean = False
    Public pubLUdtRowMulti() As DataRow
    Public pubIsEnabledChangeComLoc As Boolean = False
    Public pubCS As New VO.CS
    Public pubStationID As Integer = 0, pubComLocDivSubDivIDStorage As Integer = 0
    Public pubEnumLinkedStorage As VO.SubStation.FilterIsLinkedStorage
    Public pubProgramIDStorage As String = "", pubStorageGroupID As String = "", pubStorageID As String = ""
    Private clsData As VO.SubStation
    Private intPos As Integer
    Private clsCS As New VO.CS
    Private Const _
       cGet = 0, cSep1 = 1, cNew = 2, cDetail = 3, cDelete = 4, cConfiguration = 5, cSep2 = 6, cRefresh = 7, cClose = 8

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Get,2,New,3,Detail,4,Delete,6,Refresh,7,Close")
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "Pick", "Pick", 100, UI.usDefGrid.gBoolean, pubIsLookUp And pubIsLookGetMulti, False)
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StationID", "Station ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StationName", "Station Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IsDefault", "IsDefault", 100, UI.usDefGrid.gBoolean)
        UI.usForm.SetGrid(grdView, "RFIDIPAddress", "RFID IP Address", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "CameraIPAddress", "Camera IP Address", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        grdView.Columns("StationName").GroupIndex = 0
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Visible = pubIsLookUp
            .Item(cSep1).Visible = pubIsLookUp
            .Item(cGet).Enabled = bolEnable
            .Item(cDetail).Enabled = bolEnable
            .Item(cDelete).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            grdMain.DataSource = BL.SubStation.ListData(clsCS.CompanyID, clsCS.LocationID, pubStationID, pubEnumLinkedStorage, pubComLocDivSubDivIDStorage, pubProgramIDStorage, pubStorageGroupID, pubStorageID)
            If grdView.GroupCount > 0 Then
                grdView.ExpandAllGroups()
            End If
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If grdView.FocusedValue IsNot Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Sub prvGet()
        If Not pubIsLookUp Then Exit Sub
        If pubIsLookGetMulti Then
            ToolBar.Focus()
            Dim dtData As DataTable = grdMain.DataSource
            pubLUdtRowMulti = dtData.Select("Pick=True")
            If pubLUdtRowMulti.Count = 0 Then UI.usForm.frmMessageBox("Please pick item first") : Exit Sub
            For Each drPick As DataRow In pubLUdtRowMulti
                If drPick.Item("IDStatus") = VO.Status.Values.InActive Then
                    UI.usForm.frmMessageBox("Cannot choose " & drPick.Item("Description") & " because data is not active")
                    Exit Sub
                End If
            Next
        Else
            intPos = grdView.FocusedRowHandle
            If intPos < 0 Then Exit Sub
            If grdView.GetRowCellValue(intPos, "IDStatus") = VO.Status.Values.InActive Then
                UI.usForm.frmMessageBox("Cannot choose this data because data is not active")
                Exit Sub
            Else
                pubLUdtRow = grdView.GetDataRow(grdView.FocusedRowHandle)
            End If
        End If
        pubIsLookUpGet = True
        Me.Close()
    End Sub

    Private Sub prvSetLookUp()
        If pubIsLookUp Then
            Me.Text += " [Lookup] "
            btnCompany.Visible = pubIsEnabledChangeComLoc
            btnLocation.Visible = pubIsEnabledChangeComLoc
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "Description", pubLUDescription)
        End If
    End Sub

    Private Function prvGetData() As VO.SubStation
        Dim returnValue As New VO.SubStation
        returnValue.ID = grdView.GetRowCellValue(intPos, "ID")
        returnValue.StationID = grdView.GetRowCellValue(intPos, "StationID")
        returnValue.StationName = grdView.GetRowCellValue(intPos, "StationName")
        returnValue.Description = grdView.GetRowCellValue(intPos, "Description")
        returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnValue.IDStatus = grdView.GetRowCellValue(intPos, "IDStatus")
        returnValue.StatusInfo = grdView.GetRowCellValue(intPos, "StatusInfo")
        returnValue.CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvNew()
        Dim frmDetail As New frmMstSubStationDet
        With frmDetail
            .pubIsNew = True
            .pubCS = clsCS
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvDetail()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New frmMstSubStationDet
        With frmDetail
            .pubIsNew = False
            .pubCS = clsCS
            .pubID = grdView.GetRowCellValue(intPos, "ID")
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then pubRefresh()
        End With
    End Sub

    Private Sub prvDelete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        If Not UI.usForm.frmAskQuestion("Delete " & grdView.GetRowCellValue(intPos, "Description") & "?") Then Exit Sub
        Try
            clsData = prvGetData()
            clsData.LogBy = UI.usUserApp.UserID
            BL.SubStation.DeleteData(clsData)
            UI.usForm.frmMessageBox("Delete data success.")
            pubRefresh(grdView.GetRowCellValue(intPos, "Description"))
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvConfiguration()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New frmMstSubStationConfigurationRFIDReader
        With frmDetail
            .pubID = grdView.GetRowCellValue(intPos, "ID")
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then
                pubRefresh()
            End If
        End With
    End Sub

    Private Sub prvSetDefaultFilter()
        If pubIsLookUp Then
            clsCS.CompanyID = pubCS.CompanyID
            clsCS.CompanyName = pubCS.CompanyName
            txtCompany.Text = pubCS.CompanyName
            clsCS.LocationID = pubCS.LocationID
            clsCS.LocationName = pubCS.LocationName
            txtLocation.Text = pubCS.LocationName
        Else
            clsCS.CompanyID = UI.usUserApp.CompanyID
            clsCS.CompanyName = UI.usUserApp.CompanyName
            txtCompany.Text = UI.usUserApp.CompanyName
            clsCS.LocationID = UI.usUserApp.LocationID
            clsCS.LocationName = UI.usUserApp.LocationName
            txtLocation.Text = UI.usUserApp.LocationName
        End If
    End Sub

    Private Sub prvChooseCompany()
        Dim frmDetail As New frmMstCompany
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                clsCS.CompanyID = .pubLUDataRow.Item("CompanyID")
                clsCS.CompanyName = .pubLUDataRow.Item("CompanyName")
                txtCompany.Text = .pubLUDataRow.Item("CompanyName")
            End If
        End With
    End Sub

    Private Sub prvChooseLocation()
        Dim frmDetail As New frmMstCompanyLocation
        With frmDetail
            .pubIsLookUp = True
            .pubLUCompanyID = clsCS.CompanyID
            .pubLULocationID = clsCS.LocationID
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                clsCS.LocationID = .pubLUDataRow.Item("LocationID")
                clsCS.LocationName = .pubLUDataRow.Item("LocationName")
                txtLocation.Text = .pubLUDataRow.Item("LocationName")
            End If
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cNew).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSUBSTATION", "ADD")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSUBSTATION", "DELETE")
            .Item(cConfiguration).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSUBSTATION", "CONFIGURATION")
        End With
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstSubStation_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstSubStation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvSetDefaultFilter()
        prvQuery()
        prvUserAccess()
        prvSetLookUp()

        If Not pubIsLookUp Then Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text
            Case "Get" : prvGet()
            Case "New" : prvNew()
            Case "Detail" : prvDetail()
            Case "Delete" : prvDelete()
            Case "Configuration" : prvConfiguration()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim intIDStatus As Integer = View.GetRowCellDisplayText(e.RowHandle, View.Columns("IDStatus"))
            If intIDStatus = VO.Status.Values.InActive And e.Appearance.BackColor <> Color.Salmon Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click
        prvChooseCompany()
    End Sub

    Private Sub btnLocation_Click(sender As Object, e As EventArgs) Handles btnLocation.Click
        prvChooseLocation()
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub grdMain_DoubleClick(sender As Object, e As EventArgs) Handles grdMain.DoubleClick
        If pubIsLookUp And pubIsLookGetMulti = False Then prvGet()
    End Sub

#End Region

End Class


