<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMstDriverDet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMstDriverDet))
        Me.ToolBar = New QMS.usToolBar()
        Me.BarSave = New System.Windows.Forms.ToolBarButton()
        Me.BarClose = New System.Windows.Forms.ToolBarButton()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripEmpty = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogInc = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogBy = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLogDate = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblIdentityCardNumber = New System.Windows.Forms.Label()
        Me.txtIdentityCardNumber = New QMS.usTextBox()
        Me.lblDrivingLicenseNumber = New System.Windows.Forms.Label()
        Me.txtDrivingLicenseNumber = New QMS.usTextBox()
        Me.lblAddressOfIdentityCard = New System.Windows.Forms.Label()
        Me.txtAddressOfIdentityCard = New QMS.usTextBox()
        Me.lblAddressOfDrivingLicense = New System.Windows.Forms.Label()
        Me.txtAddressOfDrivingLicense = New QMS.usTextBox()
        Me.lblNationalityID = New System.Windows.Forms.Label()
        Me.lblValidThruOfIdentityCard = New System.Windows.Forms.Label()
        Me.dtpValidThruOfIdentityCard = New System.Windows.Forms.DateTimePicker()
        Me.lblValidThruOfDrivingLicense = New System.Windows.Forms.Label()
        Me.dtpValidThruOfDrivingLicense = New System.Windows.Forms.DateTimePicker()
        Me.lblDrivingLicenseTypeID = New System.Windows.Forms.Label()
        Me.tcDriver = New System.Windows.Forms.TabControl()
        Me.tpMain = New System.Windows.Forms.TabPage()
        Me.btnChooseFaceRecognation = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPathFaceRecognation = New QMS.usTextBox()
        Me.cboStatus = New QMSLib.usComboBox()
        Me.lblIDStatus = New System.Windows.Forms.Label()
        Me.lblReferencesID = New System.Windows.Forms.Label()
        Me.txtReferencesID = New QMS.usTextBox()
        Me.lblInternalRemarks = New System.Windows.Forms.Label()
        Me.txtInternalRemarks = New QMS.usTextBox()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.txtRemarks = New QMS.usTextBox()
        Me.lblPlaceOfBirth = New System.Windows.Forms.Label()
        Me.txtPlaceOfBirth = New QMS.usTextBox()
        Me.lblDateOfBirth = New System.Windows.Forms.Label()
        Me.dtpDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.lblFullName = New System.Windows.Forms.Label()
        Me.txtFullName = New QMS.usTextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.txtID = New QMS.usTextBox()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.peFaceRecognation = New DevExpress.XtraEditors.PictureEdit()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.tpIdentityCard = New System.Windows.Forms.TabPage()
        Me.btnChooseIdentityCard = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPathIdentityCard = New QMS.usTextBox()
        Me.cboNationality = New QMSLib.usComboBox()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.peIdentityCard = New DevExpress.XtraEditors.PictureEdit()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tpDrivingLicense = New System.Windows.Forms.TabPage()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.peDrivingLicense = New DevExpress.XtraEditors.PictureEdit()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnChooseDrivingLicense = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPathDrivingLicense = New QMS.usTextBox()
        Me.cboDrivingLicenseType = New QMSLib.usComboBox()
        Me.tpHistory = New System.Windows.Forms.TabPage()
        Me.grdHistory = New DevExpress.XtraGrid.GridControl()
        Me.grdHistoryView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.tpAdditionalInfo = New System.Windows.Forms.TabPage()
        Me.gboLastUpdatedFrom = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtLastUpdatedFromCompany = New QMS.usTextBox()
        Me.txtLastUpdatedFromLocation = New QMS.usTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.gboCreatedFrom = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCreatedFromCompany = New QMS.usTextBox()
        Me.txtCreatedFromLocation = New QMS.usTextBox()
        Me.lblCreatedFromComLocID = New System.Windows.Forms.Label()
        Me.StatusStrip.SuspendLayout()
        Me.tcDriver.SuspendLayout()
        Me.tpMain.SuspendLayout()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.peFaceRecognation.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpIdentityCard.SuspendLayout()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        CType(Me.peIdentityCard.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpDrivingLicense.SuspendLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.peDrivingLicense.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpHistory.SuspendLayout()
        CType(Me.grdHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdHistoryView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpAdditionalInfo.SuspendLayout()
        Me.gboLastUpdatedFrom.SuspendLayout()
        Me.gboCreatedFrom.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarSave, Me.BarClose})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(828, 28)
        Me.ToolBar.TabIndex = 0
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarSave
        '
        Me.BarSave.Name = "BarSave"
        Me.BarSave.Tag = "Save"
        Me.BarSave.Text = "Save"
        '
        'BarClose
        '
        Me.BarClose.Name = "BarClose"
        Me.BarClose.Tag = "Close"
        Me.BarClose.Text = "Close"
        '
        'lblInfo
        '
        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue
        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.Color.White
        Me.lblInfo.Location = New System.Drawing.Point(0, 28)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(828, 22)
        Me.lblInfo.TabIndex = 1
        Me.lblInfo.Text = "« Driver Detail"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'StatusStrip
        '
        Me.StatusStrip.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripEmpty, Me.ToolStripLogInc, Me.ToolStripLogBy, Me.ToolStripStatusLabel1, Me.ToolStripLogDate})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 380)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(828, 22)
        Me.StatusStrip.TabIndex = 3
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'ToolStripEmpty
        '
        Me.ToolStripEmpty.Name = "ToolStripEmpty"
        Me.ToolStripEmpty.Size = New System.Drawing.Size(705, 17)
        Me.ToolStripEmpty.Spring = True
        '
        'ToolStripLogInc
        '
        Me.ToolStripLogInc.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogInc.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogInc.Name = "ToolStripLogInc"
        Me.ToolStripLogInc.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogInc.Text = "Log Inc : "
        '
        'ToolStripLogBy
        '
        Me.ToolStripLogBy.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogBy.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogBy.Name = "ToolStripLogBy"
        Me.ToolStripLogBy.Size = New System.Drawing.Size(48, 17)
        Me.ToolStripLogBy.Text = "Last Log :"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripLogDate
        '
        Me.ToolStripLogDate.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripLogDate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripLogDate.Name = "ToolStripLogDate"
        Me.ToolStripLogDate.Size = New System.Drawing.Size(12, 17)
        Me.ToolStripLogDate.Text = "-"
        '
        'lblIdentityCardNumber
        '
        Me.lblIdentityCardNumber.AutoSize = True
        Me.lblIdentityCardNumber.BackColor = System.Drawing.Color.Transparent
        Me.lblIdentityCardNumber.ForeColor = System.Drawing.Color.Black
        Me.lblIdentityCardNumber.Location = New System.Drawing.Point(20, 23)
        Me.lblIdentityCardNumber.Name = "lblIdentityCardNumber"
        Me.lblIdentityCardNumber.Size = New System.Drawing.Size(44, 13)
        Me.lblIdentityCardNumber.TabIndex = 93
        Me.lblIdentityCardNumber.Text = "NIK No."
        '
        'txtIdentityCardNumber
        '
        Me.txtIdentityCardNumber.BackColor = System.Drawing.Color.White
        Me.txtIdentityCardNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtIdentityCardNumber.Location = New System.Drawing.Point(93, 20)
        Me.txtIdentityCardNumber.MaxLength = 20
        Me.txtIdentityCardNumber.Name = "txtIdentityCardNumber"
        Me.txtIdentityCardNumber.Size = New System.Drawing.Size(290, 21)
        Me.txtIdentityCardNumber.TabIndex = 0
        '
        'lblDrivingLicenseNumber
        '
        Me.lblDrivingLicenseNumber.AutoSize = True
        Me.lblDrivingLicenseNumber.BackColor = System.Drawing.Color.Transparent
        Me.lblDrivingLicenseNumber.ForeColor = System.Drawing.Color.Black
        Me.lblDrivingLicenseNumber.Location = New System.Drawing.Point(21, 85)
        Me.lblDrivingLicenseNumber.Name = "lblDrivingLicenseNumber"
        Me.lblDrivingLicenseNumber.Size = New System.Drawing.Size(45, 13)
        Me.lblDrivingLicenseNumber.TabIndex = 93
        Me.lblDrivingLicenseNumber.Text = "SIM No."
        '
        'txtDrivingLicenseNumber
        '
        Me.txtDrivingLicenseNumber.BackColor = System.Drawing.Color.White
        Me.txtDrivingLicenseNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDrivingLicenseNumber.Location = New System.Drawing.Point(100, 82)
        Me.txtDrivingLicenseNumber.MaxLength = 20
        Me.txtDrivingLicenseNumber.Name = "txtDrivingLicenseNumber"
        Me.txtDrivingLicenseNumber.Size = New System.Drawing.Size(300, 21)
        Me.txtDrivingLicenseNumber.TabIndex = 1
        '
        'lblAddressOfIdentityCard
        '
        Me.lblAddressOfIdentityCard.AutoSize = True
        Me.lblAddressOfIdentityCard.BackColor = System.Drawing.Color.Transparent
        Me.lblAddressOfIdentityCard.ForeColor = System.Drawing.Color.Black
        Me.lblAddressOfIdentityCard.Location = New System.Drawing.Point(20, 50)
        Me.lblAddressOfIdentityCard.Name = "lblAddressOfIdentityCard"
        Me.lblAddressOfIdentityCard.Size = New System.Drawing.Size(46, 13)
        Me.lblAddressOfIdentityCard.TabIndex = 93
        Me.lblAddressOfIdentityCard.Text = "Address"
        '
        'txtAddressOfIdentityCard
        '
        Me.txtAddressOfIdentityCard.BackColor = System.Drawing.Color.White
        Me.txtAddressOfIdentityCard.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtAddressOfIdentityCard.Location = New System.Drawing.Point(93, 47)
        Me.txtAddressOfIdentityCard.MaxLength = 250
        Me.txtAddressOfIdentityCard.Multiline = True
        Me.txtAddressOfIdentityCard.Name = "txtAddressOfIdentityCard"
        Me.txtAddressOfIdentityCard.Size = New System.Drawing.Size(290, 60)
        Me.txtAddressOfIdentityCard.TabIndex = 1
        '
        'lblAddressOfDrivingLicense
        '
        Me.lblAddressOfDrivingLicense.AutoSize = True
        Me.lblAddressOfDrivingLicense.BackColor = System.Drawing.Color.Transparent
        Me.lblAddressOfDrivingLicense.ForeColor = System.Drawing.Color.Black
        Me.lblAddressOfDrivingLicense.Location = New System.Drawing.Point(21, 19)
        Me.lblAddressOfDrivingLicense.Name = "lblAddressOfDrivingLicense"
        Me.lblAddressOfDrivingLicense.Size = New System.Drawing.Size(46, 13)
        Me.lblAddressOfDrivingLicense.TabIndex = 93
        Me.lblAddressOfDrivingLicense.Text = "Address"
        '
        'txtAddressOfDrivingLicense
        '
        Me.txtAddressOfDrivingLicense.BackColor = System.Drawing.Color.White
        Me.txtAddressOfDrivingLicense.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtAddressOfDrivingLicense.Location = New System.Drawing.Point(100, 16)
        Me.txtAddressOfDrivingLicense.MaxLength = 250
        Me.txtAddressOfDrivingLicense.Multiline = True
        Me.txtAddressOfDrivingLicense.Name = "txtAddressOfDrivingLicense"
        Me.txtAddressOfDrivingLicense.Size = New System.Drawing.Size(300, 60)
        Me.txtAddressOfDrivingLicense.TabIndex = 0
        '
        'lblNationalityID
        '
        Me.lblNationalityID.AutoSize = True
        Me.lblNationalityID.BackColor = System.Drawing.Color.Transparent
        Me.lblNationalityID.ForeColor = System.Drawing.Color.Black
        Me.lblNationalityID.Location = New System.Drawing.Point(20, 117)
        Me.lblNationalityID.Name = "lblNationalityID"
        Me.lblNationalityID.Size = New System.Drawing.Size(58, 13)
        Me.lblNationalityID.TabIndex = 93
        Me.lblNationalityID.Text = "Nationality"
        '
        'lblValidThruOfIdentityCard
        '
        Me.lblValidThruOfIdentityCard.AutoSize = True
        Me.lblValidThruOfIdentityCard.BackColor = System.Drawing.Color.Transparent
        Me.lblValidThruOfIdentityCard.ForeColor = System.Drawing.Color.Black
        Me.lblValidThruOfIdentityCard.Location = New System.Drawing.Point(20, 143)
        Me.lblValidThruOfIdentityCard.Name = "lblValidThruOfIdentityCard"
        Me.lblValidThruOfIdentityCard.Size = New System.Drawing.Size(54, 13)
        Me.lblValidThruOfIdentityCard.TabIndex = 93
        Me.lblValidThruOfIdentityCard.Text = "Valid Thru"
        '
        'dtpValidThruOfIdentityCard
        '
        Me.dtpValidThruOfIdentityCard.CustomFormat = "dd/MM/yyyy"
        Me.dtpValidThruOfIdentityCard.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpValidThruOfIdentityCard.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpValidThruOfIdentityCard.Location = New System.Drawing.Point(93, 140)
        Me.dtpValidThruOfIdentityCard.Name = "dtpValidThruOfIdentityCard"
        Me.dtpValidThruOfIdentityCard.Size = New System.Drawing.Size(101, 21)
        Me.dtpValidThruOfIdentityCard.TabIndex = 3
        Me.dtpValidThruOfIdentityCard.Value = New Date(3000, 1, 1, 0, 0, 0, 0)
        '
        'lblValidThruOfDrivingLicense
        '
        Me.lblValidThruOfDrivingLicense.AutoSize = True
        Me.lblValidThruOfDrivingLicense.BackColor = System.Drawing.Color.Transparent
        Me.lblValidThruOfDrivingLicense.ForeColor = System.Drawing.Color.Black
        Me.lblValidThruOfDrivingLicense.Location = New System.Drawing.Point(21, 113)
        Me.lblValidThruOfDrivingLicense.Name = "lblValidThruOfDrivingLicense"
        Me.lblValidThruOfDrivingLicense.Size = New System.Drawing.Size(54, 13)
        Me.lblValidThruOfDrivingLicense.TabIndex = 93
        Me.lblValidThruOfDrivingLicense.Text = "Valid Thru"
        '
        'dtpValidThruOfDrivingLicense
        '
        Me.dtpValidThruOfDrivingLicense.CustomFormat = "dd/MM/yyyy"
        Me.dtpValidThruOfDrivingLicense.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpValidThruOfDrivingLicense.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpValidThruOfDrivingLicense.Location = New System.Drawing.Point(100, 109)
        Me.dtpValidThruOfDrivingLicense.Name = "dtpValidThruOfDrivingLicense"
        Me.dtpValidThruOfDrivingLicense.Size = New System.Drawing.Size(101, 21)
        Me.dtpValidThruOfDrivingLicense.TabIndex = 2
        Me.dtpValidThruOfDrivingLicense.Value = New Date(2000, 1, 1, 0, 0, 0, 0)
        '
        'lblDrivingLicenseTypeID
        '
        Me.lblDrivingLicenseTypeID.AutoSize = True
        Me.lblDrivingLicenseTypeID.BackColor = System.Drawing.Color.Transparent
        Me.lblDrivingLicenseTypeID.ForeColor = System.Drawing.Color.Black
        Me.lblDrivingLicenseTypeID.Location = New System.Drawing.Point(21, 140)
        Me.lblDrivingLicenseTypeID.Name = "lblDrivingLicenseTypeID"
        Me.lblDrivingLicenseTypeID.Size = New System.Drawing.Size(48, 13)
        Me.lblDrivingLicenseTypeID.TabIndex = 93
        Me.lblDrivingLicenseTypeID.Text = "Tipe SIM"
        '
        'tcDriver
        '
        Me.tcDriver.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tcDriver.Controls.Add(Me.tpMain)
        Me.tcDriver.Controls.Add(Me.tpIdentityCard)
        Me.tcDriver.Controls.Add(Me.tpDrivingLicense)
        Me.tcDriver.Controls.Add(Me.tpHistory)
        Me.tcDriver.Controls.Add(Me.tpAdditionalInfo)
        Me.tcDriver.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcDriver.Location = New System.Drawing.Point(0, 50)
        Me.tcDriver.Name = "tcDriver"
        Me.tcDriver.SelectedIndex = 0
        Me.tcDriver.Size = New System.Drawing.Size(828, 330)
        Me.tcDriver.TabIndex = 2
        '
        'tpMain
        '
        Me.tpMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpMain.Controls.Add(Me.btnChooseFaceRecognation)
        Me.tpMain.Controls.Add(Me.Label5)
        Me.tpMain.Controls.Add(Me.txtPathFaceRecognation)
        Me.tpMain.Controls.Add(Me.cboStatus)
        Me.tpMain.Controls.Add(Me.lblIDStatus)
        Me.tpMain.Controls.Add(Me.lblReferencesID)
        Me.tpMain.Controls.Add(Me.txtReferencesID)
        Me.tpMain.Controls.Add(Me.lblInternalRemarks)
        Me.tpMain.Controls.Add(Me.txtInternalRemarks)
        Me.tpMain.Controls.Add(Me.lblRemarks)
        Me.tpMain.Controls.Add(Me.txtRemarks)
        Me.tpMain.Controls.Add(Me.lblPlaceOfBirth)
        Me.tpMain.Controls.Add(Me.txtPlaceOfBirth)
        Me.tpMain.Controls.Add(Me.lblDateOfBirth)
        Me.tpMain.Controls.Add(Me.dtpDateOfBirth)
        Me.tpMain.Controls.Add(Me.lblFullName)
        Me.tpMain.Controls.Add(Me.txtFullName)
        Me.tpMain.Controls.Add(Me.lblID)
        Me.tpMain.Controls.Add(Me.txtID)
        Me.tpMain.Controls.Add(Me.PanelControl1)
        Me.tpMain.Location = New System.Drawing.Point(4, 25)
        Me.tpMain.Name = "tpMain"
        Me.tpMain.Size = New System.Drawing.Size(820, 301)
        Me.tpMain.TabIndex = 2
        Me.tpMain.Text = "Main - F1"
        Me.tpMain.UseVisualStyleBackColor = True
        '
        'btnChooseFaceRecognation
        '
        Me.btnChooseFaceRecognation.BackColor = System.Drawing.Color.Transparent
        Me.btnChooseFaceRecognation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnChooseFaceRecognation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChooseFaceRecognation.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChooseFaceRecognation.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnChooseFaceRecognation.Image = CType(resources.GetObject("btnChooseFaceRecognation.Image"), System.Drawing.Image)
        Me.btnChooseFaceRecognation.Location = New System.Drawing.Point(791, 257)
        Me.btnChooseFaceRecognation.Name = "btnChooseFaceRecognation"
        Me.btnChooseFaceRecognation.Size = New System.Drawing.Size(19, 20)
        Me.btnChooseFaceRecognation.TabIndex = 10
        Me.btnChooseFaceRecognation.TabStop = False
        Me.btnChooseFaceRecognation.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(439, 261)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 112
        Me.Label5.Text = "Source"
        '
        'txtPathFaceRecognation
        '
        Me.txtPathFaceRecognation.BackColor = System.Drawing.Color.LightYellow
        Me.txtPathFaceRecognation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPathFaceRecognation.Location = New System.Drawing.Point(485, 257)
        Me.txtPathFaceRecognation.MaxLength = 250
        Me.txtPathFaceRecognation.Name = "txtPathFaceRecognation"
        Me.txtPathFaceRecognation.ReadOnly = True
        Me.txtPathFaceRecognation.Size = New System.Drawing.Size(304, 21)
        Me.txtPathFaceRecognation.TabIndex = 9
        '
        'cboStatus
        '
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.Enabled = False
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(121, 99)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(177, 21)
        Me.cboStatus.TabIndex = 4
        '
        'lblIDStatus
        '
        Me.lblIDStatus.AutoSize = True
        Me.lblIDStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblIDStatus.ForeColor = System.Drawing.Color.Black
        Me.lblIDStatus.Location = New System.Drawing.Point(26, 102)
        Me.lblIDStatus.Name = "lblIDStatus"
        Me.lblIDStatus.Size = New System.Drawing.Size(38, 13)
        Me.lblIDStatus.TabIndex = 109
        Me.lblIDStatus.Text = "Status"
        '
        'lblReferencesID
        '
        Me.lblReferencesID.AutoSize = True
        Me.lblReferencesID.BackColor = System.Drawing.Color.Transparent
        Me.lblReferencesID.ForeColor = System.Drawing.Color.Black
        Me.lblReferencesID.Location = New System.Drawing.Point(26, 261)
        Me.lblReferencesID.Name = "lblReferencesID"
        Me.lblReferencesID.Size = New System.Drawing.Size(76, 13)
        Me.lblReferencesID.TabIndex = 105
        Me.lblReferencesID.Text = "References ID"
        '
        'txtReferencesID
        '
        Me.txtReferencesID.BackColor = System.Drawing.Color.LightYellow
        Me.txtReferencesID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtReferencesID.Location = New System.Drawing.Point(121, 257)
        Me.txtReferencesID.MaxLength = 250
        Me.txtReferencesID.Name = "txtReferencesID"
        Me.txtReferencesID.ReadOnly = True
        Me.txtReferencesID.Size = New System.Drawing.Size(177, 21)
        Me.txtReferencesID.TabIndex = 7
        '
        'lblInternalRemarks
        '
        Me.lblInternalRemarks.AutoSize = True
        Me.lblInternalRemarks.BackColor = System.Drawing.Color.Transparent
        Me.lblInternalRemarks.ForeColor = System.Drawing.Color.Black
        Me.lblInternalRemarks.Location = New System.Drawing.Point(26, 129)
        Me.lblInternalRemarks.Name = "lblInternalRemarks"
        Me.lblInternalRemarks.Size = New System.Drawing.Size(89, 13)
        Me.lblInternalRemarks.TabIndex = 106
        Me.lblInternalRemarks.Text = "Internal Remarks"
        '
        'txtInternalRemarks
        '
        Me.txtInternalRemarks.BackColor = System.Drawing.Color.White
        Me.txtInternalRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtInternalRemarks.Location = New System.Drawing.Point(121, 126)
        Me.txtInternalRemarks.MaxLength = 250
        Me.txtInternalRemarks.Multiline = True
        Me.txtInternalRemarks.Name = "txtInternalRemarks"
        Me.txtInternalRemarks.Size = New System.Drawing.Size(300, 60)
        Me.txtInternalRemarks.TabIndex = 5
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.BackColor = System.Drawing.Color.Transparent
        Me.lblRemarks.ForeColor = System.Drawing.Color.Black
        Me.lblRemarks.Location = New System.Drawing.Point(26, 195)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(48, 13)
        Me.lblRemarks.TabIndex = 107
        Me.lblRemarks.Text = "Remarks"
        '
        'txtRemarks
        '
        Me.txtRemarks.BackColor = System.Drawing.Color.White
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Location = New System.Drawing.Point(121, 192)
        Me.txtRemarks.MaxLength = 250
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(300, 60)
        Me.txtRemarks.TabIndex = 6
        '
        'lblPlaceOfBirth
        '
        Me.lblPlaceOfBirth.AutoSize = True
        Me.lblPlaceOfBirth.BackColor = System.Drawing.Color.Transparent
        Me.lblPlaceOfBirth.ForeColor = System.Drawing.Color.Black
        Me.lblPlaceOfBirth.Location = New System.Drawing.Point(26, 75)
        Me.lblPlaceOfBirth.Name = "lblPlaceOfBirth"
        Me.lblPlaceOfBirth.Size = New System.Drawing.Size(90, 13)
        Me.lblPlaceOfBirth.TabIndex = 100
        Me.lblPlaceOfBirth.Text = "Place / Birth Date"
        '
        'txtPlaceOfBirth
        '
        Me.txtPlaceOfBirth.BackColor = System.Drawing.Color.White
        Me.txtPlaceOfBirth.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPlaceOfBirth.Location = New System.Drawing.Point(121, 72)
        Me.txtPlaceOfBirth.MaxLength = 250
        Me.txtPlaceOfBirth.Name = "txtPlaceOfBirth"
        Me.txtPlaceOfBirth.Size = New System.Drawing.Size(177, 21)
        Me.txtPlaceOfBirth.TabIndex = 2
        '
        'lblDateOfBirth
        '
        Me.lblDateOfBirth.AutoSize = True
        Me.lblDateOfBirth.BackColor = System.Drawing.Color.Transparent
        Me.lblDateOfBirth.ForeColor = System.Drawing.Color.Black
        Me.lblDateOfBirth.Location = New System.Drawing.Point(305, 75)
        Me.lblDateOfBirth.Name = "lblDateOfBirth"
        Me.lblDateOfBirth.Size = New System.Drawing.Size(11, 13)
        Me.lblDateOfBirth.TabIndex = 101
        Me.lblDateOfBirth.Text = "/"
        '
        'dtpDateOfBirth
        '
        Me.dtpDateOfBirth.CustomFormat = "dd/MM/yyyy"
        Me.dtpDateOfBirth.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateOfBirth.Location = New System.Drawing.Point(320, 72)
        Me.dtpDateOfBirth.Name = "dtpDateOfBirth"
        Me.dtpDateOfBirth.Size = New System.Drawing.Size(101, 21)
        Me.dtpDateOfBirth.TabIndex = 3
        Me.dtpDateOfBirth.Value = New Date(1900, 1, 1, 0, 0, 0, 0)
        '
        'lblFullName
        '
        Me.lblFullName.AutoSize = True
        Me.lblFullName.BackColor = System.Drawing.Color.Transparent
        Me.lblFullName.ForeColor = System.Drawing.Color.Black
        Me.lblFullName.Location = New System.Drawing.Point(26, 48)
        Me.lblFullName.Name = "lblFullName"
        Me.lblFullName.Size = New System.Drawing.Size(53, 13)
        Me.lblFullName.TabIndex = 97
        Me.lblFullName.Text = "Full Name"
        '
        'txtFullName
        '
        Me.txtFullName.BackColor = System.Drawing.Color.White
        Me.txtFullName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtFullName.Location = New System.Drawing.Point(121, 45)
        Me.txtFullName.MaxLength = 250
        Me.txtFullName.Name = "txtFullName"
        Me.txtFullName.Size = New System.Drawing.Size(300, 21)
        Me.txtFullName.TabIndex = 1
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.Color.Transparent
        Me.lblID.ForeColor = System.Drawing.Color.Black
        Me.lblID.Location = New System.Drawing.Point(26, 21)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(18, 13)
        Me.lblID.TabIndex = 95
        Me.lblID.Text = "ID"
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.LightYellow
        Me.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtID.Location = New System.Drawing.Point(121, 18)
        Me.txtID.MaxLength = 250
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(177, 21)
        Me.txtID.TabIndex = 0
        '
        'PanelControl1
        '
        Me.PanelControl1.Controls.Add(Me.peFaceRecognation)
        Me.PanelControl1.Controls.Add(Me.Label8)
        Me.PanelControl1.Location = New System.Drawing.Point(485, 18)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(304, 234)
        Me.PanelControl1.TabIndex = 8
        '
        'peFaceRecognation
        '
        Me.peFaceRecognation.Dock = System.Windows.Forms.DockStyle.Fill
        Me.peFaceRecognation.EditValue = ""
        Me.peFaceRecognation.Location = New System.Drawing.Point(0, 0)
        Me.peFaceRecognation.Name = "peFaceRecognation"
        Me.peFaceRecognation.Properties.Caption.Alignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.peFaceRecognation.Properties.InitialImage = Nothing
        Me.peFaceRecognation.Properties.ReadOnly = True
        Me.peFaceRecognation.Properties.ShowMenu = False
        Me.peFaceRecognation.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom
        Me.peFaceRecognation.Size = New System.Drawing.Size(304, 234)
        Me.peFaceRecognation.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.Label8.ForeColor = System.Drawing.Color.CadetBlue
        Me.Label8.Location = New System.Drawing.Point(33, 111)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(243, 27)
        Me.Label8.TabIndex = 107
        Me.Label8.Text = "FACE RECOGNATION"
        '
        'tpIdentityCard
        '
        Me.tpIdentityCard.AutoScroll = True
        Me.tpIdentityCard.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpIdentityCard.Controls.Add(Me.btnChooseIdentityCard)
        Me.tpIdentityCard.Controls.Add(Me.Label6)
        Me.tpIdentityCard.Controls.Add(Me.txtPathIdentityCard)
        Me.tpIdentityCard.Controls.Add(Me.cboNationality)
        Me.tpIdentityCard.Controls.Add(Me.lblAddressOfIdentityCard)
        Me.tpIdentityCard.Controls.Add(Me.lblValidThruOfIdentityCard)
        Me.tpIdentityCard.Controls.Add(Me.dtpValidThruOfIdentityCard)
        Me.tpIdentityCard.Controls.Add(Me.txtAddressOfIdentityCard)
        Me.tpIdentityCard.Controls.Add(Me.lblNationalityID)
        Me.tpIdentityCard.Controls.Add(Me.txtIdentityCardNumber)
        Me.tpIdentityCard.Controls.Add(Me.lblIdentityCardNumber)
        Me.tpIdentityCard.Controls.Add(Me.PanelControl2)
        Me.tpIdentityCard.Location = New System.Drawing.Point(4, 25)
        Me.tpIdentityCard.Name = "tpIdentityCard"
        Me.tpIdentityCard.Padding = New System.Windows.Forms.Padding(3)
        Me.tpIdentityCard.Size = New System.Drawing.Size(820, 301)
        Me.tpIdentityCard.TabIndex = 0
        Me.tpIdentityCard.Text = "KTP - F2"
        Me.tpIdentityCard.UseVisualStyleBackColor = True
        '
        'btnChooseIdentityCard
        '
        Me.btnChooseIdentityCard.BackColor = System.Drawing.Color.Transparent
        Me.btnChooseIdentityCard.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnChooseIdentityCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChooseIdentityCard.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChooseIdentityCard.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnChooseIdentityCard.Image = CType(resources.GetObject("btnChooseIdentityCard.Image"), System.Drawing.Image)
        Me.btnChooseIdentityCard.Location = New System.Drawing.Point(784, 259)
        Me.btnChooseIdentityCard.Name = "btnChooseIdentityCard"
        Me.btnChooseIdentityCard.Size = New System.Drawing.Size(19, 20)
        Me.btnChooseIdentityCard.TabIndex = 12
        Me.btnChooseIdentityCard.TabStop = False
        Me.btnChooseIdentityCard.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(432, 263)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 116
        Me.Label6.Text = "Source"
        '
        'txtPathIdentityCard
        '
        Me.txtPathIdentityCard.BackColor = System.Drawing.Color.LightYellow
        Me.txtPathIdentityCard.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPathIdentityCard.Location = New System.Drawing.Point(478, 259)
        Me.txtPathIdentityCard.MaxLength = 250
        Me.txtPathIdentityCard.Name = "txtPathIdentityCard"
        Me.txtPathIdentityCard.ReadOnly = True
        Me.txtPathIdentityCard.Size = New System.Drawing.Size(304, 21)
        Me.txtPathIdentityCard.TabIndex = 11
        '
        'cboNationality
        '
        Me.cboNationality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboNationality.FormattingEnabled = True
        Me.cboNationality.Location = New System.Drawing.Point(93, 113)
        Me.cboNationality.Name = "cboNationality"
        Me.cboNationality.Size = New System.Drawing.Size(135, 21)
        Me.cboNationality.TabIndex = 2
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.peIdentityCard)
        Me.PanelControl2.Controls.Add(Me.Label9)
        Me.PanelControl2.Location = New System.Drawing.Point(478, 20)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(304, 234)
        Me.PanelControl2.TabIndex = 10
        '
        'peIdentityCard
        '
        Me.peIdentityCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.peIdentityCard.EditValue = ""
        Me.peIdentityCard.Location = New System.Drawing.Point(0, 0)
        Me.peIdentityCard.Name = "peIdentityCard"
        Me.peIdentityCard.Properties.Caption.Alignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.peIdentityCard.Properties.InitialImage = Nothing
        Me.peIdentityCard.Properties.ReadOnly = True
        Me.peIdentityCard.Properties.ShowMenu = False
        Me.peIdentityCard.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom
        Me.peIdentityCard.Size = New System.Drawing.Size(304, 234)
        Me.peIdentityCard.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.Label9.ForeColor = System.Drawing.Color.CadetBlue
        Me.Label9.Location = New System.Drawing.Point(61, 111)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(192, 27)
        Me.Label9.TabIndex = 107
        Me.Label9.Text = "IDENTITY CARD"
        '
        'tpDrivingLicense
        '
        Me.tpDrivingLicense.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpDrivingLicense.Controls.Add(Me.PanelControl3)
        Me.tpDrivingLicense.Controls.Add(Me.btnChooseDrivingLicense)
        Me.tpDrivingLicense.Controls.Add(Me.Label7)
        Me.tpDrivingLicense.Controls.Add(Me.txtPathDrivingLicense)
        Me.tpDrivingLicense.Controls.Add(Me.cboDrivingLicenseType)
        Me.tpDrivingLicense.Controls.Add(Me.lblDrivingLicenseNumber)
        Me.tpDrivingLicense.Controls.Add(Me.txtAddressOfDrivingLicense)
        Me.tpDrivingLicense.Controls.Add(Me.txtDrivingLicenseNumber)
        Me.tpDrivingLicense.Controls.Add(Me.lblAddressOfDrivingLicense)
        Me.tpDrivingLicense.Controls.Add(Me.lblValidThruOfDrivingLicense)
        Me.tpDrivingLicense.Controls.Add(Me.lblDrivingLicenseTypeID)
        Me.tpDrivingLicense.Controls.Add(Me.dtpValidThruOfDrivingLicense)
        Me.tpDrivingLicense.Location = New System.Drawing.Point(4, 25)
        Me.tpDrivingLicense.Name = "tpDrivingLicense"
        Me.tpDrivingLicense.Padding = New System.Windows.Forms.Padding(3)
        Me.tpDrivingLicense.Size = New System.Drawing.Size(820, 301)
        Me.tpDrivingLicense.TabIndex = 1
        Me.tpDrivingLicense.Text = "SIM - F3"
        Me.tpDrivingLicense.UseVisualStyleBackColor = True
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.peDrivingLicense)
        Me.PanelControl3.Controls.Add(Me.Label10)
        Me.PanelControl3.Location = New System.Drawing.Point(482, 15)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(304, 234)
        Me.PanelControl3.TabIndex = 7
        '
        'peDrivingLicense
        '
        Me.peDrivingLicense.Dock = System.Windows.Forms.DockStyle.Fill
        Me.peDrivingLicense.EditValue = ""
        Me.peDrivingLicense.Location = New System.Drawing.Point(0, 0)
        Me.peDrivingLicense.Name = "peDrivingLicense"
        Me.peDrivingLicense.Properties.Caption.Alignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.peDrivingLicense.Properties.InitialImage = Nothing
        Me.peDrivingLicense.Properties.ShowMenu = False
        Me.peDrivingLicense.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom
        Me.peDrivingLicense.Size = New System.Drawing.Size(304, 234)
        Me.peDrivingLicense.TabIndex = 0
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.Label10.ForeColor = System.Drawing.Color.CadetBlue
        Me.Label10.Location = New System.Drawing.Point(44, 110)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(219, 27)
        Me.Label10.TabIndex = 107
        Me.Label10.Text = "DRIVING LICENSE"
        '
        'btnChooseDrivingLicense
        '
        Me.btnChooseDrivingLicense.BackColor = System.Drawing.Color.Transparent
        Me.btnChooseDrivingLicense.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnChooseDrivingLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChooseDrivingLicense.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChooseDrivingLicense.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnChooseDrivingLicense.Image = CType(resources.GetObject("btnChooseDrivingLicense.Image"), System.Drawing.Image)
        Me.btnChooseDrivingLicense.Location = New System.Drawing.Point(788, 255)
        Me.btnChooseDrivingLicense.Name = "btnChooseDrivingLicense"
        Me.btnChooseDrivingLicense.Size = New System.Drawing.Size(19, 20)
        Me.btnChooseDrivingLicense.TabIndex = 9
        Me.btnChooseDrivingLicense.TabStop = False
        Me.btnChooseDrivingLicense.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(436, 259)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 120
        Me.Label7.Text = "Source"
        '
        'txtPathDrivingLicense
        '
        Me.txtPathDrivingLicense.BackColor = System.Drawing.Color.LightYellow
        Me.txtPathDrivingLicense.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPathDrivingLicense.Location = New System.Drawing.Point(482, 255)
        Me.txtPathDrivingLicense.MaxLength = 250
        Me.txtPathDrivingLicense.Name = "txtPathDrivingLicense"
        Me.txtPathDrivingLicense.ReadOnly = True
        Me.txtPathDrivingLicense.Size = New System.Drawing.Size(304, 21)
        Me.txtPathDrivingLicense.TabIndex = 8
        '
        'cboDrivingLicenseType
        '
        Me.cboDrivingLicenseType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDrivingLicenseType.FormattingEnabled = True
        Me.cboDrivingLicenseType.Location = New System.Drawing.Point(100, 136)
        Me.cboDrivingLicenseType.Name = "cboDrivingLicenseType"
        Me.cboDrivingLicenseType.Size = New System.Drawing.Size(101, 21)
        Me.cboDrivingLicenseType.TabIndex = 3
        '
        'tpHistory
        '
        Me.tpHistory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpHistory.Controls.Add(Me.grdHistory)
        Me.tpHistory.Location = New System.Drawing.Point(4, 25)
        Me.tpHistory.Name = "tpHistory"
        Me.tpHistory.Size = New System.Drawing.Size(820, 301)
        Me.tpHistory.TabIndex = 4
        Me.tpHistory.Text = "Status History - F4"
        Me.tpHistory.UseVisualStyleBackColor = True
        '
        'grdHistory
        '
        Me.grdHistory.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdHistory.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdHistory.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdHistory.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdHistory.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdHistory.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdHistory.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdHistory.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdHistory.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdHistory.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdHistory.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdHistory.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdHistory.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdHistory.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdHistory.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdHistory.Location = New System.Drawing.Point(0, 0)
        Me.grdHistory.MainView = Me.grdHistoryView
        Me.grdHistory.Name = "grdHistory"
        Me.grdHistory.Size = New System.Drawing.Size(816, 297)
        Me.grdHistory.TabIndex = 3
        Me.grdHistory.UseEmbeddedNavigator = True
        Me.grdHistory.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdHistoryView})
        '
        'grdHistoryView
        '
        Me.grdHistoryView.GridControl = Me.grdHistory
        Me.grdHistoryView.Name = "grdHistoryView"
        Me.grdHistoryView.OptionsCustomization.AllowColumnMoving = False
        Me.grdHistoryView.OptionsCustomization.AllowGroup = False
        Me.grdHistoryView.OptionsView.ColumnAutoWidth = False
        Me.grdHistoryView.OptionsView.ShowGroupPanel = False
        '
        'tpAdditionalInfo
        '
        Me.tpAdditionalInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpAdditionalInfo.Controls.Add(Me.gboLastUpdatedFrom)
        Me.tpAdditionalInfo.Controls.Add(Me.gboCreatedFrom)
        Me.tpAdditionalInfo.Location = New System.Drawing.Point(4, 25)
        Me.tpAdditionalInfo.Name = "tpAdditionalInfo"
        Me.tpAdditionalInfo.Size = New System.Drawing.Size(820, 301)
        Me.tpAdditionalInfo.TabIndex = 3
        Me.tpAdditionalInfo.Text = "Additional Info - F5"
        Me.tpAdditionalInfo.UseVisualStyleBackColor = True
        '
        'gboLastUpdatedFrom
        '
        Me.gboLastUpdatedFrom.Controls.Add(Me.Label3)
        Me.gboLastUpdatedFrom.Controls.Add(Me.txtLastUpdatedFromCompany)
        Me.gboLastUpdatedFrom.Controls.Add(Me.txtLastUpdatedFromLocation)
        Me.gboLastUpdatedFrom.Controls.Add(Me.Label4)
        Me.gboLastUpdatedFrom.Location = New System.Drawing.Point(295, 12)
        Me.gboLastUpdatedFrom.Name = "gboLastUpdatedFrom"
        Me.gboLastUpdatedFrom.Size = New System.Drawing.Size(272, 93)
        Me.gboLastUpdatedFrom.TabIndex = 11
        Me.gboLastUpdatedFrom.TabStop = False
        Me.gboLastUpdatedFrom.Text = "Last Updated From"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(17, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 116
        Me.Label3.Text = "Location"
        '
        'txtLastUpdatedFromCompany
        '
        Me.txtLastUpdatedFromCompany.BackColor = System.Drawing.Color.LightYellow
        Me.txtLastUpdatedFromCompany.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtLastUpdatedFromCompany.Location = New System.Drawing.Point(89, 23)
        Me.txtLastUpdatedFromCompany.MaxLength = 250
        Me.txtLastUpdatedFromCompany.Name = "txtLastUpdatedFromCompany"
        Me.txtLastUpdatedFromCompany.ReadOnly = True
        Me.txtLastUpdatedFromCompany.ShortcutsEnabled = False
        Me.txtLastUpdatedFromCompany.Size = New System.Drawing.Size(163, 21)
        Me.txtLastUpdatedFromCompany.TabIndex = 0
        '
        'txtLastUpdatedFromLocation
        '
        Me.txtLastUpdatedFromLocation.BackColor = System.Drawing.Color.LightYellow
        Me.txtLastUpdatedFromLocation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtLastUpdatedFromLocation.Location = New System.Drawing.Point(89, 50)
        Me.txtLastUpdatedFromLocation.MaxLength = 250
        Me.txtLastUpdatedFromLocation.Name = "txtLastUpdatedFromLocation"
        Me.txtLastUpdatedFromLocation.ReadOnly = True
        Me.txtLastUpdatedFromLocation.ShortcutsEnabled = False
        Me.txtLastUpdatedFromLocation.Size = New System.Drawing.Size(163, 21)
        Me.txtLastUpdatedFromLocation.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(17, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 112
        Me.Label4.Text = "Company"
        '
        'gboCreatedFrom
        '
        Me.gboCreatedFrom.Controls.Add(Me.Label2)
        Me.gboCreatedFrom.Controls.Add(Me.txtCreatedFromCompany)
        Me.gboCreatedFrom.Controls.Add(Me.txtCreatedFromLocation)
        Me.gboCreatedFrom.Controls.Add(Me.lblCreatedFromComLocID)
        Me.gboCreatedFrom.Location = New System.Drawing.Point(17, 12)
        Me.gboCreatedFrom.Name = "gboCreatedFrom"
        Me.gboCreatedFrom.Size = New System.Drawing.Size(272, 93)
        Me.gboCreatedFrom.TabIndex = 10
        Me.gboCreatedFrom.TabStop = False
        Me.gboCreatedFrom.Text = "Created From"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(17, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 116
        Me.Label2.Text = "Location"
        '
        'txtCreatedFromCompany
        '
        Me.txtCreatedFromCompany.BackColor = System.Drawing.Color.LightYellow
        Me.txtCreatedFromCompany.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCreatedFromCompany.Location = New System.Drawing.Point(89, 23)
        Me.txtCreatedFromCompany.MaxLength = 250
        Me.txtCreatedFromCompany.Name = "txtCreatedFromCompany"
        Me.txtCreatedFromCompany.ReadOnly = True
        Me.txtCreatedFromCompany.ShortcutsEnabled = False
        Me.txtCreatedFromCompany.Size = New System.Drawing.Size(163, 21)
        Me.txtCreatedFromCompany.TabIndex = 0
        '
        'txtCreatedFromLocation
        '
        Me.txtCreatedFromLocation.BackColor = System.Drawing.Color.LightYellow
        Me.txtCreatedFromLocation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCreatedFromLocation.Location = New System.Drawing.Point(89, 50)
        Me.txtCreatedFromLocation.MaxLength = 250
        Me.txtCreatedFromLocation.Name = "txtCreatedFromLocation"
        Me.txtCreatedFromLocation.ReadOnly = True
        Me.txtCreatedFromLocation.ShortcutsEnabled = False
        Me.txtCreatedFromLocation.Size = New System.Drawing.Size(163, 21)
        Me.txtCreatedFromLocation.TabIndex = 1
        '
        'lblCreatedFromComLocID
        '
        Me.lblCreatedFromComLocID.AutoSize = True
        Me.lblCreatedFromComLocID.BackColor = System.Drawing.Color.Transparent
        Me.lblCreatedFromComLocID.ForeColor = System.Drawing.Color.Black
        Me.lblCreatedFromComLocID.Location = New System.Drawing.Point(17, 27)
        Me.lblCreatedFromComLocID.Name = "lblCreatedFromComLocID"
        Me.lblCreatedFromComLocID.Size = New System.Drawing.Size(52, 13)
        Me.lblCreatedFromComLocID.TabIndex = 112
        Me.lblCreatedFromComLocID.Text = "Company"
        '
        'frmMstDriverDet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(828, 402)
        Me.Controls.Add(Me.tcDriver)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.ToolBar)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMstDriverDet"
        Me.Text = "Driver"
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.tcDriver.ResumeLayout(False)
        Me.tpMain.ResumeLayout(False)
        Me.tpMain.PerformLayout()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        Me.PanelControl1.PerformLayout()
        CType(Me.peFaceRecognation.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpIdentityCard.ResumeLayout(False)
        Me.tpIdentityCard.PerformLayout()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.PanelControl2.PerformLayout()
        CType(Me.peIdentityCard.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpDrivingLicense.ResumeLayout(False)
        Me.tpDrivingLicense.PerformLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        Me.PanelControl3.PerformLayout()
        CType(Me.peDrivingLicense.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpHistory.ResumeLayout(False)
        CType(Me.grdHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdHistoryView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpAdditionalInfo.ResumeLayout(False)
        Me.gboLastUpdatedFrom.ResumeLayout(False)
        Me.gboLastUpdatedFrom.PerformLayout()
        Me.gboCreatedFrom.ResumeLayout(False)
        Me.gboCreatedFrom.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolBar As QMS.usToolBar
    Friend WithEvents BarSave As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripEmpty As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogInc As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogBy As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLogDate As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblIdentityCardNumber As System.Windows.Forms.Label
    Friend WithEvents txtIdentityCardNumber As usTextBox
    Friend WithEvents lblDrivingLicenseNumber As System.Windows.Forms.Label
    Friend WithEvents txtDrivingLicenseNumber As usTextBox
    Friend WithEvents lblAddressOfIdentityCard As System.Windows.Forms.Label
    Friend WithEvents txtAddressOfIdentityCard As usTextBox
    Friend WithEvents lblAddressOfDrivingLicense As System.Windows.Forms.Label
    Friend WithEvents txtAddressOfDrivingLicense As usTextBox
    Friend WithEvents lblNationalityID As System.Windows.Forms.Label
    Friend WithEvents lblValidThruOfIdentityCard As System.Windows.Forms.Label
    Friend WithEvents dtpValidThruOfIdentityCard As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblValidThruOfDrivingLicense As System.Windows.Forms.Label
    Friend WithEvents dtpValidThruOfDrivingLicense As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDrivingLicenseTypeID As System.Windows.Forms.Label
    Friend WithEvents tcDriver As System.Windows.Forms.TabControl
    Friend WithEvents tpMain As System.Windows.Forms.TabPage
    Friend WithEvents lblPlaceOfBirth As System.Windows.Forms.Label
    Friend WithEvents txtPlaceOfBirth As QMS.usTextBox
    Friend WithEvents lblDateOfBirth As System.Windows.Forms.Label
    Friend WithEvents dtpDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblFullName As System.Windows.Forms.Label
    Friend WithEvents txtFullName As QMS.usTextBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtID As QMS.usTextBox
    Friend WithEvents tpIdentityCard As System.Windows.Forms.TabPage
    Friend WithEvents tpDrivingLicense As System.Windows.Forms.TabPage
    Friend WithEvents lblIDStatus As System.Windows.Forms.Label
    Friend WithEvents lblReferencesID As System.Windows.Forms.Label
    Friend WithEvents txtReferencesID As QMS.usTextBox
    Friend WithEvents lblInternalRemarks As System.Windows.Forms.Label
    Friend WithEvents txtInternalRemarks As QMS.usTextBox
    Friend WithEvents cboNationality As QMSLib.usComboBox
    Friend WithEvents cboDrivingLicenseType As QMSLib.usComboBox
    Friend WithEvents cboStatus As QMSLib.usComboBox
    Friend WithEvents tpHistory As System.Windows.Forms.TabPage
    Friend WithEvents tpAdditionalInfo As System.Windows.Forms.TabPage
    Friend WithEvents gboLastUpdatedFrom As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtLastUpdatedFromCompany As QMS.usTextBox
    Friend WithEvents txtLastUpdatedFromLocation As QMS.usTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents gboCreatedFrom As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCreatedFromCompany As QMS.usTextBox
    Friend WithEvents txtCreatedFromLocation As QMS.usTextBox
    Friend WithEvents lblCreatedFromComLocID As System.Windows.Forms.Label
    Friend WithEvents peFaceRecognation As DevExpress.XtraEditors.PictureEdit
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPathFaceRecognation As QMS.usTextBox
    Friend WithEvents btnChooseFaceRecognation As System.Windows.Forms.Button
    Friend WithEvents grdHistory As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdHistoryView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents btnChooseIdentityCard As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtPathIdentityCard As QMS.usTextBox
    Friend WithEvents peIdentityCard As DevExpress.XtraEditors.PictureEdit
    Friend WithEvents btnChooseDrivingLicense As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPathDrivingLicense As QMS.usTextBox
    Friend WithEvents peDrivingLicense As DevExpress.XtraEditors.PictureEdit
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents txtRemarks As QMS.usTextBox
End Class


