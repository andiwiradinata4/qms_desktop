<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMstDriver
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMstDriver))
        Me.ToolBar = New QMS.usToolBar()
        Me.BarGet = New System.Windows.Forms.ToolBarButton()
        Me.BarSep1 = New System.Windows.Forms.ToolBarButton()
        Me.BarNew = New System.Windows.Forms.ToolBarButton()
        Me.BarDetail = New System.Windows.Forms.ToolBarButton()
        Me.BarDelete = New System.Windows.Forms.ToolBarButton()
        Me.BarSep2 = New System.Windows.Forms.ToolBarButton()
        Me.BarBlacklist = New System.Windows.Forms.ToolBarButton()
        Me.BarRevertBlackList = New System.Windows.Forms.ToolBarButton()
        Me.BarMerge = New System.Windows.Forms.ToolBarButton()
        Me.BarImportExcel = New System.Windows.Forms.ToolBarButton()
        Me.BarSep3 = New System.Windows.Forms.ToolBarButton()
        Me.BarRefresh = New System.Windows.Forms.ToolBarButton()
        Me.BarClose = New System.Windows.Forms.ToolBarButton()
        Me.grdMain = New DevExpress.XtraGrid.GridControl()
        Me.grdView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.pnlFilter = New System.Windows.Forms.Panel()
        Me.progressBar = New DevExpress.XtraWaitForm.ProgressPanel()
        Me.chkShowDuplicateOnly = New DevExpress.XtraEditors.CheckEdit()
        Me.txtFullName = New QMS.usTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.chkHideBlacklist = New DevExpress.XtraEditors.CheckEdit()
        Me.chkHideInactive = New DevExpress.XtraEditors.CheckEdit()
        Me.chkShowAllDriver = New DevExpress.XtraEditors.CheckEdit()
        Me.btnClear = New DevExpress.XtraEditors.SimpleButton()
        Me.btnExecute = New DevExpress.XtraEditors.SimpleButton()
        Me.txtDrivingLicenseNumber = New QMS.usTextBox()
        Me.txtIdentityCardNumber = New QMS.usTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFilter.SuspendLayout()
        CType(Me.chkShowDuplicateOnly.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkHideBlacklist.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkHideInactive.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkShowAllDriver.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarGet, Me.BarSep1, Me.BarNew, Me.BarDetail, Me.BarDelete, Me.BarSep2, Me.BarBlacklist, Me.BarRevertBlackList, Me.BarMerge, Me.BarImportExcel, Me.BarSep3, Me.BarRefresh, Me.BarClose})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(1114, 28)
        Me.ToolBar.TabIndex = 0
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarGet
        '
        Me.BarGet.Name = "BarGet"
        Me.BarGet.Tag = "Get"
        Me.BarGet.Text = "Get"
        '
        'BarSep1
        '
        Me.BarSep1.Name = "BarSep1"
        Me.BarSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarNew
        '
        Me.BarNew.Name = "BarNew"
        Me.BarNew.Tag = "New"
        Me.BarNew.Text = "New"
        '
        'BarDetail
        '
        Me.BarDetail.Name = "BarDetail"
        Me.BarDetail.Tag = "Detail"
        Me.BarDetail.Text = "Detail"
        '
        'BarDelete
        '
        Me.BarDelete.Name = "BarDelete"
        Me.BarDelete.Tag = "Delete"
        Me.BarDelete.Text = "Delete"
        '
        'BarSep2
        '
        Me.BarSep2.Name = "BarSep2"
        Me.BarSep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarBlacklist
        '
        Me.BarBlacklist.Name = "BarBlacklist"
        Me.BarBlacklist.Tag = "Sub"
        Me.BarBlacklist.Text = "Blacklist"
        '
        'BarRevertBlackList
        '
        Me.BarRevertBlackList.Name = "BarRevertBlackList"
        Me.BarRevertBlackList.Tag = "Alt"
        Me.BarRevertBlackList.Text = "Revert Blacklist"
        '
        'BarMerge
        '
        Me.BarMerge.Name = "BarMerge"
        Me.BarMerge.Tag = "Approved"
        Me.BarMerge.Text = "Merge"
        '
        'BarImportExcel
        '
        Me.BarImportExcel.Name = "BarImportExcel"
        Me.BarImportExcel.Tag = "Excel"
        Me.BarImportExcel.Text = "Import Excel"
        '
        'BarSep3
        '
        Me.BarSep3.Name = "BarSep3"
        Me.BarSep3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarRefresh
        '
        Me.BarRefresh.Name = "BarRefresh"
        Me.BarRefresh.Tag = "Refresh"
        Me.BarRefresh.Text = "Refresh"
        '
        'BarClose
        '
        Me.BarClose.Name = "BarClose"
        Me.BarClose.Tag = "Close"
        Me.BarClose.Text = "Close"
        '
        'grdMain
        '
        Me.grdMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdMain.EmbeddedNavigator.Buttons.Append.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.Append.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.Edit.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.Edit.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.EndEdit.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.EndEdit.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.NextPage.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.NextPage.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.PrevPage.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.PrevPage.Visible = False
        Me.grdMain.EmbeddedNavigator.Buttons.Remove.Enabled = False
        Me.grdMain.EmbeddedNavigator.Buttons.Remove.Visible = False
        Me.grdMain.Location = New System.Drawing.Point(0, 165)
        Me.grdMain.MainView = Me.grdView
        Me.grdMain.Name = "grdMain"
        Me.grdMain.Size = New System.Drawing.Size(1114, 447)
        Me.grdMain.TabIndex = 2
        Me.grdMain.UseEmbeddedNavigator = True
        Me.grdMain.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdView})
        '
        'grdView
        '
        Me.grdView.GridControl = Me.grdMain
        Me.grdView.Name = "grdView"
        Me.grdView.OptionsCustomization.AllowColumnMoving = False
        Me.grdView.OptionsCustomization.AllowGroup = False
        Me.grdView.OptionsView.ColumnAutoWidth = False
        Me.grdView.OptionsView.ShowAutoFilterRow = True
        Me.grdView.OptionsView.ShowGroupPanel = False
        '
        'pnlFilter
        '
        Me.pnlFilter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlFilter.Controls.Add(Me.progressBar)
        Me.pnlFilter.Controls.Add(Me.chkShowDuplicateOnly)
        Me.pnlFilter.Controls.Add(Me.txtFullName)
        Me.pnlFilter.Controls.Add(Me.Label4)
        Me.pnlFilter.Controls.Add(Me.chkHideBlacklist)
        Me.pnlFilter.Controls.Add(Me.chkHideInactive)
        Me.pnlFilter.Controls.Add(Me.chkShowAllDriver)
        Me.pnlFilter.Controls.Add(Me.btnClear)
        Me.pnlFilter.Controls.Add(Me.btnExecute)
        Me.pnlFilter.Controls.Add(Me.txtDrivingLicenseNumber)
        Me.pnlFilter.Controls.Add(Me.txtIdentityCardNumber)
        Me.pnlFilter.Controls.Add(Me.Label3)
        Me.pnlFilter.Controls.Add(Me.Label2)
        Me.pnlFilter.Controls.Add(Me.Label1)
        Me.pnlFilter.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlFilter.Location = New System.Drawing.Point(0, 28)
        Me.pnlFilter.Name = "pnlFilter"
        Me.pnlFilter.Size = New System.Drawing.Size(1114, 137)
        Me.pnlFilter.TabIndex = 1
        '
        'progressBar
        '
        Me.progressBar.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.progressBar.Appearance.Options.UseBackColor = True
        Me.progressBar.AppearanceCaption.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.progressBar.AppearanceCaption.Options.UseFont = True
        Me.progressBar.AppearanceDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.progressBar.AppearanceDescription.Options.UseFont = True
        Me.progressBar.Location = New System.Drawing.Point(888, 66)
        Me.progressBar.Name = "progressBar"
        Me.progressBar.Size = New System.Drawing.Size(145, 50)
        Me.progressBar.TabIndex = 13
        Me.progressBar.Text = "ProgressPanel1"
        Me.progressBar.Visible = False
        '
        'chkShowDuplicateOnly
        '
        Me.chkShowDuplicateOnly.Location = New System.Drawing.Point(926, 41)
        Me.chkShowDuplicateOnly.Name = "chkShowDuplicateOnly"
        Me.chkShowDuplicateOnly.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.chkShowDuplicateOnly.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray
        Me.chkShowDuplicateOnly.Properties.Appearance.Options.UseFont = True
        Me.chkShowDuplicateOnly.Properties.Appearance.Options.UseForeColor = True
        Me.chkShowDuplicateOnly.Properties.Caption = "Show Duplicate Only"
        Me.chkShowDuplicateOnly.Size = New System.Drawing.Size(144, 19)
        Me.chkShowDuplicateOnly.TabIndex = 6
        '
        'txtFullName
        '
        Me.txtFullName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtFullName.Location = New System.Drawing.Point(192, 80)
        Me.txtFullName.Name = "txtFullName"
        Me.txtFullName.Size = New System.Drawing.Size(381, 21)
        Me.txtFullName.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(26, 83)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Full Name"
        '
        'chkHideBlacklist
        '
        Me.chkHideBlacklist.EditValue = True
        Me.chkHideBlacklist.Location = New System.Drawing.Point(819, 41)
        Me.chkHideBlacklist.Name = "chkHideBlacklist"
        Me.chkHideBlacklist.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.chkHideBlacklist.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray
        Me.chkHideBlacklist.Properties.Appearance.Options.UseFont = True
        Me.chkHideBlacklist.Properties.Appearance.Options.UseForeColor = True
        Me.chkHideBlacklist.Properties.Caption = "Hide Blacklist"
        Me.chkHideBlacklist.Size = New System.Drawing.Size(101, 19)
        Me.chkHideBlacklist.TabIndex = 5
        '
        'chkHideInactive
        '
        Me.chkHideInactive.EditValue = True
        Me.chkHideInactive.Location = New System.Drawing.Point(712, 41)
        Me.chkHideInactive.Name = "chkHideInactive"
        Me.chkHideInactive.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.chkHideInactive.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray
        Me.chkHideInactive.Properties.Appearance.Options.UseFont = True
        Me.chkHideInactive.Properties.Appearance.Options.UseForeColor = True
        Me.chkHideInactive.Properties.Caption = "Hide Inactive"
        Me.chkHideInactive.Size = New System.Drawing.Size(101, 19)
        Me.chkHideInactive.TabIndex = 4
        '
        'chkShowAllDriver
        '
        Me.chkShowAllDriver.Location = New System.Drawing.Point(597, 41)
        Me.chkShowAllDriver.Name = "chkShowAllDriver"
        Me.chkShowAllDriver.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.chkShowAllDriver.Properties.Appearance.ForeColor = System.Drawing.Color.DimGray
        Me.chkShowAllDriver.Properties.Appearance.Options.UseFont = True
        Me.chkShowAllDriver.Properties.Appearance.Options.UseForeColor = True
        Me.chkShowAllDriver.Properties.Caption = "Show All Driver"
        Me.chkShowAllDriver.Size = New System.Drawing.Size(109, 19)
        Me.chkShowAllDriver.TabIndex = 3
        '
        'btnClear
        '
        Me.btnClear.Appearance.ForeColor = System.Drawing.Color.Black
        Me.btnClear.Appearance.Options.UseForeColor = True
        Me.btnClear.Image = CType(resources.GetObject("btnClear.Image"), System.Drawing.Image)
        Me.btnClear.Location = New System.Drawing.Point(739, 78)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 23)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        '
        'btnExecute
        '
        Me.btnExecute.Image = CType(resources.GetObject("btnExecute.Image"), System.Drawing.Image)
        Me.btnExecute.Location = New System.Drawing.Point(598, 78)
        Me.btnExecute.Name = "btnExecute"
        Me.btnExecute.Size = New System.Drawing.Size(125, 23)
        Me.btnExecute.TabIndex = 7
        Me.btnExecute.Text = "Execute"
        '
        'txtDrivingLicenseNumber
        '
        Me.txtDrivingLicenseNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDrivingLicenseNumber.Location = New System.Drawing.Point(192, 60)
        Me.txtDrivingLicenseNumber.Name = "txtDrivingLicenseNumber"
        Me.txtDrivingLicenseNumber.Size = New System.Drawing.Size(381, 21)
        Me.txtDrivingLicenseNumber.TabIndex = 1
        '
        'txtIdentityCardNumber
        '
        Me.txtIdentityCardNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtIdentityCardNumber.Location = New System.Drawing.Point(192, 40)
        Me.txtIdentityCardNumber.MaxLength = 20
        Me.txtIdentityCardNumber.Name = "txtIdentityCardNumber"
        Me.txtIdentityCardNumber.Size = New System.Drawing.Size(381, 21)
        Me.txtIdentityCardNumber.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(26, 43)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Identity Card Number"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(26, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(139, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Driving License Number"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label1.Location = New System.Drawing.Point(20, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Query Data By :"
        '
        'frmMstDriver
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1114, 612)
        Me.Controls.Add(Me.grdMain)
        Me.Controls.Add(Me.pnlFilter)
        Me.Controls.Add(Me.ToolBar)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.KeyPreview = True
        Me.Name = "frmMstDriver"
        Me.Text = "Master Driver"
        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFilter.ResumeLayout(False)
        Me.pnlFilter.PerformLayout()
        CType(Me.chkShowDuplicateOnly.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkHideBlacklist.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkHideInactive.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkShowAllDriver.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolBar As QMS.usToolBar
    Friend WithEvents BarGet As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarNew As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarDetail As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarDelete As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarRefresh As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton
    Friend WithEvents grdMain As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents pnlFilter As System.Windows.Forms.Panel
    Friend WithEvents chkHideBlacklist As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkHideInactive As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkShowAllDriver As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents btnClear As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnExecute As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents txtDrivingLicenseNumber As QMS.usTextBox
    Friend WithEvents txtIdentityCardNumber As QMS.usTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BarBlacklist As System.Windows.Forms.ToolBarButton
    Friend WithEvents txtFullName As QMS.usTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents BarMerge As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents chkShowDuplicateOnly As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents BarRevertBlackList As System.Windows.Forms.ToolBarButton
    Friend WithEvents progressBar As DevExpress.XtraWaitForm.ProgressPanel
    Friend WithEvents BarImportExcel As System.Windows.Forms.ToolBarButton
End Class


