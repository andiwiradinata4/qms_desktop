Public Class frmMstDriver

#Region "Properties Handle"

    Public pubLUdtRow As DataRow
    Public pubIsLookUp As Boolean = False
    Public pubIsLookUpGet As Boolean = False
    Public pubLUID As String = ""

    Private clsData As VO.Driver
    Private intPos As Integer
    Private Const _
       cGet = 0, cSep1 = 1, cNew = 2, cDetail = 3, cDelete = 4, cSep2 = 5, cBlacklist = 6, cRevertBlackList = 7, cMerge = 8, cImportExcel = 9, cSep3 = 10, cRefresh = 11, cClose = 12

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IdentityCardNumber", "NIK No.", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DrivingLicenseNumber", "SIM No.", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "FullName", "Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "PlaceOfBirth", "Place of Birth", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DateOfBirth", "Date of Birth", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "GenderID", "GenderID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "GenderName", "Gender", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "BloodTypeID", "BloodTypeID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "BloodTypeName", "Blood Type", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AddressOfIdentityCard", "Address [KTP]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "AddressOfDrivingLicense", "Address [SIM]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ReligionID", "ReligionID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ReligionName", "Religion", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "MaritalStatusID", "MaritalStatusID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "MaritalStatusName", "Marital Status", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "NationalityID", "NationalityID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "NationalityName", "Nationality", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "OccuptionsIDOfIdentityCard", "OccuptionsID [Identity Card]", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "OccuptionsNameOfIdentityCard", "Occuptions [Identity Card]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "OccupationsOthersOfIdentityCard", "Occupations Others [Identity Card]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "OccuptionsIDOfDrivingLicense", "OccuptionsIDOfDrivingLicense", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "OccuptionsNameOfDrivingLicense", "Occuptions [Driving License]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "OccupationsOthersOfDrivingLicense", "Occupations Others [Driving License]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ValidThruOfIdentityCard", "Valid Thru [KTP]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "ValidThruOfDrivingLicense", "Valid Thru [SIM]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeID", "DrivingLicenseTypeID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeName", "Tipe SIM", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Height", "Height", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedFromComLocID", "CreatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "LastUpdatedFromComLocID", "LastUpdatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "CreatedFromComLoc", "Created From ComLoc", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LastUpdatedFromComLoc", "Last Updated From ComLoc", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "InternalRemarks", "Internal Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cGet).Visible = pubIsLookUp
            .Item(cSep1).Visible = pubIsLookUp
            .Item(cGet).Enabled = bolEnable
            .Item(cDetail).Enabled = bolEnable
            .Item(cDelete).Enabled = bolEnable
            .Item(cBlacklist).Enabled = bolEnable
            .Item(cRevertBlackList).Enabled = bolEnable
            .Item(cMerge).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Me.Cursor = Cursors.WaitCursor
        progressBar.Visible = True
        Try
            grdMain.DataSource = BL.Driver.ListData(txtIdentityCardNumber.Text.Trim, txtDrivingLicenseNumber.Text.Trim, txtFullName.Text.Trim, chkShowAllDriver.Checked, _
                                                    chkHideInactive.Checked, chkHideBlacklist.Checked, chkShowDuplicateOnly.Checked)
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            Me.Cursor = Cursors.Default
            progressBar.Visible = False
            prvSetButton()
        End Try
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item("ID")
            End If
            prvQuery()
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "ID", strSearch)
        End With
    End Sub

    Private Sub prvGet()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        If Not pubIsLookUp Then Exit Sub
        If grdView.GetRowCellValue(intPos, "IDStatus") = VO.Status.Values.InActive Then
            UI.usForm.frmMessageBox("Cannot choose this data because data is not active")
            Exit Sub
        ElseIf grdView.GetRowCellValue(intPos, "IDStatus") = VO.Status.Values.Blacklist Then
            UI.usForm.frmMessageBox("Cannot choose this data because data is blacklist")
            Exit Sub
        Else
            pubLUdtRow = grdView.GetDataRow(grdView.FocusedRowHandle)
            pubIsLookUpGet = True
            Me.Close()
        End If
    End Sub

    Private Sub prvSetLookUp()
        If pubIsLookUp Then
            Me.Text += " [Lookup] "
            UI.usForm.GridMoveRow(grdView, "ID", pubLUID)
        End If
    End Sub

    Private Function prvGetData() As VO.Driver
        Dim returnValue As New VO.Driver
        returnValue.ID = grdView.GetRowCellValue(intPos, "ID")
        returnValue.IdentityCardNumber = grdView.GetRowCellValue(intPos, "IdentityCardNumber")
        returnValue.DrivingLicenseNumber = grdView.GetRowCellValue(intPos, "DrivingLicenseNumber")
        returnValue.FullName = grdView.GetRowCellValue(intPos, "FullName")
        returnValue.PlaceOfBirth = grdView.GetRowCellValue(intPos, "PlaceOfBirth")
        returnValue.DateOfBirth = grdView.GetRowCellValue(intPos, "DateOfBirth")
        returnValue.GenderID = grdView.GetRowCellValue(intPos, "GenderID")
        returnValue.BloodTypeID = grdView.GetRowCellValue(intPos, "BloodTypeID")
        returnValue.AddressOfIdentityCard = grdView.GetRowCellValue(intPos, "AddressOfIdentityCard")
        returnValue.AddressOfDrivingLicense = grdView.GetRowCellValue(intPos, "AddressOfDrivingLicense")
        returnValue.ReligionID = grdView.GetRowCellValue(intPos, "ReligionID")
        returnValue.MaritalStatusID = grdView.GetRowCellValue(intPos, "MaritalStatusID")
        returnValue.NationalityID = grdView.GetRowCellValue(intPos, "NationalityID")
        returnValue.OccupationsIDOfIdentityCard = grdView.GetRowCellValue(intPos, "OccuptionsIDOfIdentityCard")
        returnValue.OccupationsOthersOfIdentityCard = grdView.GetRowCellValue(intPos, "OccupationsOthersOfIdentityCard")
        returnValue.OccupationsIDOfDrivingLicense = grdView.GetRowCellValue(intPos, "OccuptionsIDOfDrivingLicense")
        returnValue.OccupationsOthersOfDrivingLicense = grdView.GetRowCellValue(intPos, "OccupationsOthersOfDrivingLicense")
        returnValue.ValidThruOfIdentityCard = grdView.GetRowCellValue(intPos, "ValidThruOfIdentityCard")
        returnValue.ValidThruOfDrivingLicense = grdView.GetRowCellValue(intPos, "ValidThruOfDrivingLicense")
        returnValue.DrivingLicenseTypeID = grdView.GetRowCellValue(intPos, "DrivingLicenseTypeID")
        returnValue.Height = grdView.GetRowCellValue(intPos, "Height")
        returnValue.CreatedFromComLocID = grdView.GetRowCellValue(intPos, "CreatedFromComLocID")
        returnValue.LastUpdatedFromComLocID = grdView.GetRowCellValue(intPos, "LastUpdatedFromComLocID")
        returnValue.ReferencesID = grdView.GetRowCellValue(intPos, "ReferencesID")
        returnValue.InternalRemarks = grdView.GetRowCellValue(intPos, "InternalRemarks")
        returnValue.Remarks = grdView.GetRowCellValue(intPos, "Remarks")
        returnValue.IDStatus = grdView.GetRowCellValue(intPos, "IDStatus")
        returnValue.StatusInfo = grdView.GetRowCellValue(intPos, "StatusInfo")
        returnValue.CreatedBy = grdView.GetRowCellValue(intPos, "CreatedBy")
        returnValue.CreatedDate = grdView.GetRowCellValue(intPos, "CreatedDate")
        Return returnValue
    End Function

    Private Sub prvNew()
        Dim frmDetail As New frmMstDriverDet
        With frmDetail
            .pubIsNew = True
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
        End With
    End Sub

    Private Sub prvDetail()
        Dim intPos As Integer = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New frmMstDriverDet
        With frmDetail
            .pubIsNew = False
            .pubID = grdView.GetRowCellValue(intPos, "ID")
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then pubRefresh()
        End With
    End Sub

    Private Sub prvDelete()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        If Not UI.usForm.frmAskQuestion("Delete Driver ID: " & clsData.ID & "?") Then Exit Sub
        clsData.LogBy = UI.usUserApp.UserID
        Try
            BL.Driver.DeleteData(clsData)
            UI.usForm.frmMessageBox("Delete data success.")
            pubRefresh(grdView.GetRowCellValue(intPos, "ID"))
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvBlacklist()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        clsData = prvGetData()
        If clsData.IdentityCardNumber.Trim = "" Then
            UI.usForm.frmMessageBox("Cannot Blacklist. Please fill identity card number first")
            Exit Sub
        End If

        Dim frmDetail As New usFormRemarks
        With frmDetail
            .pubTitle = "Blacklist Driver ID: " & clsData.ID
            .pubInfo = "Blacklist Driver"
            .pubLabel = "Internal Remarks"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                clsData.InternalRemarks = .pubValue.Trim
                clsData.LogBy = UI.usUserApp.UserID
            Else : Exit Sub
            End If
        End With

        Try
            BL.Driver.BlacklistData(clsData)
            UI.usForm.frmMessageBox("Blacklist data success.")
            pubRefresh(clsData.ID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvRevertBlacklist()
        intPos = grdView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim frmDetail As New usFormRemarks
        clsData = prvGetData()
        With frmDetail
            .pubTitle = "Revert Blacklist Driver ID: " & grdView.GetRowCellValue(intPos, "ID")
            .pubInfo = "Revert Blacklist Driver"
            .pubLabel = "Internal Remarks"
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsSave Then
                clsData.InternalRemarks = .pubValue.Trim
                clsData.LogBy = UI.usUserApp.UserID
            Else : Exit Sub
            End If
        End With
        Try
            BL.Driver.RevertBlacklistData(clsData)
            UI.usForm.frmMessageBox("Revert Blacklist data success.")
            pubRefresh(grdView.GetRowCellValue(intPos, "ID"))
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvMerge()
        Dim frmDetail As New frmMstDriverMerge
        With frmDetail
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then
                pubRefresh()
            Else : Exit Sub
            End If
        End With
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cNew).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVER", "ADD")
            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVER", "DELETE")
            .Item(cBlacklist).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVER", "BLACKLIST")
            .Item(cMerge).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVER", "MERGE")
            .Item(cImportExcel).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVER", "IMPORT")
        End With
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
    End Sub

    Private Sub prvImportExcel()
        Dim frmDetail As New frmMstDriverImportExcel
        With frmDetail
            .StartPosition = FormStartPosition.CenterScreen
            .pubShowDialog(Me)
            If .pubIsSave Then
                pubRefresh()
            Else : Exit Sub
            End If
        End With
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstDriver_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstDriver_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvSetGrid()
        prvSetButton()
        prvUserAccess()
        prvSetLookUp()
        If Not pubIsLookUp Then Me.WindowState = FormWindowState.Maximized
        AddHandler chkShowAllDriver.CheckedChanged, AddressOf chkShowAllDriver_CheckedChanged
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text
            Case "Get" : prvGet()
            Case "New" : prvNew()
            Case "Detail" : prvDetail()
            Case "Delete" : prvDelete()
            Case "Blacklist" : prvBlacklist()
            Case "Revert Blacklist" : prvRevertBlacklist()
            Case "Merge" : prvMerge()
            Case "Import Excel" : prvImportExcel()
            Case "Refresh" : pubRefresh()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub grdView_DoubleClick(sender As Object, e As EventArgs) Handles grdView.DoubleClick
        If pubIsLookUp Then prvGet()
    End Sub

    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle
        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender
        If (e.RowHandle >= 0) Then
            Dim intIDStatus As Integer = View.GetRowCellDisplayText(e.RowHandle, View.Columns("IDStatus"))
            If intIDStatus = VO.Status.Values.InActive And e.Appearance.BackColor <> Color.Salmon Then
                e.Appearance.BackColor = Color.Salmon
                e.Appearance.BackColor2 = Color.SeaShell
            ElseIf intIDStatus = VO.Status.Values.Blacklist And e.Appearance.BackColor <> Color.Gray Then
                e.Appearance.BackColor = Color.Gray
                e.Appearance.BackColor2 = Color.SeaShell
            End If
        End If
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        prvClear()
    End Sub

    Private Sub chkShowAllDriver_CheckedChanged(sender As Object, e As EventArgs)
        If chkShowAllDriver.Checked Then
            If Not UI.usForm.frmAskQuestion("Sure want to show all driver ?") Then
                chkShowAllDriver.Checked = False
            End If
            txtIdentityCardNumber.Text = ""
            txtIdentityCardNumber.Enabled = False
            txtDrivingLicenseNumber.Text = ""
            txtDrivingLicenseNumber.Enabled = False
            txtFullName.Text = ""
            txtFullName.Enabled = False
            chkHideInactive.Checked = False
            chkHideInactive.Enabled = False
            chkHideBlacklist.Checked = False
            chkHideBlacklist.Enabled = False
            chkShowDuplicateOnly.Checked = False
            chkShowDuplicateOnly.Enabled = False
            btnExecute.Focus()
        Else
            txtIdentityCardNumber.Enabled = True
            txtDrivingLicenseNumber.Enabled = True
            txtFullName.Enabled = True
            chkHideInactive.Enabled = True
            chkHideBlacklist.Enabled = True
            chkShowDuplicateOnly.Enabled = True
        End If
        prvClear()
    End Sub

#End Region

End Class


