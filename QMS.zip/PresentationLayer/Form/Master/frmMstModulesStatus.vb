﻿Public Class frmMstModulesStatus

#Region "Property Handle"

    Private frmParent As frmMstModules
    Property pubClsData As VO.Modules
    Property pubIsSave As Boolean = False
    Private intPos As Integer
    Private dtData As New DataTable

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

    Private Const _
        cSave = 0, cClose = 1, cAdd = 0, cDelete = 1

#End Region

#Region "Function Handle"

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdItemView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdItemView, "IDStatus", "ID Status", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdItemView, "StatusName", "Status Name", 300, UI.usDefGrid.gString)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdItemView.RowCount > 0, True, False)
        With ToolBarDetail.Buttons
            .Item(cDelete).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvQuery()
        Try
            dtData = BL.StatusDet.ListDataByModuleID(pubClsData.ID)
            grdItem.DataSource = dtData
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            prvSetButton()
        End Try
    End Sub

    Private Sub prvSave()
        If grdItemView.RowCount = 0 Then
            UI.usForm.frmMessageBox("Please add item first")
            grdItemView.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        Dim clsData As VO.StatusDet
        Dim clsDataAll(grdItemView.RowCount - 1) As VO.StatusDet
        With grdItemView
            For i As Integer = 0 To .RowCount - 1
                clsData = New VO.StatusDet
                clsData.ModuleID = pubClsData.ID
                clsData.IDStatus = .GetRowCellValue(i, "IDStatus")
                clsDataAll(i) = clsData
            Next
        End With

        Try
            BL.StatusDet.SaveDataByModuleID(clsDataAll)
            UI.usForm.frmMessageBox("Save data success.")
            Me.Close()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvAdd()
        Dim frmDetail As New frmMstStatus
        With frmDetail
            .pubIsLookUp = True
            .pubLUTableParent = dtData
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .pubIsLookUpGet Then
                Dim drNewRow As DataRow
                For Each drRow As DataRow In .pubLUdtRow
                    drNewRow = dtData.NewRow
                    With drNewRow
                        .BeginEdit()
                        .Item("ID") = 0
                        .Item("IDStatus") = drRow.Item("ID")
                        .Item("StatusName") = drRow.Item("Description")
                        .EndEdit()
                    End With
                    dtData.Rows.Add(drNewRow)
                Next
                dtData.AcceptChanges()
                prvSetButton()
            End If
        End With
    End Sub

    Private Sub prvDelete()
        intPos = grdItemView.FocusedRowHandle
        If intPos < 0 Then Exit Sub
        Dim intIDStatus As Integer = grdItemView.GetRowCellValue(intPos, "IDStatus")
        For Each drRow As DataRow In dtData.Rows
            If drRow.Item("IDStatus") = intIDStatus Then
                drRow.Delete()
                Exit For
            End If
        Next
        dtData.AcceptChanges()
        grdItem.DataSource = dtData
        prvSetButton()
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMstModulesStatus_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmMstModulesStatus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        ToolBarDetail.SetIcon(Me)
        prvSetGrid()
        txtModule.Text = pubClsData.Description
        prvQuery()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text
            Case "Save" : prvSave()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub ToolBarDetail_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarDetail.ButtonClick
        Select Case e.Button.Text
            Case "Add" : prvAdd()
            Case "Delete" : prvDelete()
        End Select
    End Sub

#End Region

End Class