﻿Public Class frmSysReport

    Public Sub New(ByVal strTitle As String)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.Text = strTitle

    End Sub

End Class