﻿Public Class frmSysTestInputRFID

#Region "Property Handle"

    Private frmParent As Object
    Private enumPorts As VO.SubStation.Ports

    Public WriteOnly Property pubPorts As VO.SubStation.Ports
        Set(value As VO.SubStation.Ports)
            enumPorts = value
        End Set
    End Property

    Public Sub pubShowDialog(ByVal frmGetParent As Form)
        frmParent = frmGetParent
        Me.ShowDialog()
    End Sub

#End Region

#Region "Form Handle"

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        If txtRFID.Text.Trim = "" Then Exit Sub
        If enumPorts = VO.SubStation.Ports.COMPort1 Then
            VO.DefaultServer.RFIDValueCOMPort1 = txtRFID.Text.Trim
            frmParent.prvStartTimer()
        Else
            VO.DefaultServer.RFIDValueCOMPort2 = txtRFID.Text.Trim
            frmParent.prvStartTimerRFID()
        End If
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        If enumPorts = VO.SubStation.Ports.COMPort1 Then
            frmParent.prvStopTimer()
        Else
            frmParent.prvStopTimerRFID()
        End If
    End Sub

    Private Sub txtRFID_TextChanged(sender As Object, e As EventArgs) Handles txtRFID.TextChanged
        If enumPorts = VO.SubStation.Ports.COMPort1 Then
            VO.DefaultServer.RFIDValueCOMPort1 = txtRFID.Text.Trim
        Else
            VO.DefaultServer.RFIDValueCOMPort2 = txtRFID.Text.Trim
        End If
    End Sub

#End Region

End Class