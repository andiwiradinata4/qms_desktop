﻿Imports System.Data.SqlClient
Imports DevExpress.XtraPrinting.Native.Lines

Public Class frmSysSyncDataMasterRDCtoLocation

#Region "Properties Handle"

    Dim dtData As New List(Of DataTable)
    Dim dtAll As New DataTable("ALL"), dtStation As New DataTable, dtSubStation As New DataTable,
    dtGender As New DataTable, dtReligion As New DataTable, dtNationality As New DataTable,
    dtMaritalStatus As New DataTable, dtBloodType As New DataTable, dtOccupations As New DataTable,
    dtDrivingLicenseType As New DataTable, dtImageType As New DataTable, dtDriver As New DataTable,
    dtDriverImage As New DataTable, dtDriverStatus As New DataTable, dtQueueFlow As New DataTable,
    dtQueueFlowStation As New DataTable, dtQueueFlowItem As New DataTable, dtStatus As New DataTable,
    dtModules As New DataTable, dtStorage As New DataTable
    Dim drNew As DataRow

    Private Const _
       cPost = 0, cRefresh = 1, cSep1 = 2, cClose = 3,
       cTotalMaster = 19

#End Region

#Region "Function Handle"

    Private Sub prvSetProgressBar(ByVal intMax As Integer)
        pbMain.Maximum = intMax
        pbMain.Value = 0
    End Sub

    Private Sub prvRefreshProgressBar()
        pbMain.Value += 1
        Me.Refresh()
    End Sub

    Private Sub prvSetGrid()
        If cboModule.SelectedValue = VO.Modules.Values.All Then
            UI.usForm.SetGrid(grdView, "Module", "Module", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Data", "Data", 100, UI.usDefGrid.gString)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Station Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IsLinkStorage", "Link to Storage?", 100, UI.usDefGrid.gBoolean)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.SubStation Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StationID", "Station ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StationName", "Station Name", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IsDefault", "IsDefault", 100, UI.usDefGrid.gBoolean)
            UI.usForm.SetGrid(grdView, "ComputerName", "Computer Name", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "InitialID", "Initial ID", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "COMPort1", "COMPort 1", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "COMPort2", "COMPort 2", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "BaudRate", "Baud Rate", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "DataBits", "Data Bits", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Comparity", "Comparity", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "ComStopBits", "ComStopBits", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Gender Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Religion Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Nationality Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.MaritalStatus Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.BloodType Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Occupations Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.DrivingLicenseType Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.ImageType Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "Description", "Description", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Driver Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IdentityCardNumber", "Identity Card Number", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "DrivingLicenseNumber", "Driving License Number", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "FullName", "Full Name", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "PlaceOfBirth", "Place of Birth", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "DateOfBirth", "Date of Birth", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "GenderID", "GenderID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "GenderName", "Gender", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "BloodTypeID", "BloodTypeID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "BloodTypeName", "Blood Type", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "AddressOfIdentityCard", "Address [KTP]", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "AddressOfDrivingLicense", "Address [SIM]", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "ReligionID", "ReligionID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "ReligionName", "Religion", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "MaritalStatusID", "MaritalStatusID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "MaritalStatusName", "Marital Status", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "NationalityID", "NationalityID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "NationalityName", "Nationality", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "OccuptionsIDOfIdentityCard", "OccuptionsID [Identity Card]", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "OccuptionsNameOfIdentityCard", "Occuptions [Identity Card]", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "OccupationsOthersOfIdentityCard", "Occupations Others [Identity Card]", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "OccuptionsIDOfDrivingLicense", "OccuptionsIDOfDrivingLicense", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "OccuptionsNameOfDrivingLicense", "Occuptions [Driving License]", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "OccupationsOthersOfDrivingLicense", "Occupations Others [Driving License]", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "ValidThruOfIdentityCard", "Valid Thru [KTP]", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "ValidThruOfDrivingLicense", "Valid Thru [SIM]", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "DrivingLicenseTypeID", "DrivingLicenseTypeID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "DrivingLicenseTypeName", "Tipe SIM", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Height", "Height", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedFromComLocID", "CreatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "LastUpdatedFromComLocID", "LastUpdatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "CreatedFromComLoc", "Created From ComLoc", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LastUpdatedFromComLoc", "Last Updated From ComLoc", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "InternalRemarks", "Internal Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.QueueFlow Then
            UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Name", "Name", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Type", "Type", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "TypeInfo", "Type", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IsDefault", "IsDefault", 100, UI.usDefGrid.gBoolean)
            UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
            UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Storage Then
            UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
            UI.usForm.SetGrid(grdView, "CompanyID", "CompanyID", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "LocationID", "LocationID", 100, UI.usDefGrid.gString, False)
            UI.usForm.SetGrid(grdView, "ProgramID", "ProgramID", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "StorageGroupID", "StorageGroupID", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "StorageGroupName", "StorageGroupName", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "StorageID", "StorageID", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "StorageName", "StorageName", 100, UI.usDefGrid.gString)
            UI.usForm.SetGrid(grdView, "IsBlackList", "IsBlackList", 100, UI.usDefGrid.gBoolean)
        End If
        grdView.BestFitColumns()
    End Sub

    Private Sub prvFillCombo()
        Dim dtData As New DataTable
        Try
            dtData = BL.Modules.ListData
            For Each dr As DataRow In dtData.Rows
                If dr.Item("IsActive") = False Then
                    dr.Delete()
                End If
            Next

            Dim drNew As DataRow
            drNew = dtData.NewRow
            With drNew
                .BeginEdit()
                .Item("ID") = 0
                .Item("Description") = "ALL"
                .EndEdit()
            End With
            dtData.Rows.Add(drNew)
            dtData.AcceptChanges()
            UI.usForm.FillComboBox(cboModule, dtData, "ID", "Description", True)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cPost).Enabled = bolEnable
        End With
    End Sub

    Private Function prvCollectData() As DataTable
        dtAll.Clear()
        Dim dtReturn As New DataTable

        '# Sync All Master
        If cboModule.SelectedValue = VO.Modules.Values.All Then '# All
            prvSetProgressBar(cTotalMaster)
            '# Master Station
            dtStation = BL.PostData.CollectDataMasterStationRDCtoLocation
            dtStation.TableName = BL.PostData.mStation
            If dtStation.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER STATION"
                    .Item("Data") = dtStation.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtStation)
            End If
            prvRefreshProgressBar()

            '# Master Sub Station
            dtSubStation = BL.PostData.CollectDataMasterSubStationRDCtoLocation(UI.usUserApp.CompanyID, UI.usUserApp.LocationID)
            dtSubStation.TableName = BL.PostData.mSubStation
            If dtSubStation.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER SUBSTATION"
                    .Item("Data") = dtSubStation.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtSubStation)
            End If
            prvRefreshProgressBar()

            '# Master Gender
            dtGender = BL.PostData.CollectDataMasterGenderRDCtoLocation
            dtGender.TableName = BL.PostData.mGender
            If dtGender.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER GENDER"
                    .Item("Data") = dtGender.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtGender)
            End If
            prvRefreshProgressBar()

            '# Master Religion
            dtReligion = BL.PostData.CollectDataMasterReligionRDCtoLocation
            dtReligion.TableName = BL.PostData.mReligion
            If dtReligion.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER RELIGION"
                    .Item("Data") = dtReligion.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtReligion)
            End If
            prvRefreshProgressBar()

            '# Master Nationality
            dtNationality = BL.PostData.CollectDataMasterNationalityRDCtoLocation
            dtNationality.TableName = BL.PostData.mNationality
            If dtNationality.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER NATIONALITY"
                    .Item("Data") = dtNationality.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtNationality)
            End If
            prvRefreshProgressBar()

            '# Master Marital Status
            dtMaritalStatus = BL.PostData.CollectDataMasterMaritalStatusRDCtoLocation
            dtMaritalStatus.TableName = BL.PostData.mMaritalStatus
            If dtMaritalStatus.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER MARITAL STATUS"
                    .Item("Data") = dtMaritalStatus.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtMaritalStatus)
            End If
            prvRefreshProgressBar()

            '# Master Blood Type
            dtBloodType = BL.PostData.CollectDataMasterBloodTypeRDCtoLocation
            dtBloodType.TableName = BL.PostData.mBloodType
            If dtBloodType.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER BLOOD TYPE"
                    .Item("Data") = dtBloodType.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtBloodType)
            End If
            prvRefreshProgressBar()

            '# Master Occupations
            dtOccupations = BL.PostData.CollectDataMasterOccupationsRDCtoLocation
            dtOccupations.TableName = BL.PostData.mOccupations
            If dtOccupations.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER OCCUPATIONS"
                    .Item("Data") = dtOccupations.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtOccupations)
            End If
            prvRefreshProgressBar()

            '# Master Driving License Type
            dtDrivingLicenseType = BL.PostData.CollectDataMasterDrivingLicenseTypeRDCtoLocation
            dtDrivingLicenseType.TableName = BL.PostData.mDrivingLicenseType
            If dtDrivingLicenseType.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER DRIVING LICENSE TYPE"
                    .Item("Data") = dtDrivingLicenseType.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtDrivingLicenseType)
            End If
            prvRefreshProgressBar()

            '# Master Image Type
            dtImageType = BL.PostData.CollectDataMasterImageTypeRDCtoLocation
            dtImageType.TableName = BL.PostData.mImageType
            If dtImageType.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER IMAGE TYPE"
                    .Item("Data") = dtImageType.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtImageType)
            End If
            prvRefreshProgressBar()

            '# Master Driver
            dtDriver = BL.PostData.CollectDataMasterDriverRDCtoLocation
            dtDriver.TableName = BL.PostData.mDriver
            If dtDriver.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER DRIVER"
                    .Item("Data") = dtDriver.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtDriver)
            End If
            prvRefreshProgressBar()

            '# Master Driver Image
            dtDriverImage = BL.PostData.CollectDataMasterDriverImageRDCtoLocation
            dtDriverImage.TableName = BL.PostData.mDriverImage
            If dtDriverImage.Rows.Count > 0 Then dtData.Add(dtDriverImage)
            prvRefreshProgressBar()

            '# Master Driver Status
            dtDriverStatus = BL.PostData.CollectDataMasterDriverStatusRDCtoLocation
            dtDriverStatus.TableName = BL.PostData.mDriverStatus
            If dtDriverStatus.Rows.Count > 0 Then dtData.Add(dtDriverStatus)
            prvRefreshProgressBar()

            '# Master Queue Flow
            dtQueueFlow = BL.PostData.CollectDataMasterQueueFlowRDCtoLocation
            dtQueueFlow.TableName = BL.PostData.mQueueFlow
            If dtQueueFlow.Rows.Count > 0 Then
                drNew = dtAll.NewRow
                With drNew
                    .BeginEdit()
                    .Item("Module") = "MASTER QUEUE FLOW"
                    .Item("Data") = dtQueueFlow.Rows.Count.ToString & " DATA"
                    .EndEdit()
                End With
                dtAll.Rows.Add(drNew)
                dtData.Add(dtQueueFlow)
            End If
            prvRefreshProgressBar()

            '# Master Queue Flow Station
            dtQueueFlowStation = BL.PostData.CollectDataMasterQueueFlowStationRDCtoLocation
            dtQueueFlowStation.TableName = BL.PostData.mQueueFlowStation
            If dtQueueFlowStation.Rows.Count > 0 Then dtData.Add(dtQueueFlowStation)
            prvRefreshProgressBar()

            '# Master Queue Flow Item
            dtQueueFlowItem = BL.PostData.CollectDataMasterQueueFlowItemRDCtoLocation
            dtQueueFlowItem.TableName = BL.PostData.mQueueFlowItem
            If dtQueueFlowItem.Rows.Count > 0 Then dtData.Add(dtQueueFlowItem)
            prvRefreshProgressBar()

            '# Master Storage
            dtStorage = BL.PostData.CollectDataMasterStorageRDCtoLocation(UI.usUserApp.CompanyID, UI.usUserApp.LocationID)
            dtStorage.TableName = BL.PostData.mStorage
            If dtStorage.Rows.Count > 0 Then dtData.Add(dtStorage)
            prvRefreshProgressBar()

            '# Master Status
            dtStatus = BL.PostData.CollectDataMasterStatusRDCtoLocation
            dtStatus.TableName = BL.PostData.mStatus
            If dtStatus.Rows.Count > 0 Then dtData.Add(dtStatus)
            prvRefreshProgressBar()

            '# Master Modules
            dtModules = BL.PostData.CollectDataMasterModulesRDCtoLocation
            dtModules.TableName = BL.PostData.mModules
            If dtModules.Rows.Count > 0 Then dtData.Add(dtModules)
            prvRefreshProgressBar()

            dtReturn = dtAll
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Station Then '# Master Station
            dtStation = BL.PostData.CollectDataMasterStationRDCtoLocation
            dtStation.TableName = BL.PostData.mStation
            If dtStation.Rows.Count > 0 Then dtData.Add(dtStation)
            dtReturn = dtStation
        ElseIf cboModule.SelectedValue = VO.Modules.Values.SubStation Then '# Master Sub Station
            dtSubStation = BL.PostData.CollectDataMasterSubStationRDCtoLocation(UI.usUserApp.CompanyID, UI.usUserApp.LocationID)
            dtSubStation.TableName = BL.PostData.mSubStation
            If dtSubStation.Rows.Count > 0 Then dtData.Add(dtSubStation)
            dtReturn = dtSubStation
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Gender Then '# Master Gender
            dtGender = BL.PostData.CollectDataMasterGenderRDCtoLocation
            dtGender.TableName = BL.PostData.mGender
            If dtGender.Rows.Count > 0 Then dtData.Add(dtGender)
            dtReturn = dtGender
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Religion Then '# Master Religion
            dtReligion = BL.PostData.CollectDataMasterReligionRDCtoLocation
            dtReligion.TableName = BL.PostData.mReligion
            If dtReligion.Rows.Count > 0 Then dtData.Add(dtReligion)
            dtReturn = dtReligion
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Nationality Then '# Master Nationality
            dtNationality = BL.PostData.CollectDataMasterNationalityRDCtoLocation
            dtNationality.TableName = BL.PostData.mNationality
            If dtNationality.Rows.Count > 0 Then dtData.Add(dtNationality)
            dtReturn = dtNationality
        ElseIf cboModule.SelectedValue = VO.Modules.Values.MaritalStatus Then '# Master Marital Status
            dtMaritalStatus = BL.PostData.CollectDataMasterMaritalStatusRDCtoLocation
            dtMaritalStatus.TableName = BL.PostData.mMaritalStatus
            If dtMaritalStatus.Rows.Count > 0 Then dtData.Add(dtMaritalStatus)
            dtReturn = dtMaritalStatus
        ElseIf cboModule.SelectedValue = VO.Modules.Values.BloodType Then '# Master Blood Type
            dtBloodType = BL.PostData.CollectDataMasterBloodTypeRDCtoLocation
            dtBloodType.TableName = BL.PostData.mBloodType
            If dtBloodType.Rows.Count > 0 Then dtData.Add(dtBloodType)
            dtReturn = dtBloodType
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Occupations Then '# Master Occupations
            dtOccupations = BL.PostData.CollectDataMasterOccupationsRDCtoLocation
            dtOccupations.TableName = BL.PostData.mOccupations
            If dtOccupations.Rows.Count > 0 Then dtData.Add(dtOccupations)
            dtReturn = dtOccupations
        ElseIf cboModule.SelectedValue = VO.Modules.Values.DrivingLicenseType Then '# Master Driving License Type
            dtDrivingLicenseType = BL.PostData.CollectDataMasterDrivingLicenseTypeRDCtoLocation
            dtDrivingLicenseType.TableName = BL.PostData.mDrivingLicenseType
            If dtDrivingLicenseType.Rows.Count > 0 Then dtData.Add(dtDrivingLicenseType)
            dtReturn = dtDrivingLicenseType
        ElseIf cboModule.SelectedValue = VO.Modules.Values.ImageType Then '# Master Image Type
            dtImageType = BL.PostData.CollectDataMasterImageTypeRDCtoLocation
            dtImageType.TableName = BL.PostData.mImageType
            If dtImageType.Rows.Count > 0 Then dtData.Add(dtImageType)
            dtReturn = dtImageType
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Driver Then '# Master Driver
            dtDriver = BL.PostData.CollectDataMasterDriverRDCtoLocation
            dtDriver.TableName = BL.PostData.mDriver
            If dtDriver.Rows.Count > 0 Then dtData.Add(dtDriver)

            '# Master Driver Image
            dtDriverImage = BL.PostData.CollectDataMasterDriverImageRDCtoLocation
            dtDriverImage.TableName = BL.PostData.mDriverImage
            If dtDriverImage.Rows.Count > 0 Then dtData.Add(dtDriverImage)

            '# Master Driver Status
            dtDriverStatus = BL.PostData.CollectDataMasterDriverStatusRDCtoLocation
            dtDriverStatus.TableName = BL.PostData.mDriverStatus
            If dtDriverStatus.Rows.Count > 0 Then dtData.Add(dtDriverStatus)

            dtReturn = dtDriver
        ElseIf cboModule.SelectedValue = VO.Modules.Values.QueueFlow Then '# Master Queue Flow
            dtQueueFlow = BL.PostData.CollectDataMasterQueueFlowRDCtoLocation
            dtQueueFlow.TableName = BL.PostData.mQueueFlow
            If dtQueueFlow.Rows.Count > 0 Then dtData.Add(dtQueueFlow)

            '# Master Queue Flow Station
            dtQueueFlowStation = BL.PostData.CollectDataMasterQueueFlowStationRDCtoLocation
            dtQueueFlowStation.TableName = BL.PostData.mQueueFlowStation
            If dtQueueFlowStation.Rows.Count > 0 Then dtData.Add(dtQueueFlowStation)

            '# Master Queue Flow Item
            dtQueueFlowItem = BL.PostData.CollectDataMasterQueueFlowItemRDCtoLocation
            dtQueueFlowItem.TableName = BL.PostData.mQueueFlowItem
            If dtQueueFlowItem.Rows.Count > 0 Then dtData.Add(dtQueueFlowItem)

            dtReturn = dtQueueFlow
        ElseIf cboModule.SelectedValue = VO.Modules.Values.Storage Then '# Master Storage
            dtStorage = BL.PostData.CollectDataMasterStorageRDCtoLocation(UI.usUserApp.CompanyID, UI.usUserApp.LocationID)
            dtStorage.TableName = BL.PostData.mStorage
            If dtStorage.Rows.Count > 0 Then dtData.Add(dtStorage)
            dtReturn = dtStorage
        End If
        Return dtReturn
    End Function

    Private Sub prvQuery()
        If cboModule.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose module first")
            cboModule.Focus()
            Exit Sub
        End If

        Me.Cursor = Cursors.WaitCursor
        Try
            grdMain.DataSource = prvCollectData()
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
            dtAll.Dispose()
        Finally
            Me.Cursor = Cursors.Default
            prvSetButton()
        End Try
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
        prvSetButton()
        dtData.Clear()
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cPost).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "POSTMSTRDCTOLOC", "POST")
        End With
    End Sub

    Private Sub prvPost()
        If Not UI.usForm.frmAskQuestion("Posting all data?") Then Exit Sub
        Me.Cursor = Cursors.WaitCursor
        Dim dtmSyncDate As DateTime = Now
        BL.Server.ServerDefault()
        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
            Try
                For Each dt As DataTable In dtData
                    If dt.TableName = BL.PostData.mStation Then '# Master Station
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Station
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Station With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IsLinkStorage = dr.Item("IsLinkStorage"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterStationRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.Station, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mSubStation Then '# Master SubStation
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.SubStation
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.SubStation With {
                                .CompanyID = dr.Item("CompanyID"),
                                .LocationID = dr.Item("LocationID"),
                                .ID = dr.Item("ID"),
                                .StationID = dr.Item("StationID"),
                                .Description = dr.Item("Description"),
                                .IsDefault = dr.Item("IsDefault"),
                                .ComputerName = dr.Item("ComputerName"),
                                .InitialID = dr.Item("InitialID"),
                                .COMPort1 = dr.Item("COMPort1"),
                                .COMPort2 = dr.Item("COMPort2"),
                                .BaudRate = dr.Item("BaudRate"),
                                .DataBits = dr.Item("DataBits"),
                                .Comparity = dr.Item("Comparity"),
                                .ComStopBits = dr.Item("ComStopBits"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterSubStationRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.SubStation, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mGender Then '# Master Gender
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Gender
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Gender With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterGenderRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.Gender, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mReligion Then '# Master Religion
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Religion
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Religion With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterReligionRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.Religion, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mNationality Then '# Master Nationality
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Nationality
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Nationality With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterNationalityRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.Nationality, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mMaritalStatus Then '# Master Marital Status
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.MaritalStatus
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.MaritalStatus With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterMaritalStatusRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.MaritalStatus, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mBloodType Then '# Master Blood Type
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.BloodType
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.BloodType With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterBloodTypeRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.BloodType, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mOccupations Then '# Master Occupations
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Occupations
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Occupations With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterOccupationsRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.Occupations, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mDrivingLicenseType Then '# Master Driving License Type
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.DrivingLicenseType
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.DrivingLicenseType With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterDrivingLicenseTypeRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.DrivingLicenseType, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mImageType Then '# Master Image Type
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.ImageType
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.ImageType With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterImageTypeRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.ImageType, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mDriver Then '# Master Driver
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Driver
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Driver With {
                                .ID = dr.Item("ID"),
                                .IdentityCardNumber = dr.Item("IdentityCardNumber"),
                                .DrivingLicenseNumber = dr.Item("DrivingLicenseNumber"),
                                .FullName = dr.Item("FullName"),
                                .PlaceOfBirth = dr.Item("PlaceOfBirth"),
                                .DateOfBirth = dr.Item("DateOfBirth"),
                                .GenderID = dr.Item("GenderID"),
                                .BloodTypeID = dr.Item("BloodTypeID"),
                                .AddressOfIdentityCard = dr.Item("AddressOfIdentityCard"),
                                .AddressOfDrivingLicense = dr.Item("AddressOfDrivingLicense"),
                                .ReligionID = dr.Item("ReligionID"),
                                .MaritalStatusID = dr.Item("MaritalStatusID"),
                                .NationalityID = dr.Item("NationalityID"),
                                .OccupationsIDOfIdentityCard = dr.Item("OccupationsIDOfIdentityCard"),
                                .OccupationsOthersOfIdentityCard = dr.Item("OccupationsOthersOfIdentityCard"),
                                .OccupationsIDOfDrivingLicense = dr.Item("OccupationsIDOfDrivingLicense"),
                                .OccupationsOthersOfDrivingLicense = dr.Item("OccupationsOthersOfDrivingLicense"),
                                .ValidThruOfIdentityCard = dr.Item("ValidThruOfIdentityCard"),
                                .ValidThruOfDrivingLicense = dr.Item("ValidThruOfDrivingLicense"),
                                .DrivingLicenseTypeID = dr.Item("DrivingLicenseTypeID"),
                                .Height = dr.Item("Height"),
                                .IDStatus = dr.Item("IDStatus"),
                                .CreatedFromComLocID = dr.Item("CreatedFromComLocID"),
                                .LastUpdatedFromComLocID = dr.Item("LastUpdatedFromComLocID"),
                                .ReferencesID = dr.Item("ReferencesID"),
                                .InternalRemarks = dr.Item("InternalRemarks"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterDriverRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.Driver, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mDriverImage Then '# Master Driver Image
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.DriverImage
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.DriverImage With {
                                .ID = dr.Item("ID"),
                                .DriverID = dr.Item("DriverID"),
                                .ImageTypeID = dr.Item("ImageTypeID"),
                                .ImagePath = dr.Item("ImagePath")
                            }
                            BL.PostData.PostDataMasterDriverImageRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next
                    ElseIf dt.TableName = BL.PostData.mDriverStatus Then '# Master Driver Status
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.DriverStatus
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.DriverStatus With {
                                .ID = dr.Item("ID"),
                                .DriverID = dr.Item("DriverID"),
                                .Status = dr.Item("Status"),
                                .StatusBy = dr.Item("StatusBy"),
                                .StatusDate = dr.Item("StatusDate"),
                                .Remarks = dr.Item("Remarks")
                            }
                            BL.PostData.PostDataMasterDriverStatusRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next
                    ElseIf dt.TableName = BL.PostData.mQueueFlow Then '# Master Queue Flow
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.QueueFlow
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.QueueFlow With {
                                .ID = dr.Item("ID"),
                                .Name = dr.Item("Name"),
                                .Type = dr.Item("Type"),
                                .IsDefault = dr.Item("IsDefault"),
                                .IDStatus = dr.Item("IDStatus"),
                                .Remarks = dr.Item("Remarks"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterQueueFlowRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next

                        '# Adding Sync Table
                        BL.SyncTable.SaveDataSync(sqlCon, sqlTrans, VO.Modules.Values.QueueFlow, UI.usUserApp.UserID, dtmSyncDate)
                    ElseIf dt.TableName = BL.PostData.mQueueFlowStation Then '# Master Queue Flow Station
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.QueueFlowStation
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.QueueFlowStation With {
                                .ID = dr.Item("ID"),
                                .QueueFlowID = dr.Item("QueueFlowID"),
                                .Idx = dr.Item("Idx"),
                                .StationID = dr.Item("StationID")
                            }
                            BL.PostData.PostDataMasterQueueFlowStationRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next
                    ElseIf dt.TableName = BL.PostData.mQueueFlowItem Then '# Master Queue Flow Item
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.QueueFlowItem
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.QueueFlowItem With {
                                .ID = dr.Item("ID"),
                                .ItemCode = dr.Item("ItemCode"),
                                .QueueFlowID = dr.Item("QueueFlowID")
                            }
                            BL.PostData.PostDataMasterQueueFlowItemRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next
                    ElseIf dt.TableName = BL.PostData.mStorage Then '# Master Storage
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Storage
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Storage With {
                                .ComLocDivSubDivID = dr.Item("ComLocDivSubDivID"),
                                .CompanyID = dr.Item("CompanyID"),
                                .LocationID = dr.Item("LocationID"),
                                .ProgramID = dr.Item("ProgramID"),
                                .StorageGroupID = dr.Item("StorageGroupID"),
                                .StorageID = dr.Item("StorageID"),
                                .StorageGroupName = dr.Item("StorageGroupName"),
                                .StorageName = dr.Item("StorageName"),
                                .IsBlackList = dr.Item("IsBlackList")
                            }
                            BL.PostData.PostDataMasterStorageRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next
                    ElseIf dt.TableName = BL.PostData.mStatus Then '# Master Status
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Status
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Status With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .Remarks = dr.Item("Remarks"),
                                .IsActive = dr.Item("IsActive"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterStatusRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next
                    ElseIf dt.TableName = BL.PostData.mModules Then '# Master Modules
                        prvSetProgressBar(dt.Rows.Count)
                        Dim clsData As VO.Modules
                        For Each dr As DataRow In dt.Rows
                            clsData = New VO.Modules With {
                                .ID = dr.Item("ID"),
                                .Description = dr.Item("Description"),
                                .Remarks = dr.Item("Remarks"),
                                .IsActive = dr.Item("IsActive"),
                                .CreatedBy = dr.Item("CreatedBy"),
                                .CreatedDate = dr.Item("CreatedDate"),
                                .LogBy = dr.Item("LogBy"),
                                .LogDate = dr.Item("LogDate"),
                                .LogInc = dr.Item("LogInc")
                            }
                            BL.PostData.PostDataMasterModulesRDCtoLocation(sqlCon, sqlTrans, clsData)
                            prvRefreshProgressBar()
                        Next
                    End If
                Next

                sqlTrans.Commit()
                UI.usForm.frmMessageBox("Posting data success")
            Catch ex As Exception
                sqlTrans.Rollback()
                UI.usForm.frmMessageBox("Posting data fail" & vbNewLine & ex.Message)
                pbMain.Value = 0
            Finally
                Me.Cursor = Cursors.Default
                dtData.Clear()
            End Try
        End Using
        prvQuery()
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmSysPostingDataMasterHOtoLocation_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

    End Sub

    Private Sub frmSysPostingDataMasterHOtoLocation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvFillCombo()
        prvUserAccess()
        prvSetButton()

        Me.WindowState = FormWindowState.Maximized

        AddHandler btnClear.Click, AddressOf pClear
        AddHandler cboModule.TextChanged, AddressOf pClear
        cboModule.SelectedIndex = 0

        '# Add Column
        dtAll.Columns.Add("Module", GetType(String))
        dtAll.Columns.Add("Data", GetType(String))
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Post" : prvPost()
            Case "Refresh" : prvQuery()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub pClear(sender As Object, e As EventArgs)
        prvClear()
    End Sub

#End Region

End Class