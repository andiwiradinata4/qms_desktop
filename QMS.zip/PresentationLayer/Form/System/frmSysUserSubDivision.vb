﻿Public Class frmSysUserSubDivision

    Private Const cOK = 0, cClose = 1
    Private intPos As Integer

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Get,1,Close")
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "CompanyName", "Company Name", 180, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LocationName", "Location Name", 120, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DivisionName", "Division Name", 120, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "SubDivisionName", "SubDivision Name", 220, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ComLocDivSubDivID", "ComLocDivSubDivID", 100, UI.usDefGrid.gIntNum, False)
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cOK).Enabled = bolEnable
        End With
    End Sub

    Public Sub pubQuery()
        Try
            UI.usUserApp.AccessList = BL.UserAccess.AccessList(UI.usUserApp.UserID, UI.usUserApp.UserCompanyID)
            Dim dvMain As New DataView(UI.usUserApp.AccessList)
            dvMain.Sort = "ProgramID, CompanyName, LocationName, DivisionName, SubDivisionName"
            grdMain.DataSource = dvMain
            grdView.ExpandAllGroups()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
        prvSetButton()
    End Sub

    Private Sub prvGetSubStationConfiguration()
        Try
            Dim clsData As VO.SubStation = BL.SubStation.GetDetail(UI.usUserApp.CompanyID, UI.usUserApp.LocationID, VO.DefaultServer.ComputerName)
            VO.DefaultServer.InitialID = clsData.InitialID
            VO.DefaultServer.COMPort1 = clsData.COMPort1
            VO.DefaultServer.COMPort2 = clsData.COMPort2
            VO.DefaultServer.ComParity = clsData.Comparity
            VO.DefaultServer.ComStopBits = clsData.ComStopBits
            VO.DefaultServer.BaudRate = clsData.BaudRate
            VO.DefaultServer.DataBits = clsData.DataBits
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Get Configuration Sub Station")
        End Try
    End Sub

    Private Sub prvGetUserServerLocation()
        Try
            VO.DefaultServer.UserServerLocation = BL.UserServerLocation.GetDetail(UI.usUserApp.ComLocDivSubDivID)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "User Server Location")
        End Try
    End Sub

    Private Sub prvChoose()
        intPos = grdView.FocusedRowHandle
        UI.usUserApp.ProgramID = grdView.GetDataRow(intPos).Item("ProgramID")
        UI.usUserApp.ProgramName = grdView.GetDataRow(intPos).Item("ProgramName")
        UI.usUserApp.ComLocDivSubDivID = grdView.GetDataRow(intPos).Item("ComLocDivSubDivID")
        UI.usUserApp.CompanyID = grdView.GetDataRow(intPos).Item("CompanyID")
        UI.usUserApp.CompanyName = grdView.GetDataRow(intPos).Item("CompanyName")
        UI.usUserApp.LocationID = grdView.GetDataRow(intPos).Item("LocationID")
        UI.usUserApp.LocationName = grdView.GetDataRow(intPos).Item("LocationName")
        UI.usUserApp.DivisionID = grdView.GetDataRow(intPos).Item("DivisionID")
        UI.usUserApp.DivisionName = grdView.GetDataRow(intPos).Item("DivisionName")
        UI.usUserApp.SubDivisionID = grdView.GetDataRow(intPos).Item("SubDivisionID")
        UI.usUserApp.SubDivisionName = grdView.GetDataRow(intPos).Item("SubDivisionName")
        BL.UserAccess.AccessFillRight()
        prvGetSubStationConfiguration()
        prvGetUserServerLocation()
        If frmSysMain.Visible = True Then
            frmSysMain.prvFormReload()
        Else
            frmSysMain.Show()
        End If
        Me.Close()
    End Sub

#Region "Form Handle"

    Private Sub Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        prvSetIcon()
        prvSetGrid()
        pubQuery()
    End Sub

    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If grdView.FocusedRowHandle >= 0 Then
            Select Case e.Button.Text
                Case "Choose" : prvChoose()
            End Select
        End If
        If e.Button.Text = "Close" Then
            Application.Exit()
        End If
    End Sub

    Private Sub grdMain_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdMain.DoubleClick
        If grdView.FocusedRowHandle < 0 Then Exit Sub
        prvChoose()
    End Sub

    Private Sub Form_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Enter Then prvChoose()
    End Sub

#End Region

End Class