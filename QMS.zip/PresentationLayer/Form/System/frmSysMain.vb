﻿Imports System.Data.SqlClient
Imports System.IO.Ports
Public Class frmSysMain

#Region "Variable Handle"

    Private WithEvents tmrRFID As New Timer

    Dim bolLogOut As Boolean, bolSuccessSettingSerialPort As Boolean
    Private intCount As Integer = 0, intCountLPR As Integer = 0
    Private clsLPRReGet As New VO.LPRReGet, clsLPRGet As New VO.LPRGet

    'MASTER
    Dim frmMainMstModule As frmMstModules
    Dim frmMainMstStatus As frmMstStatus
    Dim frmMainMstGender As frmMstGender
    Dim frmMainMstReligion As frmMstReligion
    Dim frmMainMstNationality As frmMstNationality
    Dim frmMainMstMaritalStatus As frmMstMaritalStatus
    Dim frmMainMstBloodType As frmMstBloodType
    Dim frmMainMstOccupations As frmMstOccupations
    Dim frmMainMstDrivingLicenseType As frmMstDrivingLicenseType
    Dim frmMainMstImageType As frmMstImageType
    Dim frmMainMstDriver As frmMstDriver
    Dim frmMainMstRFIDCard As frmMstRFIDCard
    Dim frmMainMstStation As frmMstStation
    Dim frmMainMstSubStation As frmMstSubStation
    Dim frmMainMstQueueFlow As frmMstQueueFlow

    'TRANSACTION
    Dim frmMainTraStorageLaneSwitching As frmTraStorageLaneSwitching
    Dim frmMainTraQueueRegister As frmTraQueueRegister
    Dim frmMainTraQueue As frmTraQueue
    Dim frmMainTraQueueArrange As frmTraQueueArrange
    Dim frmMainTraQueueOnProgress As frmTraQueueOnProgress
    Dim frmMainTraQueueUnloading As frmTraQueueUnloading
    Dim frmMainTraQueueUnloadingVer2 As frmTraQueueUnloadingVer2

    'TOOLS
    Dim frmMainSysUserSubDivision As frmSysUserSubDivision
    Dim frmMainSysSyncDataMasterRDCtoLocation As frmSysSyncDataMasterRDCtoLocation
    Dim frmMainSysSyncDataMasterLocationtoRDC As frmSysSyncDataMasterLocationtoRDC

#End Region

#Region "Setup COMPort"

    Private Sub OpenIO()
        Try
            UI.usForm.usSerialPort2.Open()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Open Port")
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If UI.usForm.usSerialPort2.IsOpen Then
                UI.usForm.usSerialPort2.Close()
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Close Port")
        End Try
    End Sub

    Private Sub prvStartReadRFID()
        If bolSuccessSettingSerialPort = False Then Exit Sub
        OpenIO()
        prvStartTimerRFID()
    End Sub

    Public Sub prvStartTimerRFID()
        tmrRFID.Enabled = True
        tmrRFID.Interval = 1000
        tmrRFID.Start()
    End Sub

    Public Sub prvStopTimerRFID()
        tmrRFID.Stop()
    End Sub

    Private Sub prvReadCard()
        Try
            '# Process Read RFID Card
            If VO.DefaultServer.IsLinkRFIDDevice2 Then
                If Not UI.usForm.usSerialPort2.IsOpen Then Exit Sub
                VO.DefaultServer.RFIDValueCOMPort2 = UI.usForm.usSerialPort2.ReadExisting
            End If

            intCount += 1
            If VO.DefaultServer.RFIDValueCOMPort2.Trim = "" Then Exit Sub Else VO.DefaultServer.RFIDValueCOMPort2 = VO.DefaultServer.RFIDValueCOMPort2.Trim

            If VO.DefaultServer.IsLinkRFIDDevice2 Then VO.DefaultServer.RFIDValueCOMPort2 = VO.DefaultServer.RFIDValueCOMPort2.Substring(1, VO.DefaultServer.RFIDValueCOMPort2.Length - 4)

            If VO.DefaultServer.RFIDValueCOMPort2.Trim = VO.DefaultServer.PrevRFIDValueCOMPort2.Trim And intCount <= 10 Then Exit Sub
            VO.DefaultServer.PrevRFIDValueCOMPort2 = VO.DefaultServer.RFIDValueCOMPort2
            intCount = 0
            prvStopTimerRFID()

            '# Process Re-Get LPR
            clsLPRGet = BL.Queue.LPRReGet(VO.DefaultServer.InitialID, "", "")
            If Not clsLPRGet.Status Then UI.usForm.frmMessageBox("REGET data LPR fail!" & vbNewLine & clsLPRGet.Message, "Read Card")
            prvCompareRFIDvsLPR()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Read Card")
        End Try
    End Sub

    Private Sub prvCompareRFIDvsLPR()
        Dim clsQueueDet As VO.QueueDet
        Try
            clsQueueDet = BL.Queue.CompareRFID(UI.usUserApp.ComLocDivSubDivID, VO.DefaultServer.RFIDValueCOMPort2, VO.DefaultServer.InitialID, clsLPRGet)
            BL.LPRHistory.UpdateReferencesIDAndPlatNumber(clsLPRGet.InternalID.Trim, clsQueueDet.ID.Trim, clsQueueDet.PlatNumber.Trim, clsLPRGet.PlatNo.Trim)
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                BL.Queue.CheckingStatusDetail(sqlCon, Nothing, VO.QueueDet.Action.Request, clsQueueDet.QueueID, clsQueueDet.ID, clsQueueDet, False)
            End Using
            If clsQueueDet.IsRequested Then
                UI.usForm.frmMessageBox("Plat Number " & clsQueueDet.PlatNumber & " already requested Queue Flow")
                Exit Sub
            End If

            If clsQueueDet.IsSuccessCompareLPR Then
                '# Request
                clsQueueDet.Remarks = ""
                clsQueueDet.IsRequested = True
                clsQueueDet.LogBy = "SYSTEM"
                BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Request, clsQueueDet)

                '# Done
                If clsQueueDet.StationID = VO.DefaultServer.AutoDoneStationID Then
                    clsQueueDet.Remarks = ""
                    clsQueueDet.IsDone = True
                    clsQueueDet.LogBy = "SYSTEM"
                    BL.Queue.HandleQueueFlow(VO.QueueDet.Action.Done, clsQueueDet)
                End If
            Else
                Dim frmDetail As New frmTraQueueCompareFailed
                With frmDetail
                    .pubCompanyID = UI.usUserApp.CompanyID
                    .pubLocationID = UI.usUserApp.LocationID
                    .pubLPRGet = clsLPRGet
                    .pubData = clsQueueDet
                    .StartPosition = FormStartPosition.CenterScreen
                    .ShowDialog()
                End With
            End If
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Compare RFID vs LPR")
        Finally
            prvStartTimerRFID()
        End Try
    End Sub

#End Region

    Private Sub prvUserAccess()
        'MASTER
        mnuMasterModule.Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTMODULES", "VIEW")
        mnuMasterStatus.Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSTATUS", "VIEW")
        mnuMasterSeparator1.Visible = _
            BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTMODULES", "VIEW") _
            And BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSTATUS", "VIEW")

        mnuMasterGender.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTGENDER", "VIEW")
        mnuMasterReligion.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTRELIGION", "VIEW")
        mnuMasterNationality.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTNATIONALITY", "VIEW")
        mnuMasterMaritalStatus.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTMARITALSTATUS", "VIEW")
        mnuMasterBloodType.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTBLOODTYPE", "VIEW")
        mnuMasterOccupations.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTOCCUPATIONS", "VIEW")
        mnuMasterDrivingLicenseType.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVINGLICENSETYPE", "VIEW")
        mnuMasterImageType.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTIMAGETYPE", "VIEW")
        mnuMasterDriver.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTDRIVER", "VIEW")

        mnuMasterStation.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSTATION", "VIEW")
        mnuMasterSubStation.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTSUBSTATION", "VIEW")
        mnuMasterQueueFlow.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "MSTQUEUEFLOW", "VIEW")

        'TRANSACTION
        mnuTransactionStorageLaneSwitching.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRASTORAGELANESWTCHING", "VIEW")
        mnuTransactionQueueRegister.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "ADD")
        mnuTransactionQueueQueue.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "VIEW")
        mnuTransactionQueueQueueArrange.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUE", "ARRANGE")
        mnuTransactionQueueQueueOnProgress.Enabled = _
            BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEFREEPASS", "VIEW") Or _
            BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEREPEAT", "VIEW")
        mnuTransactionUnloading.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "TRAQUEUEUNLOADING", "VIEW")

        'TOOLS
        mnuToolsSyncDataRDCToLocation_Master.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "POSTMSTRDCTOLOC", "VIEW")
        mnuToolsSyncDataLocationToRDC_Master.Enabled = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "POSTMSTLOCTORDC", "VIEW")
    End Sub

    Private Sub prvSetupStatusStrip()
        Dim buildDate As New DateTime(2000, 1, 1)
        buildDate = buildDate.AddDays(My.Application.Info.Version.Build).AddSeconds(My.Application.Info.Version.Revision * 2)

        lblVersionQMS.Text = "Version: " &
            FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly().Location).FileVersion
        lblUserID.Text = UI.usUserApp.UserID
        lblProgramGroup.Text = UI.usUserApp.ProgramName
        lblCompany.Text = UI.usUserApp.CompanyName
        lblLocation.Text = UI.usUserApp.LocationName
        lblComputerName.Text = VO.DefaultServer.ComputerName
        lblSubdivision.Text = UI.usUserApp.SubDivisionName
        lblInitalID.Text = VO.DefaultServer.InitialID
        If VO.DefaultServer.IsLinkRFIDDevice2 Then
            lblTimer.Text = Format(Now, "HH:mm:ss")
        Else
            lblTimer.Text = "RFID Device 2 Not Linked"
        End If
    End Sub

    Public Sub prvFormReload()
        prvSetupStatusStrip()
        prvUserAccess()
    End Sub

#Region "Form Handle"

    Private Sub frmSysMain_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F10 And VO.DefaultServer.IsLinkRFIDDevice2 = False Then
            Dim frmDetail As New frmSysTestInputRFID
            With frmDetail
                .pubPorts = VO.SubStation.Ports.COMPort2
                .StartPosition = FormStartPosition.CenterScreen
                .pubShowDialog(Me)
            End With
        ElseIf e.KeyCode = Keys.F11 Then
            Dim crReportFile As New rptTest
            Dim frmDetail As New frmSysReport("Testing")
            With frmDetail
                .crvViewer.ReportSource = crReportFile
                .crvViewer.Refresh()
                .crvViewer.Show()
                .WindowState = FormWindowState.Maximized
                .StartPosition = FormStartPosition.CenterScreen
                .ShowDialog()
            End With
            'frmTestPrint.ShowDialog()
        ElseIf e.KeyCode = Keys.F12 Then
            'BL.Learning.TrialInOutParamsStoredProcedure(20)
            BL.Learning.CheckErrorMessage()
            'Try
            '    BL.Learning.CheckReaderClosed()
            '    Console.WriteLine("BL.Learning.CheckTimeoutError() -> Done")
            'Catch ex As Exception
            '    Console.WriteLine(ex.Message)
            'End Try
        End If
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bolLogOut = False
        prvSetupStatusStrip()
        prvUserAccess()
        If VO.DefaultServer.IsLinkRFIDDevice2 Then
            bolSuccessSettingSerialPort = UI.usForm.SettingSerialPort(UI.usForm.usSerialPort2, VO.DefaultServer.COMPort2)
            prvStartReadRFID()
        End If
    End Sub

    Private Sub Form_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If Not bolLogOut Then
            If UI.usForm.frmAskQuestion("Exit From System ?") Then
                oUser.Logout()
                If UI.usForm.usSerialPort2.IsOpen Then
                    VO.DefaultServer.RFIDValueCOMPort2 = ""
                    tmrRFID.Dispose()
                    UI.usForm.usSerialPort2.Dispose()
                End If
                Application.Exit()
            Else
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub tmrRFID_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmrRFID.Tick
        lblTimer.Text = Format(Now, "HH:mm:ss")
        prvReadCard()
    End Sub

#End Region

#Region "Master"

    Private Sub mnuMasterModule_Click(sender As Object, e As EventArgs) Handles mnuMasterModule.Click
        UI.usForm.frmOpen(frmMainMstModule, "frmMstModules", Me)
    End Sub

    Private Sub mnuMasterStatus_Click(sender As Object, e As EventArgs) Handles mnuMasterStatus.Click
        UI.usForm.frmOpen(frmMainMstStatus, "frmMstStatus", Me)
    End Sub

    Private Sub mnuMasterGender_Click(sender As Object, e As EventArgs) Handles mnuMasterGender.Click
        UI.usForm.frmOpen(frmMainMstGender, "frmMstGender", Me)
    End Sub

    Private Sub mnuMasterReligion_Click(sender As Object, e As EventArgs) Handles mnuMasterReligion.Click
        UI.usForm.frmOpen(frmMainMstReligion, "frmMstReligion", Me)
    End Sub

    Private Sub mnuMasterNationality_Click(sender As Object, e As EventArgs) Handles mnuMasterNationality.Click
        UI.usForm.frmOpen(frmMainMstNationality, "frmMstNationality", Me)
    End Sub

    Private Sub mnuMasterMaritalStatus_Click(sender As Object, e As EventArgs) Handles mnuMasterMaritalStatus.Click
        UI.usForm.frmOpen(frmMainMstMaritalStatus, "frmMstMaritalStatus", Me)
    End Sub

    Private Sub mnuMasterBloodType_Click(sender As Object, e As EventArgs) Handles mnuMasterBloodType.Click
        UI.usForm.frmOpen(frmMainMstBloodType, "frmMstBloodType", Me)
    End Sub

    Private Sub mnuMasterOccupations_Click(sender As Object, e As EventArgs) Handles mnuMasterOccupations.Click
        UI.usForm.frmOpen(frmMainMstOccupations, "frmMstOccupations", Me)
    End Sub

    Private Sub mnuMasterDrivingLicenseType_Click(sender As Object, e As EventArgs) Handles mnuMasterDrivingLicenseType.Click
        UI.usForm.frmOpen(frmMainMstDrivingLicenseType, "frmMstDrivingLicenseType", Me)
    End Sub

    Private Sub mnuMasterImageType_Click(sender As Object, e As EventArgs) Handles mnuMasterImageType.Click
        UI.usForm.frmOpen(frmMainMstImageType, "frmMstImageType", Me)
    End Sub

    Private Sub mnuMasterDriver_Click(sender As Object, e As EventArgs) Handles mnuMasterDriver.Click
        UI.usForm.frmOpen(frmMainMstDriver, "frmMstDriver", Me)
    End Sub

    Private Sub mnuMasterRFID_Click(sender As Object, e As EventArgs) Handles mnuMasterRFID.Click
        UI.usForm.frmOpen(frmMainMstRFIDCard, "frmMstRFIDCard", Me)
    End Sub

    Private Sub mnuMasterPoint_Click(sender As Object, e As EventArgs) Handles mnuMasterStation.Click
        UI.usForm.frmOpen(frmMainMstStation, "frmMstStation", Me)
    End Sub

    Private Sub mnuMasterPointSub_Click(sender As Object, e As EventArgs) Handles mnuMasterSubStation.Click
        UI.usForm.frmOpen(frmMainMstSubStation, "frmMstSubStation", Me)
    End Sub

    Private Sub mnuMasterQueueFlow_Click(sender As Object, e As EventArgs) Handles mnuMasterQueueFlow.Click
        UI.usForm.frmOpen(frmMainMstQueueFlow, "frmMstQueueFlow", Me)
    End Sub

#End Region

#Region "Transaction"

    Private Sub mnuTransactionStorageLaneSwitching_Click(sender As Object, e As EventArgs) Handles mnuTransactionStorageLaneSwitching.Click
        UI.usForm.frmOpen(frmMainTraStorageLaneSwitching, "frmTraStorageLaneSwitching", Me)
    End Sub

    Private Sub mnuTransactionQueueRegister_Click(sender As Object, e As EventArgs) Handles mnuTransactionQueueRegister.Click
        UI.usForm.frmOpen(frmMainTraQueueRegister, "frmTraQueueRegister", Me)
    End Sub

    Private Sub mnuTransactionQueueQueue_Click(sender As Object, e As EventArgs) Handles mnuTransactionQueueQueue.Click
        UI.usForm.frmOpen(frmMainTraQueue, "frmTraQueue", Me)
    End Sub

    Private Sub mnuTransactionQueueQueueArrange_Click(sender As Object, e As EventArgs) Handles mnuTransactionQueueQueueArrange.Click
        UI.usForm.frmOpen(frmMainTraQueueArrange, "frmTraQueueArrange", Me)
    End Sub

    Private Sub mnuTransactionQueueQueueOnProgress_Click(sender As Object, e As EventArgs) Handles mnuTransactionQueueQueueOnProgress.Click
        UI.usForm.frmOpen(frmMainTraQueueOnProgress, "frmTraQueueOnProgress", Me)
    End Sub

    Private Sub mnuTransactionUnloading_Click(sender As Object, e As EventArgs) Handles mnuTransactionUnloading.Click
        UI.usForm.frmOpen(frmMainTraQueueUnloadingVer2, "frmTraQueueUnloadingVer2", Me)
    End Sub

#End Region

#Region "Tools"

    Private Sub mnuToolsLogout_Click(sender As Object, e As EventArgs) Handles mnuToolsLogout.Click
        oUser.Logout()
        Application.Exit()
    End Sub

    Private Sub mnuToolsChangePassword_Click(sender As Object, e As EventArgs) Handles mnuToolsChangePassword.Click
        oUser.ChangePassword()
    End Sub
    Private Sub mnuToolsSwitchSubDivision_Click(sender As Object, e As EventArgs) Handles mnuToolsSwitchSubDivision.Click
        UI.usForm.frmOpen(frmMainSysUserSubDivision, "frmSysUserSubDivision", Me)
    End Sub

    Private Sub mnuToolsPostingDataMasterHOToLocation_Click(sender As Object, e As EventArgs) Handles mnuToolsSyncDataRDCToLocation_Master.Click
        UI.usForm.frmOpen(frmMainSysSyncDataMasterRDCtoLocation, "frmSysSyncDataMasterRDCtoLocation", Me)
    End Sub

    Private Sub mnuToolsSyncDataLocationToRDC_Master_Click(sender As Object, e As EventArgs) Handles mnuToolsSyncDataLocationToRDC_Master.Click
        UI.usForm.frmOpen(frmMainSysSyncDataMasterLocationtoRDC, "frmSysSyncDataMasterLocationtoRDC", Me)
    End Sub

#End Region

#Region "Windows"

    Private Sub mnuWindowsTileVertical_Click(sender As Object, e As EventArgs) Handles mnuWindowsTileVertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub mnuWindowsTileHorizontal_Click(sender As Object, e As EventArgs) Handles mnuWindowsTileHorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub mnuWindowsCascade_Click(sender As Object, e As EventArgs) Handles mnuWindowsCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub mnuWindowsCloseAll_Click(sender As Object, e As EventArgs) Handles mnuWindowsCloseAll.Click
        For Each frm As Form In Me.MdiChildren
            frm.Close()
        Next
    End Sub

#End Region

End Class