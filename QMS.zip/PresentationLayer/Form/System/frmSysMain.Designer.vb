﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSysMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSysMain))
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.mnuMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterModule = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterStatus = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuMasterGender = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterReligion = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterNationality = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterMaritalStatus = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterBloodType = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterOccupations = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterDrivingLicenseType = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterImageType = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterDriver = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuMasterRFID = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterStation = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterSubStation = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMasterQueueFlow = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransaction = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransactionStorageLaneSwitching = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransactionQueue = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransactionQueueRegister = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransactionQueueQueue = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransactionQueueQueueArrange = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransactionQueueQueueOnProgress = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTransactionUnloading = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTools = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToolsSyncData = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToolsSyncDataRDCToLocation_Master = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToolsSyncDataLocationToRDC_Master = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWindows = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWindowsTileVertical = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWindowsTileHorizontal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWindowsCascade = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWindowsCloseAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWindowsSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ssMain = New System.Windows.Forms.StatusStrip()
        Me.lblUserID = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblProgramGroup = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblCompany = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblLocation = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblSubdivision = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblComputerName = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblVersionQMS = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblInitalID = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTimer = New System.Windows.Forms.ToolStripStatusLabel()
        Me.mnuToolsChangePassword = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToolsLogout = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuToolsSwitchSubDivision = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMain.SuspendLayout()
        Me.ssMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMaster, Me.mnuTransaction, Me.mnuTools, Me.mnuWindows})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.MdiWindowListItem = Me.mnuWindows
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(738, 24)
        Me.mnuMain.TabIndex = 1
        Me.mnuMain.Text = "Main Menu"
        '
        'mnuMaster
        '
        Me.mnuMaster.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMasterModule, Me.mnuMasterStatus, Me.mnuMasterSeparator1, Me.mnuMasterGender, Me.mnuMasterReligion, Me.mnuMasterNationality, Me.mnuMasterMaritalStatus, Me.mnuMasterBloodType, Me.mnuMasterOccupations, Me.mnuMasterDrivingLicenseType, Me.mnuMasterImageType, Me.mnuMasterDriver, Me.mnuMasterSeparator2, Me.mnuMasterRFID, Me.mnuMasterStation, Me.mnuMasterSubStation, Me.mnuMasterQueueFlow})
        Me.mnuMaster.Name = "mnuMaster"
        Me.mnuMaster.Size = New System.Drawing.Size(55, 20)
        Me.mnuMaster.Text = "&Master"
        '
        'mnuMasterModule
        '
        Me.mnuMasterModule.Name = "mnuMasterModule"
        Me.mnuMasterModule.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterModule.Text = "Module"
        '
        'mnuMasterStatus
        '
        Me.mnuMasterStatus.Name = "mnuMasterStatus"
        Me.mnuMasterStatus.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterStatus.Text = "Status"
        '
        'mnuMasterSeparator1
        '
        Me.mnuMasterSeparator1.Name = "mnuMasterSeparator1"
        Me.mnuMasterSeparator1.Size = New System.Drawing.Size(179, 6)
        '
        'mnuMasterGender
        '
        Me.mnuMasterGender.Name = "mnuMasterGender"
        Me.mnuMasterGender.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterGender.Text = "Gender"
        '
        'mnuMasterReligion
        '
        Me.mnuMasterReligion.Name = "mnuMasterReligion"
        Me.mnuMasterReligion.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterReligion.Text = "Religion"
        '
        'mnuMasterNationality
        '
        Me.mnuMasterNationality.Name = "mnuMasterNationality"
        Me.mnuMasterNationality.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterNationality.Text = "Nationality"
        '
        'mnuMasterMaritalStatus
        '
        Me.mnuMasterMaritalStatus.Name = "mnuMasterMaritalStatus"
        Me.mnuMasterMaritalStatus.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterMaritalStatus.Text = "Marital Status"
        '
        'mnuMasterBloodType
        '
        Me.mnuMasterBloodType.Name = "mnuMasterBloodType"
        Me.mnuMasterBloodType.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterBloodType.Text = "Blood Type"
        '
        'mnuMasterOccupations
        '
        Me.mnuMasterOccupations.Name = "mnuMasterOccupations"
        Me.mnuMasterOccupations.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterOccupations.Text = "Occupations"
        '
        'mnuMasterDrivingLicenseType
        '
        Me.mnuMasterDrivingLicenseType.Name = "mnuMasterDrivingLicenseType"
        Me.mnuMasterDrivingLicenseType.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterDrivingLicenseType.Text = "Driving License Type"
        '
        'mnuMasterImageType
        '
        Me.mnuMasterImageType.Name = "mnuMasterImageType"
        Me.mnuMasterImageType.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterImageType.Text = "Image Type"
        '
        'mnuMasterDriver
        '
        Me.mnuMasterDriver.Name = "mnuMasterDriver"
        Me.mnuMasterDriver.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterDriver.Text = "Driver"
        '
        'mnuMasterSeparator2
        '
        Me.mnuMasterSeparator2.Name = "mnuMasterSeparator2"
        Me.mnuMasterSeparator2.Size = New System.Drawing.Size(179, 6)
        '
        'mnuMasterRFID
        '
        Me.mnuMasterRFID.Name = "mnuMasterRFID"
        Me.mnuMasterRFID.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterRFID.Text = "RFID"
        '
        'mnuMasterStation
        '
        Me.mnuMasterStation.Name = "mnuMasterStation"
        Me.mnuMasterStation.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterStation.Text = "Station"
        '
        'mnuMasterSubStation
        '
        Me.mnuMasterSubStation.Name = "mnuMasterSubStation"
        Me.mnuMasterSubStation.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterSubStation.Text = "Sub Station"
        '
        'mnuMasterQueueFlow
        '
        Me.mnuMasterQueueFlow.Name = "mnuMasterQueueFlow"
        Me.mnuMasterQueueFlow.Size = New System.Drawing.Size(182, 22)
        Me.mnuMasterQueueFlow.Text = "Queue Flow"
        '
        'mnuTransaction
        '
        Me.mnuTransaction.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTransactionStorageLaneSwitching, Me.mnuTransactionQueue, Me.mnuTransactionUnloading})
        Me.mnuTransaction.Name = "mnuTransaction"
        Me.mnuTransaction.Size = New System.Drawing.Size(80, 20)
        Me.mnuTransaction.Text = "&Transaction"
        '
        'mnuTransactionStorageLaneSwitching
        '
        Me.mnuTransactionStorageLaneSwitching.Name = "mnuTransactionStorageLaneSwitching"
        Me.mnuTransactionStorageLaneSwitching.Size = New System.Drawing.Size(205, 22)
        Me.mnuTransactionStorageLaneSwitching.Text = "Storage - Lane Switching"
        '
        'mnuTransactionQueue
        '
        Me.mnuTransactionQueue.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTransactionQueueRegister, Me.mnuTransactionQueueQueue, Me.mnuTransactionQueueQueueArrange, Me.mnuTransactionQueueQueueOnProgress})
        Me.mnuTransactionQueue.Name = "mnuTransactionQueue"
        Me.mnuTransactionQueue.Size = New System.Drawing.Size(205, 22)
        Me.mnuTransactionQueue.Text = "Queue"
        '
        'mnuTransactionQueueRegister
        '
        Me.mnuTransactionQueueRegister.Name = "mnuTransactionQueueRegister"
        Me.mnuTransactionQueueRegister.Size = New System.Drawing.Size(176, 22)
        Me.mnuTransactionQueueRegister.Text = "Register"
        '
        'mnuTransactionQueueQueue
        '
        Me.mnuTransactionQueueQueue.Name = "mnuTransactionQueueQueue"
        Me.mnuTransactionQueueQueue.Size = New System.Drawing.Size(176, 22)
        Me.mnuTransactionQueueQueue.Text = "Queue"
        '
        'mnuTransactionQueueQueueArrange
        '
        Me.mnuTransactionQueueQueueArrange.Name = "mnuTransactionQueueQueueArrange"
        Me.mnuTransactionQueueQueueArrange.Size = New System.Drawing.Size(176, 22)
        Me.mnuTransactionQueueQueueArrange.Text = "Queue Arrange"
        '
        'mnuTransactionQueueQueueOnProgress
        '
        Me.mnuTransactionQueueQueueOnProgress.Name = "mnuTransactionQueueQueueOnProgress"
        Me.mnuTransactionQueueQueueOnProgress.Size = New System.Drawing.Size(176, 22)
        Me.mnuTransactionQueueQueueOnProgress.Text = "Queue On Progress"
        '
        'mnuTransactionUnloading
        '
        Me.mnuTransactionUnloading.Name = "mnuTransactionUnloading"
        Me.mnuTransactionUnloading.Size = New System.Drawing.Size(205, 22)
        Me.mnuTransactionUnloading.Text = "Unloading"
        '
        'mnuTools
        '
        Me.mnuTools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuToolsLogout, Me.mnuToolsChangePassword, Me.mnuToolsSwitchSubDivision, Me.mnuToolsSyncData})
        Me.mnuTools.Name = "mnuTools"
        Me.mnuTools.Size = New System.Drawing.Size(47, 20)
        Me.mnuTools.Text = "Tools"
        '
        'mnuToolsSyncData
        '
        Me.mnuToolsSyncData.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuToolsSyncDataRDCToLocation_Master, Me.mnuToolsSyncDataLocationToRDC_Master})
        Me.mnuToolsSyncData.Name = "mnuToolsSyncData"
        Me.mnuToolsSyncData.Size = New System.Drawing.Size(180, 22)
        Me.mnuToolsSyncData.Text = "Sync Data"
        '
        'mnuToolsSyncDataRDCToLocation_Master
        '
        Me.mnuToolsSyncDataRDCToLocation_Master.Name = "mnuToolsSyncDataRDCToLocation_Master"
        Me.mnuToolsSyncDataRDCToLocation_Master.Size = New System.Drawing.Size(226, 22)
        Me.mnuToolsSyncDataRDCToLocation_Master.Text = "Data Master RDC to Location"
        '
        'mnuToolsSyncDataLocationToRDC_Master
        '
        Me.mnuToolsSyncDataLocationToRDC_Master.Name = "mnuToolsSyncDataLocationToRDC_Master"
        Me.mnuToolsSyncDataLocationToRDC_Master.Size = New System.Drawing.Size(226, 22)
        Me.mnuToolsSyncDataLocationToRDC_Master.Text = "Data Master Location to RDC"
        '
        'mnuWindows
        '
        Me.mnuWindows.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuWindowsTileVertical, Me.mnuWindowsTileHorizontal, Me.mnuWindowsCascade, Me.mnuWindowsCloseAll, Me.mnuWindowsSeparator1})
        Me.mnuWindows.Name = "mnuWindows"
        Me.mnuWindows.Size = New System.Drawing.Size(68, 20)
        Me.mnuWindows.Text = "&Windows"
        '
        'mnuWindowsTileVertical
        '
        Me.mnuWindowsTileVertical.Name = "mnuWindowsTileVertical"
        Me.mnuWindowsTileVertical.Size = New System.Drawing.Size(151, 22)
        Me.mnuWindowsTileVertical.Text = "Tile Vertical"
        '
        'mnuWindowsTileHorizontal
        '
        Me.mnuWindowsTileHorizontal.Name = "mnuWindowsTileHorizontal"
        Me.mnuWindowsTileHorizontal.Size = New System.Drawing.Size(151, 22)
        Me.mnuWindowsTileHorizontal.Text = "Tile Horizontal"
        '
        'mnuWindowsCascade
        '
        Me.mnuWindowsCascade.Name = "mnuWindowsCascade"
        Me.mnuWindowsCascade.Size = New System.Drawing.Size(151, 22)
        Me.mnuWindowsCascade.Text = "Cascade"
        '
        'mnuWindowsCloseAll
        '
        Me.mnuWindowsCloseAll.Name = "mnuWindowsCloseAll"
        Me.mnuWindowsCloseAll.Size = New System.Drawing.Size(151, 22)
        Me.mnuWindowsCloseAll.Text = "Close All"
        '
        'mnuWindowsSeparator1
        '
        Me.mnuWindowsSeparator1.Name = "mnuWindowsSeparator1"
        Me.mnuWindowsSeparator1.Size = New System.Drawing.Size(148, 6)
        '
        'ssMain
        '
        Me.ssMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblUserID, Me.lblProgramGroup, Me.lblCompany, Me.lblLocation, Me.lblSubdivision, Me.lblComputerName, Me.lblVersionQMS, Me.lblInitalID, Me.lblTimer})
        Me.ssMain.Location = New System.Drawing.Point(0, 417)
        Me.ssMain.Name = "ssMain"
        Me.ssMain.Size = New System.Drawing.Size(738, 24)
        Me.ssMain.TabIndex = 4
        Me.ssMain.Text = "StatusStrip1"
        '
        'lblUserID
        '
        Me.lblUserID.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblUserID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserID.ForeColor = System.Drawing.Color.DimGray
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.Size = New System.Drawing.Size(50, 19)
        Me.lblUserID.Text = "UserID"
        '
        'lblProgramGroup
        '
        Me.lblProgramGroup.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblProgramGroup.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgramGroup.ForeColor = System.Drawing.Color.DimGray
        Me.lblProgramGroup.Name = "lblProgramGroup"
        Me.lblProgramGroup.Size = New System.Drawing.Size(60, 19)
        Me.lblProgramGroup.Text = "Program"
        '
        'lblCompany
        '
        Me.lblCompany.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblCompany.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCompany.ForeColor = System.Drawing.Color.DimGray
        Me.lblCompany.Name = "lblCompany"
        Me.lblCompany.Size = New System.Drawing.Size(64, 19)
        Me.lblCompany.Text = "Company"
        '
        'lblLocation
        '
        Me.lblLocation.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblLocation.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocation.ForeColor = System.Drawing.Color.DimGray
        Me.lblLocation.Name = "lblLocation"
        Me.lblLocation.Size = New System.Drawing.Size(59, 19)
        Me.lblLocation.Text = "Location"
        '
        'lblSubdivision
        '
        Me.lblSubdivision.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblSubdivision.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubdivision.ForeColor = System.Drawing.Color.DimGray
        Me.lblSubdivision.Name = "lblSubdivision"
        Me.lblSubdivision.Size = New System.Drawing.Size(75, 19)
        Me.lblSubdivision.Text = "Subdivision"
        '
        'lblComputerName
        '
        Me.lblComputerName.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblComputerName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblComputerName.ForeColor = System.Drawing.Color.DimGray
        Me.lblComputerName.Name = "lblComputerName"
        Me.lblComputerName.Size = New System.Drawing.Size(99, 19)
        Me.lblComputerName.Text = "ComputerName"
        '
        'lblVersionQMS
        '
        Me.lblVersionQMS.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblVersionQMS.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblVersionQMS.ForeColor = System.Drawing.Color.DimGray
        Me.lblVersionQMS.Name = "lblVersionQMS"
        Me.lblVersionQMS.Size = New System.Drawing.Size(53, 19)
        Me.lblVersionQMS.Text = "Version"
        '
        'lblInitalID
        '
        Me.lblInitalID.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblInitalID.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblInitalID.ForeColor = System.Drawing.Color.DimGray
        Me.lblInitalID.Name = "lblInitalID"
        Me.lblInitalID.Size = New System.Drawing.Size(58, 19)
        Me.lblInitalID.Text = "Initial ID"
        '
        'lblTimer
        '
        Me.lblTimer.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblTimer.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblTimer.ForeColor = System.Drawing.Color.DimGray
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(44, 19)
        Me.lblTimer.Text = "Timer"
        '
        'mnuToolsChangePassword
        '
        Me.mnuToolsChangePassword.Name = "mnuToolsChangePassword"
        Me.mnuToolsChangePassword.Size = New System.Drawing.Size(180, 22)
        Me.mnuToolsChangePassword.Text = "Change Password"
        '
        'mnuToolsLogout
        '
        Me.mnuToolsLogout.Name = "mnuToolsLogout"
        Me.mnuToolsLogout.Size = New System.Drawing.Size(180, 22)
        Me.mnuToolsLogout.Text = "Logout"
        '
        'mnuToolsSwitchSubDivision
        '
        Me.mnuToolsSwitchSubDivision.Name = "mnuToolsSwitchSubDivision"
        Me.mnuToolsSwitchSubDivision.Size = New System.Drawing.Size(180, 22)
        Me.mnuToolsSwitchSubDivision.Text = "Switch Sub Division"
        '
        'frmSysMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(738, 441)
        Me.Controls.Add(Me.ssMain)
        Me.Controls.Add(Me.mnuMain)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.mnuMain
        Me.Name = "frmSysMain"
        Me.Text = "Queue Management System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.ssMain.ResumeLayout(False)
        Me.ssMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterModule As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterStatus As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransaction As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWindows As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWindowsTileVertical As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWindowsTileHorizontal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWindowsCascade As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWindowsSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ssMain As System.Windows.Forms.StatusStrip
    Friend WithEvents lblUserID As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblProgramGroup As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblCompany As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblLocation As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblSubdivision As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblVersionQMS As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnuMasterSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuMasterStation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterSubStation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterGender As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterReligion As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuMasterNationality As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterMaritalStatus As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterBloodType As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterOccupations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterDrivingLicenseType As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterImageType As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterDriver As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMasterQueueFlow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTools As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuToolsSyncData As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuToolsSyncDataRDCToLocation_Master As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuToolsSyncDataLocationToRDC_Master As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransactionQueue As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransactionQueueRegister As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransactionQueueQueue As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransactionQueueQueueArrange As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransactionQueueQueueOnProgress As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblComputerName As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnuMasterRFID As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuTransactionStorageLaneSwitching As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblInitalID As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblTimer As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnuTransactionUnloading As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWindowsCloseAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuToolsChangePassword As ToolStripMenuItem
    Friend WithEvents mnuToolsLogout As ToolStripMenuItem
    Friend WithEvents mnuToolsSwitchSubDivision As ToolStripMenuItem
End Class
