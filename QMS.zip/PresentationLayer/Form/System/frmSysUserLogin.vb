Public Class frmSysUserLogin

    Dim bolOK As Boolean = False

    Public ReadOnly Property IsOK() As Boolean
        Get
            Return bolOK
        End Get
    End Property

    Private Sub prvCheckUserPassword()
        If txtUserID.Text.Trim = "" Then
            UI.usForm.frmMessageBox("User ID Cannot Blank ... ")
            txtUserID.Focus()
            bolOK = False
            Exit Sub
        End If

        If txtUserPassword.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Password Cannot Blank ... ")
            txtUserPassword.Focus()
            bolOK = False
            Exit Sub
        End If

        If Format(Now, "yyyyMMddHHmm") >= "201310112100" Then
            UI.usForm.frmMessageBox("CPS tidak dapat dipergunakan..." & vbCrLf & "Sedang dilakukan maintenance server." & vbCrLf & "Estimasi dapat dipergunakan kembali pada tanggal 12 Oktober 2013 jam 09:00 WIB.")
            Exit Sub
        End If

        Dim strUserID As String = txtUserID.Text.Trim

        If strUserID.IndexOf("@") > 0 Then
            UI.usUserApp.UserID = strUserID.Substring(0, strUserID.IndexOf("@"))
            UI.usUserApp.UserCompanyID = strUserID.Substring(strUserID.IndexOf("@") + 1)
        Else
            UI.usUserApp.UserID = txtUserID.Text.Trim
            UI.usUserApp.UserCompanyID = ""
        End If

        If BL.UserAccess.CheckUserLogin(UI.usUserApp.UserID, txtUserPassword.Text.Trim) Then
            bolOK = True
            Me.Close()
        Else
            UI.usForm.frmMessageBox("User Login Failed ... ")
            bolOK = False
            txtUserPassword.Text = ""
            txtUserPassword.Focus()
        End If
    End Sub

#Region "Form Handle"

    Private Sub Form_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtUserPassword.CharacterCasing = CharacterCasing.Normal
        lblVersion.Text = "Version 1.0"
        txtUserID.Text = oUser.UserId
        txtUserID.ReadOnly = True
    End Sub

    Private Sub Form_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Enter Then prvCheckUserPassword()
    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        prvCheckUserPassword()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        oUser.Logout()
        Application.Exit()
    End Sub

#End Region


End Class

