﻿Public Class frmSysSyncDataMasterLocationtoRDC

#Region "Properties Handle"

    Dim dtData As New List(Of DataTable)
    Dim dtAll As New DataTable("ALL"), dtDriver As New DataTable, _
        dtDriverImage As New DataTable, dtDriverStatus As New DataTable

    Private Const _
       cPost = 0, cRefresh = 1, cSep1 = 2, cClose = 3

#End Region

#Region "Function Handle"

    Private Sub prvSetProgressBar(ByVal intMax As Integer)
        pbMain.Maximum = intMax
        pbMain.Value = 0
    End Sub

    Private Sub prvRefreshProgressBar()
        pbMain.Value += 1
        Me.Refresh()
    End Sub

    Private Sub prvSetGrid()
        UI.usForm.SetGrid(grdView, "ID", "ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "IdentityCardNumber", "Identity Card Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DrivingLicenseNumber", "Driving License Number", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "FullName", "Full Name", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "PlaceOfBirth", "Place of Birth", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "DateOfBirth", "Date of Birth", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "GenderID", "GenderID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "GenderName", "Gender", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "BloodTypeID", "BloodTypeID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "BloodTypeName", "Blood Type", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "AddressOfIdentityCard", "Address [KTP]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "AddressOfDrivingLicense", "Address [SIM]", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ReligionID", "ReligionID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "ReligionName", "Religion", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "MaritalStatusID", "MaritalStatusID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "MaritalStatusName", "Marital Status", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "NationalityID", "NationalityID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "NationalityName", "Nationality", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "OccuptionsIDOfIdentityCard", "OccuptionsID [Identity Card]", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "OccuptionsNameOfIdentityCard", "Occuptions [Identity Card]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "OccupationsOthersOfIdentityCard", "Occupations Others [Identity Card]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "OccuptionsIDOfDrivingLicense", "OccuptionsIDOfDrivingLicense", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "OccuptionsNameOfDrivingLicense", "Occuptions [Driving License]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "OccupationsOthersOfDrivingLicense", "Occupations Others [Driving License]", 100, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdView, "ValidThruOfIdentityCard", "Valid Thru [KTP]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "ValidThruOfDrivingLicense", "Valid Thru [SIM]", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeID", "DrivingLicenseTypeID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "DrivingLicenseTypeName", "Tipe SIM", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Height", "Height", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "IDStatus", "IDStatus", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "StatusInfo", "Status", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedFromComLocID", "CreatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "LastUpdatedFromComLocID", "LastUpdatedFromComLocID", 100, UI.usDefGrid.gIntNum, False)
        UI.usForm.SetGrid(grdView, "CreatedFromComLoc", "Created From ComLoc", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LastUpdatedFromComLoc", "Last Updated From ComLoc", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "ReferencesID", "References ID", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "InternalRemarks", "Internal Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "Remarks", "Remarks", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedBy", "Created By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "CreatedDate", "Created Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogBy", "Log By", 100, UI.usDefGrid.gString)
        UI.usForm.SetGrid(grdView, "LogDate", "Log Date", 100, UI.usDefGrid.gFullDate)
        UI.usForm.SetGrid(grdView, "LogInc", "Log Inc", 100, UI.usDefGrid.gIntNum)
        grdView.BestFitColumns()
    End Sub

    Private Sub prvFillCombo()
        Dim dtData As New DataTable
        Dim dtUsed As New DataTable
        dtUsed.Columns.Add("ID", GetType(Integer))
        dtUsed.Columns.Add("Description", GetType(String))

        Try
            dtData = BL.Modules.ListData
            For Each dr As DataRow In dtData.Rows
                If dr.Item("ID") = VO.Modules.Values.Driver Then
                    Dim drNew As DataRow = dtUsed.NewRow
                    With drNew
                        .BeginEdit()
                        .Item("ID") = dr.Item("ID")
                        .Item("Description") = dr.Item("Description")
                        .EndEdit()
                    End With

                    dtUsed.Rows.Add(drNew)
                    dtUsed.AcceptChanges()
                End If
            Next

            dtData.Dispose()
            UI.usForm.FillComboBox(cboModule, dtUsed, "ID", "Description", True)
            cboModule.SelectedValue = VO.Modules.Values.Driver
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cPost).Enabled = bolEnable
        End With
    End Sub

    Private Function prvCollectData() As DataTable
        Dim dtReturn As New DataTable

        If cboModule.SelectedValue = VO.Modules.Values.Driver Then '# Master Driver
            dtDriver = BL.PostData.CollectDataMasterDriverLocationtoRDC
            dtDriver.TableName = BL.PostData.mDriver
            If dtDriver.Rows.Count > 0 Then dtData.Add(dtDriver)

            '# Master Driver Image
            dtDriverImage = BL.PostData.CollectDataMasterDriverImageLocationtoRDC
            dtDriverImage.TableName = BL.PostData.mDriverImage
            If dtDriverImage.Rows.Count > 0 Then dtData.Add(dtDriverImage)

            '# Master Driver Status
            dtDriverStatus = BL.PostData.CollectDataMasterDriverStatusLocationtoRDC
            dtDriverStatus.TableName = BL.PostData.mDriverStatus
            If dtDriverStatus.Rows.Count > 0 Then dtData.Add(dtDriverStatus)

            dtReturn = dtDriver
        End If
        Return dtReturn
    End Function

    Private Sub prvQuery()
        If cboModule.SelectedIndex = -1 Then
            UI.usForm.frmMessageBox("Please choose module first")
            cboModule.Focus()
            Exit Sub
        End If

        Me.Cursor = Cursors.WaitCursor
        Try
            grdMain.DataSource = prvCollectData()
            grdView.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        Finally
            Me.Cursor = Cursors.Default
            prvSetButton()
        End Try
    End Sub

    Private Sub prvClear()
        grdMain.DataSource = Nothing
        grdView.Columns.Clear()
        prvSetGrid()
        prvSetButton()
    End Sub

    Private Sub prvUserAccess()
        With ToolBar.Buttons
            .Item(cPost).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, "POSTMSTLOCTORDC", "POST")
        End With
    End Sub

    Private Sub prvPost()
        If Not UI.usForm.frmAskQuestion("Posting all data?") Then Exit Sub
        Me.Cursor = Cursors.WaitCursor
        Dim dtmSyncDate As DateTime = Now
        Try
            For Each dt As DataTable In dtData
                If dt.TableName = BL.PostData.mDriver Then '# Master Driver
                    prvSetProgressBar(dt.Rows.Count)
                    Dim clsData As VO.Driver
                    For Each dr As DataRow In dt.Rows
                        clsData = New VO.Driver
                        clsData.ID = dr.Item("ID")
                        clsData.IdentityCardNumber = dr.Item("IdentityCardNumber")
                        clsData.DrivingLicenseNumber = dr.Item("DrivingLicenseNumber")
                        clsData.FullName = dr.Item("FullName")
                        clsData.PlaceOfBirth = dr.Item("PlaceOfBirth")
                        clsData.DateOfBirth = dr.Item("DateOfBirth")
                        clsData.GenderID = dr.Item("GenderID")
                        clsData.BloodTypeID = dr.Item("BloodTypeID")
                        clsData.AddressOfIdentityCard = dr.Item("AddressOfIdentityCard")
                        clsData.AddressOfDrivingLicense = dr.Item("AddressOfDrivingLicense")
                        clsData.ReligionID = dr.Item("ReligionID")
                        clsData.MaritalStatusID = dr.Item("MaritalStatusID")
                        clsData.NationalityID = dr.Item("NationalityID")
                        clsData.OccupationsIDOfIdentityCard = dr.Item("OccupationsIDOfIdentityCard")
                        clsData.OccupationsOthersOfIdentityCard = dr.Item("OccupationsOthersOfIdentityCard")
                        clsData.OccupationsIDOfDrivingLicense = dr.Item("OccupationsIDOfDrivingLicense")
                        clsData.OccupationsOthersOfDrivingLicense = dr.Item("OccupationsOthersOfDrivingLicense")
                        clsData.ValidThruOfIdentityCard = dr.Item("ValidThruOfIdentityCard")
                        clsData.ValidThruOfDrivingLicense = dr.Item("ValidThruOfDrivingLicense")
                        clsData.DrivingLicenseTypeID = dr.Item("DrivingLicenseTypeID")
                        clsData.Height = dr.Item("Height")
                        clsData.IDStatus = dr.Item("IDStatus")
                        clsData.CreatedFromComLocID = dr.Item("CreatedFromComLocID")
                        clsData.LastUpdatedFromComLocID = dr.Item("LastUpdatedFromComLocID")
                        clsData.ReferencesID = dr.Item("ReferencesID")
                        clsData.InternalRemarks = dr.Item("InternalRemarks")
                        clsData.Remarks = dr.Item("Remarks")
                        clsData.CreatedBy = dr.Item("CreatedBy")
                        clsData.CreatedDate = dr.Item("CreatedDate")
                        clsData.LogBy = dr.Item("LogBy")
                        clsData.LogDate = dr.Item("LogDate")
                        clsData.LogInc = dr.Item("LogInc")
                        BL.PostData.PostDataMasterDriverLocationtoRDC(clsData)
                        prvRefreshProgressBar()
                    Next

                    '# Adding Sync Table
                    BL.SyncTable.SaveDataSyncDefault(VO.Modules.Values.Driver, UI.usUserApp.UserID, dtmSyncDate)
                ElseIf dt.TableName = BL.PostData.mDriverImage Then '# Master Driver Image
                    prvSetProgressBar(dt.Rows.Count)
                    Dim clsData As VO.DriverImage
                    For Each dr As DataRow In dt.Rows
                        clsData = New VO.DriverImage
                        clsData.ID = dr.Item("ID")
                        clsData.DriverID = dr.Item("DriverID")
                        clsData.ImageTypeID = dr.Item("ImageTypeID")
                        clsData.ImagePath = dr.Item("ImagePath")
                        BL.PostData.PostDataMasterDriverImageLocationtoRDC(clsData)
                        prvRefreshProgressBar()
                    Next
                ElseIf dt.TableName = BL.PostData.mDriverStatus Then '# Master Driver Status
                    prvSetProgressBar(dt.Rows.Count)
                    Dim clsData As VO.DriverStatus
                    For Each dr As DataRow In dt.Rows
                        clsData = New VO.DriverStatus
                        clsData.ID = dr.Item("ID")
                        clsData.DriverID = dr.Item("DriverID")
                        clsData.Status = dr.Item("Status")
                        clsData.StatusBy = dr.Item("StatusBy")
                        clsData.StatusDate = dr.Item("StatusDate")
                        clsData.Remarks = dr.Item("Remarks")
                        BL.PostData.PostDataMasterDriverStatusLocationtoRDC(clsData)
                        prvRefreshProgressBar()
                    Next
                End If
            Next
            UI.usForm.frmMessageBox("Posting data success")
            prvQuery()
        Catch ex As Exception
            UI.usForm.frmMessageBox("Posting data fail" & vbNewLine & ex.Message)
        Finally
            Me.Cursor = Cursors.Default
            prvSetButton()
        End Try
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmSysSyncDataMasterLocationtoRDC_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

    End Sub

    Private Sub frmSysSyncDataMasterLocationtoRDC_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolBar.SetIcon(Me)
        prvFillCombo()
        prvUserAccess()
        prvSetGrid()
        prvSetButton()

        Me.WindowState = FormWindowState.Maximized

        AddHandler btnClear.Click, AddressOf pClear
        AddHandler cboModule.TextChanged, AddressOf pClear
        cboModule.SelectedIndex = 0
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text.Trim
            Case "Post" : prvPost()
            Case "Refresh" : prvQuery()
            Case "Close" : Me.Close()
        End Select
    End Sub

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click
        prvQuery()
    End Sub

    Private Sub pClear(sender As Object, e As EventArgs)
        prvClear()
    End Sub

#End Region

End Class