﻿Imports System.Runtime.Remoting

Public Class frmSysLogin

    Private Sub frmSysLogin_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        RemotingConfiguration.Configure(AppDomain.CurrentDomain.BaseDirectory & "\Client.exe.config", False)
        Dim strXML As String = Application.StartupPath & "\QMS-CONFIG.XML"
        If Not IO.File.Exists(strXML) Then
            UI.usForm.frmMessageBox("XML File Not Found ... ")
            Exit Sub
        End If

        Dim xmlHandle As New usXML(strXML)
        With xmlHandle
            VO.DefaultServer.Server = .GetConfigInfo("CONNECTION", "SERVER", ".").Item(1)
            VO.DefaultServer.Database = .GetConfigInfo("CONNECTION", "DATABASE", ".").Item(1)
            strDBAbs = .GetConfigInfo("CONNECTION", "ABS", ".").Item(1)
            VO.DefaultServer.ReportingServer = .GetConfigInfo("CONNECTION", "REPORTSERVER", "0").Item(1)
            VO.DefaultServer.DSPath = .GetConfigInfo("CONNECTION", "DSPATH", "C:\DATA").Item(1)
            VO.DefaultServer.DSTempPath = .GetConfigInfo("CONNECTION", "DSTEMPPATH", "C:\DATA").Item(1)
            VO.DefaultServer.Use2FA = CBool(.GetConfigInfo("CONNECTION", "USE2FA", "0").Item(1))
            VO.DefaultServer.WebAPILPRReGet = .GetConfigInfo("CONNECTION", "WEBAPILPRREGET", "localhost").Item(1)
            VO.DefaultServer.WebAPILPRGet = .GetConfigInfo("CONNECTION", "WEBAPILPRGET", "localhost").Item(1)
            VO.DefaultServer.AutoDoneStationID = .GetConfigInfo("CONNECTION", "AUTODONESTATIONID", 1).Item(1)
            VO.DefaultServer.IsLinkRFIDDevice1 = .GetConfigInfo("CONNECTION", "ISLINKRFIDDEVICE1", False).Item(1)
            VO.DefaultServer.IsLinkRFIDDevice2 = .GetConfigInfo("CONNECTION", "ISLINKRFIDDEVICE2", False).Item(1)
            VO.DefaultServer.IsAutoConfirm = .GetConfigInfo("CONNECTION", "ISAUTOCONFIRM", False).Item(1)
            VO.DefaultServer.ComputerName = SharedLib.Common.GetCompName

            '# Get default value for Auto Confirm
            VO.DefaultValueAutoConfirm.QueueType = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "QUEUETYPE", False).Item(1)
            VO.DefaultValueAutoConfirm.ItemCode = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "ITEMCODE", "").Item(1)
            VO.DefaultValueAutoConfirm.ComLocDivSubDivIDStorage = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "COMLOCDIVSUBDIVIDSTORAGE", 0).Item(1)
            VO.DefaultValueAutoConfirm.ProgramIDStorage = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "PROGRAMIDSTORAGE", "").Item(1)
            VO.DefaultValueAutoConfirm.StorageGroupID = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "STORAGEGROUPID", "").Item(1)
            VO.DefaultValueAutoConfirm.StorageID = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "STORAGEID", "").Item(1)
        End With
        If ProcessLogin() = True Then
            UI.usUserApp.UserID = oUser.UserId
            UI.usUserApp.UserCompanyID = ""
            UI.usUserApp.DelegateUserID = BL.UserAccess.GetDelegatedFrom(UI.usUserApp.UserID, Today)
            BL.UserAccess.AccessFillRight()
            BL.Server.ServerAllCompanyList()
            UI.usUserApp.UserEmail = BL.UserAccess.GetUserEmail(UI.usUserApp.UserID)
            frmSysUserSubDivision.Show()
            Me.Hide()
        Else
            oUser.Logout()
            Application.Exit()
        End If
    End Sub

End Class