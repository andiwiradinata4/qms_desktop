﻿Imports DevExpress.XtraPrinting

Namespace UI
    Public Class usDXHelper
        Public Const cETDataAware = 0, cETWYSIWYG = 1
        Public Const cTEMValue = 0, cTEMText = 1
        Public MyReportTitle As String = ""

        Public Sub ExportToExcel(frmMe As Form, grdMain As DevExpress.XtraGrid.GridControl, strFileName As String, strSheetName As String, Optional ByVal bolShowGroupSummary As Boolean = False, Optional ByVal bolShowTotalSummary As Boolean = False, _
                                        Optional ByVal bytExportType As Byte = cETDataAware, Optional ByVal bytTextExportMode As Byte = cTEMValue)

            Dim ofdExport As New FolderBrowserDialog
            Dim strPath As String = ""
            With ofdExport
                If .ShowDialog() = Windows.Forms.DialogResult.OK Then
                    strPath = .SelectedPath & "\Result_" & strFileName & "_"
                    strPath = strPath & Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString & ".xls"

                    If Not UI.usForm.frmAskQuestion("Save data to " & strPath & "?") Then Exit Sub
                    Try
                        frmMe.Cursor = Cursors.WaitCursor
                        Dim advOption As New XlsExportOptionsEx()
                        advOption.AllowGrouping = DevExpress.Utils.DefaultBoolean.True
                        If bolShowGroupSummary Then advOption.ShowGroupSummaries = DevExpress.Utils.DefaultBoolean.True
                        If bolShowTotalSummary Then advOption.ShowTotalSummaries = DevExpress.Utils.DefaultBoolean.True
                        advOption.ExportType = bytExportType 'DevExpress.Export.ExportType.DataAware
                        advOption.SheetName = strSheetName
                        advOption.TextExportMode = bytTextExportMode 'TextExportMode.Value
                        grdMain.ExportToXls(strPath.Trim, advOption)
                        UI.usForm.frmMessageBox("Export data success. " & strPath)
                    Catch ex As Exception
                        UI.usForm.frmMessageBox(ex.Message)
                    End Try
                End If
            End With
            frmMe.Cursor = Cursors.Default
            ofdExport.Dispose()
        End Sub

        Public Sub Preview(grdRpt As DevExpress.XtraGrid.GridControl, Optional ByVal strPaperKind As System.Drawing.Printing.PaperKind = System.Drawing.Printing.PaperKind.Ledger, Optional ByVal bolLandscape As Boolean = False, _
                       Optional ByVal strReportTitle As String = "")
            Try
                Dim myLink As New PrintableComponentLink(New PrintingSystem())
                myLink.PaperKind = strPaperKind
                myLink.Landscape = bolLandscape

                myLink.Margins = New System.Drawing.Printing.Margins(0.1, 0.1, 0.1, 0.1)
                myLink.PrintingSystem.Document.AutoFitToPagesWidth = 1
                myLink.Component = grdRpt

                If strReportTitle <> "" Then
                    MyReportTitle = strReportTitle
                    AddHandler myLink.CreateReportHeaderArea, AddressOf MyLink_CreateReportHeaderArea
                End If

                myLink.ShowPreview()
            Catch ex As Exception
                UI.usForm.frmMessageBox(ex.Message)
            End Try
        End Sub

        Private Sub MyLink_CreateReportHeaderArea(ByVal sender As Object, ByVal e _
        As DevExpress.XtraPrinting.CreateAreaEventArgs)

            Dim brick As DevExpress.XtraPrinting.TextBrick
            brick = e.Graph.DrawString(MyReportTitle, Color.Navy, New RectangleF(0, 0, 500, 40), DevExpress.XtraPrinting.BorderSide.None)
            brick.Font = New Font("Arial", 16)
            brick.StringFormat = New DevExpress.XtraPrinting.BrickStringFormat(StringAlignment.Center)
        End Sub

        Public Sub ExportToExcel1(frmMe As Form, dtData As DataTable, strFileName As String, strSheetName As String, Optional ByVal bolShowGroupSummary As Boolean = False, Optional ByVal bolShowTotalSummary As Boolean = False, _
                                        Optional ByVal bytExportType As Byte = cETDataAware, Optional ByVal bytTextExportMode As Byte = cTEMValue)

            Dim ofdExport As New FolderBrowserDialog
            Dim strPath As String = ""
            grdA = New DevExpress.XtraGrid.GridControl()
            grdAView = New DevExpress.XtraGrid.Views.Grid.GridView(grdA)
            grdAView.GridControl = grdA
            grdA.DataSource = dtData

            With ofdExport
                If .ShowDialog() = Windows.Forms.DialogResult.OK Then
                    strPath = .SelectedPath & "\Result_" & strFileName & "_"
                    strPath = strPath & Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString & ".xls"

                    If Not UI.usForm.frmAskQuestion("Save data to " & strPath & "?") Then Exit Sub
                    Try
                        frmMe.Cursor = Cursors.WaitCursor
                        Dim advOption As New XlsExportOptionsEx()
                        advOption.AllowGrouping = DevExpress.Utils.DefaultBoolean.True
                        If bolShowGroupSummary Then advOption.ShowGroupSummaries = DevExpress.Utils.DefaultBoolean.True
                        If bolShowTotalSummary Then advOption.ShowTotalSummaries = DevExpress.Utils.DefaultBoolean.True
                        advOption.ExportType = bytExportType 'DevExpress.Export.ExportType.DataAware
                        advOption.SheetName = strSheetName
                        advOption.TextExportMode = bytTextExportMode 'TextExportMode.Value
                        grdA.ExportToXls(strPath.Trim, advOption)
                        UI.usForm.frmMessageBox("Export data success. " & strPath)
                    Catch ex As Exception
                        UI.usForm.frmMessageBox(ex.Message)
                    End Try
                End If
            End With
            frmMe.Cursor = Cursors.Default
            ofdExport.Dispose()
        End Sub

        Friend WithEvents grdA As DevExpress.XtraGrid.GridControl
        Friend WithEvents grdAView As DevExpress.XtraGrid.Views.Grid.GridView
    End Class
End Namespace