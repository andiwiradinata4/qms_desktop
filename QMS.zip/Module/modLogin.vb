﻿Imports Gma.QrCodeNet.Encoding
Imports Gma.QrCodeNet.Encoding.Windows.Render
Imports System.IO
Imports System.Drawing.Imaging
Imports System.Data.SqlClient

Module modLogin

    Public oUser As MusimMas.MMUser
    Public oConn As SqlConnection
    Public strDBAbs As String

    Public Function ProcessLogin() As Boolean
        Dim bolReturn As Boolean = False

        oUser = New MusimMas.MMUser()
        oUser.ConnDB = strDBAbs
        oUser.ConnServer = VO.DefaultServer.Server
        oConn = New SqlConnection
        oConn.ConnectionString = "Server=" & VO.DefaultServer.Server & ";Database=" & strDBAbs & ";Trusted_Connection=SSPI"
        oUser.Connection = oConn

        Dim aResult As MusimMas.MMUser.LoginResult

        If oUser.ConnConnect Then
            oUser.Use2FAAuthentication = VO.DefaultServer.Use2FA
            aResult = oUser.LoginWODetail()
            If aResult = MusimMas.MMUser.LoginResult.Succeded Then
                bolReturn = True
                UI.usUserApp.UserID = oUser.UserId
            ElseIf aResult = MusimMas.MMUser.LoginResult.LegacyLogin And VO.DefaultServer.ReportingServer = 0 Then
                Dim strLegacyUser As String = oUser.UserId
                If ValidateMyLegacyUser() = True Then
                    aResult = oUser.InitiateSwitchUser(strLegacyUser, False)
                    If aResult = MusimMas.MMUser.LoginResult.SwitchLegacyUserSucceed Then
                        SaveNewIdToMyDB(oUser.UserId)
                        MessageBox.Show("Switch user completed, application will be terminated, reopen app")
                        bolReturn = False
                    Else
                        bolReturn = False
                    End If
                End If
            Else
                bolReturn = False
            End If
        End If
        Return bolReturn
    End Function

    Public Function ValidateMyLegacyUser() As Boolean
        Dim bolOK As Boolean
        Dim frmLogin As New frmSysUserLogin
        With frmLogin
            .StartPosition = FormStartPosition.CenterScreen
            .ShowDialog()
            If .IsOK = True Then
                bolOK = True
            Else
                bolOK = False
            End If
        End With
        Return bolOK
    End Function

    Public Sub SaveNewIdToMyDB(ByVal strUserID As String)
        Dim dtDB As New DataTable
        Dim dtAll As New DataTable
        Dim dtUserListDetail As New DataTable

        BL.Server.ServerDefault()
        dtDB = BL.Server.ServerList

        For Each drDB As DataRow In dtDB.Rows
            DL.SQL.strServer = drDB.Item("Server")
            DL.SQL.strDatabase = drDB.Item("DBName")
            DL.SQL.strSAID = drDB.Item("UserID")
            DL.SQL.strSAPassword = drDB.Item("UserPassword")
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                dtUserListDetail = DL.UserAccess.GetUserListDetail(sqlCon, Nothing, UI.usUserApp.UserID, drDB.Item("DBName"))
            End Using
            dtAll.Merge(dtUserListDetail)
        Next

        If dtAll.Rows.Count > 0 Then
            Dim strUserMenu As String = ""
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                For Each drData As DataRow In dtAll.Rows
                    strUserMenu = DL.UserAccess.GetUserProgramMenu(sqlCon, Nothing, UI.usUserApp.UserID, drData("ProgramID"))
                    DL.UserAccess.CopyUserListDetail(sqlCon, Nothing, strUserID, drData("Sub_Div_Id"), drData("Com_Loc_Div_Id"), drData("ProgramId"), strUserMenu)
                Next
            End Using
        End If

        BL.Server.ServerDefault()
        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
            DL.UserAccess.UpdateLegacyID(sqlCon, Nothing, strUserID, UI.usUserApp.UserID)
        End Using

        For Each drDB As DataRow In dtDB.Rows
            DL.SQL.strServer = drDB.Item("Server")
            DL.SQL.strDatabase = drDB.Item("DBName")
            DL.SQL.strSAID = drDB.Item("UserID")
            DL.SQL.strSAPassword = drDB.Item("UserPassword")
        Next
    End Sub

    Public Function GetHRDept(ByVal strUserID As String) As String
        Dim strHRDept As String = ""
        oUser = New MusimMas.MMUser
        oUser.ConnDB = strDBAbs
        oUser.ConnServer = VO.DefaultServer.Server
        oConn = New SqlConnection
        oConn.ConnectionString = "Server=" & VO.DefaultServer.Server & ";Database=" & strDBAbs & ";Trusted_Connection=SSPI"
        oUser.Connection = oConn
        If oUser.ConnConnect Then
            oUser.UserId = strUserID
            oUser.GetUserDetails()
            strHRDept = oUser.HRDept
        End If
        Return strHRDept
    End Function

    Public Function QrCodeImage(ByVal oText As [String]) As MemoryStream
        ' generating a barcode here. Code is taken from QrCode.Net library 
        Dim qrEncoder As New QrEncoder(ErrorCorrectionLevel.H)
        Dim qrCode As New QrCode()
        qrEncoder.TryEncode(oText, qrCode)
        Dim renderer As New GraphicsRenderer(New FixedModuleSize(3, QuietZoneModules.Zero), Brushes.Black, Brushes.White)
        Dim memoryStream As Stream = New MemoryStream()
        renderer.WriteToStream(qrCode.Matrix, ImageFormat.Png, memoryStream)
        ' very important to reset memory stream to a starting position, otherwise you would get 0 bytes returned memoryStream.Position = 0 
        Dim Img As Image = Image.FromStream(memoryStream)
        Return memoryStream
    End Function

End Module
