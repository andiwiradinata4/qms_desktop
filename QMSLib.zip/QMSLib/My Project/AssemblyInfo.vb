﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Runtime.CompilerServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("QMSLib")> 
<Assembly: AssemblyDescription("Queue Management System")> 
<Assembly: AssemblyCompany("MM")> 
<Assembly: AssemblyProduct("QMSLib")> 
<Assembly: AssemblyCopyright("Copyright ©  2021")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("db99cddd-3b91-4123-8b9e-8416e2ac9fe7")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.1")> 
<Assembly: AssemblyFileVersion("1.0.0.1")> 
<Assembly: InternalsVisibleTo("QMS,PublicKey=0024000004800000940000000602000000240000525341310004000001000100077AF5118481FBCC27E13EC4115C5819AEC06D6E7B5DE3C9275E3EDB67DFF2783A24090EE955A92C0A5C0B172A0D0B5C38295BA8082256B8FDB9F1336FCB9490B7E33B811FC8C24E515D0F57BD5A933970084317D768DE3D6B49BF0C36217D501FD819D2B432DB3203B26B3227B7CE41D146CEB5641583C9CBFBAF8FC84F8FD1")> 
<Assembly: InternalsVisibleTo("QMSInterface,PublicKey=0024000004800000940000000602000000240000525341310004000001000100077AF5118481FBCC27E13EC4115C5819AEC06D6E7B5DE3C9275E3EDB67DFF2783A24090EE955A92C0A5C0B172A0D0B5C38295BA8082256B8FDB9F1336FCB9490B7E33B811FC8C24E515D0F57BD5A933970084317D768DE3D6B49BF0C36217D501FD819D2B432DB3203B26B3227B7CE41D146CEB5641583C9CBFBAF8FC84F8FD1")> 