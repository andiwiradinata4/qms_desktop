Namespace VO
    Public Class RFIDCard
        Inherits Common
        Property LocationID As String
        Property ID As String
        Property RFID As String
        Property InitialCode As String
        Property IDStatus As Byte
        Property Remarks As String
    End Class 
End Namespace

