﻿Imports Newtonsoft.Json
Namespace VO
    Public Class LPRReGet
        <JsonProperty("Status")>
        Property Status As Boolean = False
        <JsonProperty("Message")>
        Property Message As String = ""
        <JsonProperty("Payload")>
        Property Payload As Object = ""
    End Class
End Namespace
