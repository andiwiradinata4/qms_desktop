Namespace VO
    Public Class StorageLaneSwitchingDet
        Inherits Common
        Property ID As String
        Property StorageLaneSwitchingID As String
        Property SubStationID As Integer
        Property SubStationName As String
    End Class
End Namespace

