Namespace VO
    Public Class StorageLaneSwitching
        Inherits Common
        Property LocationID As String
        Property LocationName As String
        Property ID As String
        Property StorageGroupID As String
        Property StorageGroupName As String
        Property StorageID As String
        Property StorageName As String
        Property IsDeleted As Boolean
        Property Remarks As String
    End Class 
End Namespace

