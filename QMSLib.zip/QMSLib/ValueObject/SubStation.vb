Namespace VO
    Public Class SubStation
        Inherits Common
        Property LocationID As String
        Property LocationName As String
        Property ID As Integer
        Property StationID As Integer
        Property StationName As String
        Property Description As String
        Property IsDefault As Boolean
        Property ComputerName As String = ""
        Property InitialID As String = ""
        Property COMPort1 As String = ""
        Property COMPort2 As String = ""
        Property BaudRate As Integer
        Property DataBits As Integer
        Property Comparity As String = ""
        Property ComStopBits As String = ""
        Property IDStatus As Byte
        Property Remarks As String

        Enum FilterIsLinkedStorage
            All = 0
            IsLinkedStorage = 1
            IsNotLinkedStorage = 2
        End Enum

        Enum Ports
            COMPort1
            COMPort2
        End Enum

    End Class
End Namespace

