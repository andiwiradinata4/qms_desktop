﻿Namespace VO

    Public Class CS

        Private intComLocDivSubDivID As Integer
        Private strProgramID, strProgramName, strServerName As String
        Private strCompanyID, strLocationID As String
        Private strCompanyName, strLocationName, strDivisionID, strDivisionName, strSubDivisionName As String

        Public Property ComLocDivSubDivID() As Integer
            Get
                Return intComLocDivSubDivID
            End Get
            Set(ByVal value As Integer)
                intComLocDivSubDivID = value
            End Set
        End Property

        Public Property ProgramID() As String
            Get
                Return strProgramID
            End Get
            Set(ByVal value As String)
                strProgramID = value
            End Set
        End Property

        Public Property ProgramName() As String
            Get
                Return strProgramName
            End Get
            Set(ByVal value As String)
                strProgramName = value
            End Set
        End Property

        Public Property ServerName() As String
            Get
                Return strServerName
            End Get
            Set(value As String)
                strServerName = value
            End Set
        End Property

        Public Property CompanyID() As String
            Get
                Return strCompanyID
            End Get
            Set(ByVal value As String)
                strCompanyID = value
            End Set
        End Property

        Public Property CompanyName() As String
            Get
                Return strCompanyName
            End Get
            Set(ByVal value As String)
                strCompanyName = value
            End Set
        End Property

        Public Property LocationID() As String
            Get
                Return strLocationID
            End Get
            Set(ByVal value As String)
                strLocationID = value
            End Set
        End Property

        Public Property LocationName() As String
            Get
                Return strLocationName
            End Get
            Set(ByVal value As String)
                strLocationName = value
            End Set
        End Property

        Public Property DivisionID() As String
            Get
                Return strDivisionID
            End Get
            Set(ByVal value As String)
                strDivisionID = value
            End Set
        End Property

        Public Property DivisionName() As String
            Get
                Return strDivisionName
            End Get
            Set(ByVal value As String)
                strDivisionName = value
            End Set
        End Property

        Public Property SubDivisionName() As String
            Get
                Return strSubDivisionName
            End Get
            Set(ByVal value As String)
                strSubDivisionName = value
            End Set
        End Property

    End Class

End Namespace
