﻿Namespace VO

    Public Class DefaultServer
        Public Shared Server, Database, CompID, CompanyID, LocationID As String
        Public Shared Use2FA As Boolean
        Public Shared ReportingServer As Integer
        Public Shared DSPath As String
        Public Shared DSTempPath As String
        Public Shared WebAPILPRReGet As String
        Public Shared WebAPILPRGet As String
        Public Shared ComputerName As String
        Public Shared InitialID As String
        Public Shared COMPort1 As String
        Public Shared COMPort2 As String
        Public Shared ComParity As String = "NONE"
        Public Shared ComStopBits As String = "1.5"
        Public Shared BaudRate As Integer = 9600
        Public Shared DataBits As Integer = 8
        Public Shared RFIDValueCOMPort1 As String = ""
        Public Shared PrevRFIDValueCOMPort1 As String = ""
        Public Shared RFIDValueCOMPort2 As String = ""
        Public Shared PrevRFIDValueCOMPort2 As String = ""
        Public Shared AutoDoneStationID As Integer = 8
        Public Shared IsLinkRFIDDevice1 As Boolean = False
        Public Shared IsLinkRFIDDevice2 As Boolean = False
        Public Shared UserServerLocation As New VO.UserServerLocation
        Public Shared IsAutoConfirm As Boolean = False
    End Class

End Namespace
