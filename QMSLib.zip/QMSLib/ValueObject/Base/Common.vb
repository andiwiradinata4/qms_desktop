﻿Namespace VO
    Public Class Common
        Property ComLocDivSubDivID As Integer
        Property ProgramID As String
        Property CompanyID As String
        Property CompanyName As String
        Property StatusInfo As String
        Property CreatedBy As String
        Property CreatedDate As DateTime
        Property LogInc As Integer
        Property LogBy As String
        Property LogDate As DateTime

        Public Const DefaultProgramID As String = "QMS.1"
    End Class
End Namespace

