Namespace VO
    Public Class Occupations
        Inherits Common
        Property ID As Byte
        Property Description As String
        Property Remarks As String
        Property IDStatus As Byte

        Enum Values
            None = 0
            Others = 3
        End Enum
    End Class
End Namespace

