Namespace VO
    Public Class DriverStatus
        Inherits Common
        Property ID As String
        Property DriverID As String
        Property Status As String
        Property StatusBy As String
        Property StatusDate As DateTime
        Property Remarks As String
    End Class
End Namespace

