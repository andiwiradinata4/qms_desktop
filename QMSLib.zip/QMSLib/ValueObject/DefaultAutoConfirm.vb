﻿Namespace VO
    Public Class DefaultValueAutoConfirm
        Public Shared QueueType As Byte = 1
        Public Shared ItemCode As String = ""
        Public Shared ComLocDivSubDivIDStorage As Integer = 0
        Public Shared ProgramIDStorage As String = ""
        Public Shared StorageGroupID As String = ""
        Public Shared StorageID As String = ""
    End Class
End Namespace