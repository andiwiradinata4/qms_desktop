Namespace VO
    Public Class QueueDet
        Inherits Common
        Property ID As String
        Property Idx As Byte
        Property QueueID As String
        Property IsLinkedTank As Boolean
        Property StationID As Integer
        Property StationName As String
        Property SubStationID As Byte
        Property SubStationName As String
        Property IsRequested As Boolean
        Property RequestedBy As String
        Property RequestedDate As DateTime
        Property IsDone As Boolean
        Property DoneBy As String
        Property DoneDate As DateTime
        Property InternalRemarks As String
        Property Remarks As String
        Property PlatNumber As String = ""
        Property PlatNumberAcknowledge As String = ""
        Property IsSuccessCompareLPR As Boolean = False
        Property IsDeleteNextStation As Boolean = False
        Property IsIgnoreOnHold As Boolean = False
        Property IsReject As Boolean = False
        Property DetailAction As VO.QueueDetStatus.StatusAction

        Enum Action
            Request = 0
            CancelRequest = 1
            Done = 2
            CancelDone = 3
            Add = 4
            Edit = 5
            Delete = 6
            Up = 7
            Down = 8
            Reject = 9
        End Enum

        Enum FilterBy
            QueueID = 0
            StationID = 1
        End Enum

    End Class
End Namespace

