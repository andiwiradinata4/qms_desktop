Namespace VO
    Public Class Driver
        Inherits Common
        Property ID As String
        Property IdentityCardNumber As String
        Property DrivingLicenseNumber As String
        Property FullName As String
        Property PlaceOfBirth As String
        Property DateOfBirth As DateTime
        Property GenderID As Byte
        Property BloodTypeID As Byte
        Property AddressOfIdentityCard As String
        Property AddressOfDrivingLicense As String
        Property ReligionID As Byte
        Property MaritalStatusID As Byte
        Property NationalityID As Byte
        Property OccupationsIDOfIdentityCard As Byte
        Property OccupationsOthersOfIdentityCard As String
        Property OccupationsIDOfDrivingLicense As Byte
        Property OccupationsOthersOfDrivingLicense As String
        Property ValidThruOfIdentityCard As DateTime
        Property ValidThruOfDrivingLicense As DateTime
        Property DrivingLicenseTypeID As Byte
        Property Height As Integer
        Property IDStatus As Byte
        Property CreatedFromComLocID As Integer
        Property CreatedFromCompany As String
        Property CreatedFromLocation As String
        Property LastUpdatedFromComLocID As Integer
        Property LastUpdatedFromCompany As String
        Property LastUpdatedFromLocation As String
        Property ReferencesID As String
        Property InternalRemarks As String
        Property Remarks As String
    End Class 
End Namespace

