Namespace VO
    Public Class QueueLPRHistory
        Property ID As String
        Property QueueID As String
        Property ReGetStatus As Boolean
        Property ReGetMessage As String
        Property ReGetPayload As String
        Property GetID As String
        Property WBID As String
        Property GarduID As Integer
        Property Type As String
        Property PlatNumber As String
        Property CaptureDate As DateTime
        Property GetStatus As Boolean
        Property GetMessage As String
    End Class 
End Namespace

