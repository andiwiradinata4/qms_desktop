Namespace VO
    Public Class ImageType
        Inherits Common
        Property ID As Byte
        Property Description As String
        Property IDStatus As Byte
        Property Remarks As String

        Enum Values
            FaceRecognation = 1
            IdentityCard = 2
            DrivingLicense = 3
        End Enum
    End Class
End Namespace

