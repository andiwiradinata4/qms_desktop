﻿Namespace VO
    Public Class LPRGet
        Property InternalID As String
        Property Id As String
        Property WbId As String
        Property GarduId As Integer
        Property Tipe As String
        Property PlatNo As String = ""
        Property CaptureDate As DateTime
        Property Status As Boolean
        Property Message As String
    End Class
End Namespace