Namespace VO
    Public Class QueueStatus
        Inherits Common
        Property ID As String
        Property QueueID As String
        Property Status As String
        Property StatusBy As String
        Property StatusDate As DateTime
        Property Remarks As String
    End Class
End Namespace