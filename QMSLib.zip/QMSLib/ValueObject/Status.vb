Namespace VO
    Public Class Status
        Inherits Common
        Property ID As Byte
        Property Description As String
        Property Remarks As String
        Property IsActive As Boolean

        Enum Values
            All = 0
            Active = 1
            InActive = 2
            Blacklist = 3
            Draft = 4
            Verified = 5
            Deleted = 6
            Confirm = 7
            Completed = 8
            Requested = 9
            Done = 10
        End Enum
    End Class
End Namespace

