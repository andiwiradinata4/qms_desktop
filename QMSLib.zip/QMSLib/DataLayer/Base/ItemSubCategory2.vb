﻿Namespace DL

    Friend Class ItemSubCategory2

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  Optional ByVal intSubCategory1ID As Integer = -1, Optional ByVal intGroupID As Integer = -1,
                                        Optional ByVal bolBCFacility As Boolean = False) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " &
                    "   A.SubCategory2ID, A.SubCategory2Code, A.SubCategory2Name, " &
                    "   A.ClassID, B.ClassCode, B.ClassName, " &
                    "   A.GroupID, C.GroupCode, C.GroupName, " &
                    "   A.CategoryID, D.CategoryCode, D.CategoryName, " &
                    "   A.SubCategory1ID, E.SubCategory1Code, E.SubCategory1Name, " &
                    "   A.Status,CASE A.Status WHEN 0 THEN 'ACTIVE' WHEN 1 THEN 'IN-ACTIVE' END AS StatusInfo," &
                    "   A.LogInc, A.LogBy, A.LogDate " &
                    "FROM QMS_vwItemSubCategory2 A " &
                    "INNER JOIN QMS_vwItemClass B ON " &
                    "   A.ClassID=B.ClassID " &
                    "INNER JOIN QMS_vwItemGroup C ON " &
                    "   A.GroupID=C.GroupID " &
                    "INNER JOIN QMS_vwItemCategory D ON " &
                    "   A.CategoryID=D.CategoryID " &
                    "INNER JOIN QMS_vwItemSubCategory1 E ON " &
                    "   A.SubCategory1ID=E.SubCategory1ID "

                If bolBCFacility Then
                    .CommandText +=
                    "LEFT JOIN QMS_sysSubCategory2BCFacility SCF " &
                        " ON SCF.SubCategory2ID = A.SubCategory2ID " &
                    "WHERE SCF.SubCategory2ID IS NULL "
                Else
                    .CommandText += "WHERE 1=1 "
                End If

                If intGroupID <> -1 Then
                    .CommandText += "AND A.GroupID = @GroupID "
                    .Parameters.AddWithValue("@GroupID", intGroupID)
                End If

                If intSubCategory1ID <> -1 Then
                    .CommandText += "AND A.SubCategory1ID = @SubCategory1ID "
                    .Parameters.Add("@SubCategory1ID", SqlDbType.Int).Value = intSubCategory1ID
                End If

                .CommandText += "ORDER BY A.SubCategory2Code, B.ClassCode, C.GroupCode, D.CategoryCode, E.SubCategory1Code"
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

    End Class

End Namespace
