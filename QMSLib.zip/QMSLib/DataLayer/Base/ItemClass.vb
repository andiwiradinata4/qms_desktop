﻿Namespace DL

    Friend Class ItemClass

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " &
                    "   ClassID, ClassCode, ClassName, Status, " &
                    "   Case Status WHEN 0 THEN 'ACTIVE' WHEN 1 THEN 'IN-ACTIVE' END AS StatusInfo, " &
                    "   StatusRemarks, LogInc, LogBy, LogDate " &
                    "FROM QMS_vwItemClass " &
                    "ORDER BY ClassCode "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

    End Class

End Namespace
