﻿Namespace DL

    Friend Class ItemGroup

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  Optional ByVal intClassID As Integer = -1) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " &
                    "   A.GroupID, A.GroupCode, A.GroupName, " &
                    "   A.ClassID, B.ClassCode, B.ClassName, " &
                    "   A.Status, CASE A.Status When 0 Then 'ACTIVE' When 1 Then 'IN-ACTIVE' End as StatusInfo, " &
                    "   A.StatusRemarks, A.LogInc, A.LogBy, A.LogDate " &
                    "FROM QMS_vwItemGroup A " &
                    "INNER JOIN QMS_vwItemClass B ON " &
                    "   A.ClassID=B.ClassID "

                If intClassID <> -1 Then
                    .CommandText += "WHERE A.ClassID = @ClassID "
                    .Parameters.Add("@ClassID", SqlDbType.Int).Value = intClassID
                End If

                .CommandText += "ORDER BY A.GroupCode, A.ClassID"
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

    End Class

End Namespace

