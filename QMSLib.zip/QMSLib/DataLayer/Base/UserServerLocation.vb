Namespace DL
    Friend Class UserServerLocation

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ComLocDivSubDivID, A.Server, A.DBName  " & vbNewLine &
                   "FROM QMS_sysUserServerLocation A " & vbNewLine

            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.UserServerLocation)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_sysUserServerLocation " & vbNewLine &
                       "    (ComLocDivSubDivID, Server, DBName)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@ComLocDivSubDivID, @Server, @DBName)  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_sysUserServerLocation SET " & vbNewLine &
                       "    Server=@Server, " & vbNewLine &
                       "    DBName=@DBName " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine
                End If

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = clsData.ComLocDivSubDivID
                .Parameters.Add("@Server", SqlDbType.VarChar, 50).Value = clsData.Server
                .Parameters.Add("@DBName", SqlDbType.VarChar, 50).Value = clsData.DBName
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal intComLocDivSubDivID As Integer) As VO.UserServerLocation
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.UserServerLocation
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ComLocDivSubDivID, A.Server, A.DBName  " & vbNewLine &
                       "FROM QMS_sysUserServerLocation A " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ComLocDivSubDivID = .Item("ComLocDivSubDivID")
                        voReturn.Server = .Item("Server")
                        voReturn.DBName = .Item("DBName")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal intComLocDivSubDivID As Integer)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_sysUserServerLocation " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function DataExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal intComLocDivSubDivID As Integer) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ComLocDivSubDivID " & vbNewLine &
                        "FROM QMS_sysUserServerLocation " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

    End Class

End Namespace

