﻿Namespace DL

    Friend Class Item

        Protected Friend Shared Function ListAllData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     Optional ByVal bolShowAll As Boolean = False,
                                                     Optional ByVal strItemCode As String = "",
                                                     Optional ByVal strItemName As String = "",
                                                     Optional ByVal bolHideInactive As Boolean = False) As DataTable

            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " & vbNewLine &
                    "   A.ItemID, A.ItemCode, A.ItemName, A.UomCode, " & vbNewLine &
                    "   CONVERT(bit,(CASE WHEN J.ItemID IS NULL THEN 0 ELSE 1 END)) AS Subs, " & vbNewLine &
                    "   A.HSCode, A.HSCodeBy, CASE WHEN A.HSCodeBy='' THEN NULL ELSE A.HSCodeDate END AS HSCodeDate, " & vbNewLine &
                    "   A.ClassID, B.ClassCode, B.ClassName, " & vbNewLine &
                    "   A.GroupID, C.GroupCode, C.GroupName, " & vbNewLine &
                    "   A.CategoryID, D.CategoryCode, D.CategoryName, " & vbNewLine &
                    "   A.SubCategory1ID, E.SubCategory1Code, E.SubCategory1Name, " & vbNewLine &
                    "   A.SubCategory2ID, F.SubCategory2Code, F.SubCategory2Name, " & vbNewLine &
                    "   A.AccGroupID, G.AccGroupCode, G.AccGroupName, " & vbNewLine &
                    "   A.AccCategoryID, H.AccCategoryCode, H.AccCategoryName, " & vbNewLine &
                    "   A.AccSubCategoryID, I.AccSubCategoryCode, I.AccSubCategoryName, A.RefPrice, " & vbNewLine &
                    "   A.Status,CASE A.Status WHEN 0 THEN 'ACTIVE' WHEN 1 THEN 'IN-ACTIVE' END AS StatusInfo, " & vbNewLine &
                    "   A.StatusBy, A.StatusDate, A.xToleranceType, A.xToleranceValue, " & vbNewLine &
                    "   CONVERT(bit,A.IsCriticalChemical) AS IsCriticalChemical, " & vbNewLine &
                    "   CONVERT(bit,A.IsCriticalFuel) AS IsCriticalFuel, " & vbNewLine &
                    "   A.IsContract, CAST(ISNULL(IA.IsAltName,0) AS BIT) AS IsAltName, " & vbNewLine &
                    "   A.IsImport, A.IsSourcingItem, A.xBrand, A.PartNumber, A.WeightInKg, A.LocationItem, A.LocationItem, A.LogInc, A.LogBy, A.LogDate " & vbNewLine &
                    "FROM QMS_vwItem A " & vbNewLine &
                    "INNER JOIN QMS_vwItemClass B ON " & vbNewLine &
                    "   A.ClassID=B.ClassID " & vbNewLine &
                    "INNER JOIN QMS_vwItemGroup C ON " & vbNewLine &
                    "   A.GroupID=C.GroupID " & vbNewLine &
                    "INNER JOIN QMS_vwItemCategory D ON " & vbNewLine &
                    "   A.CategoryID=D.CategoryID " & vbNewLine &
                    "INNER JOIN QMS_vwItemSubCategory1 E ON " & vbNewLine &
                    "   A.SubCategory1ID=E.SubCategory1ID " & vbNewLine &
                    "INNER JOIN QMS_vwItemSubCategory2 F ON " & vbNewLine &
                    "   A.SubCategory2ID=F.SubCategory2ID " & vbNewLine &
                    "INNER JOIN QMS_vwItemAccGroup G ON " & vbNewLine &
                    "   A.AccGroupID=G.AccGroupID " & vbNewLine &
                    "INNER JOIN QMS_vwItemAccCategory H ON " & vbNewLine &
                    "   A.AccCategoryID=H.AccCategoryID " & vbNewLine &
                    "INNER JOIN QMS_vwItemAccSubCategory I ON " & vbNewLine &
                    "   A.AccSubCategoryID=I.AccSubCategoryID " & vbNewLine &
                    "INNER JOIN QMS_vwItemSub W ON " & vbNewLine &
                    "   A.ItemID = W.ItemID " & vbNewLine &
                    "LEFT JOIN " & vbNewLine &
                    "   (SELECT ItemID,MAX(ItemSubID) AS ItemSubID FROM QMS_vwItemSubsitution GROUP BY ItemID) J ON " & vbNewLine &
                    "   A.ItemID=J.ItemID " & vbNewLine &
                    "LEFT JOIN " & vbNewLine &
                    "   (SELECT ItemID, CAST(1 AS BIT) AS IsAltName " & vbNewLine &
                    "   FROM QMS_vwItemAlternate " & vbNewLine &
                    "   GROUP BY ItemID) IA ON " & vbNewLine &
                    "   A.ItemID = IA.ItemID "

                If Not bolShowAll Then
                    .CommandText += "WHERE "
                    If strItemCode <> "" And strItemName <> "" Then
                        .CommandText += "A.ItemCode LIKE @ItemCode AND A.ItemName LIKE @ItemName "
                        .Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = "%" + strItemCode + "%"
                        .Parameters.Add("@ItemName", SqlDbType.VarChar).Value = "%" + strItemName + "%"
                    ElseIf strItemName <> "" And strItemCode = "" Then
                        .CommandText += "A.ItemName LIKE @ItemName "
                        .Parameters.Add("@ItemName", SqlDbType.VarChar).Value = "%" + strItemName + "%"
                    ElseIf strItemName = "" And strItemCode <> "" Then
                        .CommandText += "A.ItemCode LIKE @ItemCode "
                        .Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = "%" + strItemCode + "%"
                    Else
                        .CommandText += "1=0 "
                    End If

                    If bolHideInactive = True Then
                        .CommandText += "AND A.Status <> 1 "
                    End If
                End If

                .CommandText +=
                    "GROUP BY " & vbNewLine &
                    "   A.ItemID, A.ItemCode, A.ItemName, A.UomCode, " & vbNewLine &
                    "   J.ItemID, A.HSCode, A.HSCodeBy, A.HSCodeDate, " & vbNewLine &
                    "   A.ClassID, B.ClassCode, B.ClassName, " & vbNewLine &
                    "   A.GroupID, C.GroupCode, C.GroupName, " & vbNewLine &
                    "   A.CategoryID, D.CategoryCode, D.CategoryName, " & vbNewLine &
                    "   A.SubCategory1ID, E.SubCategory1Code, E.SubCategory1Name, " & vbNewLine &
                    "   A.SubCategory2ID, F.SubCategory2Code, F.SubCategory2Name, " & vbNewLine &
                    "   A.AccGroupID, G.AccGroupCode, G.AccGroupName, " & vbNewLine &
                    "   A.AccCategoryID, H.AccCategoryCode, H.AccCategoryName, " & vbNewLine &
                    "   A.AccSubCategoryID, I.AccSubCategoryCode, I.AccSubCategoryName, A.RefPrice, " & vbNewLine &
                    "   A.Status, A.StatusBy, A.StatusDate, A.xToleranceType, A.xToleranceValue, A.IsCriticalChemical, A.IsCriticalFuel, " & vbNewLine &
                    "   A.IsContract, IA.IsAltName, A.IsImport, A.IsSourcingItem, A.xBrand, A.PartNumber, A.WeightInKg, A.LocationItem, A.LogInc, A.LogBy, A.LogDate " & vbNewLine &
                    "ORDER BY A.ItemCode "

            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal intItemID As Integer, Optional ByVal bolSAPLockPrice As Boolean = False) As VO.Item
            Dim sqlcmdExecute As New SqlCommand
            Dim sqlrdData As SqlDataReader = Nothing
            Dim clsReturn As New VO.Item
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1  " & vbNewLine &
                        "   A.ItemCode, A.ItemName, A.UomCode, " & vbNewLine &
                        "   A.ClassID, B.ClassCode, B.ClassName, " & vbNewLine &
                        "   A.GroupID, C.GroupCode, C.GroupName, " & vbNewLine &
                        "   A.CategoryID, D.CategoryCode, D.CategoryName, " & vbNewLine &
                        "   A.SubCategory1ID, E.SubCategory1Code, E.SubCategory1Name, " & vbNewLine &
                        "   A.SubCategory2ID, F.SubCategory2Code, F.SubCategory2Name, " & vbNewLine &
                        "   A.AccGroupID, G.AccGroupCode, G.AccGroupName, " & vbNewLine &
                        "   A.AccCategoryID, H.AccCategoryCode, H.AccCategoryName, " & vbNewLine &
                        "   A.AccSubCategoryID, I.AccSubCategoryCode, I.AccSubCategoryName, " & vbNewLine &
                        "   A.Remarks, " & vbNewLine &
                        "   A.Status, A.StatusRemarks, " & vbNewLine &
                        "   A.LogInc, A.LogBy, A.LogDate, " & vbNewLine &
                        "   A.GNCode, ISNULL(J.GNName,'') AS GNName, " & vbNewLine &
                        "   A.xName, A.xBrand, A.xType, A.xSpec, A.xCountry, "

                    If bolSAPLockPrice Then
                        .CommandText +=
                        "   CASE WHEN (A.GroupID=2) THEN 0 ELSE A.RefPrice END AS RefPrice, "
                    Else
                        .CommandText +=
                        "   A.RefPrice, "
                    End If

                    .CommandText +=
                            "   A.RefDate, " & vbNewLine &
                            "   A.HSCode, A.HSCodeBy, A.HSCodeDate, " & vbNewLine &
                            "   A.StatusBy, A.StatusDate, " & vbNewLine &
                            "   A.IsCriticalChemical, A.IsCriticalFuel, " & vbNewLine &
                            "   A.xToleranceType, A.xToleranceValue, " & vbNewLine &
                            "   A.IsContract, " & vbNewLine &
                            "   A.xID1, A.ItemChineseName, A.ItemSpanishName, A.WeightInKg, A.PartNumber, A.LocationItem " & vbNewLine &
                            "FROM QMS_vwItem A " & vbNewLine &
                            "INNER JOIN QMS_vwItemClass B ON " & vbNewLine &
                            "   A.ClassID=B.ClassID " & vbNewLine &
                            "INNER JOIN QMS_vwItemGroup C ON " & vbNewLine &
                            "   A.GroupID=C.GroupID " & vbNewLine &
                            "INNER JOIN QMS_vwItemCategory D ON " & vbNewLine &
                            "   A.CategoryID=D.CategoryID " & vbNewLine &
                            "INNER JOIN QMS_vwItemSubCategory1 E ON " & vbNewLine &
                            "   A.SubCategory1ID=E.SubCategory1ID " & vbNewLine &
                            "INNER JOIN QMS_vwItemSubCategory2 F ON " & vbNewLine &
                            "   A.SubCategory2ID=F.SubCategory2ID " & vbNewLine &
                            "INNER JOIN QMS_vwItemAccGroup G ON " & vbNewLine &
                            "   A.AccGroupID=G.AccGroupID " & vbNewLine &
                            "INNER JOIN QMS_vwItemAccCategory H ON " & vbNewLine &
                            "   A.AccCategoryID=H.AccCategoryID " & vbNewLine &
                            "INNER JOIN QMS_vwItemAccSubCategory I ON " & vbNewLine &
                            "   A.AccSubCategoryID=I.AccSubCategoryID " & vbNewLine &
                            "LEFT JOIN QMS_vwItemGN J ON " & vbNewLine &
                            "   A.GNCode=J.GNCode " & vbNewLine &
                            "WHERE " & vbNewLine &
                            "   A.ItemID=@ItemID "

                    .Parameters.Add("@ItemID", SqlDbType.Int).Value = intItemID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        clsReturn.ItemID = intItemID
                        clsReturn.ItemCode = .Item("ItemCode")
                        clsReturn.ItemName = .Item("ItemName")
                        clsReturn.UomCode = .Item("UomCode")
                        clsReturn.ClassID = .Item("ClassID")
                        clsReturn.ClassCode = .Item("ClassCode")
                        clsReturn.ClassName = .Item("ClassName")
                        clsReturn.GroupID = .Item("GroupID")
                        clsReturn.GroupCode = .Item("GroupCode")
                        clsReturn.GroupName = .Item("GroupName")
                        clsReturn.CategoryID = .Item("CategoryID")
                        clsReturn.CategoryCode = .Item("CategoryCode")
                        clsReturn.CategoryName = .Item("CategoryName")
                        clsReturn.SubCategory1ID = .Item("SubCategory1ID")
                        clsReturn.SubCategory1Code = .Item("SubCategory1Code")
                        clsReturn.SubCategory1Name = .Item("SubCategory1Name")
                        clsReturn.SubCategory2ID = .Item("SubCategory2ID")
                        clsReturn.SubCategory2Code = .Item("SubCategory2Code")
                        clsReturn.SubCategory2Name = .Item("SubCategory2Name")
                        clsReturn.AccGroupID = .Item("AccGroupID")
                        clsReturn.AccGroupCode = .Item("AccGroupCode")
                        clsReturn.AccGroupName = .Item("AccGroupName")
                        clsReturn.AccCategoryID = .Item("AccCategoryID")
                        clsReturn.AccCategoryCode = .Item("AccCategoryCode")
                        clsReturn.AccCategoryName = .Item("AccCategoryName")
                        clsReturn.AccSubCategoryID = .Item("AccSubCategoryID")
                        clsReturn.AccSubCategoryCode = .Item("AccSubCategoryCode")
                        clsReturn.AccSubCategoryName = .Item("AccSubCategoryName")
                        clsReturn.Remarks = .Item("Remarks")
                        clsReturn.Status = .Item("Status")
                        clsReturn.StatusRemarks = .Item("StatusRemarks")
                        clsReturn.LogInc = .Item("LogInc")
                        clsReturn.LogBy = .Item("LogBy")
                        clsReturn.LogDate = .Item("LogDate")

                        clsReturn.GNCode = .Item("GNCode")
                        clsReturn.GNName = .Item("GNName")

                        clsReturn.xName = .Item("xName")
                        clsReturn.xBrand = .Item("xBrand")
                        clsReturn.xType = .Item("xType")
                        clsReturn.xSpec = .Item("xSpec")
                        clsReturn.xCountry = .Item("xCountry")
                        clsReturn.RefPrice = .Item("RefPrice")
                        clsReturn.RefDate = .Item("RefDate")
                        clsReturn.HSCode = .Item("HSCode")
                        clsReturn.HSCodeBy = .Item("HSCodeBy")
                        clsReturn.HSCodeDate = .Item("HSCodeDate")

                        clsReturn.StatusBy = .Item("StatusBy")
                        clsReturn.StatusDate = .Item("StatusDate")

                        clsReturn.IsCriticalChemical = .Item("IsCriticalChemical")
                        clsReturn.IsCriticalFuel = .Item("IsCriticalFuel")

                        clsReturn.xToleranceType = .Item("xToleranceType")
                        clsReturn.xToleranceValue = .Item("xToleranceValue")

                        clsReturn.xID1 = .Item("xID1")
                        clsReturn.IsContract = .Item("IsContract")

                        clsReturn.ItemChineseName = .Item("ItemChineseName")
                        clsReturn.ItemSpanishName = .Item("ItemSpanishName")
                        clsReturn.WeightInKg = .Item("WeightInKg")
                        clsReturn.PartNumber = .Item("PartNumber")
                        clsReturn.LocationItem = .Item("LocationItem")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return clsReturn
        End Function

        Protected Friend Shared Function IsInactiveItem(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal intItemID As Integer) As Boolean
            Dim bolInactive As Boolean = False
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT [Status] " & vbNewLine &
                        "FROM QMS_vwItem " & vbNewLine &
                        "WHERE ItemID = @ItemID "

                    .Parameters.Add("@ItemID", SqlDbType.Int).Value = intItemID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        If .Item(0) = 0 Then
                            bolInactive = False
                        ElseIf .Item(0) = 1 Then
                            bolInactive = True
                        End If
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolInactive
        End Function

    End Class

End Namespace