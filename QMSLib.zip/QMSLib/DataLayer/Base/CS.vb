﻿Namespace DL

    Friend Class CS

        Protected Friend Shared Function GetComLocIDByComLocDiv(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal intComLocDivSubDivID As Integer) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Dim strCompanyID As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1   
	ComLocID, CompanyID  
FROM QMS_vwCompanyStructure  
WHERE  
	ComLocDivSubDivID=@ComLocDivSubDivID  
"
                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ComLocID")
                        strCompanyID = .Item("CompanyID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            If intReturn <> 0 Then
                Return intReturn
            Else
                Err.Raise(515, "", "Cannot Save." & vbCrLf & "Company Location ID For CompanyID : " & strCompanyID & " cannot be blank." & vbCrLf & "Please contact IT-Software Support for the data initialization.")
                Return ""
            End If
        End Function

        Public Shared Function GetComLocInfoByComLocDiv(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal intComLocDivSubDivID As Integer) As VO.CS
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim clsReturn As New VO.CS
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1  " & vbNewLine &
                        "  CompanyID, CompanyName, LocationID, LocationName " & vbNewLine &
                        "FROM QMS_vwCompanyStructure " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        clsReturn.CompanyID = .Item("CompanyID")
                        clsReturn.CompanyName = .Item("CompanyName")
                        clsReturn.LocationID = .Item("LocationID")
                        clsReturn.LocationName = .Item("LocationName")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return clsReturn
        End Function

        Public Shared Function GetComLocInitialByComLocDiv(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal intComLocDivSubDivID As Integer) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strReturn As String = ""
            Dim strCompanyID As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1  " & vbNewLine &
                        "  ComLocInitial, CompanyID " & vbNewLine &
                        "FROM QMS_vwCompanyStructure " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   ComLocDivSubDivID=@ComLocDivSubDivID "

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strReturn = .Item("ComLocInitial")
                        strCompanyID = .Item("CompanyID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            If strReturn <> "" Then
                Return strReturn
            Else
                Err.Raise(515, "", "Cannot Save." & vbCrLf & "Company Location Initial For CompanyID : " & strCompanyID & " cannot be blank." & vbCrLf & "Please contact IT-Software Support for the data initialization.")
                Return ""
            End If
        End Function

        Public Shared Function GetComLocInitialByLocationID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal strCompanyID As String, ByVal strLocationID As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strReturn As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1  " & vbNewLine &
                        "  ComLocInitial " & vbNewLine &
                        "FROM QMS_vwCompanyStructure " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   CompanyID=@CompanyID " & vbNewLine &
                        "   AND LocationID=@LocationID "

                    .Parameters.Add("@CompanyID", SqlDbType.VarChar, 20).Value = strCompanyID
                    .Parameters.Add("@LocationID", SqlDbType.VarChar, 20).Value = strLocationID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strReturn = .Item("ComLocInitial")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            If strReturn <> "" Then
                Return strReturn
            Else
                Err.Raise(515, "", "Cannot Save." & vbCrLf & "Company Location Initial For CompanyID : " & strCompanyID & " cannot be blank." & vbCrLf & "Please contact IT-Software Support for the data initialization.")
                Return ""
            End If
        End Function

        Public Shared Function ListDataAllComLocInitial(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strCompanyID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " & vbNewLine & vbNewLine &
                    "	ComLocInitial " & vbNewLine & vbNewLine &
                    "FROM QMS_vwCompanyStructure  " & vbNewLine & vbNewLine &
                    "WHERE " & vbNewLine & vbNewLine &
                    "	ComLocInitial<>''" & vbNewLine

                If strCompanyID.Trim <> "" Then
                    .CommandText +=
                    "	AND CompanyID=@CompanyID " & vbNewLine
                End If

                .CommandText +=
                    "GROUP BY ComLocInitial " & vbNewLine & vbNewLine &
                    "ORDER BY ComLocInitial " & vbNewLine

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

    End Class

End Namespace
