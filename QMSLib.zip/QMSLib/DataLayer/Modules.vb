Namespace DL
    Friend Class Modules

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
SELECT  
    CAST(0 AS BIT) AS Pick, A.ID, A.Description, A.Remarks, A.IsActive, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate,    
    A.LogInc   
FROM QMS_mstModules A  
"

            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.Modules)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
"
INSERT INTO QMS_mstModules  
    (ID, Description, Remarks, IsActive, CreatedBy, LogBy)    
VALUES  
    (@ID, @Description, @Remarks, @IsActive, @LogBy, @LogBy)   
"
                Else
                    .CommandText =
"
UPDATE QMS_mstModules SET  
    Description=@Description,  
    Remarks=@Remarks,  
    IsActive=@IsActive,  
    LogBy=@LogBy,  
    LogDate=GETDATE(),  
    LogInc=LogInc+1  
WHERE  
    ID=@ID  
"
                End If
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 100).Value = clsData.Description
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@IsActive", SqlDbType.TinyInt).Value = clsData.IsActive
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal bytID As Byte) As VO.Modules
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Modules
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
    A.ID, A.Description, A.Remarks, A.IsActive, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate,    
    A.LogInc   
FROM QMS_mstModules A  
WHERE  
    ID=@ID  
"

                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.Description = .Item("Description")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.IsActive = .Item("IsActive")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   ID=ISNULL(MAX(ID),0)  
FROM QMS_mstModules  
"
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IsIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   ID  
FROM QMS_mstModules  
WHERE   
   ID=@ID  
"
                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDescriptionExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                             ByVal bytID As Byte, ByVal strDescription As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   Description  
FROM QMS_mstModules  
WHERE   
   ID<>@ID AND Description=@Description  
"
                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                    .Parameters.Add("@Description", SqlDbType.VarChar, 100).Value = strDescription
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.Modules)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
UPDATE QMS_mstModules SET  
    IsActive=0,  
    LogBy=@LogBy,  
    LogDate=GETDATE(),  
    LogInc=LogInc+1  
WHERE  
    ID=@ID  
"
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function IsActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   Description  
FROM QMS_mstModules  
WHERE   
   ID=@ID AND IsActive=1  
"
                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#Region "Post Data"

        Protected Friend Shared Function QueryOutstandingPosting() As String
            Dim strReturn As String =
"
SELECT  
    A.ID, A.Description, A.Remarks, A.IsActive, A.CreatedBy, A.CreatedDate, A.LogBy,    
    A.LogDate, A.LogInc   
FROM QMS_mstModules A  
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostData() As String
            Dim strReturn As String =
"
IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstModules WHERE ID=@ID)  
BEGIN  
   INSERT INTO QMS_mstModules  
   (ID, Description, Remarks, IsActive, CreatedBy, CreatedDate, LogBy, LogDate, LogInc)    
   VALUES  
   (@ID, @Description, @Remarks, @IsActive, @CreatedBy, @CreatedDate, @LogBy, @LogDate, @LogInc)   
END  
ELSE  
BEGIN  
   UPDATE QMS_mstModules SET  
       Description=@Description,  
       Remarks=@Remarks,  
       IsActive=@IsActive,  
       CreatedBy=@CreatedBy,  
       CreatedDate=@CreatedDate,  
       LogBy=@LogBy,  
       LogDate=@LogDate,  
       LogInc=@LogInc  
   WHERE  
       ID=@ID  
END  
"
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocation() As DataTable
            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPosting)
        End Function

        Protected Friend Shared Sub PostDataRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal clsData As VO.Modules)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryPostData()
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 100).Value = clsData.Description
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@IsActive", SqlDbType.Bit).Value = clsData.IsActive
                .Parameters.Add("@CreatedBy", SqlDbType.VarChar, 20).Value = clsData.CreatedBy
                .Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = clsData.CreatedDate
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@LogDate", SqlDbType.DateTime).Value = clsData.LogDate
                .Parameters.Add("@LogInc", SqlDbType.Int).Value = clsData.LogInc
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

    End Class

End Namespace

