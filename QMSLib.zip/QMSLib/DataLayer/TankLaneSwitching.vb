Namespace DL
    Public Class TankLaneSwitching

#Region "Main"

        Public Shared Function ListData(ByVal strCompanyID As String, ByVal strLocationID As String, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                   "SELECT " & vbNewLine & _
                   "    A.CompanyID, VC.CompanyName, A.LocationID, VL.LocationName, A.ID, A.TankCode, VT.TankName, A.IsDeleted, A.Remarks, A.CreatedBy,   " & vbNewLine & _
                   "    A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine & _
                   "FROM QMS_traTankLaneSwitching A " & vbNewLine & _
                   "INNER JOIN QMS_vwTank VT ON " & vbNewLine & _
                   "    A.TankCode=VT.TankCode " & vbNewLine & _
                   "INNER JOIN QMS_vwCompany VC ON " & vbNewLine & _
                   "    A.CompanyID=VC.CompanyID " & vbNewLine & _
                   "INNER JOIN QMS_vwLocation VL ON " & vbNewLine & _
                   "    A.LocationID=VL.LocationID " & vbNewLine & _
                   "WHERE  " & vbNewLine & _
                   "    A.CompanyID=@CompanyID " & vbNewLine & _
                   "    AND A.LocationID=@LocationID " & vbNewLine & _
                   "    AND A.CreatedDate>=@DateFrom AND A.CreatedDate<=@DateTo" & vbNewLine

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.TankLaneSwitching)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                If bolNew Then
                    .CommandText = _
                       "INSERT INTO QMS_traTankLaneSwitching " & vbNewLine & _
                       "    (CompanyID, LocationID, ID, TankCode, Remarks, CreatedBy, LogBy)   " & vbNewLine & _
                       "VALUES " & vbNewLine & _
                       "    (@CompanyID, @LocationID, @ID, @TankCode, @Remarks, @LogBy, @LogBy)  " & vbNewLine
                Else
                    .CommandText = _
                       "UPDATE QMS_traTankLaneSwitching SET " & vbNewLine & _
                       "    TankCode=@TankCode, " & vbNewLine & _
                       "    Remarks=@Remarks, " & vbNewLine & _
                       "    LogBy=@LogBy, " & vbNewLine & _
                       "    LogDate=GETDATE(), " & vbNewLine & _
                       "    LogInc=LogInc+1 " & vbNewLine & _
                       "WHERE " & vbNewLine & _
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = clsData.CompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = clsData.LocationID
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@TankCode", SqlDbType.VarChar, 50).Value = clsData.TankCode
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Function GetDetail(ByVal strID As String) As VO.TankLaneSwitching
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.TankLaneSwitching
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                       "SELECT TOP 1 " & vbNewLine & _
                       "    A.CompanyID, VC.CompanyName, A.LocationID, VL.LocationName, A.ID, A.TankCode, VT.TankName, A.IsDeleted, A.Remarks, A.CreatedBy,   " & vbNewLine & _
                       "    A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine & _
                       "FROM QMS_traTankLaneSwitching A " & vbNewLine & _
                       "INNER JOIN QMS_vwTank VT ON " & vbNewLine & _
                       "    A.TankCode=VT.TankCode " & vbNewLine & _
                       "INNER JOIN QMS_vwCompany VC ON " & vbNewLine & _
                       "    A.CompanyID=VC.CompanyID " & vbNewLine & _
                       "INNER JOIN QMS_vwLocation VL ON " & vbNewLine & _
                       "    A.LocationID=VL.LocationID " & vbNewLine & _
                       "WHERE " & vbNewLine & _
                       "    A.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.CompanyID = .Item("CompanyID")
                        voReturn.CompanyName = .Item("CompanyName")
                        voReturn.LocationID = .Item("LocationID")
                        voReturn.LocationName = .Item("LocationName")
                        voReturn.ID = .Item("ID")
                        voReturn.TankCode = .Item("TankCode")
                        voReturn.TankName = .Item("TankName")
                        voReturn.IsDeleted = .Item("IsDeleted")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            Finally
                If Not sqlrdData Is Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Public Shared Sub DeleteData(ByVal clsData As VO.TankLaneSwitching)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "UPDATE QMS_traTankLaneSwitching " & vbNewLine & _
                    "SET IsDeleted=1, LogBy=@LogBy, LogDate=GETDATE(), LogInc=LogInc+1  " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Function GetMaxID(ByVal strID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 " & vbNewLine & _
                        "   ID=ISNULL(RIGHT(ID,3),0) " & vbNewLine & _
                        "FROM QMS_traTankLaneSwitching " & vbNewLine & _
                        "WHERE  " & vbNewLine & _
                        "   LEFT(ID,12)=@ID " & vbNewLine & _
                        "ORDER BY ID DESC " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else : intReturn = 1
                    End If
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            Finally
                If Not sqlrdData Is Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Public Shared Function DataExists(ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 " & vbNewLine & _
                        "   ID " & vbNewLine & _
                        "FROM QMS_traTankLaneSwitching " & vbNewLine & _
                        "WHERE  " & vbNewLine & _
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            Finally
                If Not sqlrdData Is Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Public Shared Function IsDeleted(ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 " & vbNewLine & _
                        "   ID " & vbNewLine & _
                        "FROM QMS_traTankLaneSwitching " & vbNewLine & _
                        "WHERE  " & vbNewLine & _
                        "   ID=@ID " & vbNewLine & _
                        "   AND IsDeleted=1 " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            Finally
                If Not sqlrdData Is Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#End Region

#Region "Detail"

        Public Shared Function ListDataDetail(ByVal strTankLaneSwitchingID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                   "SELECT " & vbNewLine & _
                   "    A.ID, A.TankLaneSwitchingID, A.SubStationID, MSS.Description AS SubStationName " & vbNewLine & _
                   "FROM QMS_traTankLaneSwitchingDet A " & vbNewLine & _
                   "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine & _
                   "    A.SubStationID=MSS.ID " & vbNewLine & _
                   "WHERE  " & vbNewLine & _
                   "    A.TankLaneSwitchingID=@TankLaneSwitchingID" & vbNewLine

                .Parameters.Add("@TankLaneSwitchingID", SqlDbType.VarChar, 20).Value = strTankLaneSwitchingID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub SaveDataDetail(ByVal clsData As VO.TankLaneSwitchingDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                   "INSERT INTO QMS_traTankLaneSwitchingDet " & vbNewLine & _
                   "    (ID, TankLaneSwitchingID, SubStationID)   " & vbNewLine & _
                   "VALUES " & vbNewLine & _
                   "    (@ID, @TankLaneSwitchingID, @SubStationID)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@TankLaneSwitchingID", SqlDbType.VarChar, 20).Value = clsData.TankLaneSwitchingID
                .Parameters.Add("@SubStationID", SqlDbType.Int).Value = clsData.SubStationID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Sub DeleteDataDetail(ByVal strTankLaneSwitchingID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "DELETE FROM QMS_traTankLaneSwitchingDet " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "   TankLaneSwitchingID=@TankLaneSwitchingID " & vbNewLine

                .Parameters.Add("@TankLaneSwitchingID", SqlDbType.VarChar, 20).Value = strTankLaneSwitchingID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

#Region "Status"

        Public Shared Function ListDataStatus(ByVal strTankLaneSwitchingID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                   "SELECT " & vbNewLine & _
                   "    A.Status, A.StatusBy, A.StatusDate, A.Remarks  " & vbNewLine & _
                   "FROM QMS_traTankLaneSwitchingStatus A " & vbNewLine & _
                   "WHERE  " & vbNewLine & _
                   "    A.TankLaneSwitchingID=@TankLaneSwitchingID" & vbNewLine

                .Parameters.Add("@TankLaneSwitchingID", SqlDbType.VarChar, 20).Value = strTankLaneSwitchingID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub SaveDataStatus(ByVal clsData As VO.TankLaneSwitchingStatus)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "INSERT INTO QMS_traTankLaneSwitchingStatus " & vbNewLine & _
                    "    (ID, TankLaneSwitchingID, Status, StatusBy, StatusDate, Remarks)   " & vbNewLine & _
                    "VALUES " & vbNewLine & _
                    "    (@ID, @TankLaneSwitchingID, @Status, @StatusBy, @StatusDate, @Remarks)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@TankLaneSwitchingID", SqlDbType.VarChar, 20).Value = clsData.TankLaneSwitchingID
                .Parameters.Add("@Status", SqlDbType.VarChar, 150).Value = clsData.Status
                .Parameters.Add("@StatusBy", SqlDbType.VarChar, 20).Value = clsData.StatusBy
                .Parameters.Add("@StatusDate", SqlDbType.DateTime).Value = clsData.StatusDate
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Function GetMaxIDStatus(ByVal strTankLaneSwitchingID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT " & vbNewLine & _
                        "   ID=COUNT(ID) " & vbNewLine & _
                        "FROM QMS_traTankLaneSwitchingStatus " & vbNewLine & _
                        "WHERE  " & vbNewLine & _
                        "   TankLaneSwitchingID=@TankLaneSwitchingID " & vbNewLine

                    .Parameters.Add("@TankLaneSwitchingID", SqlDbType.VarChar, 20).Value = strTankLaneSwitchingID

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            Finally
                If Not sqlrdData Is Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

#End Region

    End Class

End Namespace

