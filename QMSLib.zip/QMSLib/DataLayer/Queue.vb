Namespace DL
    Friend Class Queue

#Region "Main"

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime, ByVal intIDStatus As VO.Status.Values) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ComLocDivSubDivID, A.ID, CASE WHEN A.IsArrange=0 THEN NULL ELSE A.QueueNumber END AS QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName, " & vbNewLine &
                   "    A.SPBNumber, A.RFID, A.QueueType, CASE A.QueueType WHEN 0 THEN '-' WHEN 1 THEN 'INCOMING' ELSE 'OUTGOING' END AS QueueTypeName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, " & vbNewLine &
                   "    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, " & vbNewLine &
                   "    A.QueueFlowID, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, A.IsFreePass, A.WBNumber, A.WBProgramID, A.ContractNumber, " & vbNewLine &
                   "    A.IsRepeat, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, A.IsCompleted, A.CompletedBy, CASE WHEN A.IsCompleted=0 THEN NULL ELSE A.CompletedDate END AS CompletedDate,   " & vbNewLine &
                   "    A.IsDeleted, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc, A.IsHold " & vbNewLine &
                   "FROM QMS_traQueue A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "    A.IDStatus=B.ID " & vbNewLine &
                   "INNER JOIN QMS_mstDriver MD ON " & vbNewLine &
                   "    A.DriverID=MD.ID " & vbNewLine &
                   "LEFT JOIN QMS_mstStorage MS ON " & vbNewLine &
                   "    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID " & vbNewLine &
                   "    AND A.ProgramIDStorage=MS.ProgramID" & vbNewLine &
                   "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                   "    AND A.StorageID=MS.StorageID " & vbNewLine &
                   "LEFT JOIN QMS_vwItem VI ON " & vbNewLine &
                   "    A.ItemCode=VI.ItemCode " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.ComLocDivSubDivID=@ComLocDivSubDivID" & vbNewLine &
                   "    AND A.QueueDate>=@DateFrom AND A.QueueDate<=@DateTo" & vbNewLine

                If intIDStatus <> VO.Status.Values.All Then
                    .CommandText +=
                        "    AND A.IDStatus=@IDStatus" & vbNewLine
                End If

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom.Date
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = intIDStatus
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataByStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal intIDStatus As VO.Status.Values) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ComLocDivSubDivID, A.ID, CASE WHEN A.IsArrange=0 THEN NULL ELSE A.QueueNumber END AS QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName, " & vbNewLine &
                   "    A.SPBNumber, A.RFID, A.QueueType, CASE A.QueueType WHEN 0 THEN '-' WHEN 1 THEN 'INCOMING' ELSE 'OUTGOING' END AS QueueTypeName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, " & vbNewLine &
                   "    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, " & vbNewLine &
                   "    A.QueueFlowID, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, A.IsFreePass, A.WBNumber, A.WBProgramID, A.ContractNumber, " & vbNewLine &
                   "    A.IsRepeat, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, A.IsCompleted, A.CompletedBy, CASE WHEN A.IsCompleted=0 THEN NULL ELSE A.CompletedDate END AS CompletedDate,   " & vbNewLine &
                   "    A.IsDeleted, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc, A.IsHold " & vbNewLine &
                   "FROM QMS_traQueue A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "    A.IDStatus=B.ID " & vbNewLine &
                   "INNER JOIN QMS_mstDriver MD ON " & vbNewLine &
                   "    A.DriverID=MD.ID " & vbNewLine &
                   "LEFT JOIN QMS_mstStorage MS ON " & vbNewLine &
                   "    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID " & vbNewLine &
                   "    AND A.ProgramIDStorage=MS.ProgramID" & vbNewLine &
                   "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                   "    AND A.StorageID=MS.StorageID " & vbNewLine &
                   "LEFT JOIN QMS_vwItem VI ON " & vbNewLine &
                   "    A.ItemCode=VI.ItemCode " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    1=1 " & vbNewLine

                If intIDStatus <> VO.Status.Values.All Then
                    .CommandText +=
                        "    AND A.IDStatus=@IDStatus" & vbNewLine
                End If

                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = intIDStatus
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataOnProgress(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime,
                                                            ByVal bolIsFreePass As Boolean, ByVal bolIsRepeat As Boolean) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    CAST(0 AS BIT) AS Pick, A.ComLocDivSubDivID, A.ID, CASE WHEN A.IsArrange=0 THEN NULL ELSE A.QueueNumber END AS QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName, " & vbNewLine &
                   "    A.SPBNumber, A.RFID, A.QueueType, CASE A.QueueType WHEN 0 THEN '-' WHEN 1 THEN 'INCOMING' ELSE 'OUTGOING' END AS QueueTypeName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, " & vbNewLine &
                   "    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, A.QueueFlowID, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, " & vbNewLine &
                   "    A.IsFreePass, A.WBNumber, A.WBProgramID, A.ContractNumber, A.IsRepeat, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, A.IsCompleted, A.CompletedBy, CASE WHEN A.IsCompleted=0 THEN NULL ELSE A.CompletedDate END AS CompletedDate,   " & vbNewLine &
                   "    A.IsDeleted, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc " & vbNewLine &
                   "FROM QMS_traQueue A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "    A.IDStatus=B.ID " & vbNewLine &
                   "INNER JOIN QMS_mstDriver MD ON " & vbNewLine &
                   "    A.DriverID=MD.ID " & vbNewLine &
                   "LEFT JOIN QMS_mstStorage MS ON " & vbNewLine &
                   "    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID " & vbNewLine &
                   "    AND A.ProgramIDStorage=MS.ProgramID" & vbNewLine &
                   "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                   "    AND A.StorageID=MS.StorageID " & vbNewLine &
                   "LEFT JOIN QMS_vwItem VI ON " & vbNewLine &
                   "    A.ItemCode=VI.ItemCode " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.ComLocDivSubDivID=@ComLocDivSubDivID" & vbNewLine &
                   "    AND A.QueueDate>=@DateFrom AND A.QueueDate<=@DateTo" & vbNewLine &
                   "    AND A.IDStatus<>@IDStatus" & vbNewLine &
                   "    AND A.IsDeleted=0 " & vbNewLine &
                   "    AND A.IsFreePass=@IsFreePass " & vbNewLine &
                   "    AND A.IsRepeat=@IsRepeat " & vbNewLine

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom.Date
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Completed
                .Parameters.Add("@IsFreePass", SqlDbType.Bit).Value = bolIsFreePass
                .Parameters.Add("@IsRepeat", SqlDbType.Bit).Value = bolIsRepeat
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataOutstandingConfirm(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                    ByVal strPlatNumber As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.SPBNumber, A.RFID " & vbNewLine &
                   "FROM QMS_traQueue A " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.IDStatus=@IDStatus" & vbNewLine &
                   "    AND A.PlatNumber=@PlatNumber " & vbNewLine

                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Verified
                .Parameters.Add("@PlatNumber", SqlDbType.VarChar, 10).Value = strPlatNumber
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                        "INSERT INTO QMS_traQueue " & vbNewLine &
                        "    (ComLocDivSubDivID, ID, QueueNumber, TicketParkingID, QueueDate, PlatNumber, DriverID,   " & vbNewLine &
                        "     SPBNumber, RFID, QueueType, QueueFlowID, ItemCode, ReferencesID, IsFreePass, IDStatus, Remarks, CreatedBy, LogBy)   " & vbNewLine &
                        "VALUES " & vbNewLine &
                        "    (@ComLocDivSubDivID, @ID, @QueueNumber, @TicketParkingID, @QueueDate, @PlatNumber, @DriverID,   " & vbNewLine &
                        "     @SPBNumber, @RFID, @QueueType, @QueueFlowID, @ItemCode, @ReferencesID, @IsFreePass, @IDStatus, @Remarks, @LogBy, @LogBy)  " & vbNewLine
                Else
                    .CommandText =
                        "UPDATE QMS_traQueue SET " & vbNewLine &
                        "    TicketParkingID=@TicketParkingID, " & vbNewLine &
                        "    PlatNumber=@PlatNumber, " & vbNewLine &
                        "    DriverID=@DriverID, " & vbNewLine &
                        "    SPBNumber=@SPBNumber, " & vbNewLine &
                        "    RFID=@RFID, " & vbNewLine &
                        "    Remarks=@Remarks, " & vbNewLine &
                        "    LogBy=@LogBy, " & vbNewLine &
                        "    LogDate=GETDATE(), " & vbNewLine &
                        "    LogInc=LogInc+1 " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = clsData.ComLocDivSubDivID
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@QueueNumber", SqlDbType.Int).Value = clsData.QueueNumber
                .Parameters.Add("@TicketParkingID", SqlDbType.VarChar, 20).Value = clsData.TicketParkingID
                .Parameters.Add("@QueueDate", SqlDbType.DateTime).Value = clsData.QueueDate
                .Parameters.Add("@PlatNumber", SqlDbType.VarChar, 10).Value = clsData.PlatNumber
                .Parameters.Add("@DriverID", SqlDbType.VarChar, 30).Value = clsData.DriverID
                .Parameters.Add("@SPBNumber", SqlDbType.VarChar, 150).Value = clsData.SPBNumber
                .Parameters.Add("@RFID", SqlDbType.VarChar, 20).Value = clsData.RFID
                .Parameters.Add("@QueueType", SqlDbType.TinyInt).Value = clsData.QueueType
                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = clsData.QueueFlowID
                .Parameters.Add("@ItemCode", SqlDbType.VarChar, 50).Value = clsData.ItemCode
                .Parameters.Add("@ReferencesID", SqlDbType.VarChar, 20).Value = clsData.ReferencesID
                .Parameters.Add("@IsFreePass", SqlDbType.Bit).Value = clsData.IsFreePass
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Draft
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub Verified(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    IDStatus=@IDStatus, " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Verified
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub CancelVerified(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    IDStatus=@IDStatus, " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Draft
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub Confirm(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                            ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    ComLocDivSubDivIDStorage=@ComLocDivSubDivIDStorage, " & vbNewLine &
                    "    ProgramIDStorage=@ProgramIDStorage, " & vbNewLine &
                    "    StorageGroupID=@StorageGroupID, " & vbNewLine &
                    "    StorageID=@StorageID, " & vbNewLine &
                    "    IsFreePass=@IsFreePass, " & vbNewLine &
                    "    WBNumber=@WBNumber, " & vbNewLine &
                    "    WBProgramID=@WBProgramID, " & vbNewLine &
                    "    ContractNumber=@ContractNumber, " & vbNewLine &
                    "    QueueType=@QueueType, " & vbNewLine &
                    "    QueueFlowID=@QueueFlowID, " & vbNewLine &
                    "    ItemCode=@ItemCode, " & vbNewLine &
                    "    IsRepeat=@IsRepeat, " & vbNewLine &
                    "    IDStatus=@IDStatus, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@ComLocDivSubDivIDStorage", SqlDbType.Int).Value = clsData.ComLocDivSubDivIDStorage
                .Parameters.Add("@ProgramIDStorage", SqlDbType.VarChar, 15).Value = clsData.ProgramIDStorage
                .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = clsData.StorageGroupID
                .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = clsData.StorageID
                .Parameters.Add("@IsFreePass", SqlDbType.Bit).Value = clsData.IsFreePass
                .Parameters.Add("@WBNumber", SqlDbType.VarChar, 50).Value = clsData.WBNumber
                .Parameters.Add("@WBProgramID", SqlDbType.VarChar, 10).Value = clsData.WBProgramID
                .Parameters.Add("@ContractNumber", SqlDbType.VarChar, 250).Value = clsData.ContractNumber
                .Parameters.Add("@QueueType", SqlDbType.TinyInt).Value = clsData.QueueType
                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = clsData.QueueFlowID
                .Parameters.Add("@ItemCode", SqlDbType.VarChar, 50).Value = clsData.ItemCode
                .Parameters.Add("@IsRepeat", SqlDbType.Bit).Value = clsData.IsRepeat
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Confirm
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub CancelConfirm(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    ComLocDivSubDivIDStorage=0, " & vbNewLine &
                    "    ProgramIDStorage='', " & vbNewLine &
                    "    StorageGroupID='', " & vbNewLine &
                    "    StorageID='', " & vbNewLine &
                    "    IsFreePass=0, " & vbNewLine &
                    "    IsRepeat=0, " & vbNewLine &
                    "    WBNumber='', " & vbNewLine &
                    "    WBProgramID='', " & vbNewLine &
                    "    ContractNumber='', " & vbNewLine &
                    "    QueueFlowID='', " & vbNewLine &
                    "    ItemCode='', " & vbNewLine &
                    "    IDStatus=@IDStatus, " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Verified
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub Complete(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    IDStatus=@IDStatus, " & vbNewLine &
                    "    IsCompleted=1, " & vbNewLine &
                    "    CompletedBy=@LogBy, " & vbNewLine &
                    "    CompletedDate=GETDATE(), " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Completed
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub CancelComplete(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    IDStatus=@IDStatus, " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    IsCompleted=0, " & vbNewLine &
                    "    CompletedBy='', " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Confirm
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strID As String) As VO.Queue
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Queue
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ComLocDivSubDivID, A.ID, A.QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName,   " & vbNewLine &
                       "    A.SPBNumber, A.RFID, A.QueueFlowID, ISNULL(MQF.Name,'') AS QueueFlowName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, " & vbNewLine &
                       "    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, A.IsFreePass, A.WBNumber, A.WBProgramID,   " & vbNewLine &
                       "    A.ContractNumber, A.QueueType, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, A.IsRepeat, A.IsArrange, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, A.IsCompleted, A.CompletedBy, A.CompletedDate,   " & vbNewLine &
                       "    A.IsDeleted, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc, A.IsHold " & vbNewLine &
                       "FROM QMS_traQueue A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "INNER JOIN QMS_mstDriver MD ON " & vbNewLine &
                       "    A.DriverID=MD.ID " & vbNewLine &
                       "LEFT JOIN QMS_mstStorage MS ON " & vbNewLine &
                       "    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID " & vbNewLine &
                       "    AND A.ProgramIDStorage=MS.ProgramID" & vbNewLine &
                       "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                       "    AND A.StorageID=MS.StorageID " & vbNewLine &
                       "LEFT JOIN QMS_mstQueueFlow MQF ON " & vbNewLine &
                       "    A.QueueFlowID=MQF.ID " & vbNewLine &
                       "LEFT JOIN QMS_vwItem VI ON " & vbNewLine &
                       "    A.ItemCode=VI.ItemCode " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ComLocDivSubDivID = .Item("ComLocDivSubDivID")
                        voReturn.ID = .Item("ID")
                        voReturn.QueueNumber = .Item("QueueNumber")
                        voReturn.TicketParkingID = .Item("TicketParkingID")
                        voReturn.QueueDate = .Item("QueueDate")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.DriverID = .Item("DriverID")
                        voReturn.DriverFullName = .Item("DriverFullName")
                        voReturn.SPBNumber = .Item("SPBNumber")
                        voReturn.RFID = .Item("RFID")
                        voReturn.QueueType = .Item("QueueType")
                        voReturn.QueueFlowID = .Item("QueueFlowID")
                        voReturn.QueueFlowName = .Item("QueueFlowName")
                        voReturn.ItemCode = .Item("ItemCode")
                        voReturn.ItemName = .Item("ItemName")
                        voReturn.ComLocDivSubDivIDStorage = .Item("ComLocDivSubDivIDStorage")
                        voReturn.ProgramIDStorage = .Item("ProgramIDStorage")
                        voReturn.StorageGroupID = .Item("StorageGroupID")
                        voReturn.StorageGroupName = .Item("StorageGroupName")
                        voReturn.StorageID = .Item("StorageID")
                        voReturn.StorageName = .Item("StorageName")
                        voReturn.IsFreePass = .Item("IsFreePass")
                        voReturn.WBNumber = .Item("WBNumber")
                        voReturn.WBProgramID = .Item("WBProgramID")
                        voReturn.ContractNumber = .Item("ContractNumber")
                        voReturn.IsRepeat = .Item("IsRepeat")
                        voReturn.IsArrange = .Item("IsArrange")
                        voReturn.ReferencesID = .Item("ReferencesID")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.IsCompleted = .Item("IsCompleted")
                        voReturn.CompletedBy = .Item("CompletedBy")
                        voReturn.CompletedDate = .Item("CompletedDate")
                        voReturn.IsDeleted = .Item("IsDeleted")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                        voReturn.IsHold = .Item("IsHold")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailByRFID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal intComLocDivSubDivID As Integer, ByVal strRFID As String) As VO.Queue
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Queue
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ComLocDivSubDivID, A.ID, A.QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName,   " & vbNewLine &
                       "    A.SPBNumber, A.RFID, A.QueueFlowID, ISNULL(MQF.Name,'') AS QueueFlowName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, " & vbNewLine &
                       "    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, A.IsFreePass, A.WBNumber, A.WBProgramID,   " & vbNewLine &
                       "    A.ContractNumber, A.QueueType, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, A.IsRepeat, A.IsArrange, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, A.IsCompleted, A.CompletedBy, A.CompletedDate,   " & vbNewLine &
                       "    A.IsDeleted, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_traQueue A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "INNER JOIN QMS_mstDriver MD ON " & vbNewLine &
                       "    A.DriverID=MD.ID " & vbNewLine &
                       "LEFT JOIN QMS_mstStorage MS ON " & vbNewLine &
                       "    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID " & vbNewLine &
                       "    AND A.ProgramIDStorage=MS.ProgramID" & vbNewLine &
                       "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                       "    AND A.StorageID=MS.StorageID " & vbNewLine &
                       "LEFT JOIN QMS_mstQueueFlow MQF ON " & vbNewLine &
                       "    A.QueueFlowID=MQF.ID " & vbNewLine &
                       "LEFT JOIN QMS_vwItem VI ON " & vbNewLine &
                       "    A.ItemCode=VI.ItemCode " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                       "    AND A.RFID=@RFID " & vbNewLine &
                       "    AND A.IsDeleted=0 " & vbNewLine &
                       "    AND A.IsCompleted=0 " & vbNewLine

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                    .Parameters.Add("@RFID", SqlDbType.VarChar, 20).Value = strRFID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ComLocDivSubDivID = .Item("ComLocDivSubDivID")
                        voReturn.ID = .Item("ID")
                        voReturn.QueueNumber = .Item("QueueNumber")
                        voReturn.TicketParkingID = .Item("TicketParkingID")
                        voReturn.QueueDate = .Item("QueueDate")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.DriverID = .Item("DriverID")
                        voReturn.DriverFullName = .Item("DriverFullName")
                        voReturn.SPBNumber = .Item("SPBNumber")
                        voReturn.RFID = .Item("RFID")
                        voReturn.QueueType = .Item("QueueType")
                        voReturn.QueueFlowID = .Item("QueueFlowID")
                        voReturn.QueueFlowName = .Item("QueueFlowName")
                        voReturn.ItemCode = .Item("ItemCode")
                        voReturn.ItemName = .Item("ItemName")
                        voReturn.ComLocDivSubDivIDStorage = .Item("ComLocDivSubDivIDStorage")
                        voReturn.ProgramIDStorage = .Item("ProgramIDStorage")
                        voReturn.StorageGroupID = .Item("StorageGroupID")
                        voReturn.StorageGroupName = .Item("StorageGroupName")
                        voReturn.StorageID = .Item("StorageID")
                        voReturn.StorageName = .Item("StorageName")
                        voReturn.IsFreePass = .Item("IsFreePass")
                        voReturn.WBNumber = .Item("WBNumber")
                        voReturn.WBProgramID = .Item("WBProgramID")
                        voReturn.ContractNumber = .Item("ContractNumber")
                        voReturn.IsRepeat = .Item("IsRepeat")
                        voReturn.IsArrange = .Item("IsArrange")
                        voReturn.ReferencesID = .Item("ReferencesID")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.IsCompleted = .Item("IsCompleted")
                        voReturn.CompletedBy = .Item("CompletedBy")
                        voReturn.CompletedDate = .Item("CompletedDate")
                        voReturn.IsDeleted = .Item("IsDeleted")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailOutstanding(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                              ByVal strFilterValue As String, ByVal FilterBy As VO.Queue.Filter) As VO.Queue
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Queue
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ComLocDivSubDivID, A.ID, A.QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName,   " & vbNewLine &
                       "    A.SPBNumber, A.RFID, A.QueueFlowID, ISNULL(MQF.Name,'') AS QueueFlowName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, " & vbNewLine &
                       "    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, A.IsFreePass, A.WBNumber, A.WBProgramID,   " & vbNewLine &
                       "    A.ContractNumber, A.QueueType, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, A.IsRepeat, A.IsArrange, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, A.IsCompleted, A.CompletedBy, A.CompletedDate,   " & vbNewLine &
                       "    A.IsDeleted, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_traQueue A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "INNER JOIN QMS_mstDriver MD ON " & vbNewLine &
                       "    A.DriverID=MD.ID " & vbNewLine &
                       "LEFT JOIN QMS_mstStorage MS ON " & vbNewLine &
                       "    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID " & vbNewLine &
                       "    AND A.ProgramIDStorage=MS.ProgramID" & vbNewLine &
                       "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                       "    AND A.StorageID=MS.StorageID " & vbNewLine &
                       "LEFT JOIN QMS_mstQueueFlow MQF ON " & vbNewLine &
                       "    A.QueueFlowID=MQF.ID " & vbNewLine &
                       "LEFT JOIN QMS_vwItem VI ON " & vbNewLine &
                       "    A.ItemCode=VI.ItemCode " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.IsDeleted=0 " & vbNewLine &
                       "    AND A.IsCompleted=0 " & vbNewLine

                    If FilterBy = VO.Queue.Filter.RFID Then
                        .CommandText += "   AND A.RFID=@FilterValue " & vbNewLine
                    ElseIf FilterBy = VO.Queue.Filter.PlatNumber Then
                        .CommandText += "   AND A.PlatNumber=@FilterValue " & vbNewLine
                    End If

                    .Parameters.Add("@FilterValue", SqlDbType.VarChar, 20).Value = strFilterValue
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ComLocDivSubDivID = .Item("ComLocDivSubDivID")
                        voReturn.ID = .Item("ID")
                        voReturn.QueueNumber = .Item("QueueNumber")
                        voReturn.TicketParkingID = .Item("TicketParkingID")
                        voReturn.QueueDate = .Item("QueueDate")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.DriverID = .Item("DriverID")
                        voReturn.DriverFullName = .Item("DriverFullName")
                        voReturn.SPBNumber = .Item("SPBNumber")
                        voReturn.RFID = .Item("RFID")
                        voReturn.QueueType = .Item("QueueType")
                        voReturn.QueueFlowID = .Item("QueueFlowID")
                        voReturn.QueueFlowName = .Item("QueueFlowName")
                        voReturn.ItemCode = .Item("ItemCode")
                        voReturn.ItemName = .Item("ItemName")
                        voReturn.ComLocDivSubDivIDStorage = .Item("ComLocDivSubDivIDStorage")
                        voReturn.ProgramIDStorage = .Item("ProgramIDStorage")
                        voReturn.StorageGroupID = .Item("StorageGroupID")
                        voReturn.StorageGroupName = .Item("StorageGroupName")
                        voReturn.StorageID = .Item("StorageID")
                        voReturn.StorageName = .Item("StorageName")
                        voReturn.IsFreePass = .Item("IsFreePass")
                        voReturn.WBNumber = .Item("WBNumber")
                        voReturn.WBProgramID = .Item("WBProgramID")
                        voReturn.ContractNumber = .Item("ContractNumber")
                        voReturn.IsRepeat = .Item("IsRepeat")
                        voReturn.IsArrange = .Item("IsArrange")
                        voReturn.ReferencesID = .Item("ReferencesID")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.IsCompleted = .Item("IsCompleted")
                        voReturn.CompletedBy = .Item("CompletedBy")
                        voReturn.CompletedDate = .Item("CompletedDate")
                        voReturn.IsDeleted = .Item("IsDeleted")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "   IDStatus=@IDStatus, Remarks=@Remarks, IsDeleted=1, LogBy=@LogBy, LogDate=GETDATE(), LogInc=LogInc+1  " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Deleted
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(RIGHT(ID,3),0) " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   LEFT(ID,10)=@ID " & vbNewLine &
                        "ORDER BY ID DESC " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else : intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function GetMaxTicketParkingID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                               ByVal dtmQueueDate As DateTime) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=ISNULL(MAX(TicketParkingID),0) " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   CONVERT(DATE,QueueDate)=CONVERT(DATE,@QueueDate) " & vbNewLine

                    .Parameters.Add("@QueueDate", SqlDbType.DateTime).Value = dtmQueueDate
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else : intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function GetMaxQueueNumber(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal dtmQueueDate As DateTime) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(QueueNumber,0) " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   CONVERT(DATE,QueueDate)=CONVERT(DATE,@QueueDate) " & vbNewLine &
                        "ORDER BY QueueNumber DESC " & vbNewLine

                    .Parameters.Add("@QueueDate", SqlDbType.DateTime).Value = dtmQueueDate
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else : intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function DataExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function TicketParkingIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                               ByVal strTicketParkingID As String, ByVal dtmQueueDate As DateTime) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strReturn As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   TicketParkingID=@TicketParkingID " & vbNewLine &
                        "   AND CONVERT(DATE,QueueDate)=CONVERT(DATE,@QueueDate) " & vbNewLine

                    .Parameters.Add("@TicketParkingID", SqlDbType.VarChar, 20).Value = strTicketParkingID
                    .Parameters.Add("@QueueDate", SqlDbType.DateTime).Value = dtmQueueDate
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strReturn = .Item("ID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strReturn
        End Function

        Protected Friend Shared Function QueueNumberExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal intQueueNumber As Integer, ByVal dtmQueueDate As DateTime) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strReturn As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueNumber=@QueueNumber " & vbNewLine &
                        "   AND CONVERT(DATE,QueueDate)=CONVERT(DATE,@QueueDate) " & vbNewLine

                    .Parameters.Add("@QueueNumber", SqlDbType.Int).Value = intQueueNumber
                    .Parameters.Add("@QueueDate", SqlDbType.DateTime).Value = dtmQueueDate
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strReturn = .Item("ID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strReturn
        End Function

        Protected Friend Shared Function IsDeleted(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine &
                        "   AND IsDeleted=1 " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function GetQueueNumber(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   QueueNumber " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("QueueNumber")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function ListDataArrange(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime, ByVal bolIsArrange As Boolean) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
SELECT 
    A.ComLocDivSubDivID, A.ID, CASE WHEN A.IsArrange=0 THEN NULL ELSE A.QueueNumber END AS QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName, 
    A.SPBNumber, A.RFID, A.QueueType, CASE A.QueueType WHEN 0 THEN '-' WHEN 1 THEN 'INCOMING' ELSE 'OUTGOING' END AS QueueTypeName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, 
    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, A.QueueFlowID, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, A.IsFreePass, A.WBNumber, A.WBProgramID, 
    A.IsRepeat, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, 
    A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc 
FROM QMS_traQueue A 
INNER JOIN QMS_mstStatus B ON 
    A.IDStatus=B.ID 
INNER JOIN QMS_mstDriver MD ON 
    A.DriverID=MD.ID 
LEFT JOIN QMS_mstStorage MS ON 
    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID 
    AND A.ProgramIDStorage=MS.ProgramID
    AND A.StorageGroupID=MS.StorageGroupID 
    AND A.StorageID=MS.StorageID 
LEFT JOIN QMS_vwItem VI ON 
    A.ItemCode=VI.ItemCode 
WHERE  
    A.ComLocDivSubDivID=@ComLocDivSubDivID
    AND A.QueueDate>=@DateFrom AND A.QueueDate<=@DateTo
    AND A.IDStatus=@IDStatus 
    AND A.IsFreePass=0 
    AND A.IsArrange=@IsArrange 
    AND A.IsDeleted=0 
"

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom.Date
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Confirm
                .Parameters.Add("@IsArrange", SqlDbType.Bit).Value = bolIsArrange
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub Arrange(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                            ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    QueueNumber=@QueueNumber, " & vbNewLine &
                    "    IsArrange=@IsArrange, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@QueueNumber", SqlDbType.Int).Value = clsData.QueueNumber
                .Parameters.Add("@IsArrange", SqlDbType.Bit).Value = clsData.IsArrange
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub ChangeIsRepeat(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    IsRepeat=@IsRepeat, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IsRepeat", SqlDbType.Bit).Value = clsData.IsRepeat
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub ChangeIsFreePass(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    IsFreePass=@IsFreePass, " & vbNewLine &
                    "    QueueNumber=CASE WHEN @IsFreePass=1 THEN 0 ELSE QueueNumber END, " & vbNewLine &
                    "    IsArrange=CASE WHEN @IsFreePass=1 THEN 0 ELSE IsArrange END, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IsFreePass", SqlDbType.Bit).Value = clsData.IsFreePass
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub UpdateMinusQueueNumber(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal clsData As VO.Queue)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    QueueNumber=QueueNumber-1, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    CONVERT(DATE,QueueDate)=CONVERT(DATE,@QueueDate) " & vbNewLine &
                    "    AND QueueNumber>=@QueueNumber " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@QueueDate", SqlDbType.DateTime).Value = clsData.QueueDate
                .Parameters.Add("@QueueNumber", SqlDbType.Int).Value = clsData.QueueNumber
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function IsAlreadyGenerateQueue(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traQueue " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ReferencesID=@ID " & vbNewLine &
                        "   AND IsDeleted=0 " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Sub UpdatePlatNumber(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strQueueID As String, ByVal strPlatNumber As String, ByVal strLogBy As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    PlatNumber=@PlatNumber, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strQueueID
                .Parameters.Add("@PlatNumber", SqlDbType.VarChar, 10).Value = strPlatNumber
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = strLogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub ChangeRFID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal strQueueID As String, ByVal strOldRFID As String, ByVal strNewRFID As String, ByVal strLogBy As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    OldRFID=@OldRFID, " & vbNewLine &
                    "    RFID=@NewRFID, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strQueueID
                .Parameters.Add("@OldRFID", SqlDbType.VarChar, 20).Value = strOldRFID
                .Parameters.Add("@NewRFID", SqlDbType.VarChar, 20).Value = strNewRFID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = strLogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub UpdateIsHold(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                 ByVal strID As String, ByVal bolIsHold As Boolean)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueue SET " & vbNewLine &
                    "    IsHold=@IsHold " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                .Parameters.Add("@IsHold", SqlDbType.Bit).Value = bolIsHold
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

#Region "Detail"

        Protected Friend Shared Function ListDataDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strQueueID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.QueueID, A.Idx, MS.IsLinkStorage, A.StationID, MS.Description AS StationName, A.SubStationID, MSS.Description AS SubStationName, A.IsRequested, A.RequestedBy, CASE WHEN A.IsRequested=0 THEN NULL ELSE A.RequestedDate END AS RequestedDate,   " & vbNewLine &
                   "    A.IsDone, A.DoneBy, CASE WHEN A.IsDone=0 THEN NULL ELSE A.DoneDate END AS DoneDate, A.InternalRemarks, A.Remarks, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_traQueueDet A " & vbNewLine &
                   "INNER JOIN QMS_mstStation MS ON " & vbNewLine &
                   "    A.StationID=MS.ID " & vbNewLine &
                   "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine &
                   "    A.SubStationID=MSS.ID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueID=@QueueID" & vbNewLine &
                   "ORDER BY A.Idx ASC " & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strQueueID As String, ByVal intStationID As Integer) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.QueueID, A.Idx, MS.IsLinkStorage, A.StationID, MS.Description AS StationName, A.SubStationID, MSS.Description AS SubStationName, A.IsRequested, A.RequestedBy, CASE WHEN A.IsRequested=0 THEN NULL ELSE A.RequestedDate END AS RequestedDate,   " & vbNewLine &
                   "    A.IsDone, A.DoneBy, CASE WHEN A.IsDone=0 THEN NULL ELSE A.DoneDate END AS DoneDate, A.InternalRemarks, A.Remarks, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_traQueueDet A " & vbNewLine &
                   "INNER JOIN QMS_mstStation MS ON " & vbNewLine &
                   "    A.StationID=MS.ID " & vbNewLine &
                   "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine &
                   "    A.SubStationID=MSS.ID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueID=@QueueID " & vbNewLine &
                   "    AND A.StationID=@StationID " & vbNewLine &
                   "ORDER BY A.Idx ASC " & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = intStationID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal bolNew As Boolean, ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_traQueueDet " & vbNewLine &
                       "    (ID, QueueID, Idx, StationID, SubStationID, Remarks, LogBy, IsIgnoreOnHold)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@ID, @QueueID, @Idx, @StationID, @SubStationID, @Remarks, @LogBy, @IsIgnoreOnHold)  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_traQueueDet SET " & vbNewLine &
                       "    Idx=@Idx, " & vbNewLine &
                       "    StationID=@StationID, " & vbNewLine &
                       "    SubStationID=@SubStationID, " & vbNewLine &
                       "    Remarks=@Remarks, " & vbNewLine &
                       "    LogBy=@LogBy, " & vbNewLine &
                       "    LogDate=GETDATE(), " & vbNewLine &
                       "    LogInc=LogInc+1, " & vbNewLine &
                       "    IsIgnoreOnHold=@IsIgnoreOnHold, " & vbNewLine &
                       "    IsReject=@IsReject " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = clsData.QueueID
                .Parameters.Add("@Idx", SqlDbType.TinyInt).Value = clsData.Idx
                .Parameters.Add("@StationID", SqlDbType.Int).Value = clsData.StationID
                .Parameters.Add("@SubStationID", SqlDbType.TinyInt).Value = clsData.SubStationID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IsIgnoreOnHold", SqlDbType.TinyInt).Value = clsData.IsIgnoreOnHold
                .Parameters.Add("@IsReject", SqlDbType.TinyInt).Value = clsData.IsReject
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub RequestDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueueDet SET " & vbNewLine &
                    "    StationID=@StationID, " & vbNewLine &
                    "    SubStationID=@SubStationID, " & vbNewLine &
                    "    IsRequested=1, " & vbNewLine &
                    "    RequestedBy=@LogBy, " & vbNewLine &
                    "    RequestedDate=GETDATE(), " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = clsData.StationID
                .Parameters.Add("@SubStationID", SqlDbType.TinyInt).Value = clsData.SubStationID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub CancelRequestDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueueDet SET " & vbNewLine &
                    "    IsRequested=0, " & vbNewLine &
                    "    RequestedBy='', " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DoneDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueueDet SET " & vbNewLine &
                    "    StationID=@StationID, " & vbNewLine &
                    "    SubStationID=@SubStationID, " & vbNewLine &
                    "    IsDone=1, " & vbNewLine &
                    "    DoneBy=@LogBy, " & vbNewLine &
                    "    DoneDate=GETDATE(), " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = clsData.StationID
                .Parameters.Add("@SubStationID", SqlDbType.TinyInt).Value = clsData.SubStationID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DoneDetailWithOnHold(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueueDet SET " & vbNewLine &
                    "    IsDone=1, " & vbNewLine &
                    "    DoneBy=@LogBy, " & vbNewLine &
                    "    DoneDate=GETDATE(), " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub CancelDoneDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueueDet SET " & vbNewLine &
                    "    IsDone=0, " & vbNewLine &
                    "    DoneBy='', " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub RejectDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                 ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traQueueDet SET " & vbNewLine &
                    "    IsReject=1, " & vbNewLine &
                    "    Remarks=@Remarks, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataDetailByID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal strID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_traQueueDet " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = strID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataDetailQueueID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal strQueueID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_traQueueDet " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   QueueID=@QueueID " & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetailDet(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strID As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "    A.ID, A.QueueID, A.Idx, A.StationID, MS.Description AS StationName, A.SubStationID, MSS.Description AS SubStationName, A.IsRequested, A.RequestedBy,   " & vbNewLine &
                        "    A.RequestedDate, A.IsDone, A.DoneBy, A.DoneDate, A.InternalRemarks, A.Remarks,   " & vbNewLine &
                        "    A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                        "FROM QMS_traQueueDet A " & vbNewLine &
                        "INNER JOIN QMS_mstStation MS ON	" & vbNewLine &
                        "	A.StationID=MS.ID " & vbNewLine &
                        "INNER JOIN QMS_mstSubStation MSS ON	" & vbNewLine &
                        "	A.SubStationID=MSS.ID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "    A.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.StationName = .Item("StationName")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.SubStationName = .Item("SubStationName")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailLastRequested(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal strQueueID As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ID, A.QueueID, A.Idx, A.StationID, A.SubStationID, A.IsRequested, A.RequestedBy,   " & vbNewLine &
                       "    A.RequestedDate, A.IsDone, A.DoneBy, A.DoneDate, A.InternalRemarks, A.Remarks,   " & vbNewLine &
                       "    A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_traQueueDet A " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    QueueID=@QueueID " & vbNewLine &
                       "    AND IsRequested=1 " & vbNewLine &
                       "ORDER BY A.Idx DESC " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 30).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailLastDone(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal strQueueID As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ID, A.QueueID, A.Idx, A.StationID, A.SubStationID, A.IsRequested, A.RequestedBy,   " & vbNewLine &
                       "    A.RequestedDate, A.IsDone, A.DoneBy, A.DoneDate, A.InternalRemarks, A.Remarks,   " & vbNewLine &
                       "    A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_traQueueDet A " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    QueueID=@QueueID " & vbNewLine &
                       "    AND IsDone=1 " & vbNewLine &
                       "ORDER BY A.Idx DESC " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 30).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailFirstByInitialIDAndRFID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                          ByVal intComLocDivSubDivID As Integer, ByVal strInitialID As String, ByVal strRFID As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "	TQD.ID, TQD.QueueID, TQD.Idx, TQD.StationID, MS.Description AS StationName, TQD.SubStationID, MSS.Description AS SubStationName, TQH.PlatNumber, TQD.IsRequested, TQD.RequestedBy,   " & vbNewLine &
                        "	TQD.RequestedDate, TQD.IsDone, TQD.DoneBy, TQD.DoneDate, TQD.InternalRemarks, TQD.Remarks,   " & vbNewLine &
                        "   TQD.LogBy, TQD.LogDate, TQD.LogInc " & vbNewLine &
                        "FROM QMS_traQueue TQH " & vbNewLine &
                        "INNER JOIN QMS_traQueueDet TQD ON " & vbNewLine &
                        "	TQH.ID=TQD.QueueID " & vbNewLine &
                        "INNER JOIN QMS_mstStation MS ON	" & vbNewLine &
                        "	TQD.StationID=MS.ID " & vbNewLine &
                        "INNER JOIN QMS_mstSubStation MSS ON	" & vbNewLine &
                        "	TQD.SubStationID=MSS.ID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "	TQD.IsRequested=0 " & vbNewLine &
                        "	AND TQH.IDStatus=@IDStatus " & vbNewLine &
                        "	AND TQH.ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                        "	AND MSS.InitialID=@InitialID " & vbNewLine &
                        "	AND TQH.RFID=@RFID" & vbNewLine &
                        "ORDER BY TQD.Idx ASC " & vbNewLine

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                    .Parameters.Add("@InitialID", SqlDbType.VarChar, 10).Value = strInitialID
                    .Parameters.Add("@RFID", SqlDbType.VarChar, 20).Value = strRFID
                    .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Confirm
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.StationName = .Item("StationName")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.SubStationName = .Item("SubStationName")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailQueueFlowOnProgressByInitialID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                                 ByVal strInitialID As String, ByVal strQueueID As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "	TQD.ID, TQD.QueueID, TQD.Idx, TQD.StationID, MS.Description AS StationName, TQD.SubStationID, MSS.Description AS SubStationName, TQH.PlatNumber, TQD.IsRequested, TQD.RequestedBy,   " & vbNewLine &
                        "	TQD.RequestedDate, TQD.IsDone, TQD.DoneBy, TQD.DoneDate, TQD.InternalRemarks, TQD.Remarks,   " & vbNewLine &
                        "   TQD.LogBy, TQD.LogDate, TQD.LogInc " & vbNewLine &
                        "FROM QMS_traQueue TQH " & vbNewLine &
                        "INNER JOIN QMS_traQueueDet TQD ON " & vbNewLine &
                        "	TQH.ID=TQD.QueueID " & vbNewLine &
                        "INNER JOIN QMS_mstStation MS ON	" & vbNewLine &
                        "	TQD.StationID=MS.ID " & vbNewLine &
                        "INNER JOIN QMS_mstSubStation MSS ON	" & vbNewLine &
                        "	TQD.SubStationID=MSS.ID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "	TQH.IDStatus=@IDStatus " & vbNewLine &
                        "	AND TQH.ID=@QueueID " & vbNewLine &
                        "	AND MSS.InitialID=@InitialID " & vbNewLine &
                        "	AND (TQD.IsRequested=0 OR TQD.IsDone=0)" & vbNewLine &
                        "ORDER BY TQD.Idx ASC " & vbNewLine

                    .Parameters.Add("@InitialID", SqlDbType.VarChar, 10).Value = strInitialID
                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                    .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Confirm
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.StationName = .Item("StationName")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.SubStationName = .Item("SubStationName")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailQueueFlowOnProgressByInitialID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                                 ByVal action As VO.QueueDet.Action, ByVal strInitialID As String, ByVal strWBProgramID As String, ByVal strWBNumber As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "	TQD.ID, TQD.QueueID, TQD.Idx, TQD.StationID, MS.Description AS StationName, TQD.SubStationID, MSS.Description AS SubStationName, TQH.PlatNumber, TQD.IsRequested, TQD.RequestedBy,   " & vbNewLine &
                        "	TQD.RequestedDate, TQD.IsDone, TQD.DoneBy, TQD.DoneDate, TQD.InternalRemarks, TQD.Remarks,   " & vbNewLine &
                        "   TQD.LogBy, TQD.LogDate, TQD.LogInc " & vbNewLine &
                        "FROM QMS_traQueue TQH " & vbNewLine &
                        "INNER JOIN QMS_traQueueDet TQD ON " & vbNewLine &
                        "	TQH.ID=TQD.QueueID " & vbNewLine &
                        "INNER JOIN QMS_mstStation MS ON	" & vbNewLine &
                        "	TQD.StationID=MS.ID " & vbNewLine &
                        "INNER JOIN QMS_mstSubStation MSS ON	" & vbNewLine &
                        "	TQD.SubStationID=MSS.ID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "	TQH.IDStatus=@IDStatus " & vbNewLine &
                        "	AND TQH.WBProgramID=@WBProgramID " & vbNewLine &
                        "	AND TQH.WBNumber=@WBNumber " & vbNewLine &
                        "	AND MSS.InitialID=@InitialID " & vbNewLine

                    If action = VO.QueueDet.Action.Request Then
                        .CommandText += "	AND (TQD.IsRequested=0 OR TQD.IsDone=0)" & vbNewLine
                    ElseIf action = VO.QueueDet.Action.Done Then
                        .CommandText += "	AND (TQD.IsRequested=1 OR TQD.IsDone=0)" & vbNewLine
                    End If

                    .CommandText += "ORDER BY TQD.Idx ASC " & vbNewLine

                    .Parameters.Add("@InitialID", SqlDbType.VarChar, 10).Value = strInitialID
                    .Parameters.Add("@WBProgramID", SqlDbType.VarChar, 10).Value = strWBProgramID
                    .Parameters.Add("@WBNumber", SqlDbType.VarChar, 50).Value = strWBNumber
                    .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Confirm
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.StationName = .Item("StationName")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.SubStationName = .Item("SubStationName")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetMaxIDDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strQueueID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=ISNULL(RIGHT(MAX(ID),3),0) " & vbNewLine &
                        "FROM QMS_traQueueDet " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueID=@QueueID " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function GetMaxTotalOutstandingDone(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                    ByVal strQueueID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   COUNT(ID) AS Total " & vbNewLine &
                        "FROM QMS_traQueueDet " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueID=@QueueID " & vbNewLine &
                        "   AND IsDone=0 " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("Total")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function GetMaxIdxDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal strQueueID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 1
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   MAX(Idx) AS Total " & vbNewLine &
                        "FROM QMS_traQueueDet " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueID=@QueueID " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("Total")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Sub UpdatePlusIdxDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traQueueDet SET " & vbNewLine &
                   "    Idx=Idx+1 " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    QueueID=@QueueID " & vbNewLine &
                   "    AND Idx>=@Idx " & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = clsData.QueueID
                .Parameters.Add("@Idx", SqlDbType.TinyInt).Value = clsData.Idx
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub UpdateMinusIdxDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal clsData As VO.QueueDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traQueueDet SET " & vbNewLine &
                   "    Idx=Idx-1 " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    QueueID=@QueueID " & vbNewLine &
                   "    AND Idx>=@Idx " & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = clsData.QueueID
                .Parameters.Add("@Idx", SqlDbType.TinyInt).Value = clsData.Idx
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub MoveUpIdxDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traQueueDet SET " & vbNewLine &
                   "    Idx=Idx-1 " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub MoveDownIdxDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traQueueDet SET " & vbNewLine &
                   "    Idx=Idx+1 " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub UpdateIdxDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String, ByVal intNewIdx As Integer)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traQueueDet SET " & vbNewLine &
                   "    Idx=@NewIdx " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                .Parameters.Add("@NewIdx", SqlDbType.Int).Value = intNewIdx
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function ListDataQueueUnloading(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT  " & vbNewLine &
                    "	QH.ComLocDivSubDivID, QD.ID, QD.QueueID, QD.Idx,  " & vbNewLine &
                    "	Position=CAST('' AS VARCHAR), QH.IsHold, QH.PlatNumber, QH.WBNumber, " & vbNewLine &
                    "	StatusInfo= CASE WHEN QD.IsDone=1 THEN 'DONE' WHEN QD.IsRequested=1 THEN 'REQUEST' ELSE '' END, " & vbNewLine &
                    "	MSS.Description AS SubStationName, QD.Remarks, CASE WHEN QDS.IsRequested=1 THEN QDS.RequestedDate ELSE NULL END AS FactoryInDate, " & vbNewLine &
                    "	CASE WHEN QD.IsRequested=1 THEN QD.RequestedDate ELSE NULL END StartDate, " & vbNewLine &
                    "	CASE WHEN QD.IsDone=1 THEN QD.DoneDate ELSE NULL END EndDate, QH.ComLocDivSubDivIDStorage, QH.ProgramIDStorage, QH.StorageGroupID, QH.StorageID, " & vbNewLine &
                    "   QD.StationID, MS.Description AS StationName, QD.SubStationID, MSS.Description AS SubStationName, QH.RFID, QD.IsRequested, QD.IsDone " & vbNewLine &
                    "FROM QMS_traQueue QH  " & vbNewLine &
                    "INNER JOIN QMS_traQueueDet QD ON  " & vbNewLine &
                    "	QH.ID=QD.QueueID  " & vbNewLine &
                    "INNER JOIN  " & vbNewLine &
                    "( " & vbNewLine &
                    "	SELECT  " & vbNewLine &
                    "		QD.QueueID, MAX(QD.Idx) AS Idx " & vbNewLine &
                    "	FROM QMS_traQueueDet QD  " & vbNewLine &
                    "	WHERE QD.StationID=@UnloadingStationID  " & vbNewLine &
                    "	GROUP BY QD.QueueID  " & vbNewLine &
                    ") QD1 ON " & vbNewLine &
                    "	QD.QueueID=QD1.QueueID  " & vbNewLine &
                    "	AND QD.Idx=QD1.Idx  " & vbNewLine &
                    "INNER JOIN QMS_mstStation MS ON  " & vbNewLine &
                    "	QD.StationID=MS.ID  " & vbNewLine &
                    "INNER JOIN QMS_mstSubStation MSS ON  " & vbNewLine &
                    "	QD.SubStationID=MSS.ID  " & vbNewLine &
                    "INNER JOIN QMS_traQueueDet QDS ON " & vbNewLine &
                    "	QH.ID=QDS.QueueID " & vbNewLine &
                    "	AND QDS.Idx=1 " & vbNewLine &
                    "LEFT JOIN QMS_mstStorage MSG ON  " & vbNewLine &
                    "    QH.ComLocDivSubDivIDStorage=MSG.ComLocDivSubDivID  " & vbNewLine &
                    "    AND QH.ProgramIDStorage=MSG.ProgramID " & vbNewLine &
                    "    AND QH.StorageGroupID=MSG.StorageGroupID  " & vbNewLine &
                    "    AND QH.StorageID=MSG.StorageID  " & vbNewLine &
                    "WHERE  " & vbNewLine &
                    "	QH.ComLocDivSubDivID=@ComLocDivSubDivID  " & vbNewLine &
                    "	AND QH.QueueDate>=@DateFrom AND QH.QueueDate<=@DateTo  " & vbNewLine &
                    "	AND QH.IsDeleted=0  " & vbNewLine &
                    "	AND QH.IDStatus=@IDStatus " & vbNewLine

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom.Date
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
                .Parameters.Add("@UnloadingStationID", SqlDbType.Int).Value = VO.Station.Values.Unloading
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Confirm
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataQueueUnloadingV2(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                  ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT  " & vbNewLine &
                    "	QH.ComLocDivSubDivID, QD.ID, QD.QueueID, QD.Idx,  " & vbNewLine &
                    "	Position=CAST('' AS VARCHAR), QH.IsHold, QH.PlatNumber, QH.WBNumber, " & vbNewLine &
                    "	StatusInfo=CASE WHEN QD.IsDone=1 THEN 'SELESAI' WHEN QD.IsRequested=1 THEN 'ONPROGRESS' ELSE 'READY' END, " & vbNewLine &
                    "	MSS.Description AS SubStationName, QD.Remarks, CASE WHEN QDS.IsRequested=1 THEN QDS.RequestedDate ELSE NULL END AS FactoryInDate, " & vbNewLine &
                    "	CASE WHEN QD.IsRequested=1 THEN QD.RequestedDate ELSE NULL END StartDate, " & vbNewLine &
                    "	CASE WHEN QD.IsDone=1 THEN QD.DoneDate ELSE NULL END EndDate, QH.ComLocDivSubDivIDStorage, QH.ProgramIDStorage, QH.StorageGroupID, QH.StorageID, " & vbNewLine &
                    "   QD.StationID, MS.Description AS StationName, QD.SubStationID, MSS.Description AS SubStationName, QH.RFID, QD.IsRequested, QD.IsDone " & vbNewLine &
                    "FROM QMS_traQueue QH  " & vbNewLine &
                    "INNER JOIN QMS_traQueueDet QD ON  " & vbNewLine &
                    "	QH.ID=QD.QueueID  " & vbNewLine &
                    "INNER JOIN  " & vbNewLine &
                    "( " & vbNewLine &
                    "	SELECT  " & vbNewLine &
                    "		QD.QueueID, MAX(QD.Idx) AS Idx " & vbNewLine &
                    "	FROM QMS_traQueueDet QD  " & vbNewLine &
                    "	WHERE QD.StationID=@UnloadingStationID  " & vbNewLine &
                    "	GROUP BY QD.QueueID  " & vbNewLine &
                    ") QD1 ON " & vbNewLine &
                    "	QD.QueueID=QD1.QueueID  " & vbNewLine &
                    "	AND QD.Idx=QD1.Idx  " & vbNewLine &
                    "INNER JOIN QMS_mstStation MS ON  " & vbNewLine &
                    "	QD.StationID=MS.ID  " & vbNewLine &
                    "INNER JOIN QMS_mstSubStation MSS ON  " & vbNewLine &
                    "	QD.SubStationID=MSS.ID  " & vbNewLine &
                    "INNER JOIN QMS_traQueueDet QDS ON " & vbNewLine &
                    "	QH.ID=QDS.QueueID " & vbNewLine &
                    "	AND QDS.Idx=1 " & vbNewLine &
                    "LEFT JOIN QMS_mstStorage MSG ON  " & vbNewLine &
                    "    QH.ComLocDivSubDivIDStorage=MSG.ComLocDivSubDivID  " & vbNewLine &
                    "    AND QH.ProgramIDStorage=MSG.ProgramID " & vbNewLine &
                    "    AND QH.StorageGroupID=MSG.StorageGroupID  " & vbNewLine &
                    "    AND QH.StorageID=MSG.StorageID  " & vbNewLine &
                    "WHERE  " & vbNewLine &
                    "	QH.ComLocDivSubDivID=@ComLocDivSubDivID  " & vbNewLine &
                    "	AND QH.QueueDate>=@DateFrom AND QH.QueueDate<=@DateTo  " & vbNewLine &
                    "	AND QH.IsDeleted=0  " & vbNewLine &
                    "	AND QH.IDStatus=@IDStatus " & vbNewLine

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom.Date
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
                .Parameters.Add("@UnloadingStationID", SqlDbType.Int).Value = VO.Station.Values.Unloading
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Confirm
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function GetLastQueueFlow(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal strQueueID As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "-- Ongoing" & vbNewLine &
                        "SELECT TOP 1 " & vbNewLine &
                        "	QD.ID, QD.QueueID, QD.Idx, QD.StationID, QD.SubStationID, QD.IsRequested, QD.RequestedBy, QD.RequestedDate, QD.IsDone, QD.DoneBy, QD.DoneDate, QD.InternalRemarks, " & vbNewLine &
                        "	QD.Remarks, QD.LogBy, QD.LogDate, QD.LogInc" & vbNewLine &
                        "FROM QMS_traQueueDet QD " & vbNewLine &
                        "INNER JOIN " & vbNewLine &
                        "(" & vbNewLine &
                        "	SELECT TOP 1 QD1.ID" & vbNewLine &
                        "	FROM QMS_traQueueDet QD1" & vbNewLine &
                        "	WHERE " & vbNewLine &
                        "		QD1.QueueID=@QueueID " & vbNewLine &
                        "		AND QD1.IsRequested=1 AND QD1.IsDone=0 " & vbNewLine &
                        "	ORDER BY QD1.ID ASC " & vbNewLine &
                        ") QD1 ON QD.ID=QD1.ID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "	QD.QueueID=@QueueID " & vbNewLine &
                        "" & vbNewLine &
                        "UNION ALL -- Oustanding" & vbNewLine &
                        "SELECT TOP 1 " & vbNewLine &
                        "	QD.ID, QD.QueueID, QD.Idx, QD.StationID, QD.SubStationID, QD.IsRequested, QD.RequestedBy, QD.RequestedDate, QD.IsDone, QD.DoneBy, QD.DoneDate, QD.InternalRemarks, " & vbNewLine &
                        "	QD.Remarks, QD.LogBy, QD.LogDate, QD.LogInc" & vbNewLine &
                        "FROM QMS_traQueueDet QD " & vbNewLine &
                        "INNER JOIN " & vbNewLine &
                        "(" & vbNewLine &
                        "	SELECT TOP 1 QD2.ID " & vbNewLine &
                        "	FROM QMS_traQueueDet QD2 " & vbNewLine &
                        "	WHERE " & vbNewLine &
                        "		QD2.QueueID=@QueueID " & vbNewLine &
                        "		AND QD2.IsRequested=0 AND QD2.IsDone=0 " & vbNewLine &
                        "	ORDER BY QD2.Idx ASC " & vbNewLine &
                        ") QD2 ON  QD.ID=QD2.ID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "	QD.QueueID=@QueueID " & vbNewLine &
                        "" & vbNewLine &
                        "UNION ALL -- Done Last" & vbNewLine &
                        "SELECT TOP 1 " & vbNewLine &
                        "	QD.ID, QD.QueueID, QD.Idx, QD.StationID, QD.SubStationID, QD.IsRequested, QD.RequestedBy, QD.RequestedDate, QD.IsDone, QD.DoneBy, QD.DoneDate, QD.InternalRemarks, " & vbNewLine &
                        "	QD.Remarks, QD.LogBy, QD.LogDate, QD.LogInc " & vbNewLine &
                        "FROM QMS_traQueueDet QD " & vbNewLine &
                        "INNER JOIN " & vbNewLine &
                        "(" & vbNewLine &
                        "	SELECT TOP 1 QD3.ID" & vbNewLine &
                        "	FROM QMS_traQueueDet QD3 " & vbNewLine &
                        "	WHERE " & vbNewLine &
                        "		QD3.QueueID=@QueueID " & vbNewLine &
                        "		AND QD3.IsRequested=1 AND QD3.IsDone=1 " & vbNewLine &
                        "	ORDER BY QD3.ID DESC " & vbNewLine &
                        ") QD3 ON QD.ID=QD3.ID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "	QD.QueueID=@QueueID " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 30).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetailUnloadingConfirm(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                   ByVal strQueueID As String, ByVal strID As String) As VO.Queue
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Queue
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   Position=CAST('' AS VARCHAR), QH.ComLocDivSubDivID, QD.ID, QD.QueueID, QH.PlatNumber, QH.WBNumber, QH.WBProgramID, QH.ContractNumber, " & vbNewLine &
                        "   QH.IsHold, QD.IsRequested, QD.IsDone, QD.SubStationID, QD.Idx " & vbNewLine &
                        "FROM QMS_traQueue QH  " & vbNewLine &
                        "INNER JOIN QMS_traQueueDet QD ON  " & vbNewLine &
                        "	QH.ID=QD.QueueID  " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "	QD.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = strID
                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 30).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.Position = .Item("Position")
                        voReturn.ComLocDivSubDivID = .Item("ComLocDivSubDivID")
                        voReturn.ID = .Item("QueueID")
                        voReturn.QueueDetail = New VO.QueueDet
                        voReturn.QueueDetail.ID = .Item("ID")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.WBNumber = .Item("WBNumber")
                        voReturn.WBProgramID = .Item("WBProgramID")
                        voReturn.ContractNumber = .Item("ContractNumber")
                        voReturn.IsHold = .Item("IsHold")
                        voReturn.QueueDetail.IsRequested = .Item("IsRequested")
                        voReturn.QueueDetail.IsDone = .Item("IsDone")
                        voReturn.QueueDetail.SubStationID = .Item("SubStationID")
                        voReturn.QueueDetail.Idx = .Item("Idx")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function ListDataQueueDetByInitialID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                     ByVal strInitialID As String, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT   " & vbNewLine &
                    "	QH.ComLocDivSubDivID, QD.ID, QD.QueueID, QH.QueueDate, QD.Idx,   " & vbNewLine &
                    "	Status=CASE WHEN QD.IsDone=1 THEN 2 WHEN QD.IsRequested=1 THEN 1 ELSE 0 END, QH.IsHold, QH.PlatNumber, QH.WBNumber,  " & vbNewLine &
                    "	MSS.Description AS SubStationName, QD.Remarks, QH.ComLocDivSubDivIDStorage, QH.ProgramIDStorage, QH.StorageGroupID, QH.StorageID,  " & vbNewLine &
                    "	QD.StationID, MS.Description AS StationName, QD.SubStationID, MSS.Description AS SubStationName, MSS.InitialID, QH.RFID  " & vbNewLine &
                    "FROM QMS_traQueue QH   " & vbNewLine &
                    "INNER JOIN QMS_traQueueDet QD ON   " & vbNewLine &
                    "	QH.ID=QD.QueueID   " & vbNewLine &
                    "INNER JOIN QMS_mstStation MS ON   " & vbNewLine &
                    "	QD.StationID=MS.ID   " & vbNewLine &
                    "INNER JOIN QMS_mstSubStation MSS ON   " & vbNewLine &
                    "	QD.SubStationID=MSS.ID   " & vbNewLine &
                    "	AND MSS.InitialID=@InitialID " & vbNewLine &
                    "LEFT JOIN QMS_mstStorage MSG ON   " & vbNewLine &
                    "    QH.ComLocDivSubDivIDStorage=MSG.ComLocDivSubDivID   " & vbNewLine &
                    "    AND QH.ProgramIDStorage=MSG.ProgramID  " & vbNewLine &
                    "    AND QH.StorageGroupID=MSG.StorageGroupID   " & vbNewLine &
                    "    AND QH.StorageID=MSG.StorageID   " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "	QH.QueueDate>=@DateFrom AND QH.QueueDate<=@DateTo   " & vbNewLine &
                    "	AND QH.IsDeleted=0   " & vbNewLine &
                    "	AND QH.IDStatus=@IDStatus  " & vbNewLine &
                    "" & vbNewLine

                .Parameters.Add("@InitialID", SqlDbType.VarChar, 10).Value = strInitialID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom.Date
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = VO.Status.Values.Confirm
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function GetIsIgnoreOnHold(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolReturn As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traQueueDet " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID AND IsIgnoreOnHold=1" & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolReturn = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolReturn
        End Function

        Protected Friend Shared Function GetDetailIsIgnoreOnHold(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                 ByVal strQueueID As String) As VO.QueueDet
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueDet
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "    A.ID, A.QueueID, A.Idx, A.StationID, A.SubStationID, A.IsRequested, A.RequestedBy,   " & vbNewLine &
                        "    A.RequestedDate, A.IsDone, A.DoneBy, A.DoneDate, A.InternalRemarks, A.Remarks,   " & vbNewLine &
                        "    A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                        "FROM QMS_traQueueDet A " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   A.QueueID=@QueueID AND A.IsIgnoreOnHold=1" & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 30).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.QueueID = .Item("QueueID")
                        voReturn.Idx = .Item("Idx")
                        voReturn.StationID = .Item("StationID")
                        voReturn.SubStationID = .Item("SubStationID")
                        voReturn.IsRequested = .Item("IsRequested")
                        voReturn.RequestedBy = .Item("RequestedBy")
                        voReturn.RequestedDate = .Item("RequestedDate")
                        voReturn.IsDone = .Item("IsDone")
                        voReturn.DoneBy = .Item("DoneBy")
                        voReturn.DoneDate = .Item("DoneDate")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

#End Region

#Region "Status"

        Protected Friend Shared Function ListDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strQueueID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.Status, A.StatusBy, A.StatusDate, A.Remarks  " & vbNewLine &
                   "FROM QMS_traQueueStatus A " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueID=@QueueID" & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.QueueStatus)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "INSERT INTO QMS_traQueueStatus " & vbNewLine &
                    "    (ID, QueueID, Status, StatusBy, StatusDate, Remarks)   " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "    (@ID, @QueueID, @Status, @StatusBy, @StatusDate, @Remarks)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = clsData.QueueID
                .Parameters.Add("@Status", SqlDbType.VarChar, 150).Value = clsData.Status
                .Parameters.Add("@StatusBy", SqlDbType.VarChar, 20).Value = clsData.StatusBy
                .Parameters.Add("@StatusDate", SqlDbType.DateTime).Value = clsData.StatusDate
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxIDStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strQueueID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=COUNT(ID) " & vbNewLine &
                        "FROM QMS_traQueueStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueID=@QueueID " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

#End Region

#Region "Detail Status"

        Protected Friend Shared Sub SaveDataDetStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal clsData As VO.QueueDetStatus)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "INSERT INTO QMS_traQueueDetStatus " & vbNewLine &
                    "    (ID, QueueDetID, StationID, SubStationID, Status, StatusBy, StatusDate, Remarks)   " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "    (@ID, @QueueDetID, @StationID, @SubStationID, @Status, @StatusBy, @StatusDate, @Remarks)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@QueueDetID", SqlDbType.VarChar, 30).Value = clsData.QueueDetID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = clsData.StationID
                .Parameters.Add("@SubStationID", SqlDbType.Int).Value = clsData.SubStationID
                .Parameters.Add("@Status", SqlDbType.VarChar, 150).Value = clsData.Status
                .Parameters.Add("@StatusBy", SqlDbType.VarChar, 20).Value = clsData.StatusBy
                .Parameters.Add("@StatusDate", SqlDbType.DateTime).Value = clsData.StatusDate
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxIDDetStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal strQueueDetID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=COUNT(ID) " & vbNewLine &
                        "FROM QMS_traQueueDetStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueDetID=@QueueDetID " & vbNewLine

                    .Parameters.Add("@QueueDetID", SqlDbType.VarChar, 30).Value = strQueueDetID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

#End Region

#Region "LPR History"

        Public Shared Function ListDataLPRHistory(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strQueueID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.QueueID, A.ReGetStatus, A.ReGetMessage, A.ReGetPayload, A.GetID, A.WBID,   " & vbNewLine &
                   "    A.GarduID, A.Type, A.PlatNumber, A.CaptureDate, A.GetStatus, A.GetMessage, A.CreatedDate  " & vbNewLine &
                   "FROM QMS_traQueueLPRHistory A " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueID=@QueueID" & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 30).Value = strQueueID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Public Shared Sub SaveDataLPRHistory(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal clsData As VO.QueueLPRHistory)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "INSERT INTO QMS_traQueueLPRHistory " & vbNewLine &
                   "    (ID, QueueID, ReGetStatus, ReGetMessage, ReGetPayload, GetID, WBID,   " & vbNewLine &
                   "     GarduID, Type, PlatNumber, CaptureDate, GetStatus, GetMessage)   " & vbNewLine &
                   "VALUES " & vbNewLine &
                   "    (@ID, @QueueID, @ReGetStatus, @ReGetMessage, @ReGetPayload, @GetID, @WBID,   " & vbNewLine &
                   "     @GarduID, @Type, @PlatNumber, @CaptureDate, @GetStatus, @GetMessage)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = clsData.QueueID
                .Parameters.Add("@ReGetStatus", SqlDbType.Bit).Value = clsData.ReGetStatus
                .Parameters.Add("@ReGetMessage", SqlDbType.VarChar, 500).Value = clsData.ReGetMessage
                .Parameters.Add("@ReGetPayload", SqlDbType.VarChar, 500).Value = clsData.ReGetPayload
                .Parameters.Add("@GetID", SqlDbType.VarChar, 100).Value = clsData.GetID
                .Parameters.Add("@WBID", SqlDbType.VarChar, 30).Value = clsData.WBID
                .Parameters.Add("@GarduID", SqlDbType.Int).Value = clsData.GarduID
                .Parameters.Add("@Type", SqlDbType.VarChar, 30).Value = clsData.Type
                .Parameters.Add("@PlatNumber", SqlDbType.VarChar, 30).Value = clsData.PlatNumber
                .Parameters.Add("@CaptureDate", SqlDbType.DateTime).Value = clsData.CaptureDate
                .Parameters.Add("@GetStatus", SqlDbType.Bit).Value = clsData.GetStatus
                .Parameters.Add("@GetMessage", SqlDbType.VarChar, 500).Value = clsData.GetMessage
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Function GetMaxIDLPRHistory(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strQueueID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=ISNULL(RIGHT(MAX(ID),3),0) " & vbNewLine &
                        "FROM QMS_traQueueLPRHistory " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueID=@QueueID " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

#End Region

#Region "Hold Status"

        Protected Friend Shared Function ListDataHoldStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal strQueueID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.Status, A.StatusBy, A.StatusDate, A.Remarks  " & vbNewLine &
                   "FROM QMS_traQueueHoldStatus A " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueID=@QueueID" & vbNewLine

                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataHoldStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                       ByVal clsData As VO.QueueHoldStatus)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "INSERT INTO QMS_traQueueHoldStatus " & vbNewLine &
                    "    (ID, QueueID, Status, StatusBy, StatusDate, Remarks)   " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "    (@ID, @QueueID, @Status, @StatusBy, @StatusDate, @Remarks)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = clsData.QueueID
                .Parameters.Add("@Status", SqlDbType.VarChar, 150).Value = clsData.Status
                .Parameters.Add("@StatusBy", SqlDbType.VarChar, 20).Value = clsData.StatusBy
                .Parameters.Add("@StatusDate", SqlDbType.DateTime).Value = clsData.StatusDate
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxIDHoldStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal strQueueID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=COUNT(ID) " & vbNewLine &
                        "FROM QMS_traQueueHoldStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   QueueID=@QueueID " & vbNewLine

                    .Parameters.Add("@QueueID", SqlDbType.VarChar, 20).Value = strQueueID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

#End Region

    End Class

End Namespace

