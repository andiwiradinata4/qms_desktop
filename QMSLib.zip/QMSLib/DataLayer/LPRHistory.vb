Namespace DL
    Public Class LPRHistory
        Public Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.RequestDate, A.ResponseDate, A.DifferentInSecond, A.ResponseID, A.WBID, A.GarduID,   " & vbNewLine &
                   "    A.Type, A.PlatNumber, A.PlatNumberResponse, A.CaptureDate, A.Status, StatusInfo=CASE A.Status WHEN 0 THEN 'ACTIVE' ELSE 'IN-ACTIVE' END, A.Message,   " & vbNewLine &
                   "    A.ReferencesID, A.Remarks  " & vbNewLine &
                   "FROM QMS_traLPRHistory A " & vbNewLine

            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Public Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                   ByVal clsData As VO.LPRHistory)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "INSERT INTO QMS_traLPRHistory " & vbNewLine &
                   "    (ID, RequestDate, ResponseDate, DifferentInSecond, ResponseID, WBID, GarduID,   " & vbNewLine &
                   "     Type, PlatNumber, PlatNumberResponse, CaptureDate, Message, ReferencesID, Remarks)   " & vbNewLine &
                   "VALUES " & vbNewLine &
                   "    (@ID, @RequestDate, @ResponseDate, @DifferentInSecond, @ResponseID, @WBID, @GarduID,   " & vbNewLine &
                   "     @Type, @PlatNumber, @PlatNumberResponse, @CaptureDate, @Message, @ReferencesID, @Remarks)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 50).Value = clsData.ID
                .Parameters.Add("@RequestDate", SqlDbType.DateTime).Value = clsData.RequestDate
                .Parameters.Add("@ResponseDate", SqlDbType.DateTime).Value = clsData.ResponseDate
                .Parameters.Add("@DifferentInSecond", SqlDbType.Decimal).Value = clsData.DifferentInSecond
                .Parameters.Add("@ResponseID", SqlDbType.VarChar, 100).Value = clsData.ResponseID
                .Parameters.Add("@WBID", SqlDbType.VarChar, 30).Value = clsData.WBID
                .Parameters.Add("@GarduID", SqlDbType.Int).Value = clsData.GarduID
                .Parameters.Add("@Type", SqlDbType.VarChar, 30).Value = clsData.Type
                .Parameters.Add("@PlatNumber", SqlDbType.VarChar, 10).Value = clsData.PlatNumber
                .Parameters.Add("@PlatNumberResponse", SqlDbType.VarChar, 10).Value = clsData.PlatNumberResponse
                .Parameters.Add("@CaptureDate", SqlDbType.DateTime).Value = clsData.CaptureDate
                .Parameters.Add("@Status", SqlDbType.Bit).Value = clsData.Status
                .Parameters.Add("@Message", SqlDbType.VarChar, 500).Value = clsData.Message
                .Parameters.Add("@ReferencesID", SqlDbType.VarChar, 30).Value = clsData.ReferencesID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 500).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                         ByVal strID As String) As VO.LPRHistory
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.LPRHistory
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ID, A.RequestDate, A.ResponseDate, A.DifferentInSecond, A.ResponseID, A.WBID, A.GarduID,   " & vbNewLine &
                       "    A.Type, A.PlatNumber, A.PlatNumberResponse, A.PlatNumberAcknowledge, A.CaptureDate, A.Status, A.Message,   " & vbNewLine &
                       "    A.ReferencesID, A.Remarks  " & vbNewLine &
                       "FROM QMS_traLPRHistory A " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 50).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.RequestDate = .Item("RequestDate")
                        voReturn.ResponseDate = .Item("ResponseDate")
                        voReturn.DifferentInSecond = .Item("DifferentInSecond")
                        voReturn.ResponseID = .Item("ResponseID")
                        voReturn.WBID = .Item("WBID")
                        voReturn.GarduID = .Item("GarduID")
                        voReturn.Type = .Item("Type")
                        voReturn.PlatNumber = .Item("PlatNumber")
                        voReturn.PlatNumberResponse = .Item("PlatNumberResponse")
                        voReturn.PlatNumberAcknowledge = .Item("PlatNumberAcknowledge")
                        voReturn.CaptureDate = .Item("CaptureDate")
                        voReturn.Status = .Item("Status")
                        voReturn.Message = .Item("Message")
                        voReturn.ReferencesID = .Item("ReferencesID")
                        voReturn.Remarks = .Item("Remarks")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Public Shared Sub UpdateReferencesIDAndPlatNumber(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal strID As String, ByVal strReferencesID As String, ByVal strPlatNumber As String, ByVal strPlatNumberResponse As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traLPRHistory SET " & vbNewLine &
                   "    ReferencesID=@ReferencesID, " & vbNewLine &
                   "    PlatNumber=@PlatNumber, " & vbNewLine &
                   "    PlatNumberResponse=@PlatNumberResponse " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 50).Value = strID
                .Parameters.Add("@ReferencesID", SqlDbType.VarChar, 30).Value = strReferencesID
                .Parameters.Add("@PlatNumber", SqlDbType.VarChar, 10).Value = strPlatNumber
                .Parameters.Add("@PlatNumberResponse", SqlDbType.VarChar, 10).Value = strPlatNumberResponse
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Sub UpdateReferencesID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal strID As String, ByVal strReferencesID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traLPRHistory SET " & vbNewLine &
                   "    ReferencesID=@ReferencesID " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 50).Value = strID
                .Parameters.Add("@ReferencesID", SqlDbType.VarChar, 30).Value = strReferencesID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Sub UpdateAcknowledgePlatNumberAndRemarks(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal strID As String, ByVal strPlatNumberAcknowledge As String, ByVal strRemarks As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traLPRHistory SET " & vbNewLine &
                   "    PlatNumberAcknowledge=@PlatNumberAcknowledge, " & vbNewLine &
                   "    Remarks=@Remarks " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 50).Value = strID
                .Parameters.Add("@PlatNumberAcknowledge", SqlDbType.VarChar, 10).Value = strPlatNumberAcknowledge
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 500).Value = strRemarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Sub UpdateRemarks(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                        ByVal strID As String, ByVal strRemarks As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_traLPRHistory SET " & vbNewLine &
                   "    Remarks=@Remarks " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 50).Value = strID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 500).Value = strRemarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

    End Class

End Namespace

