Namespace DL
    Friend Class RFIDCard

#Region "Main"

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal intIDStatus As VO.Status.Values) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    CAST(0 AS BIT) AS Pick, A.CompanyID, A.LocationID, A.ID, A.RFID, A.InitialCode, A.IDStatus, B.Description AS StatusInfo, A.Remarks,   " & vbNewLine &
                   "    A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_mstRFIDCard A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "	A.IDStatus=B.ID " & vbNewLine

                If intIDStatus <> VO.Status.Values.All Then
                    .CommandText += "WHERE A.IDStatus=@IDStatus " & vbNewLine

                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = intIDStatus
                End If
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.RFIDCard)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_mstRFIDCard " & vbNewLine &
                       "    (CompanyID, LocationID, ID, RFID, InitialCode, IDStatus, Remarks,   " & vbNewLine &
                       "     CreatedBy, CreatedDate, LogBy, LogDate)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@CompanyID, @LocationID, @ID, @RFID, @InitialCode, @IDStatus, @Remarks,   " & vbNewLine &
                       "     @LogBy, GETDATE(), @LogBy, GETDATE())  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_mstRFIDCard SET " & vbNewLine &
                       "    CompanyID=@CompanyID, " & vbNewLine &
                       "    LocationID=@LocationID, " & vbNewLine &
                       "    RFID=@RFID, " & vbNewLine &
                       "    InitialCode=@InitialCode, " & vbNewLine &
                       "    IDStatus=@IDStatus, " & vbNewLine &
                       "    Remarks=@Remarks, " & vbNewLine &
                       "    LogBy=@LogBy, " & vbNewLine &
                       "    LogDate=GETDATE(), " & vbNewLine &
                       "    LogInc=LogInc+1 " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = clsData.CompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = clsData.LocationID
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@RFID", SqlDbType.VarChar, 20).Value = clsData.RFID
                .Parameters.Add("@InitialCode", SqlDbType.VarChar, 100).Value = clsData.InitialCode
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strID As String) As VO.RFIDCard
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.RFIDCard
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.CompanyID, A.LocationID, A.ID, A.RFID, A.InitialCode, A.IDStatus, A.Remarks,   " & vbNewLine &
                       "    A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_mstRFIDCard A " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.CompanyID = .Item("CompanyID")
                        voReturn.LocationID = .Item("LocationID")
                        voReturn.ID = .Item("ID")
                        voReturn.RFID = .Item("RFID")
                        voReturn.InitialCode = .Item("InitialCode")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.RFIDCard)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_mstRFIDCard " & vbNewLine &
                    "   SET IDStatus=@IDStatus, " & vbNewLine &
                    "   LogBy=@LogBy, " & vbNewLine &
                    "   LogDate=GETDATE(), " & vbNewLine &
                    "   LogInc=LogInc+1,  " & vbNewLine &
                    "   Remarks=@Remarks " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 1
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(RIGHT(ID,5),0) " & vbNewLine &
                        "FROM QMS_mstRFIDCard " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   LEFT(ID,8)=@ID " & vbNewLine &
                        "ORDER BY ID DESC " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 8).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstRFIDCard " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function RFIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strRFID As String, ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstRFIDCard " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   RFID=@RFID " & vbNewLine &
                        "   AND ID<>@ID " & vbNewLine

                    .Parameters.Add("@RFID", SqlDbType.VarChar, 20).Value = strRFID
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function RFIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strRFID As String) As VO.RFIDCard
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.RFIDCard
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "    A.CompanyID, A.LocationID, A.ID, A.RFID, A.InitialCode, A.IDStatus, A.Remarks,   " & vbNewLine &
                        "    A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                        "FROM QMS_mstRFIDCard A " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   RFID=@RFID " & vbNewLine

                    .Parameters.Add("@RFID", SqlDbType.VarChar, 20).Value = strRFID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.CompanyID = .Item("CompanyID")
                        voReturn.LocationID = .Item("LocationID")
                        voReturn.ID = .Item("ID")
                        voReturn.RFID = .Item("RFID")
                        voReturn.InitialCode = .Item("InitialCode")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    Else
                        voReturn.ID = ""
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function IsInActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstRFIDCard " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID AND IDStatus=@IDStatus " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#End Region

#Region "Status"

        Protected Friend Shared Function QuerySaveDataStatus() As String
            Dim strReturn =
                   "INSERT INTO QMS_mstRFIDCardStatus " & vbNewLine &
                   "    (ID, RFIDCardID, Status, StatusBy, StatusDate, Remarks)   " & vbNewLine &
                   "VALUES " & vbNewLine &
                   "    (@ID, @RFIDCardID, @Status, @StatusBy, @StatusDate, @Remarks)  " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function QueryDeleteDataStatus() As String
            Dim strReturn =
                    "DELETE FROM QMS_mstRFIDCardStatus " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   RFIDCardID=@RFIDCardID " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function ListDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strRFIDCardID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.Status, A.StatusBy, A.StatusDate, A.Remarks  " & vbNewLine &
                   "FROM QMS_mstRFIDCardStatus A " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.RFIDCardID=@RFIDCardID" & vbNewLine &
                   "ORDER BY A.ID ASC " & vbNewLine

                .Parameters.Add("@RFIDCardID", SqlDbType.VarChar, 20).Value = strRFIDCardID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.RFIDCardStatus)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QuerySaveDataStatus()
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@RFIDCardID", SqlDbType.VarChar, 20).Value = clsData.RFIDCardID
                .Parameters.Add("@Status", SqlDbType.VarChar, 100).Value = clsData.Status
                .Parameters.Add("@StatusBy", SqlDbType.VarChar, 20).Value = clsData.StatusBy
                .Parameters.Add("@StatusDate", SqlDbType.DateTime).Value = clsData.StatusDate
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxIDStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strRFIDCardID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=COUNT(ID) " & vbNewLine &
                        "FROM QMS_mstRFIDCardStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   RFIDCardID=@RFIDCardID " & vbNewLine

                    .Parameters.Add("@RFIDCardID", SqlDbType.VarChar, 20).Value = strRFIDCardID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Sub DeleteDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strRFIDCardID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryDeleteDataStatus()
                .Parameters.Add("@RFIDCardID", SqlDbType.VarChar, 20).Value = strRFIDCardID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

    End Class

End Namespace

