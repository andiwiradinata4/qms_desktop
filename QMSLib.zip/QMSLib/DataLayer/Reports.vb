﻿Namespace DL
    Friend Class Reports

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime, ByVal intIDStatus As VO.Status.Values) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ComLocDivSubDivID, A.ID, CASE WHEN A.IsArrange=0 THEN NULL ELSE A.QueueNumber END AS QueueNumber, A.TicketParkingID, A.QueueDate, A.PlatNumber, A.DriverID, MD.FullName AS DriverFullName, " & vbNewLine &
                   "    A.SPBNumber, A.RFID, A.QueueType, CASE A.QueueType WHEN 0 THEN '-' WHEN 1 THEN 'INCOMING' ELSE 'OUTGOING' END AS QueueTypeName, A.ComLocDivSubDivIDStorage, A.ProgramIDStorage, A.StorageGroupID, " & vbNewLine &
                   "    ISNULL(MS.StorageGroupName,'') AS StorageGroupName, A.StorageID, ISNULL(MS.StorageName,'') AS StorageName, " & vbNewLine &
                   "    A.QueueFlowID, A.ItemCode, ISNULL(VI.ItemName,'') AS ItemName, A.IsFreePass, A.WBNumber, A.WBProgramID, A.ContractNumber, " & vbNewLine &
                   "    A.IsRepeat, A.ReferencesID, A.IDStatus, B.Description AS StatusInfo, A.IsCompleted, A.CompletedBy, CASE WHEN A.IsCompleted=0 THEN NULL ELSE A.CompletedDate END AS CompletedDate,   " & vbNewLine &
                   "    A.IsDeleted, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc " & vbNewLine &
                   "FROM QMS_traQueue A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "    A.IDStatus=B.ID " & vbNewLine &
                   "INNER JOIN QMS_mstDriver MD ON " & vbNewLine &
                   "    A.DriverID=MD.ID " & vbNewLine &
                   "LEFT JOIN QMS_mstStorage MS ON " & vbNewLine &
                   "    A.ComLocDivSubDivIDStorage=MS.ComLocDivSubDivID " & vbNewLine &
                   "    AND A.ProgramIDStorage=MS.ProgramID" & vbNewLine &
                   "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                   "    AND A.StorageID=MS.StorageID " & vbNewLine &
                   "LEFT JOIN QMS_vwItem VI ON " & vbNewLine &
                   "    A.ItemCode=VI.ItemCode " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.ComLocDivSubDivID=@ComLocDivSubDivID" & vbNewLine &
                   "    AND A.QueueDate>=@DateFrom AND A.QueueDate<=@DateTo" & vbNewLine

                If intIDStatus <> VO.Status.Values.All Then
                    .CommandText +=
                        "    AND A.IDStatus=@IDStatus" & vbNewLine
                End If

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom.Date
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
                .Parameters.Add("@IDStatus", SqlDbType.Int).Value = intIDStatus
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

    End Class
End Namespace

