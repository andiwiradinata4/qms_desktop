Namespace DL
    Friend Class Status

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    CAST(0 AS BIT) AS Pick, A.ID, A.Description, A.Remarks, A.IsActive, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate,   " & vbNewLine &
                   "    A.LogInc  " & vbNewLine &
                   "FROM QMS_mstStatus A " & vbNewLine

            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataByModuleID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal bytModuleID As Byte, Optional ByVal bolHideNotActive As Boolean = True) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT DISTINCT " & vbNewLine &
                   "    A.ID, A.Description " & vbNewLine &
                   "FROM QMS_mstStatus A " & vbNewLine &
                   "INNER JOIN QMS_mstStatusDet B ON " & vbNewLine &
                   "    A.ID=B.IDStatus " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    B.ModuleID=@ModulID " & vbNewLine &
                   "    AND A.IsActive=@IsActive " & vbNewLine

                .Parameters.Add("@ModulID", SqlDbType.TinyInt).Value = bytModuleID
                .Parameters.Add("@IsActive", SqlDbType.Bit).Value = bolHideNotActive
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.Status)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_mstStatus " & vbNewLine &
                       "    (ID, Description, Remarks, IsActive, CreatedBy, LogBy)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@ID, @Description, @Remarks, @IsActive, @LogBy, @LogBy)  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_mstStatus SET " & vbNewLine &
                       "    Description=@Description, " & vbNewLine &
                       "    Remarks=@Remarks, " & vbNewLine &
                       "    IsActive=@IsActive, " & vbNewLine &
                       "    LogBy=@LogBy, " & vbNewLine &
                       "    LogDate=GETDATE(), " & vbNewLine &
                       "    LogInc=LogInc+1 " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@IsActive", SqlDbType.Bit).Value = clsData.IsActive
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal bytID As Byte) As VO.Status
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Status
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ID, A.Description, A.Remarks, A.IsActive, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate,   " & vbNewLine &
                       "    A.LogInc  " & vbNewLine &
                       "FROM QMS_mstStatus A " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.Int).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.Description = .Item("Description")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.IsActive = .Item("IsActive")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(MAX(ID),0) " & vbNewLine &
                        "FROM QMS_mstStatus " & vbNewLine

                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IsIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.Int).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDescriptionExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                             ByVal bytID As Byte, ByVal strDescription As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID<>@ID AND Description=@Description " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.Int).Value = bytID
                    .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = strDescription
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.Status)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_mstStatus SET " & vbNewLine &
                    "    IsActive=0, " & vbNewLine &
                    "    LogBy=@LogBy, " & vbNewLine &
                    "    LogDate=GETDATE(), " & vbNewLine &
                    "    LogInc=LogInc+1 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function IsActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   Description " & vbNewLine &
                        "FROM QMS_mstStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID AND IsActive=1 " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#Region "Post Data"

        Protected Friend Shared Function QueryOutstandingPosting() As String
            Dim strReturn As String =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.Description, A.Remarks, A.IsActive, A.CreatedBy, A.CreatedDate, A.LogBy,   " & vbNewLine &
                   "    A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_mstStatus A " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostData() As String
            Dim strReturn As String =
                    "IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstStatus WHERE ID=@ID) " & vbNewLine &
                    "BEGIN " & vbNewLine &
                    "   INSERT INTO QMS_mstStatus " & vbNewLine &
                    "   (ID, Description, Remarks, IsActive, CreatedBy, CreatedDate, LogBy, LogDate, LogInc)   " & vbNewLine &
                    "   VALUES " & vbNewLine &
                    "   (@ID, @Description, @Remarks, @IsActive, @CreatedBy, @CreatedDate, @LogBy, @LogDate, @LogInc)  " & vbNewLine &
                    "END " & vbNewLine &
                    "ELSE " & vbNewLine &
                    "BEGIN " & vbNewLine &
                    "   UPDATE QMS_mstStatus SET " & vbNewLine &
                    "       Description=@Description, " & vbNewLine &
                    "       Remarks=@Remarks, " & vbNewLine &
                    "       IsActive=@IsActive, " & vbNewLine &
                    "       CreatedBy=@CreatedBy, " & vbNewLine &
                    "       CreatedDate=@CreatedDate, " & vbNewLine &
                    "       LogBy=@LogBy, " & vbNewLine &
                    "       LogDate=@LogDate, " & vbNewLine &
                    "       LogInc=@LogInc " & vbNewLine &
                    "   WHERE " & vbNewLine &
                    "       ID=@ID " & vbNewLine &
                    "END " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocation() As DataTable
            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPosting)
        End Function

        Protected Friend Shared Sub PostDataRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal clsData As VO.Status)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryPostData()
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@IsActive", SqlDbType.Bit).Value = clsData.IsActive
                .Parameters.Add("@CreatedBy", SqlDbType.VarChar, 20).Value = clsData.CreatedBy
                .Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = clsData.CreatedDate
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@LogDate", SqlDbType.DateTime).Value = clsData.LogDate
                .Parameters.Add("@LogInc", SqlDbType.Int).Value = clsData.LogInc
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

    End Class

End Namespace

