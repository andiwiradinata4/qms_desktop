Namespace DL
    Friend Class Driver

#Region "Header"

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strIdentityCardNumber As String, ByVal strDrivingLicenseNumber As String, ByVal strFullName As String,
                                                  ByVal bolShowAllDriver As Boolean, ByVal bolHideInactive As Boolean, ByVal bolHideBlacklist As Boolean,
                                                  ByVal bolShowDuplicateOnly As Boolean) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolShowDuplicateOnly Then
                    .CommandText +=
"
--SELECT DUPLICATE IdentityCardNumber  
SELECT  
	COUNT(ID) Total, IdentityCardNumber  
INTO #T_DuplicateIdentityCardNumber  
FROM QMS_mstDriver  
GROUP BY IdentityCardNumber  
HAVING COUNT(ID)>1 
 
--SELECT DUPLICATE DrivingLicenseNumber  
SELECT  
	COUNT(ID) Total, DrivingLicenseNumber  
INTO #T_DuplicateDrivingLicenseNumber 
FROM QMS_mstDriver  
GROUP BY DrivingLicenseNumber 
HAVING COUNT(ID)>1 
"
                End If

                .CommandText +=
"
--GET ComLoc Info  
SELECT  
   CL.ComLocID, CL.CompanyID, VC.CompanyName, CL.LocationID, VL.LocationName  
INTO #T_ComLoc  
FROM QMS_vwComLoc CL  
INNER JOIN QMS_vwCompany VC ON  
   CL.CompanyID=VC.CompanyID  
INNER JOIN QMS_vwLocation VL ON  
   CL.LocationID=VL.LocationID  
 
SELECT   
	A.ID, A.IdentityCardNumber, A.DrivingLicenseNumber, A.FullName, A.PlaceOfBirth, A.DateOfBirth, A.GenderID, ISNULL(MG.Description,'') AS GenderName,     
	A.BloodTypeID, ISNULL(BT.Description,'') AS BloodTypeName, A.AddressOfIdentityCard, A.AddressOfDrivingLicense, A.ReligionID, ISNULL(MR.Description,'') AS ReligionName,  
	A.MaritalStatusID, ISNULL(MS.Description,'') AS MaritalStatusName, A.NationalityID, ISNULL(MN.Description,'') AS NationalityName,  
	A.OccupationsIDOfIdentityCard, ISNULL(MO1.Description,'') AS OccupationsNameOfIdentityCard, A.OccupationsOthersOfIdentityCard,  
	A.OccupationsIDOfDrivingLicense, ISNULL(MO2.Description,'') AS OccupationsNameOfDrivingLicense, A.OccupationsOthersOfDrivingLicense,  
	A.ValidThruOfIdentityCard, A.ValidThruOfDrivingLicense, A.DrivingLicenseTypeID, ISNULL(DLT.Description,'') AS DrivingLicenseTypeName, A.Height, A.IDStatus, B.Description AS StatusInfo,  
	A.CreatedFromComLocID, CS1.CompanyName + ' - ' + CS1.LocationName AS CreatedFromComLoc, A.LastUpdatedFromComLocID, CS2.CompanyName + ' - ' + CS2.LocationName AS LastUpdatedFromComLoc, A.ReferencesID, A.InternalRemarks, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc    
FROM QMS_mstDriver A   
INNER JOIN QMS_mstStatus B ON  
	A.IDStatus=B.ID  
INNER JOIN #T_ComLoc CS1 ON  
	A.CreatedFromComLocID=CS1.ComLocID  
INNER JOIN #T_ComLoc CS2 ON  
	A.LastUpdatedFromComLocID=CS2.ComLocID  
LEFT JOIN QMS_mstGender MG ON  
	A.GenderID=MG.ID  
LEFT JOIN QMS_mstBloodType BT ON  
	A.BloodTypeID=BT.ID  
LEFT JOIN QMS_mstReligion MR ON  
	A.ReligionID=MR.ID  
LEFT JOIN QMS_mstMaritalStatus MS ON  
	A.MaritalStatusID=MS.ID  
LEFT JOIN QMS_mstNationality MN ON  
	A.NationalityID=MN.ID  
LEFT JOIN QMS_mstOccupations MO1 ON  
	A.OccupationsIDOfIdentityCard=MO1.ID  
LEFT JOIN QMS_mstOccupations MO2 ON  
	A.OccupationsIDOfDrivingLicense=MO2.ID  
LEFT JOIN QMS_mstDrivingLicenseType DLT ON  
	A.DrivingLicenseTypeID=DLT.ID  
"

                If bolShowDuplicateOnly Then
                    .CommandText +=
"
LEFT JOIN #T_DuplicateIdentityCardNumber DI ON  
	A.IdentityCardNumber=DI.IdentityCardNumber  
LEFT JOIN #T_DuplicateDrivingLicenseNumber DD ON  
	A.DrivingLicenseNumber=DD.DrivingLicenseNumber 
"
                End If

                .CommandText += "WHERE 1=1" & vbNewLine

                If Not bolShowAllDriver Then
                    If strIdentityCardNumber.Trim <> "" Then
                        .CommandText += "   AND A.IdentityCardNumber LIKE '%" & strIdentityCardNumber & "'%" & vbNewLine
                    End If

                    If strDrivingLicenseNumber.Trim <> "" Then
                        .CommandText += "   AND A.DrivingLicenseNumber LIKE '%" & strDrivingLicenseNumber & "'%" & vbNewLine
                    End If

                    If strFullName.Trim <> "" Then
                        .CommandText += "   AND A.FullName LIKE '%" & strFullName & "%'" & vbNewLine
                    End If

                    If bolHideInactive Then
                        .CommandText += "   AND A.IDStatus<>@InactiveID" & vbNewLine
                    End If

                    If bolHideBlacklist Then
                        .CommandText += "   AND A.IDStatus<>@BlacklistID" & vbNewLine
                    End If

                    If bolShowDuplicateOnly Then
                        .CommandText += "   AND (ISNULL(DI.Total,0)>1 OR ISNULL(DD.Total,0)>1)  " & vbNewLine
                    End If
                End If

                .Parameters.Add("@InactiveID", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                .Parameters.Add("@BlacklistID", SqlDbType.TinyInt).Value = VO.Status.Values.Blacklist
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataForMerge(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
SELECT  
   CL.ComLocID, CL.CompanyID, VC.CompanyName, CL.LocationID, VL.LocationName  
INTO #T_ComLoc  
FROM QMS_vwComLoc CL  
INNER JOIN QMS_vwCompany VC ON  
   CL.CompanyID=VC.CompanyID  
INNER JOIN QMS_vwLocation VL ON  
   CL.LocationID=VL.LocationID  
 
SELECT   
	CAST(0 AS BIT) AS Mark, CAST(0 AS BIT) AS Pick, A.ID, A.IdentityCardNumber, A.DrivingLicenseNumber, A.FullName, A.PlaceOfBirth, A.DateOfBirth, A.GenderID, ISNULL(MG.Description,'') AS GenderName,     
	A.BloodTypeID, ISNULL(BT.Description,'') AS BloodTypeName, A.AddressOfIdentityCard, A.AddressOfDrivingLicense, A.ReligionID, ISNULL(MR.Description,'') AS ReligionName,  
	A.MaritalStatusID, ISNULL(MS.Description,'') AS MaritalStatusName, A.NationalityID, ISNULL(MN.Description,'') AS NationalityName,  
	A.OccupationsIDOfIdentityCard, ISNULL(MO1.Description,'') AS OccupationsNameOfIdentityCard, A.OccupationsOthersOfIdentityCard,  
	A.OccupationsIDOfDrivingLicense, ISNULL(MO2.Description,'') AS OccupationsNameOfDrivingLicense, A.OccupationsOthersOfDrivingLicense,  
	A.ValidThruOfIdentityCard, A.ValidThruOfDrivingLicense, A.DrivingLicenseTypeID, ISNULL(DLT.Description,'') AS DrivingLicenseTypeName, A.Height, A.IDStatus, B.Description AS StatusInfo,  
	A.CreatedFromComLocID, CS1.CompanyName + ' - ' + CS1.LocationName AS CreatedFromComLoc, A.LastUpdatedFromComLocID, CS2.CompanyName + ' - ' + CS2.LocationName AS LastUpdatedFromComLoc, A.ReferencesID, A.InternalRemarks, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc    
FROM QMS_mstDriver A   
INNER JOIN QMS_mstStatus B ON  
	A.IDStatus=B.ID  
INNER JOIN #T_ComLoc CS1 ON  
	A.CreatedFromComLocID=CS1.ComLocID  
INNER JOIN #T_ComLoc CS2 ON  
	A.LastUpdatedFromComLocID=CS2.ComLocID  
LEFT JOIN QMS_mstGender MG ON  
	A.GenderID=MG.ID  
LEFT JOIN QMS_mstBloodType BT ON  
	A.BloodTypeID=BT.ID  
LEFT JOIN QMS_mstReligion MR ON  
	A.ReligionID=MR.ID  
LEFT JOIN QMS_mstMaritalStatus MS ON  
	A.MaritalStatusID=MS.ID  
LEFT JOIN QMS_mstNationality MN ON  
	A.NationalityID=MN.ID  
LEFT JOIN QMS_mstOccupations MO1 ON  
	A.OccupationsIDOfIdentityCard=MO1.ID  
LEFT JOIN QMS_mstOccupations MO2 ON  
	A.OccupationsIDOfDrivingLicense=MO2.ID  
LEFT JOIN QMS_mstDrivingLicenseType DLT ON  
	A.DrivingLicenseTypeID=DLT.ID  
WHERE  
   A.IDStatus<>@InactiveID  
   AND A.IDStatus<>@BlacklistID  
"

                .Parameters.Add("@InactiveID", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                .Parameters.Add("@BlacklistID", SqlDbType.TinyInt).Value = VO.Status.Values.Blacklist
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.Driver)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
"
INSERT INTO QMS_mstDriver   
    (ID, IdentityCardNumber, DrivingLicenseNumber, FullName, PlaceOfBirth, DateOfBirth, GenderID,     
     BloodTypeID, AddressOfIdentityCard, AddressOfDrivingLicense, ReligionID, MaritalStatusID, NationalityID,     
     OccupationsIDOfIdentityCard, OccupationsOthersOfIdentityCard, OccupationsIDOfDrivingLicense, OccupationsOthersOfDrivingLicense, ValidThruOfIdentityCard, ValidThruOfDrivingLicense,     
     DrivingLicenseTypeID, Height, IDStatus, CreatedFromComLocID, LastUpdatedFromComLocID, InternalRemarks, Remarks, CreatedBy, LogBy)     
VALUES   
    (@ID, @IdentityCardNumber, @DrivingLicenseNumber, @FullName, @PlaceOfBirth, @DateOfBirth, @GenderID,     
     @BloodTypeID, @AddressOfIdentityCard, @AddressOfDrivingLicense, @ReligionID, @MaritalStatusID, @NationalityID,     
     @OccupationsIDOfIdentityCard, @OccupationsOthersOfIdentityCard, @OccupationsIDOfDrivingLicense, @OccupationsOthersOfDrivingLicense, @ValidThruOfIdentityCard, @ValidThruOfDrivingLicense,     
     @DrivingLicenseTypeID, @Height, @IDStatus, @CreatedFromComLocID, @CreatedFromComLocID, @InternalRemarks, @Remarks, @LogBy,@LogBy)   
"
                Else
                    .CommandText =
"
UPDATE QMS_mstDriver SET  
    IdentityCardNumber=@IdentityCardNumber,  
    DrivingLicenseNumber=@DrivingLicenseNumber,  
    FullName=@FullName,  
    PlaceOfBirth=@PlaceOfBirth,  
    DateOfBirth=@DateOfBirth,  
    GenderID=@GenderID,  
    BloodTypeID=@BloodTypeID,  
    AddressOfIdentityCard=@AddressOfIdentityCard,  
    AddressOfDrivingLicense=@AddressOfDrivingLicense,  
    ReligionID=@ReligionID,  
    MaritalStatusID=@MaritalStatusID,  
    NationalityID=@NationalityID,  
    OccupationsIDOfIdentityCard=@OccupationsIDOfIdentityCard,  
    OccupationsOthersOfIdentityCard=@OccupationsOthersOfIdentityCard,  
    OccupationsIDOfDrivingLicense=@OccupationsIDOfDrivingLicense,  
    OccupationsOthersOfDrivingLicense=@OccupationsOthersOfDrivingLicense,  
    ValidThruOfIdentityCard=@ValidThruOfIdentityCard,  
    ValidThruOfDrivingLicense=@ValidThruOfDrivingLicense,  
    DrivingLicenseTypeID=@DrivingLicenseTypeID,  
    Height=@Height,  
    IDStatus=@IDStatus,  
    LastUpdatedFromComLocID=@LastUpdatedFromComLocID,  
    InternalRemarks=@InternalRemarks,  
    Remarks=@Remarks,  
    LogBy=@LogBy,  
    LogDate=GETDATE(),  
    LogInc=LogInc+1  
WHERE  
    ID=@ID  
"
                End If

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IdentityCardNumber", SqlDbType.VarChar, 20).Value = clsData.IdentityCardNumber
                .Parameters.Add("@DrivingLicenseNumber", SqlDbType.VarChar, 20).Value = clsData.DrivingLicenseNumber
                .Parameters.Add("@FullName", SqlDbType.VarChar, 250).Value = clsData.FullName
                .Parameters.Add("@PlaceOfBirth", SqlDbType.VarChar, 20).Value = clsData.PlaceOfBirth
                .Parameters.Add("@DateOfBirth", SqlDbType.DateTime).Value = clsData.DateOfBirth
                .Parameters.Add("@GenderID", SqlDbType.TinyInt).Value = clsData.GenderID
                .Parameters.Add("@BloodTypeID", SqlDbType.TinyInt).Value = clsData.BloodTypeID
                .Parameters.Add("@AddressOfIdentityCard", SqlDbType.VarChar, 250).Value = clsData.AddressOfIdentityCard
                .Parameters.Add("@AddressOfDrivingLicense", SqlDbType.VarChar, 250).Value = clsData.AddressOfDrivingLicense
                .Parameters.Add("@ReligionID", SqlDbType.TinyInt).Value = clsData.ReligionID
                .Parameters.Add("@MaritalStatusID", SqlDbType.TinyInt).Value = clsData.MaritalStatusID
                .Parameters.Add("@NationalityID", SqlDbType.TinyInt).Value = clsData.NationalityID
                .Parameters.Add("@OccupationsIDOfIdentityCard", SqlDbType.TinyInt).Value = clsData.OccupationsIDOfIdentityCard
                .Parameters.Add("@OccupationsOthersOfIdentityCard", SqlDbType.VarChar, 50).Value = clsData.OccupationsOthersOfIdentityCard
                .Parameters.Add("@OccupationsIDOfDrivingLicense", SqlDbType.TinyInt).Value = clsData.OccupationsIDOfDrivingLicense
                .Parameters.Add("@OccupationsOthersOfDrivingLicense", SqlDbType.VarChar, 50).Value = clsData.OccupationsOthersOfDrivingLicense
                .Parameters.Add("@ValidThruOfIdentityCard", SqlDbType.DateTime).Value = clsData.ValidThruOfIdentityCard
                .Parameters.Add("@ValidThruOfDrivingLicense", SqlDbType.DateTime).Value = clsData.ValidThruOfDrivingLicense
                .Parameters.Add("@DrivingLicenseTypeID", SqlDbType.TinyInt).Value = clsData.DrivingLicenseTypeID
                .Parameters.Add("@Height", SqlDbType.Int).Value = clsData.Height
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@CreatedFromComLocID", SqlDbType.Int).Value = clsData.CreatedFromComLocID
                .Parameters.Add("@LastUpdatedFromComLocID", SqlDbType.Int).Value = clsData.LastUpdatedFromComLocID
                .Parameters.Add("@InternalRemarks", SqlDbType.VarChar, 250).Value = clsData.InternalRemarks
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strID As String) As VO.Driver
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Driver
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT  
   CL.ComLocID, CL.CompanyID, VC.CompanyName, CL.LocationID, VL.LocationName  
INTO #T_ComLoc  
FROM QMS_vwComLoc CL  
INNER JOIN QMS_vwCompany VC ON  
   CL.CompanyID=VC.CompanyID  
INNER JOIN QMS_vwLocation VL ON  
   CL.LocationID=VL.LocationID  
 
SELECT TOP 1  
    A.ID, A.IdentityCardNumber, A.DrivingLicenseNumber, A.FullName, A.PlaceOfBirth, A.DateOfBirth, A.GenderID,    
    A.BloodTypeID, A.AddressOfIdentityCard, A.AddressOfDrivingLicense, A.ReligionID, A.MaritalStatusID, A.NationalityID,    
    A.OccupationsIDOfIdentityCard, A.OccupationsOthersOfIdentityCard, A.OccupationsIDOfDrivingLicense, A.OccupationsOthersOfDrivingLicense, A.ValidThruOfIdentityCard, A.ValidThruOfDrivingLicense,    
    A.DrivingLicenseTypeID, A.Height, A.IDStatus, B.Description AS StatusInfo, A.CreatedFromComLocID, A.LastUpdatedFromComLocID, A.ReferencesID,    
    A.InternalRemarks, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc, CS1.CompanyName AS CreatedFromCompany, CS1.LocationName AS CreatedFromLocation,  
    CS2.CompanyName AS LastUpdatedFromCompany, CS2.LocationName AS LastUpdatedFromLocation  
FROM QMS_mstDriver A  
INNER JOIN QMS_mstStatus B ON  
	A.IDStatus=B.ID  
INNER JOIN #T_ComLoc CS1 ON  
	A.CreatedFromComLocID=CS1.ComLocID  
INNER JOIN #T_ComLoc CS2 ON  
	A.LastUpdatedFromComLocID=CS2.ComLocID  
WHERE  
    A.ID=@ID  
"
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.IdentityCardNumber = .Item("IdentityCardNumber")
                        voReturn.DrivingLicenseNumber = .Item("DrivingLicenseNumber")
                        voReturn.FullName = .Item("FullName")
                        voReturn.PlaceOfBirth = .Item("PlaceOfBirth")
                        voReturn.DateOfBirth = .Item("DateOfBirth")
                        voReturn.GenderID = .Item("GenderID")
                        voReturn.BloodTypeID = .Item("BloodTypeID")
                        voReturn.AddressOfIdentityCard = .Item("AddressOfIdentityCard")
                        voReturn.AddressOfDrivingLicense = .Item("AddressOfDrivingLicense")
                        voReturn.ReligionID = .Item("ReligionID")
                        voReturn.MaritalStatusID = .Item("MaritalStatusID")
                        voReturn.NationalityID = .Item("NationalityID")
                        voReturn.OccupationsIDOfIdentityCard = .Item("OccupationsIDOfIdentityCard")
                        voReturn.OccupationsOthersOfIdentityCard = .Item("OccupationsOthersOfIdentityCard")
                        voReturn.OccupationsIDOfDrivingLicense = .Item("OccupationsIDOfDrivingLicense")
                        voReturn.OccupationsOthersOfDrivingLicense = .Item("OccupationsOthersOfDrivingLicense")
                        voReturn.ValidThruOfIdentityCard = .Item("ValidThruOfIdentityCard")
                        voReturn.ValidThruOfDrivingLicense = .Item("ValidThruOfDrivingLicense")
                        voReturn.DrivingLicenseTypeID = .Item("DrivingLicenseTypeID")
                        voReturn.Height = .Item("Height")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.CreatedFromComLocID = .Item("CreatedFromComLocID")
                        voReturn.CreatedFromCompany = .Item("CreatedFromCompany")
                        voReturn.CreatedFromLocation = .Item("CreatedFromLocation")
                        voReturn.LastUpdatedFromComLocID = .Item("LastUpdatedFromComLocID")
                        voReturn.LastUpdatedFromCompany = .Item("LastUpdatedFromCompany")
                        voReturn.LastUpdatedFromLocation = .Item("LastUpdatedFromLocation")
                        voReturn.ReferencesID = .Item("ReferencesID")
                        voReturn.InternalRemarks = .Item("InternalRemarks")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.Driver)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
UPDATE QMS_mstDriver  
   SET IDStatus=@IDStatus,  
   LogBy=@LogBy,  
   LogDate=GETDATE(),  
   LogInc=LogInc+1,   
   ReferencesID=@ReferencesID,  
   Remarks=@Remarks,  
   InternalRemarks=@InternalRemarks   
WHERE  
   ID=@ID  
"
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                .Parameters.Add("@ReferencesID", SqlDbType.VarChar, 20).Value = clsData.ReferencesID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@InternalRemarks", SqlDbType.VarChar, 250).Value = clsData.InternalRemarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub BlacklistData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal clsData As VO.Driver)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
UPDATE QMS_mstDriver  
   SET IDStatus=@IDStatus,  
   InternalRemarks=@InternalRemarks,  
   LogBy=@LogBy,  
   LogDate=GETDATE(),  
   LogInc=LogInc+1   
WHERE  
   ID=@ID  
"
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@InternalRemarks", SqlDbType.VarChar, 250).Value = clsData.InternalRemarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Blacklist
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub RevertBlacklistData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal clsData As VO.Driver)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
UPDATE QMS_mstDriver  
   SET IDStatus=@IDStatus,  
   InternalRemarks=@InternalRemarks,  
   LogBy=@LogBy,  
   LogDate=GETDATE(),  
   LogInc=LogInc+1   
WHERE  
   ID=@ID  
"
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@InternalRemarks", SqlDbType.VarChar, 250).Value = clsData.InternalRemarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Active
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal intComLocID As Integer) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
	ID=ISNULL(RIGHT(ID,5),0)  
FROM QMS_mstDriver  
WHERE CreatedFromComLocID=@ComLocID  
ORDER BY ID DESC  
"
                    .Parameters.Add("@ComLocID", SqlDbType.Int).Value = intComLocID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IsIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   ID  
FROM QMS_mstDriver  
WHERE   
   ID=@ID  
"
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDriverExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strID As String, ByVal strIdentityCardNumber As String,
                                                        ByVal strAddressOfIdentityCard As String, ByVal dtmDateOfBirth As DateTime) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   ID  
FROM QMS_mstDriver  
WHERE   
   ID<>@ID  
   AND IdentityCardNumber=@IdentityCardNumber  
   AND AddressOfIdentityCard=@AddressOfIdentityCard  
   AND DateOfBirth=@DateOfBirth  
"
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    .Parameters.Add("@IdentityCardNumber", SqlDbType.VarChar, 20).Value = strIdentityCardNumber
                    .Parameters.Add("@AddressOfIdentityCard", SqlDbType.VarChar, 250).Value = strAddressOfIdentityCard
                    .Parameters.Add("@DateOfBirth", SqlDbType.DateTime).Value = dtmDateOfBirth
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsIdentityCardNumberExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                    ByVal strID As String, ByVal strIdentityCardNumber As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   ID  
FROM QMS_mstDriver  
WHERE   
   ID<>@ID  
   AND IdentityCardNumber=@IdentityCardNumber  
"
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    .Parameters.Add("@IdentityCardNumber", SqlDbType.VarChar, 20).Value = strIdentityCardNumber
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDrivingLicenseNumberExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                      ByVal strID As String, ByVal strDrivingLicenseNumber As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
	ID  
FROM QMS_mstDriver  
WHERE   
	ID<>@ID  
	AND DrivingLicenseNumber=@DrivingLicenseNumber  
"
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    .Parameters.Add("@DrivingLicenseNumber", SqlDbType.VarChar, 20).Value = strDrivingLicenseNumber
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsInActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
    ID  
FROM QMS_mstDriver  
WHERE   
    ID=@ID 
    AND IDStatus=@IDStatus  
"
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsBlacklist(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
    ID  
FROM QMS_mstDriver  
WHERE   
    ID=@ID 
    AND IDStatus=@IDStatus  
"

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.Blacklist
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#End Region

#Region "Image"

        Protected Friend Shared Function QuerySaveDataImage() As String
            Dim strReturn =
"
INSERT INTO QMS_mstDriverImage  
	(ID, DriverID, ImagePath, ImageTypeID)    
VALUES  
	(@ID, @DriverID, @ImagePath, @ImageTypeID)   
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryDeleteDataImage() As String
            Dim strReturn =
"
DELETE FROM QMS_mstDriverImage  
WHERE  
	DriverID=@DriverID  
"
            Return strReturn
        End Function

        Protected Friend Shared Function ListDataImage(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                       ByVal strDriverID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
SELECT  
	A.ID, A.DriverID, A.ImagePath, A.ImageTypeID, B.Description AS ImageTypeName  
FROM QMS_mstDriverImage A  
INNER JOIN QMS_mstImageType B ON  
	A.ImageTypeID=B.ID  
WHERE   
    A.DriverID=@DriverID
"
                .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = strDriverID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataImage(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal clsData As VO.DriverImage)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QuerySaveDataImage()
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = clsData.DriverID
                .Parameters.Add("@ImagePath", SqlDbType.VarChar, 250).Value = clsData.ImagePath
                .Parameters.Add("@ImageTypeID", SqlDbType.TinyInt).Value = clsData.ImageTypeID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataImage(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strDriverID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryDeleteDataImage()
                .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = strDriverID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxIDImage(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                       ByVal strDriverID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT  
	ID=COUNT(ID)  
FROM QMS_mstDriverImage  
WHERE DriverID=@DriverID  
"
                    .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = strDriverID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

#End Region

#Region "Status"

        Protected Friend Shared Function QuerySaveDataStatus() As String
            Dim strReturn =
"
INSERT INTO QMS_mstDriverStatus  
	(ID, DriverID, Status, StatusBy, StatusDate, Remarks)    
VALUES  
	(@ID, @DriverID, @Status, @StatusBy, @StatusDate, @Remarks)   
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryDeleteDataStatus() As String
            Dim strReturn =
"
DELETE FROM QMS_mstDriverStatus  
WHERE  
	DriverID=@DriverID  
"
            Return strReturn
        End Function

        Protected Friend Shared Function ListDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strDriverID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
SELECT  
	A.Status, A.StatusBy, A.StatusDate, A.Remarks   
FROM QMS_mstDriverStatus A  
WHERE   
	A.DriverID=@DriverID 
ORDER BY A.ID ASC  
"
                .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = strDriverID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.DriverStatus)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QuerySaveDataStatus()
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = clsData.DriverID
                .Parameters.Add("@Status", SqlDbType.VarChar, 100).Value = clsData.Status
                .Parameters.Add("@StatusBy", SqlDbType.VarChar, 20).Value = clsData.StatusBy
                .Parameters.Add("@StatusDate", SqlDbType.DateTime).Value = clsData.StatusDate
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxIDStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strDriverID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT  
	ID=COUNT(ID)  
FROM QMS_mstDriverStatus  
WHERE   
	DriverID=@DriverID  
"
                    .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = strDriverID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Sub DeleteDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strDriverID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryDeleteDataStatus()
                .Parameters.Add("@DriverID", SqlDbType.VarChar, 20).Value = strDriverID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

#Region "Post Data"

        Protected Friend Shared Function QueryOutstandingPosting() As String
            Dim strReturn =
"
SELECT  
   CL.ComLocID, CL.CompanyID, VC.CompanyName, CL.LocationID, VL.LocationName  
INTO #T_ComLoc  
FROM QMS_vwComLoc CL  
INNER JOIN QMS_vwCompany VC ON  
   CL.CompanyID=VC.CompanyID  
INNER JOIN QMS_vwLocation VL ON  
   CL.LocationID=VL.LocationID  
 
SELECT   
	A.ID, A.IdentityCardNumber, A.DrivingLicenseNumber, A.FullName, A.PlaceOfBirth, A.DateOfBirth, A.GenderID, ISNULL(MG.Description,'') AS GenderName,     
	A.BloodTypeID, ISNULL(BT.Description,'') AS BloodTypeName, A.AddressOfIdentityCard, A.AddressOfDrivingLicense, A.ReligionID, ISNULL(MR.Description,'') AS ReligionName,  
	A.MaritalStatusID, ISNULL(MS.Description,'') AS MaritalStatusName, A.NationalityID, ISNULL(MN.Description,'') AS NationalityName,  
	A.OccupationsIDOfIdentityCard, ISNULL(MO1.Description,'') AS OccupationsNameOfIdentityCard, A.OccupationsOthersOfIdentityCard,  
	A.OccupationsIDOfDrivingLicense, ISNULL(MO2.Description,'') AS OccupationsNameOfDrivingLicense, A.OccupationsOthersOfDrivingLicense,  
	A.ValidThruOfIdentityCard, A.ValidThruOfDrivingLicense, A.DrivingLicenseTypeID, ISNULL(DLT.Description,'') AS DrivingLicenseTypeName, A.Height, A.IDStatus, B.Description AS StatusInfo,  
	A.CreatedFromComLocID, CS1.CompanyName + ' - ' + CS1.LocationName AS CreatedFromComLoc, A.LastUpdatedFromComLocID, CS2.CompanyName + ' - ' + CS2.LocationName AS LastUpdatedFromComLoc, A.ReferencesID, A.InternalRemarks, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc    
FROM QMS_mstDriver A   
INNER JOIN QMS_mstStatus B ON  
	A.IDStatus=B.ID  
INNER JOIN #T_ComLoc CS1 ON  
	A.CreatedFromComLocID=CS1.ComLocID  
INNER JOIN #T_ComLoc CS2 ON  
	A.LastUpdatedFromComLocID=CS2.ComLocID  
LEFT JOIN QMS_mstGender MG ON  
	A.GenderID=MG.ID  
LEFT JOIN QMS_mstBloodType BT ON  
	A.BloodTypeID=BT.ID  
LEFT JOIN QMS_mstReligion MR ON  
	A.ReligionID=MR.ID  
LEFT JOIN QMS_mstMaritalStatus MS ON  
	A.MaritalStatusID=MS.ID  
LEFT JOIN QMS_mstNationality MN ON  
	A.NationalityID=MN.ID  
LEFT JOIN QMS_mstOccupations MO1 ON  
	A.OccupationsIDOfIdentityCard=MO1.ID  
LEFT JOIN QMS_mstOccupations MO2 ON  
	A.OccupationsIDOfDrivingLicense=MO2.ID  
LEFT JOIN QMS_mstDrivingLicenseType DLT ON  
	A.DrivingLicenseTypeID=DLT.ID  
WHERE  
    A.LogDate>=@SyncDate  
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostData() As String
            Dim strReturn =
"
IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstDriver WHERE ID=@ID)  
BEGIN  
   INSERT INTO QMS_mstDriver  
   (ID, IdentityCardNumber, DrivingLicenseNumber, FullName, PlaceOfBirth, DateOfBirth, GenderID,    
   BloodTypeID, AddressOfIdentityCard, AddressOfDrivingLicense, ReligionID, MaritalStatusID, NationalityID,    
   OccupationsIDOfIdentityCard, OccupationsOthersOfIdentityCard, OccupationsIDOfDrivingLicense, OccupationsOthersOfDrivingLicense, ValidThruOfIdentityCard, ValidThruOfDrivingLicense,    
   DrivingLicenseTypeID, Height, IDStatus, CreatedFromComLocID, LastUpdatedFromComLocID, ReferencesID, InternalRemarks, Remarks, CreatedBy, CreatedDate, LogBy, LogDate, LogInc)    
   VALUES  
   (@ID, @IdentityCardNumber, @DrivingLicenseNumber, @FullName, @PlaceOfBirth, @DateOfBirth, @GenderID,    
   @BloodTypeID, @AddressOfIdentityCard, @AddressOfDrivingLicense, @ReligionID, @MaritalStatusID, @NationalityID,    
   @OccupationsIDOfIdentityCard, @OccupationsOthersOfIdentityCard, @OccupationsIDOfDrivingLicense, @OccupationsOthersOfDrivingLicense, @ValidThruOfIdentityCard, @ValidThruOfDrivingLicense,    
   @DrivingLicenseTypeID, @Height, @IDStatus, @CreatedFromComLocID, @LastUpdatedFromComLocID, @ReferencesID, @InternalRemarks, @Remarks, @CreatedBy, @CreatedDate, @LogBy, @LogDate, @LogInc)   
END  
ELSE  
BEGIN  
   UPDATE QMS_mstDriver SET  
       IdentityCardNumber=@IdentityCardNumber,  
       DrivingLicenseNumber=@DrivingLicenseNumber,  
       FullName=@FullName,  
       PlaceOfBirth=@PlaceOfBirth,  
       DateOfBirth=@DateOfBirth,  
       GenderID=@GenderID,  
       BloodTypeID=@BloodTypeID,  
       AddressOfIdentityCard=@AddressOfIdentityCard,  
       AddressOfDrivingLicense=@AddressOfDrivingLicense,  
       ReligionID=@ReligionID,  
       MaritalStatusID=@MaritalStatusID,  
       NationalityID=@NationalityID,  
       OccupationsIDOfIdentityCard=@OccupationsIDOfIdentityCard,  
       OccupationsOthersOfIdentityCard=@OccupationsOthersOfIdentityCard,  
       OccupationsIDOfDrivingLicense=@OccupationsIDOfDrivingLicense,  
       OccupationsOthersOfDrivingLicense=@OccupationsOthersOfDrivingLicense,  
       ValidThruOfIdentityCard=@ValidThruOfIdentityCard,  
       ValidThruOfDrivingLicense=@ValidThruOfDrivingLicense,  
       DrivingLicenseTypeID=@DrivingLicenseTypeID,  
       Height=@Height,  
       IDStatus=@IDStatus,  
       LastUpdatedFromComLocID=@LastUpdatedFromComLocID,  
       ReferencesID=@ReferencesID,  
       InternalRemarks=@InternalRemarks,  
       Remarks=@Remarks,  
       CreatedBy=@CreatedBy,  
       CreatedDate=@CreatedDate,  
       LogBy=@LogBy,  
       LogDate=@LogDate,  
       LogInc=@LogInc  
   WHERE  
       ID=@ID  
END  
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryOutstandingPostingImage() As String
            Dim strReturn =
"
SELECT  
    A.ID, A.DriverID, A.ImagePath, A.ImageTypeID, B.Description AS ImageTypeName  
FROM QMS_mstDriverImage A  
INNER JOIN QMS_mstImageType B ON  
    A.ImageTypeID=B.ID  
INNER JOIN QMS_mstDriver C ON  
    A.DriverID=C.ID  
WHERE  
    C.LogDate>=@SyncDate  
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostDataImage() As String
            Dim strReturn =
"
IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstDriverImage WHERE ID=@ID)  
BEGIN  
   INSERT INTO QMS_mstDriverImage  
   (ID, DriverID, ImagePath, ImageTypeID)    
   VALUES  
   (@ID, @DriverID, @ImagePath, @ImageTypeID)   
END  
ELSE  
BEGIN  
   UPDATE QMS_mstDriverImage SET  
       DriverID=@DriverID,  
       ImagePath=@ImagePath,  
       ImageTypeID=@ImageTypeID  
   WHERE  
       ID=@ID  
END  
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryOutstandingPostingStatus() As String
            Dim strReturn =
"
SELECT  
    A.ID, A.DriverID, A.Status, A.StatusBy, A.StatusDate, A.Remarks 
FROM QMS_mstDriverStatus A  
INNER JOIN QMS_mstDriver C ON  
    A.DriverID=C.ID  
WHERE  
    C.LogDate>=@SyncDate  
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostDataStatus() As String
            Dim strReturn =
"
IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstDriverStatus WHERE ID=@ID)  
BEGIN  
   INSERT INTO QMS_mstDriverStatus  
   (ID, DriverID, Status, StatusBy, StatusDate, Remarks)    
   VALUES  
   (@ID, @DriverID, @Status, @StatusBy, @StatusDate, @Remarks)   
END  
ELSE  
BEGIN  
   UPDATE QMS_mstDriverStatus SET  
       DriverID=@DriverID,  
       Status=@Status,  
       StatusBy=@StatusBy,  
       StatusDate=@StatusDate,  
       Remarks=@Remarks  
   WHERE  
       ID=@ID  
END  
"
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                         ByVal dtmSyncDate As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryOutstandingPosting()
                .Parameters.Add("@SyncDate", SqlDbType.DateTime).Value = dtmSyncDate
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub PostDataRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal clsData As VO.Driver)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryPostData()
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@IdentityCardNumber", SqlDbType.VarChar, 20).Value = clsData.IdentityCardNumber
                .Parameters.Add("@DrivingLicenseNumber", SqlDbType.VarChar, 20).Value = clsData.DrivingLicenseNumber
                .Parameters.Add("@FullName", SqlDbType.VarChar, 250).Value = clsData.FullName
                .Parameters.Add("@PlaceOfBirth", SqlDbType.VarChar, 20).Value = clsData.PlaceOfBirth
                .Parameters.Add("@DateOfBirth", SqlDbType.DateTime).Value = clsData.DateOfBirth
                .Parameters.Add("@GenderID", SqlDbType.TinyInt).Value = clsData.GenderID
                .Parameters.Add("@BloodTypeID", SqlDbType.TinyInt).Value = clsData.BloodTypeID
                .Parameters.Add("@AddressOfIdentityCard", SqlDbType.VarChar, 250).Value = clsData.AddressOfIdentityCard
                .Parameters.Add("@AddressOfDrivingLicense", SqlDbType.VarChar, 250).Value = clsData.AddressOfDrivingLicense
                .Parameters.Add("@ReligionID", SqlDbType.TinyInt).Value = clsData.ReligionID
                .Parameters.Add("@MaritalStatusID", SqlDbType.TinyInt).Value = clsData.MaritalStatusID
                .Parameters.Add("@NationalityID", SqlDbType.TinyInt).Value = clsData.NationalityID
                .Parameters.Add("@OccupationsIDOfIdentityCard", SqlDbType.TinyInt).Value = clsData.OccupationsIDOfIdentityCard
                .Parameters.Add("@OccupationsOthersOfIdentityCard", SqlDbType.VarChar, 50).Value = clsData.OccupationsOthersOfIdentityCard
                .Parameters.Add("@OccupationsIDOfDrivingLicense", SqlDbType.TinyInt).Value = clsData.OccupationsIDOfDrivingLicense
                .Parameters.Add("@OccupationsOthersOfDrivingLicense", SqlDbType.VarChar, 50).Value = clsData.OccupationsOthersOfDrivingLicense
                .Parameters.Add("@ValidThruOfIdentityCard", SqlDbType.DateTime).Value = clsData.ValidThruOfIdentityCard
                .Parameters.Add("@ValidThruOfDrivingLicense", SqlDbType.DateTime).Value = clsData.ValidThruOfDrivingLicense
                .Parameters.Add("@DrivingLicenseTypeID", SqlDbType.TinyInt).Value = clsData.DrivingLicenseTypeID
                .Parameters.Add("@Height", SqlDbType.Int).Value = clsData.Height
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@CreatedFromComLocID", SqlDbType.Int).Value = clsData.CreatedFromComLocID
                .Parameters.Add("@LastUpdatedFromComLocID", SqlDbType.Int).Value = clsData.LastUpdatedFromComLocID
                .Parameters.Add("@ReferencesID", SqlDbType.VarChar, 20).Value = clsData.ReferencesID
                .Parameters.Add("@InternalRemarks", SqlDbType.VarChar, 250).Value = clsData.InternalRemarks
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@CreatedBy", SqlDbType.VarChar, 20).Value = clsData.CreatedBy
                .Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = clsData.CreatedDate
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@LogDate", SqlDbType.DateTime).Value = clsData.LogDate
                .Parameters.Add("@LogInc", SqlDbType.Int).Value = clsData.LogInc
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function OutstandingPostingRDCtoLocationImage(ByVal dtmSyncDate As DateTime) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate)
            }

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPostingImage, sqlParams)
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocationStatus(ByVal dtmSyncDate As DateTime) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate)
            }

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPostingStatus, sqlParams)
        End Function

        Protected Friend Shared Function OutstandingPostingLocationtoRDC(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                         ByVal dtmSyncDate As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryOutstandingPosting()
                .Parameters.Add("@SyncDate", SqlDbType.DateTime).Value = dtmSyncDate
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub PostDataLocationtoRDC(ByVal clsData As VO.Driver)
            'Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ID", SqlDbType.VarChar, 20, clsData.ID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@IdentityCardNumber", SqlDbType.VarChar, 20, clsData.IdentityCardNumber),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@DrivingLicenseNumber", SqlDbType.VarChar, 20, clsData.DrivingLicenseNumber),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@FullName", SqlDbType.VarChar, 250, clsData.FullName),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@PlaceOfBirth", SqlDbType.VarChar, 20, clsData.PlaceOfBirth),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@DateOfBirth", SqlDbType.DateTime, clsData.DateOfBirth),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@GenderID", SqlDbType.TinyInt, clsData.GenderID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@BloodTypeID", SqlDbType.TinyInt, clsData.BloodTypeID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@AddressOfIdentityCard", SqlDbType.VarChar, 250, clsData.AddressOfIdentityCard),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@AddressOfDrivingLicense", SqlDbType.VarChar, 250, clsData.AddressOfDrivingLicense),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ReligionID", SqlDbType.TinyInt, clsData.ReligionID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@MaritalStatusID", SqlDbType.TinyInt, clsData.MaritalStatusID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@NationalityID", SqlDbType.TinyInt, clsData.NationalityID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@OccupationsIDOfIdentityCard", SqlDbType.TinyInt, clsData.OccupationsIDOfIdentityCard),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@OccupationsOthersOfIdentityCard", SqlDbType.VarChar, 50, clsData.OccupationsOthersOfIdentityCard),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@OccupationsIDOfDrivingLicense", SqlDbType.TinyInt, clsData.OccupationsIDOfDrivingLicense),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@OccupationsOthersOfDrivingLicense", SqlDbType.VarChar, 50, clsData.OccupationsOthersOfDrivingLicense),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ValidThruOfIdentityCard", SqlDbType.DateTime, clsData.ValidThruOfIdentityCard),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ValidThruOfDrivingLicense", SqlDbType.DateTime, clsData.ValidThruOfDrivingLicense),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@DrivingLicenseTypeID", SqlDbType.TinyInt, clsData.DrivingLicenseTypeID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@Height", SqlDbType.Int, clsData.Height),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@IDStatus", SqlDbType.TinyInt, clsData.IDStatus),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@CreatedFromComLocID", SqlDbType.Int, clsData.CreatedFromComLocID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@LastUpdatedFromComLocID", SqlDbType.Int, clsData.LastUpdatedFromComLocID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ReferencesID", SqlDbType.VarChar, 20, clsData.ReferencesID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@InternalRemarks", SqlDbType.VarChar, 250, clsData.InternalRemarks),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@Remarks", SqlDbType.VarChar, 250, clsData.Remarks),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@CreatedBy", SqlDbType.VarChar, 20, clsData.CreatedBy),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@CreatedDate", SqlDbType.DateTime, clsData.CreatedDate),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@LogBy", SqlDbType.VarChar, 20, clsData.LogBy),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@LogDate", SqlDbType.DateTime, clsData.LogDate),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@LogInc", SqlDbType.Int, clsData.LogInc)
            }
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            MMRemotingService.ExecuteNonQuery(CommandType.Text, QueryPostData, sqlParams)
        End Sub

        Protected Friend Shared Function OutstandingPostingLocationtoRDCImage(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                              ByVal dtmSyncDate As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryOutstandingPostingImage()
                .Parameters.Add("@SyncDate", SqlDbType.DateTime).Value = dtmSyncDate
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub PostDataLocationtoRDCImage(ByVal clsData As VO.DriverImage)
            'Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ID", SqlDbType.VarChar, 20, clsData.ID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@DriverID", SqlDbType.VarChar, 20, clsData.DriverID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ImagePath", SqlDbType.VarChar, 250, clsData.ImagePath),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ImageTypeID", SqlDbType.TinyInt, clsData.ImageTypeID)
            }
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            MMRemotingService.ExecuteNonQuery(CommandType.Text, QueryPostDataImage, sqlParams)
        End Sub

        Protected Friend Shared Function OutstandingPostingLocationtoRDCStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                               ByVal dtmSyncDate As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryOutstandingPostingStatus()
                .Parameters.Add("@SyncDate", SqlDbType.DateTime).Value = dtmSyncDate
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub PostDataLocationtoRDCStatus(ByVal clsData As VO.DriverStatus)
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@ID", SqlDbType.VarChar, 20, clsData.ID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@DriverID", SqlDbType.VarChar, 20, clsData.DriverID),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@Status", SqlDbType.VarChar, 100, clsData.Status),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@StatusBy", SqlDbType.VarChar, 20, clsData.StatusBy),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@StatusDate", SqlDbType.DateTime, clsData.StatusDate),
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@Remarks", SqlDbType.VarChar, 250, clsData.Remarks)
            }

            '# Execute NonQuery
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            MMRemotingService.ExecuteNonQuery(CommandType.Text, QueryPostDataStatus, sqlParams)
        End Sub

#End Region

    End Class

End Namespace

