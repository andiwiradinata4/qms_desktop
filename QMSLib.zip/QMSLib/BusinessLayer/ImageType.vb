Namespace BL
    Friend Class ImageType

        Protected Friend Shared Function ListData(Optional ByVal bytIDStatus As Byte = 0) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ImageType.ListData(sqlCon, Nothing, bytIDStatus)
            End Using
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.ImageType) As String
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If bolNew Then
                        clsData.ID = DL.ImageType.GetMaxID(sqlCon, Nothing)
                        If DL.ImageType.IsIDExists(sqlCon, Nothing, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Save. ID already exist")
                        End If
                    End If

                    If DL.ImageType.IsDescriptionExists(sqlCon, Nothing, clsData.ID, clsData.Description) Then
                        Err.Raise(515, "", "Cannot Save. Description (" & clsData.Description & ") already exist")
                    End If

                    DL.ImageType.SaveData(sqlCon, Nothing, bolNew, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.ImageType.SaveData(sqlCon, Nothing, bolNew, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return clsData.Description
        End Function

        Protected Friend Shared Function GetDetail(ByVal bytID As Byte) As VO.ImageType
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ImageType.GetDetail(sqlCon, Nothing, bytID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.ImageType)
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If DL.ImageType.IsInActive(sqlCon, Nothing, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Delete. Data is Not Active")
                    End If

                    DL.ImageType.DeleteData(sqlCon, Nothing, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.ImageType.DeleteData(sqlCon, Nothing, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

    End Class

End Namespace

