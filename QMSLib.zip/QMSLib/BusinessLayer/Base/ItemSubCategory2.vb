﻿Namespace BL

    Friend Class ItemSubCategory2

        Protected Friend Shared Function ListData(Optional ByVal intSubCategory1 As Integer = -1, Optional ByVal intGroup As Integer = -1,
                                        Optional ByVal bolBCFacility As Boolean = False) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ItemSubCategory2.ListData(sqlCon, Nothing, intSubCategory1, , bolBCFacility)
            End Using
        End Function

    End Class

End Namespace