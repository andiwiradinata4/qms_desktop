﻿Namespace BL

    Friend Class Item

        Protected Friend Shared Function ListAllData(Optional ByVal bolShowAll As Boolean = False, _
                                           Optional ByVal strItemCode As String = "", _
                                           Optional ByVal strItemName As String = "", _
                                           Optional ByVal bolHideInactive As Boolean = False) As DataTable

            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Item.ListAllData(sqlCon, Nothing, bolShowAll, strItemCode, strItemName, bolHideInactive)
            End Using
        End Function

        Protected Friend Shared Function GetDetail(ByVal intItemID As Integer, Optional ByVal bolSAPLockPrice As Boolean = False) As VO.Item
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Item.GetDetail(sqlCon, Nothing, intItemID, bolSAPLockPrice)
            End Using
        End Function

        Protected Friend Shared Function IsInactiveItem(ByVal intItemID As Integer) As Boolean
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Item.IsInactiveItem(sqlCon, Nothing, intItemID)
            End Using
        End Function

    End Class

End Namespace