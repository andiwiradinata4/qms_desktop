Namespace BL
    Public Class UserServerLocation

        Public Shared Function GetDetail(ByVal intComLocDivSubDivID As Integer) As VO.UserServerLocation
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserServerLocation.GetDetail(sqlCon, Nothing, intComLocDivSubDivID)
            End Using
        End Function

    End Class

End Namespace

