﻿Namespace BL

    Friend Class ItemClass

        Protected Friend Shared Function ListData() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ItemClass.ListData(sqlCon, Nothing)
            End Using
        End Function

    End Class

End Namespace