Namespace BL
    Friend Class DrivingLicenseType

        Protected Friend Shared Function ListData(Optional ByVal bytIDStatus As Byte = VO.Status.Values.All) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.DrivingLicenseType.ListData(sqlCon, Nothing, bytIDStatus)
            End Using
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.DrivingLicenseType) As String
            BL.Server.ServerDefault()

            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If bolNew Then
                        clsData.ID = DL.DrivingLicenseType.GetMaxID(sqlCon, Nothing)
                        If DL.DrivingLicenseType.IsIDExists(sqlCon, Nothing, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Save. ID already exist")
                        End If
                    End If

                    If DL.DrivingLicenseType.IsDescriptionExists(sqlCon, Nothing, clsData.ID, clsData.Description) Then
                        Err.Raise(515, "", "Cannot Save. Description (" & clsData.Description & ") already exist")
                    End If

                    DL.DrivingLicenseType.SaveData(sqlCon, Nothing, bolNew, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.DrivingLicenseType.SaveData(sqlCon, Nothing, bolNew, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return clsData.Description
        End Function

        Protected Friend Shared Function GetDetail(ByVal bytID As Byte) As VO.DrivingLicenseType
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.DrivingLicenseType.GetDetail(sqlCon, Nothing, bytID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.DrivingLicenseType)
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If DL.DrivingLicenseType.IsInActive(sqlCon, Nothing, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Delete. Data is Not Active")
                    End If

                    DL.DrivingLicenseType.DeleteData(sqlCon, Nothing, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As New DataTable
                    dtDB = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.DrivingLicenseType.DeleteData(sqlCon, Nothing, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

    End Class

End Namespace

