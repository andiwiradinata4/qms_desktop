Imports Newtonsoft.Json
Imports System.Windows.Forms
Imports System.Reflection

Namespace BL

    Public Class Queue

#Region "Main"

        Protected Friend Const _
            cProcessEdit = "edit", cProcessVerify = "verify", cProcessCancelVerify = "cancel verify", cProcessConfirm = "confirm", cProcessQueueFlow = "queue flow",
            cProcessCancelConfirm = "cancel confirm", cProcessComplete = "complete", cProcessCancelComplete = "cancel complete", cProcessDelete = "delete",
            cProcessArrange = "arrange", cProcessOutstandingArrange = "outstanding arrange", cProcessChangeRepeat = "change repeat", cProcessChangeFreePass = "change free pass"

        Protected Friend Shared Function ListData(ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime, ByVal intIDStatus As VO.Status.Values) As DataTable
            dtmDateTo = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListData(sqlCon, Nothing, intComLocDivSubDivID, dtmDateFrom, dtmDateTo, intIDStatus)
            End Using
        End Function

        Public Shared Function ListDataByStatus(ByVal intIDStatus As VO.Status.Values) As DataTable
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataByStatus(sqlCon, Nothing, intIDStatus)
            End Using
        End Function

        Protected Friend Shared Function ListDataOnProgress(ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime,
                                                            ByVal bolIsFreePass As Boolean, ByVal bolIsRepeat As Boolean) As DataTable
            dtmDateTo = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataOnProgress(sqlCon, Nothing, intComLocDivSubDivID, dtmDateFrom, dtmDateTo, bolIsFreePass, bolIsRepeat)
            End Using
        End Function

        Protected Friend Shared Sub CheckingStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strProcess As String, ByVal strID As String)
            Dim clsDetail As VO.Queue = DL.Queue.GetDetail(sqlCon, sqlTrans, strID)
            If clsDetail.IsDeleted Then
                Err.Raise(515, "", "Cannot " & strProcess & ". Data already deleted")
            ElseIf clsDetail.IsHold Then
                Err.Raise(515, "", "Cannot " & strProcess & ". This data status is hold")
            End If

            If strProcess = cProcessEdit Or
                strProcess = cProcessVerify Then
                If clsDetail.IDStatus = VO.Status.Values.Verified Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data already verified")
                ElseIf clsDetail.IDStatus = VO.Status.Values.Confirm Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data already confirmed")
                ElseIf clsDetail.IDStatus = VO.Status.Values.Completed Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data already completed")
                End If

                'ElseIf strProcess = cProcessVerify Then
                '    If clsDetail.IDStatus = VO.Status.Values.Verified Then
                '        Err.Raise(515, "", "Cannot " & strProcess & ". Data already verified")
                '    ElseIf clsDetail.IDStatus = VO.Status.Values.Confirm Then
                '        Err.Raise(515, "", "Cannot " & strProcess & ". Data already confirmed")
                '    ElseIf clsDetail.IDStatus = VO.Status.Values.Completed Then
                '        Err.Raise(515, "", "Cannot " & strProcess & ". Data already completed")
                '    End If

            ElseIf strProcess = cProcessCancelVerify Or
                strProcess = cProcessConfirm Then
                If clsDetail.IDStatus = VO.Status.Values.Draft Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data not yet verified")
                ElseIf clsDetail.IDStatus = VO.Status.Values.Confirm Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data already confirm")
                ElseIf clsDetail.IDStatus = VO.Status.Values.Completed Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data already completed")
                End If

                'ElseIf strProcess = cProcessConfirm Then
                '    If clsDetail.IDStatus = VO.Status.Values.Draft Then
                '        Err.Raise(515, "", "Cannot " & strProcess & ". Data not yet verified")
                '    ElseIf clsDetail.IDStatus = VO.Status.Values.Confirm Then
                '        Err.Raise(515, "", "Cannot " & strProcess & ". Data already confirmed")
                '    ElseIf clsDetail.IDStatus = VO.Status.Values.Completed Then
                '        Err.Raise(515, "", "Cannot " & strProcess & ". Data already completed")
                '    End If

            ElseIf strProcess = cProcessCancelConfirm Then
                If clsDetail.IDStatus = VO.Status.Values.Draft _
                    Or clsDetail.IDStatus = VO.Status.Values.Verified Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data not yet confirmed")
                ElseIf clsDetail.IDStatus = VO.Status.Values.Completed Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data already completed")
                End If

            ElseIf strProcess = cProcessComplete Then
                If clsDetail.IDStatus = VO.Status.Values.Draft _
                    Or clsDetail.IDStatus = VO.Status.Values.Verified Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data not yet confirmed")
                ElseIf clsDetail.IDStatus = VO.Status.Values.Completed Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data already completed")
                ElseIf DL.Queue.GetMaxTotalOutstandingDone(sqlCon, sqlTrans, clsDetail.ID) > 0 Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Please processed all queue flow first")
                End If

            ElseIf strProcess = cProcessCancelComplete Then
                If clsDetail.IDStatus <> VO.Status.Values.Completed Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Data not yet completed")
                End If

            ElseIf strProcess = cProcessDelete Then
                If clsDetail.IDStatus <> VO.Status.Values.Draft Then
                    Err.Raise(515, "", "Cannot " & strProcess & ". Just draft status can process " & strProcess)
                End If

            ElseIf strProcess = cProcessArrange Then
                If clsDetail.IDStatus <> VO.Status.Values.Confirm Then
                    Err.Raise(515, "", "Cannot " & strProcess & " ID (" & clsDetail.ID & "). Because this status is not Confirm")
                End If

            ElseIf strProcess = cProcessOutstandingArrange Then
                If clsDetail.IDStatus <> VO.Status.Values.Confirm Then
                    Err.Raise(515, "", "Cannot set " & strProcess & " ID (" & clsDetail.ID & "). Because this status is not Confirm")
                End If

            ElseIf strProcess = cProcessChangeRepeat Or
                strProcess = cProcessChangeFreePass Then
                If clsDetail.IDStatus = VO.Status.Values.Completed Then
                    Err.Raise(515, "", "Cannot " & strProcess & " ID (" & clsDetail.ID & "). This data already completed")
                End If
            End If
        End Sub

        Private Shared Function GetNewID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                         ByVal dtmQueueDate As DateTime, ByVal intComLocDivSubDivID As Integer) As String
            Dim strNewID As String = Format(dtmQueueDate, "yyMMdd") & "-" & DL.CS.GetComLocInitialByComLocDiv(sqlCon, sqlTrans, intComLocDivSubDivID)
            strNewID = strNewID & "-" & Format(DL.Queue.GetMaxID(sqlCon, sqlTrans, strNewID), "000")

            If DL.Queue.DataExists(sqlCon, sqlTrans, strNewID) Then
                Err.Raise(515, "", "Cannot Save. ID already exist")
            End If
            Return strNewID
        End Function

        Private Shared Function GetNewTicketParkingID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal dtmQueueDate As DateTime) As String
            Dim strNewID As String = Format(DL.Queue.GetMaxTicketParkingID(sqlCon, sqlTrans, dtmQueueDate), "000")
            Dim strExistNewID As String = DL.Queue.TicketParkingIDExists(sqlCon, sqlTrans, strNewID, dtmQueueDate)
            If strExistNewID <> "" Then
                Err.Raise(515, "", "Cannot Save. Ticket parking ID " & strNewID & " already used in ID: " & strExistNewID)
            End If
            Return strNewID
        End Function

        Private Shared Function GetNewQueueNumber(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal dtmQueueDate As DateTime) As Integer
            Dim intNewID As Integer = DL.Queue.GetMaxQueueNumber(sqlCon, sqlTrans, dtmQueueDate)
            Dim strExistNewID As String = DL.Queue.QueueNumberExists(sqlCon, sqlTrans, intNewID, dtmQueueDate)
            If strExistNewID <> "" Then
                Err.Raise(515, "", "Cannot Save. Queue number " & intNewID & " already used in ID: " & strExistNewID)
            End If
            Return intNewID
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.Queue) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    If bolNew Then
                        '# Get new ID
                        clsData.ID = GetNewID(sqlCon, sqlTrans, clsData.QueueDate, clsData.ComLocDivSubDivID)

                        '# Get new TicketParkingID if zero
                        If clsData.TicketParkingID = "-" Then clsData.TicketParkingID = GetNewTicketParkingID(sqlCon, sqlTrans, clsData.QueueDate)

                        '# Get new QueueNumber if zero
                        'If clsData.QueueNumber = 0 Then clsData.QueueNumber = GetNewQueueNumber(clsData.QueueDate)
                    Else
                        CheckingStatus(sqlCon, sqlTrans, cProcessEdit, clsData.ID)
                    End If

                    DL.Queue.SaveData(sqlCon, sqlTrans, bolNew, clsData)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "DRAFT - " & IIf(bolNew, "NEW", "EDIT"), clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return clsData.ID
        End Function

        Protected Friend Shared Sub Verify(ByVal clsData As VO.Queue)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatus(sqlCon, sqlTrans, cProcessVerify, clsData.ID)

                    DL.Queue.Verified(sqlCon, sqlTrans, clsData)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessVerify.ToUpper(), clsData.LogBy, clsData.Remarks)

                    '# Auto Confirm
                    If VO.DefaultServer.IsAutoConfirm Then
                        Dim clsQueueFlow As VO.QueueFlow = DL.QueueFlow.GetDetailForQueue(sqlCon, sqlTrans, VO.DefaultValueAutoConfirm.QueueType, VO.DefaultValueAutoConfirm.ItemCode)

                        If clsQueueFlow.ID Is Nothing Then
                            Err.Raise(515, "", "Cannot auto confirm. Queue Flow ID is nothing")
                        Else
                            '# Get Queue Flow Station
                            Dim clsCS As VO.CS = DL.CS.GetComLocInfoByComLocDiv(sqlCon, sqlTrans, clsData.ComLocDivSubDivID)
                            Dim dtQueueFlow As DataTable = DL.QueueFlow.ListDataStationDefault(sqlCon, sqlTrans, clsQueueFlow.ID, clsCS.CompanyID, clsCS.LocationID, VO.DefaultValueAutoConfirm.ComLocDivSubDivIDStorage, VO.DefaultValueAutoConfirm.ProgramIDStorage, VO.DefaultValueAutoConfirm.StorageGroupID, VO.DefaultValueAutoConfirm.StorageID)
                            If dtQueueFlow.Rows.Count = 0 Then Err.Raise(515, "", "Cannot auto confirm. Queue flow station is nothing")
                            clsData.QueueType = VO.DefaultValueAutoConfirm.QueueType
                            clsData.ItemCode = VO.DefaultValueAutoConfirm.ItemCode
                            clsData.QueueFlowID = clsQueueFlow.ID
                            clsData.WBProgramID = ""
                            clsData.WBNumber = ""
                            clsData.ContractNumber = ""
                            clsData.ComLocDivSubDivIDStorage = VO.DefaultValueAutoConfirm.ComLocDivSubDivIDStorage
                            clsData.ProgramIDStorage = VO.DefaultValueAutoConfirm.ProgramIDStorage
                            clsData.StorageGroupID = VO.DefaultValueAutoConfirm.StorageGroupID
                            clsData.StorageGroupName = ""
                            clsData.StorageID = VO.DefaultValueAutoConfirm.StorageID
                            clsData.StorageName = ""
                            clsData.IsFreePass = False
                            clsData.IsRepeat = False
                            clsData.Remarks = ""

                            '# Confirm
                            DL.Queue.Confirm(sqlCon, sqlTrans, clsData)

                            '# Save Default Detail 
                            Dim clsItem As VO.QueueDet
                            For Each dr As DataRow In dtQueueFlow.Rows
                                Dim intMaxID As Integer = DL.Queue.GetMaxIDDetail(sqlCon, sqlTrans, clsData.ID)
                                clsItem = New VO.QueueDet With {
                                .ID = clsData.ID & "-" & Format(intMaxID, "000"),
                                .QueueID = clsData.ID,
                                .Idx = intMaxID,
                                .StationID = dr.Item("StationID"),
                                .SubStationID = dr.Item("SubStationID"),
                                .Remarks = "",
                                .LogBy = clsData.LogBy
                            }
                                DL.Queue.SaveDataDetail(sqlCon, sqlTrans, True, clsItem)
                            Next

                            '# Save data Status
                            BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessConfirm.ToUpper() & " (AUTO)", clsData.LogBy, clsData.Remarks)
                        End If
                    End If
                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Sub CancelVerify(ByVal clsData As VO.Queue)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    '# Cancel Confirm if IsAutoConfirm = True
                    If VO.DefaultServer.IsAutoConfirm Then
                        CheckingStatus(sqlCon, sqlTrans, cProcessCancelConfirm, clsData.ID)

                        DL.Queue.CancelConfirm(sqlCon, sqlTrans, clsData)

                        '# Delete default detail
                        DL.Queue.DeleteDataDetailQueueID(sqlCon, sqlTrans, clsData.ID)

                        '# Save data Status
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessCancelConfirm.ToUpper() & " (AUTO)", clsData.LogBy, clsData.Remarks)
                    End If

                    CheckingStatus(sqlCon, sqlTrans, cProcessCancelVerify, clsData.ID)

                    DL.Queue.CancelVerified(sqlCon, sqlTrans, clsData)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessCancelVerify.ToUpper(), clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Sub Confirm(ByVal clsData As VO.Queue, ByVal clsDataDet() As VO.QueueDet)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatus(sqlCon, sqlTrans, cProcessConfirm, clsData.ID)

                    '# Delete Previous Queue Flow
                    DL.Queue.DeleteDataDetailQueueID(sqlCon, sqlTrans, clsData.ID)

                    ''# Get new QueueNumber if zero
                    'Dim intQueueNumber As Integer = DL.Queue.GetQueueNumber(clsData.ID)
                    'If intQueueNumber = 0 Then clsData.QueueNumber = GetNewQueueNumber(clsData.QueueDate) Else clsData.QueueNumber = intQueueNumber

                    DL.Queue.Confirm(sqlCon, sqlTrans, clsData)

                    '# Save Default Detail
                    For Each clsItem As VO.QueueDet In clsDataDet
                        Dim intMaxID As Integer = DL.Queue.GetMaxIDDetail(sqlCon, sqlTrans, clsData.ID)
                        clsItem.ID = clsItem.QueueID & "-" & Format(intMaxID, "000")
                        clsItem.Idx = intMaxID
                        clsItem.Remarks = ""
                        DL.Queue.SaveDataDetail(sqlCon, sqlTrans, True, clsItem)
                    Next

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessConfirm.ToUpper(), clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Sub CancelConfirm(ByVal clsData As VO.Queue)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatus(sqlCon, sqlTrans, cProcessCancelConfirm, clsData.ID)

                    DL.Queue.CancelConfirm(sqlCon, sqlTrans, clsData)

                    '# Delete default detail
                    DL.Queue.DeleteDataDetailQueueID(sqlCon, sqlTrans, clsData.ID)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessCancelConfirm.ToUpper(), clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Function Complete(ByVal clsData As VO.Queue) As String
            Dim strReturn As String = ""
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatus(sqlCon, sqlTrans, cProcessComplete, clsData.ID)

                    DL.Queue.Complete(sqlCon, sqlTrans, clsData)

                    '# Save data Status [Complete]
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessComplete.ToUpper(), clsData.LogBy, clsData.Remarks)

                    '# Generate new Queue if IsRepeat is TRUE
                    If clsData.IsRepeat And DL.Queue.IsAlreadyGenerateQueue(sqlCon, sqlTrans, clsData.ID) = False Then
                        Dim clsDetail As VO.Queue = DL.Queue.GetDetail(sqlCon, sqlTrans, clsData.ID)
                        Dim clsNew As New VO.Queue() With
                        {
                            .ComLocDivSubDivID = clsDetail.ComLocDivSubDivID,
                            .QueueDate = Now,
                            .ID = GetNewID(sqlCon, sqlTrans, .QueueDate, .ComLocDivSubDivID),
                            .TicketParkingID = GetNewTicketParkingID(sqlCon, sqlTrans, .QueueDate),
                            .QueueNumber = 0,
                            .PlatNumber = clsDetail.PlatNumber,
                            .DriverID = clsDetail.DriverID,
                            .SPBNumber = clsDetail.SPBNumber,
                            .RFID = clsDetail.RFID,
                            .StorageID = clsDetail.StorageID,
                            .StorageName = clsDetail.StorageName,
                            .ReferencesID = clsDetail.ID,
                            .IsFreePass = clsDetail.IsFreePass,
                            .WBNumber = clsDetail.WBNumber,
                            .WBProgramID = clsDetail.WBProgramID,
                            .ContractNumber = clsDetail.ContractNumber,
                            .QueueType = clsDetail.QueueType,
                            .QueueFlowID = clsDetail.QueueFlowID,
                            .ItemCode = clsDetail.ItemCode,
                            .IsRepeat = clsDetail.IsRepeat,
                            .Remarks = "",
                            .LogBy = clsData.LogBy
                        }
                        DL.Queue.SaveData(sqlCon, sqlTrans, True, clsNew)

                        '# Save data Status [DRAFT]
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsNew.ID, "DRAFT - NEW", clsNew.LogBy, clsNew.Remarks)

                        '# Verify data
                        clsNew.IDStatus = VO.Status.Values.Verified
                        DL.Queue.Verified(sqlCon, sqlTrans, clsNew)

                        '# Save data Status [Verify]
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsNew.ID, cProcessVerify.ToUpper(), clsNew.LogBy, clsNew.Remarks)

                        '# Confirm data
                        clsNew.IDStatus = VO.Status.Values.Confirm
                        DL.Queue.Confirm(sqlCon, sqlTrans, clsNew)

                        '# Save previous Queue Flow
                        Dim dtQueueFlow As DataTable = DL.Queue.ListDataDetail(sqlCon, sqlTrans, clsData.ID)
                        Dim clsNewDetail As New VO.QueueDet
                        For Each drItem As DataRow In dtQueueFlow.Rows
                            Dim intMaxID As Integer = DL.Queue.GetMaxIDDetail(sqlCon, sqlTrans, clsNew.ID)
                            clsNewDetail = New VO.QueueDet With {
                                .ID = clsNew.ID & "-" & Format(intMaxID, "000"),
                                .Idx = intMaxID,
                                .QueueID = clsNew.ID,
                                .StationID = drItem.Item("StationID"),
                                .SubStationID = drItem.Item("SubStationID"),
                                .LogBy = clsData.LogBy,
                                .Remarks = ""
                            }
                            DL.Queue.SaveDataDetail(sqlCon, sqlTrans, True, clsNewDetail)
                        Next

                        '# Save data Status [Confirm]
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsNew.ID, cProcessConfirm.ToUpper(), clsNew.LogBy, clsNew.Remarks)

                        strReturn = clsNew.ID
                    End If

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return strReturn
        End Function

        Protected Friend Shared Sub CancelComplete(ByVal clsData As VO.Queue)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatus(sqlCon, sqlTrans, cProcessCancelComplete, clsData.ID)

                    DL.Queue.CancelComplete(sqlCon, sqlTrans, clsData)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessCancelComplete.ToUpper(), clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.Queue)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatus(sqlCon, sqlTrans, cProcessDelete, clsData.ID)

                    DL.Queue.DeleteData(sqlCon, sqlTrans, clsData)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessDelete.ToUpper(), clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Function GetDetail(ByVal strID As String) As VO.Queue
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.GetDetail(sqlCon, Nothing, strID)
            End Using
        End Function

        Protected Friend Shared Function ListDataArrange(ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime, ByVal bolIsArrange As Boolean) As DataTable
            dtmDateTo = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataArrange(sqlCon, Nothing, intComLocDivSubDivID, dtmDateFrom, dtmDateTo, bolIsArrange)
            End Using
        End Function

        Protected Friend Shared Function ArrangeData(ByVal clsDataOnProgress() As VO.Queue, ByVal clsDataOutStanding As List(Of VO.Queue)) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    '# Arrange Queue
                    For Each clsData As VO.Queue In clsDataOnProgress
                        CheckingStatus(sqlCon, sqlTrans, cProcessArrange, clsData.ID)

                        DL.Queue.Arrange(sqlCon, sqlTrans, clsData)

                        '# Save data Status
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessArrange.ToUpper, clsData.LogBy, clsData.Remarks)
                    Next

                    '# Set Outstanding Arrange Queue
                    For Each clsData As VO.Queue In clsDataOutStanding
                        CheckingStatus(sqlCon, sqlTrans, cProcessOutstandingArrange, clsData.ID)

                        DL.Queue.Arrange(sqlCon, sqlTrans, clsData)

                        '# Save data Status
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessOutstandingArrange.ToUpper, clsData.LogBy, clsData.Remarks)
                    Next

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

        Protected Friend Shared Function ChangeIsRepeat(ByVal clsDataAll() As VO.Queue) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    For Each clsData As VO.Queue In clsDataAll
                        CheckingStatus(sqlCon, sqlTrans, cProcessChangeRepeat, clsData.ID)
                        DL.Queue.ChangeIsRepeat(sqlCon, sqlTrans, clsData)

                        '# Save data Status
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessChangeRepeat.ToUpper(), clsData.LogBy, clsData.Remarks)
                    Next

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

        Protected Friend Shared Function ChangeIsFreePass(ByVal clsDataAll() As VO.Queue) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    For Each clsData As VO.Queue In clsDataAll
                        CheckingStatus(sqlCon, sqlTrans, cProcessChangeFreePass, clsData.ID)
                        DL.Queue.ChangeIsFreePass(sqlCon, sqlTrans, clsData)

                        If clsData.IsFreePass Then DL.Queue.UpdateMinusQueueNumber(sqlCon, sqlTrans, clsData)

                        '# Save data Status
                        BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, cProcessChangeFreePass.ToUpper(), clsData.LogBy, clsData.Remarks)
                    Next

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

        Protected Friend Shared Function ChangeRFID(ByVal clsData As VO.Queue) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    DL.Queue.ChangeRFID(sqlCon, sqlTrans, clsData.ID, clsData.RFID, clsData.NewRFID, clsData.LogBy)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "CHANGE RFID", clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return clsData.ID
        End Function

        Protected Friend Shared Function CompareRFID(ByVal intComLocDivSubDivID As Integer, ByVal strRFID As String, ByVal strInitialID As String,
                                                     ByVal clsGet As VO.LPRGet) As VO.QueueDet
            Dim voQueueDet As New VO.QueueDet
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    voQueueDet = DL.Queue.GetDetailFirstByInitialIDAndRFID(sqlCon, sqlTrans, intComLocDivSubDivID, strInitialID, strRFID)
                    If voQueueDet.ID Is Nothing Then
                        Err.Raise(515, "", "This RFID : " & strRFID & " is no longer available for Outstanding Queue on WBID " & strInitialID)
                    End If

                    If voQueueDet.PlatNumber.Trim = clsGet.PlatNo.Trim Then voQueueDet.IsSuccessCompareLPR = True
                    SaveDataLPRHistory(sqlCon, sqlTrans, voQueueDet.QueueID, clsGet)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return voQueueDet
        End Function

        Protected Friend Shared Function LPRReGet(ByVal strInitialID As String, Optional ByVal bolOtherOpsys As Boolean = False, Optional ByVal strReferencesID As String = "", Optional ByVal strPlatNumber As String = "") As VO.LPRGet
            If strInitialID Is Nothing Or strInitialID.Trim = "" Then
                Err.Raise(515, "", "Initial ID not allow blank. Please map your Computer Name with Initial ID in substation configuration")
            End If

            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            Dim WebClient As New Net.WebClient()
            Dim strGETValue As String = ""
            Dim clsGet As New VO.LPRGet
            Dim dtmRequestDate As DateTime, dtmResponseDate As DateTime
            Dim decDifferentInSecond As Decimal = 0

            dtmRequestDate = Now '# Request API
            strGETValue = WebClient.DownloadString(VO.DefaultServer.WebAPILPRReGet & strInitialID)
            clsGet = JsonConvert.DeserializeObject(Of VO.LPRGet)(strGETValue)
            dtmResponseDate = Now '# Response API
            decDifferentInSecond = DateDiff(DateInterval.Second, dtmRequestDate, dtmResponseDate)

            If Not bolOtherOpsys Then
                '# Save History Request LPR
                Dim strID As String = Guid.NewGuid.ToString.ToUpper
                clsGet.InternalID = strID
                Dim clsLPRHistory As New VO.LPRHistory
                With clsLPRHistory
                    .ID = strID
                    .RequestDate = dtmRequestDate
                    .ResponseDate = dtmResponseDate
                    .DifferentInSecond = decDifferentInSecond
                    .ResponseID = clsGet.Id
                    .WBID = clsGet.WbId
                    .GarduID = clsGet.GarduId
                    .Type = clsGet.Tipe
                    .PlatNumber = strPlatNumber
                    .PlatNumberResponse = clsGet.PlatNo
                    .CaptureDate = clsGet.CaptureDate
                    .Status = clsGet.Status
                    .Message = clsGet.Message
                    .ReferencesID = strReferencesID
                    .Remarks = ""
                End With

                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    DL.LPRHistory.SaveData(sqlCon, Nothing, clsLPRHistory)
                End Using
            End If
            Return clsGet
        End Function

        Public Shared Function LPRReGet(ByVal strInitialID As String, Optional ByVal strReferencesID As String = "", Optional ByVal strPlatNumber As String = "") As VO.LPRGet
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            Return BL.Queue.LPRReGet(strInitialID, True, strReferencesID, strPlatNumber)
        End Function

        Public Shared Function LPRGet(ByVal strInitialID As String) As VO.LPRGet
            If VO.DefaultServer.WebAPILPRGet Is Nothing Then BL.Server.InitDefaultValue()

            Dim WebClient As New Net.WebClient()
            Dim clsGet As VO.LPRGet

            Dim strGETValue As String = WebClient.DownloadString(VO.DefaultServer.WebAPILPRGet & strInitialID)
            clsGet = JsonConvert.DeserializeObject(Of VO.LPRGet)(strGETValue)
            Return clsGet
        End Function

        Public Shared Function QueueByRFID(ByVal strRFID As String) As VO.Queue
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.GetDetailOutstanding(sqlCon, Nothing, strRFID, VO.Queue.Filter.RFID)
            End Using
        End Function

        Public Shared Function QueueByPlatNumber(ByVal strPlatNumber As String) As VO.Queue
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.GetDetailOutstanding(sqlCon, Nothing, strPlatNumber, VO.Queue.Filter.PlatNumber)
            End Using
        End Function

        Public Shared Function ListDataOutstandingConfirm(ByVal strPlatNumber As String) As DataTable
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataOutstandingConfirm(sqlCon, Nothing, strPlatNumber)
            End Using
        End Function

        Protected Friend Shared Function GetDetailUnloadingConfirm(ByVal strQueueID As String, ByVal strID As String) As VO.Queue
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim clsData As New VO.Queue
                Dim clsQueueDetail As New VO.QueueDet
                clsData = DL.Queue.GetDetailUnloadingConfirm(sqlCon, Nothing, strQueueID, strID)
                clsQueueDetail = DL.Queue.GetLastQueueFlow(sqlCon, Nothing, strQueueID)
                If clsData.QueueDetail.Idx = clsQueueDetail.Idx Then
                    clsData.Position = "UNLOADING"
                ElseIf clsData.QueueDetail.Idx > clsQueueDetail.Idx Then
                    clsData.Position = ""
                ElseIf clsData.QueueDetail.Idx < clsQueueDetail.Idx Then
                    clsData.Position = "OUT"
                End If
                Return clsData
            End Using
        End Function

        Protected Friend Shared Function ConfirmUnloading(ByVal clsData As VO.Queue) As Boolean
            Dim bolReturn As Boolean = False, strAction As String = ""
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    If clsData.QueueDetail.IsRequested Then
                        CheckingStatusDetail(sqlCon, sqlTrans, VO.QueueDet.Action.Request, clsData.ID, clsData.QueueDetail.ID, clsData.QueueDetail, False)
                    ElseIf clsData.QueueDetail.IsDone Then
                        CheckingStatusDetail(sqlCon, sqlTrans, VO.QueueDet.Action.Done, clsData.ID, clsData.QueueDetail.ID, clsData.QueueDetail, False)
                    End If

                    Dim clsCurrent As VO.Queue = DL.Queue.GetDetail(sqlCon, sqlTrans, clsData.ID)

                    If clsData.QueueDetail.IsRequested Then
                        strAction = "QUEUE FLOW - REQUEST (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.RequestDetail(sqlCon, sqlTrans, clsData.QueueDetail)
                    ElseIf clsData.QueueDetail.IsDone Then
                        strAction = "QUEUE FLOW - DONE (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.DoneDetail(sqlCon, sqlTrans, clsData.QueueDetail)
                    End If

                    If clsCurrent.IsHold = True And clsData.IsHold = False Then
                        strAction += " | UNHOLD"
                        '# Set data Unhold
                        DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.ID, clsData.IsHold)
                    ElseIf clsCurrent.IsHold = False And clsData.IsHold = True Then
                        strAction += " | HOLD"
                        '# Set data hold
                        DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.ID, clsData.IsHold)
                    End If

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, strAction, clsData.QueueDetail.LogBy, clsData.QueueDetail.Remarks)

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

        Protected Friend Shared Function ConfirmUnloadingVer2(ByVal clsData As VO.Queue) As Boolean
            Dim bolReturn As Boolean = False, strAction As String = ""
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    If clsData.QueueDetail.IsRequested Then
                        CheckingStatusDetail(sqlCon, sqlTrans, VO.QueueDet.Action.Request, clsData.ID, clsData.QueueDetail.ID, clsData.QueueDetail, False)
                    ElseIf clsData.QueueDetail.IsDone Then
                        CheckingStatusDetail(sqlCon, sqlTrans, VO.QueueDet.Action.Done, clsData.ID, clsData.QueueDetail.ID, clsData.QueueDetail, False)
                    End If

                    Dim clsCurrent As VO.Queue = DL.Queue.GetDetail(sqlCon, sqlTrans, clsData.ID)
                    Dim voQueueDetStatus As New VO.QueueDetStatus
                    If clsData.QueueDetail.DetailAction = VO.QueueDetStatus.StatusAction.Start Then
                        strAction = "QUEUE FLOW - REQUEST (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.RequestDetail(sqlCon, sqlTrans, clsData.QueueDetail)

                        '# Set data Unhold
                        If clsData.IsHold Then DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.ID, False)

                    ElseIf clsData.QueueDetail.DetailAction = VO.QueueDetStatus.StatusAction.CancelStart Then
                        strAction = "QUEUE FLOW - CANCEL REQUEST (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.CancelRequestDetail(sqlCon, sqlTrans, clsData.QueueDetail)

                    ElseIf clsData.QueueDetail.DetailAction = VO.QueueDetStatus.StatusAction.Done Then
                        strAction = "QUEUE FLOW - DONE (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.DoneDetail(sqlCon, sqlTrans, clsData.QueueDetail)

                    ElseIf clsData.QueueDetail.DetailAction = VO.QueueDetStatus.StatusAction.CancelDone Then
                        strAction = "QUEUE FLOW - CANCEL DONE (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.CancelDoneDetail(sqlCon, sqlTrans, clsData.QueueDetail)

                    ElseIf clsData.QueueDetail.DetailAction = VO.QueueDetStatus.StatusAction.OnHold Then
                        strAction = "QUEUE FLOW - ONHOLD (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.DoneDetailWithOnHold(sqlCon, sqlTrans, clsData.QueueDetail)

                        '# Set data Onhold
                        DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.ID, True)
                    ElseIf clsData.QueueDetail.DetailAction = VO.QueueDetStatus.StatusAction.CancelOnHold Then
                        strAction = "QUEUE FLOW - CANCEL ONHOLD (" & clsData.QueueDetail.SubStationName & ")"
                        DL.Queue.CancelDoneDetail(sqlCon, sqlTrans, clsData.QueueDetail)

                        '# Set data cancel Onhold
                        DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.ID, False)
                    End If

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, strAction, clsData.QueueDetail.LogBy, clsData.QueueDetail.Remarks)

                    '# Save data detail Status
                    BL.Queue.SaveDataDetStatus(sqlCon, sqlTrans, clsData.QueueDetail.ID, clsData.QueueDetail.StationID, clsData.QueueDetail.SubStationID, voQueueDetStatus.StatusToString(clsData.QueueDetail.DetailAction), clsData.QueueDetail.LogBy, clsData.QueueDetail.Remarks)

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

#End Region

#Region "Detail"

        Protected Friend Shared Function ListDataDetail(ByVal strQueueID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataDetail(sqlCon, Nothing, strQueueID)
            End Using
        End Function

        Protected Friend Shared Function ListDataDetail(ByVal strQueueID As String, ByVal intStationID As Integer) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataDetail(sqlCon, Nothing, strQueueID, intStationID)
            End Using
        End Function

        Protected Friend Shared Function GetDetailDet(ByVal strID As String) As VO.QueueDet
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.GetDetailDet(sqlCon, Nothing, strID)
            End Using
        End Function

        Public Shared Function GetDetailQueueFlowOnProgressByInitialID(ByVal strInitialID As String, ByVal strQueueID As String) As VO.QueueDet
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.GetDetailQueueFlowOnProgressByInitialID(sqlCon, Nothing, strInitialID, strQueueID)
            End Using
        End Function

        Public Shared Function CheckingStatusDetail(ByVal bytAction As VO.QueueDet.Action, ByVal strQueueID As String, Optional ByVal strID As String = Nothing, Optional ByVal clsCurrent As VO.QueueDet = Nothing) As Dictionary(Of String, String)
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            Dim idReturn As New Dictionary(Of String, String) From {
                {"is_success", "True"},
                {"message", ""}
            }
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim strMessage As String = CheckingStatusDetail(sqlCon, Nothing, bytAction, strQueueID, strID, clsCurrent, True)
                If strMessage.Trim <> "" Then
                    idReturn.Item("is_success") = False
                    idReturn.Item("message") = strMessage
                End If
            End Using
            Return idReturn
        End Function

        Protected Friend Shared Function CheckingStatusDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                              ByVal bytAction As VO.QueueDet.Action, ByVal strQueueID As String,
                                                              ByVal strID As String, ByVal clsCurrent As VO.QueueDet,
                                                              ByVal bolOthersOpsys As Boolean) As String
            If Not DL.SQL.bolUseTrans Then BL.Server.ServerDefault()
            Dim clsDetail As New VO.QueueDet
            If strID IsNot Nothing Then clsDetail = DL.Queue.GetDetailDet(sqlCon, sqlTrans, strID)
            Dim clsData As VO.Queue = DL.Queue.GetDetail(sqlCon, sqlTrans, strQueueID)
            Dim intMaxIdx As Integer = DL.Queue.GetMaxIdxDetail(sqlCon, sqlTrans, strQueueID)
            Dim strMessage As String = ""

            If clsData.IsDeleted Then
                strMessage = "Cannot Processed. Data already deleted"
                If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                Return strMessage
            ElseIf clsData.IDStatus = VO.Status.Values.Draft Then
                strMessage = "Cannot Processed. Data not yet done"
                If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                Return strMessage
            ElseIf clsData.IDStatus = VO.Status.Values.Verified Then
                strMessage = "Cannot Processed. Data not yet confirmed"
                If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
            ElseIf clsData.IDStatus = VO.Status.Values.Completed Then
                strMessage = "Cannot Processed. Data already completed"
                If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                Return strMessage
            ElseIf _
                strID IsNot Nothing AndAlso (
                    clsData.IsHold And
                    (
                        (bytAction <> VO.QueueDet.Action.Add And
                         bytAction <> VO.QueueDet.Action.Edit And
                         bytAction <> VO.QueueDet.Action.Delete And
                         bytAction <> VO.QueueDet.Action.Up And
                         bytAction <> VO.QueueDet.Action.Down And
                         bytAction <> VO.QueueDet.Action.Reject) _
                     And
                        (DL.Queue.GetIsIgnoreOnHold(sqlCon, sqlTrans, strID) = False)
                     )
                ) Then
                strMessage = "Cannot Processed. This data status is hold"
                If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                Return strMessage
            End If

            Dim clsLastRequested As VO.QueueDet = DL.Queue.GetDetailLastRequested(sqlCon, sqlTrans, strQueueID)
            Dim clsLastDone As VO.QueueDet = DL.Queue.GetDetailLastDone(sqlCon, sqlTrans, strQueueID)
            If bytAction = VO.QueueDet.Action.Request Then
                If clsDetail.IsRequested Then
                    strMessage = "Cannot Processed. Data already requested"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.IsDone Then
                    strMessage = "Cannot Processed. Data already done"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.Idx <> clsLastDone.Idx + 1 Then
                    strMessage = "Cannot Processed. Please process data no " & clsLastDone.Idx + 1 & " first"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                End If
            ElseIf bytAction = VO.QueueDet.Action.CancelRequest Then
                If clsDetail.IsDone Then
                    strMessage = "Cannot Processed. Data already done"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.Idx <> clsLastRequested.Idx Then
                    strMessage = "Cannot Processed. Please cancel done / cancel request data no " & clsLastRequested.Idx & " first"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                End If
            ElseIf bytAction = VO.QueueDet.Action.Done Then
                If clsDetail.IsRequested = False Then
                    strMessage = "Cannot Processed. Please process request / start this data first"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.IsDone Then
                    strMessage = "Cannot Processed. Data already done"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                End If
            ElseIf bytAction = VO.QueueDet.Action.CancelDone Then
                If clsDetail.IsDone = False Then
                    strMessage = "Cannot Processed. Data not yet done"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.Idx <> clsLastRequested.Idx Then
                    strMessage = "Cannot Processed. Please cancel request data no " & clsLastRequested.Idx & " first"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.Idx <> clsLastDone.Idx Then
                    strMessage = "Cannot Processed. Please cancel done / cancel request data no " & clsLastDone.Idx & " first"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                End If
            ElseIf bytAction = VO.QueueDet.Action.Add And clsCurrent IsNot Nothing Then
                If clsLastDone.Idx >= clsCurrent.Idx Then
                    strMessage = "Cannot Processed. No must more than last done"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsLastRequested.Idx >= clsCurrent.Idx Then
                    strMessage = "Cannot Processed. No must more than last requested"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                End If
            ElseIf bytAction = VO.QueueDet.Action.Edit Or
                bytAction = VO.QueueDet.Action.Delete Or
                bytAction = VO.QueueDet.Action.Up Or
                bytAction = VO.QueueDet.Action.Down Then
                If clsDetail.IsDone Then
                    strMessage = "Cannot Processed. Data already done"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.IsRequested Then
                    strMessage = "Cannot Processed. Data already requested"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                End If

                If bytAction = VO.QueueDet.Action.Up Then
                    If clsDetail.Idx - 1 <= clsLastDone.Idx Then
                        strMessage = "Cannot move up. Previous data already done"
                        If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                        Return strMessage
                    ElseIf clsDetail.Idx - 1 <= clsLastRequested.Idx Then
                        strMessage = "Cannot move up. Previous data already requested"
                        If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                        Return strMessage
                    End If
                End If

                If bytAction = VO.QueueDet.Action.Down Then
                    If clsDetail.Idx >= intMaxIdx Then
                        strMessage = "Cannot move down. Data already on the last row"
                        If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                        Return strMessage
                    End If
                End If
            ElseIf bytAction = VO.QueueDet.Action.Reject Then
                If clsDetail.Idx < clsLastRequested.Idx Then
                    strMessage = "Cannot Processed. This flow has been passed"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                ElseIf clsDetail.Idx > clsLastDone.Idx + 1 Then
                    strMessage = "Cannot Processed. Please process data no " & clsLastDone.Idx + 1 & " first"
                    If Not bolOthersOpsys Then Err.Raise(515, "", strMessage)
                    Return strMessage
                End If
            End If
            Return strMessage
        End Function

        Public Shared Function HandleQueueFlow(ByVal action As VO.QueueDet.Action, ByVal clsData As VO.QueueDet) As Boolean
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            Return HandleQueueFlow(action, clsData, Nothing)
        End Function

        Public Shared Function HandleQueueFlow(ByVal action As VO.QueueDet.Action, ByVal strInitial As String, ByVal strWBProgramID As String, ByVal strWBNumber As String) As Boolean
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            BL.Server.ServerDefault()
            Dim clsData As New VO.QueueDet
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    clsData = DL.Queue.GetDetailQueueFlowOnProgressByInitialID(sqlCon, Nothing, action, strInitial, strWBProgramID, strWBNumber)
                End Using
            Catch ex As Exception
                Throw ex
            End Try
            Return HandleQueueFlow(action, clsData, Nothing)
        End Function

        Protected Friend Shared Function HandleQueueFlow(ByVal action As VO.QueueDet.Action, ByVal clsData As VO.QueueDet, Optional ByVal clsReference As VO.QueueDet = Nothing) As Boolean
            Dim bolReturn As Boolean = False
            Dim strAction As String = "", strRemarksStatus As String = ""
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    Dim strErrorMessage As String = CheckingStatusDetail(sqlCon, sqlTrans, action, clsData.QueueID, clsData.ID, clsData, False)
                    If strErrorMessage.Trim <> "" Then Return False

                    If action = VO.QueueDet.Action.Request Then
                        strAction = "QUEUE FLOW - REQUEST (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.Remarks
                        clsData.DetailAction = VO.QueueDetStatus.StatusAction.Request
                        DL.Queue.RequestDetail(sqlCon, sqlTrans, clsData)

                        '# Update Plat Number if Queue Detail difference with Acknowledge Plat Number
                        If clsData.PlatNumber.Trim <> clsData.PlatNumberAcknowledge.Trim And clsData.PlatNumberAcknowledge.Trim <> "" Then DL.Queue.UpdatePlatNumber(sqlCon, sqlTrans, clsData.QueueID, clsData.PlatNumberAcknowledge, clsData.LogBy)
                    ElseIf action = VO.QueueDet.Action.CancelRequest Then
                        strAction = "QUEUE FLOW - CANCEL REQUEST (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.InternalRemarks
                        clsData.DetailAction = VO.QueueDetStatus.StatusAction.CancelRequest
                        DL.Queue.CancelRequestDetail(sqlCon, sqlTrans, clsData)

                    ElseIf action = VO.QueueDet.Action.Done Then
                        strAction = "QUEUE FLOW - DONE (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.Remarks
                        clsData.DetailAction = VO.QueueDetStatus.StatusAction.Done
                        DL.Queue.DoneDetail(sqlCon, sqlTrans, clsData)

                    ElseIf action = VO.QueueDet.Action.CancelDone Then
                        strAction = "QUEUE FLOW - CANCEL DONE (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.InternalRemarks
                        clsData.DetailAction = VO.QueueDetStatus.StatusAction.CancelDone
                        DL.Queue.CancelDoneDetail(sqlCon, sqlTrans, clsData)

                    ElseIf action = VO.QueueDet.Action.Add Then
                        Dim intLastIdx As Integer = DL.Queue.GetMaxIdxDetail(sqlCon, sqlTrans, clsData.QueueID)
                        If clsData.Idx > intLastIdx + 1 Then
                            Err.Raise(515, "", "Cannot Processed. No must less than or be equal " & intLastIdx + 1)
                        End If

                        strAction = "QUEUE FLOW - ADD " & clsData.SubStationName
                        clsData.ID = clsData.QueueID & "-" & Format(DL.Queue.GetMaxIDDetail(sqlCon, sqlTrans, clsData.QueueID), "000")
                        strRemarksStatus = clsData.Remarks
                        DL.Queue.UpdatePlusIdxDetail(sqlCon, sqlTrans, clsData)
                        DL.Queue.SaveDataDetail(sqlCon, sqlTrans, True, clsData)

                    ElseIf action = VO.QueueDet.Action.Edit Then
                        strAction = "QUEUE FLOW - EDIT (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.Remarks
                        DL.Queue.SaveDataDetail(sqlCon, sqlTrans, False, clsData)

                    ElseIf action = VO.QueueDet.Action.Delete Then
                        strAction = "QUEUE FLOW - DELETE (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.InternalRemarks
                        DL.Queue.DeleteDataDetailByID(sqlCon, sqlTrans, clsData.ID)
                        DL.Queue.UpdateMinusIdxDetail(sqlCon, sqlTrans, clsData)

                    ElseIf action = VO.QueueDet.Action.Up Then
                        strAction = "QUEUE FLOW - UP (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.InternalRemarks
                        DL.Queue.MoveUpIdxDetail(sqlCon, sqlTrans, clsData.ID)
                        DL.Queue.MoveDownIdxDetail(sqlCon, sqlTrans, clsReference.ID)

                    ElseIf action = VO.QueueDet.Action.Down Then
                        strAction = "QUEUE FLOW - DOWN (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.InternalRemarks
                        DL.Queue.MoveDownIdxDetail(sqlCon, sqlTrans, clsData.ID)
                        DL.Queue.MoveUpIdxDetail(sqlCon, sqlTrans, clsReference.ID)

                    ElseIf action = VO.QueueDet.Action.Reject Then
                        strAction = "QUEUE FLOW - REJECT (" & clsData.SubStationName & ")"
                        strRemarksStatus = clsData.Remarks
                        clsData.DetailAction = VO.QueueDetStatus.StatusAction.Reject
                        DL.Queue.RejectDetail(sqlCon, sqlTrans, clsData)
                        DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.QueueID, False)
                    End If

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.QueueID, strAction, clsData.LogBy, strRemarksStatus)

                    '# Save data detail Status
                    If action = VO.QueueDet.Action.Request And
                    action = VO.QueueDet.Action.CancelRequest And
                    action = VO.QueueDet.Action.Done And
                    action = VO.QueueDet.Action.CancelDone Then
                        Dim voQueueDetStatus As New VO.QueueDetStatus
                        BL.Queue.SaveDataDetStatus(sqlCon, sqlTrans, clsData.ID, clsData.StationID, clsData.SubStationID, voQueueDetStatus.StatusToString(clsData.DetailAction), clsData.LogBy, clsData.Remarks)
                    End If

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

        Protected Friend Shared Function ListDataQueueUnloading(ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            dtmDateTo = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59)
            BL.Server.ServerDefault()
            Dim dtData As New DataTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                dtData = DL.Queue.ListDataQueueUnloading(sqlCon, Nothing, intComLocDivSubDivID, dtmDateFrom, dtmDateTo)
                For Each dr As DataRow In dtData.Rows
                    Dim clsQueueDetail As VO.QueueDet = DL.Queue.GetLastQueueFlow(sqlCon, Nothing, dr.Item("QueueID"))
                    dr.BeginEdit()
                    If dr.Item("Idx") = clsQueueDetail.Idx Then
                        dr.Item("Position") = "UNLOADING"
                    ElseIf dr.Item("Idx") > clsQueueDetail.Idx Then
                        dr.Item("Position") = ""
                    ElseIf dr.Item("Idx") < clsQueueDetail.Idx Then
                        dr.Item("Position") = "OUT"
                    End If
                    dr.EndEdit()
                Next
            End Using
            dtData.AcceptChanges()
            Return dtData
        End Function

        Protected Friend Shared Function ListDataQueueUnloadingV2(ByVal intComLocDivSubDivID As Integer, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            dtmDateTo = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59)
            BL.Server.ServerDefault()
            Dim dtData As New DataTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                dtData = DL.Queue.ListDataQueueUnloadingV2(sqlCon, Nothing, intComLocDivSubDivID, dtmDateFrom, dtmDateTo)
                For Each dr As DataRow In dtData.Rows
                    Dim clsQueueDetail As VO.QueueDet = DL.Queue.GetLastQueueFlow(sqlCon, Nothing, dr.Item("QueueID"))
                    dr.BeginEdit()
                    If dr.Item("Idx") = clsQueueDetail.Idx Then
                        dr.Item("Position") = "UNLOADING"
                    ElseIf dr.Item("Idx") > clsQueueDetail.Idx Then
                        dr.Item("Position") = ""
                    ElseIf dr.Item("Idx") < clsQueueDetail.Idx Then
                        dr.Item("Position") = "OUT"
                    End If
                    dr.EndEdit()
                Next
            End Using
            dtData.AcceptChanges()
            Return dtData
        End Function

        Protected Friend Shared Function GenerateNewUnloadingStation(ByVal clsData As VO.QueueDet) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatusDetail(sqlCon, sqlTrans, VO.QueueDet.Action.Add, clsData.QueueID, clsData.ID, clsData, False)

                    Dim intLastIdx As Integer = DL.Queue.GetMaxIdxDetail(sqlCon, sqlTrans, clsData.QueueID)
                    If clsData.Idx > intLastIdx + 1 Then
                        Err.Raise(515, "", "Cannot Processed. No must less than or be equal " & intLastIdx + 1)
                    End If

                    '# Generate New Unloading Station
                    Dim strAction As String = "QUEUE FLOW - ADD " & clsData.SubStationName
                    clsData.ID = clsData.QueueID & "-" & Format(DL.Queue.GetMaxIDDetail(sqlCon, sqlTrans, clsData.QueueID), "000")
                    Dim strRemarksStatus As String = clsData.Remarks
                    DL.Queue.UpdatePlusIdxDetail(sqlCon, sqlTrans, clsData)
                    DL.Queue.SaveDataDetail(sqlCon, sqlTrans, True, clsData)

                    '# Unhold Queue
                    DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.QueueID, False)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.QueueID, strAction, clsData.LogBy, strRemarksStatus)

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

        Protected Friend Shared Function GenerateResamplingStation(ByVal clsDataAll() As VO.QueueDet) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    For Each clsData As VO.QueueDet In clsDataAll
                        BL.Queue.GenerateResamplingStation(sqlCon, sqlTrans, clsData)
                    Next

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using

            Return bolReturn
        End Function

        Protected Friend Shared Function GenerateResamplingStation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                   ByVal clsData As VO.QueueDet) As Boolean
            Dim bolReturn As Boolean = False

            CheckingStatusDetail(sqlCon, sqlTrans, VO.QueueDet.Action.Add, clsData.QueueID, clsData.ID, clsData, False)

            Dim intLastIdx As Integer = DL.Queue.GetMaxIdxDetail(sqlCon, sqlTrans, clsData.QueueID)
            If clsData.Idx > intLastIdx + 1 Then
                Err.Raise(515, "", "Cannot Processed. No must less than or be equal " & intLastIdx + 1)
            End If

            '# Generate New Unloading Station
            Dim strAction As String = "QUEUE FLOW - ADD " & clsData.SubStationName
            clsData.ID = clsData.QueueID & "-" & Format(DL.Queue.GetMaxIDDetail(sqlCon, sqlTrans, clsData.QueueID), "000")
            Dim strRemarksStatus As String = clsData.Remarks
            DL.Queue.UpdatePlusIdxDetail(sqlCon, sqlTrans, clsData)
            DL.Queue.SaveDataDetail(sqlCon, sqlTrans, True, clsData)

            '# Unhold Queue
            DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.QueueID, False)

            '# Save data Status
            BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.QueueID, strAction, clsData.LogBy, strRemarksStatus)

            Return bolReturn
        End Function

        Protected Friend Shared Function RejectQueueDetail(ByVal clsData As VO.QueueDet) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    CheckingStatusDetail(sqlCon, sqlTrans, VO.QueueDet.Action.Add, clsData.QueueID, clsData.ID, clsData, False)

                    Dim intLastIdx As Integer = DL.Queue.GetMaxIdxDetail(sqlCon, sqlTrans, clsData.QueueID)
                    If clsData.Idx > intLastIdx + 1 Then
                        Err.Raise(515, "", "Cannot Processed. No must less than or be equal " & intLastIdx + 1)
                    End If

                    '# Generate New Unloading Station
                    Dim strAction As String = "QUEUE FLOW - ADD " & clsData.SubStationName
                    clsData.ID = clsData.QueueID & "-" & Format(DL.Queue.GetMaxIDDetail(sqlCon, sqlTrans, clsData.QueueID), "000")
                    Dim strRemarksStatus As String = clsData.Remarks
                    DL.Queue.UpdatePlusIdxDetail(sqlCon, sqlTrans, clsData)
                    DL.Queue.SaveDataDetail(sqlCon, sqlTrans, True, clsData)

                    '# Unhold Queue
                    DL.Queue.UpdateIsHold(sqlCon, sqlTrans, clsData.QueueID, False)

                    '# Save data Status
                    BL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData.QueueID, strAction, clsData.LogBy, strRemarksStatus)

                    sqlTrans.Commit()
                    bolReturn = True
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return bolReturn
        End Function

        Public Shared Function ListDataDetailByInitialID(ByVal strInitialID As String, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            If VO.DefaultServer.WebAPILPRReGet Is Nothing Then BL.Server.InitDefaultValue()
            dtmDateTo = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59)
            BL.Server.ServerDefault()
            Dim dtData As New DataTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                dtData = DL.Queue.ListDataQueueDetByInitialID(sqlCon, Nothing, strInitialID, dtmDateFrom, dtmDateTo)
                For i As Integer = 0 To dtData.Rows.Count - 1
                    Dim clsQueueDetail As VO.QueueDet = DL.Queue.GetLastQueueFlow(sqlCon, Nothing, dtData.Rows(i).Item("QueueID"))
                    If dtData.Rows(i).Item("Idx") > clsQueueDetail.Idx Then dtData.Rows(i).Delete()
                Next
                dtData.AcceptChanges()
            End Using
            Return dtData
        End Function

#End Region

#Region "Status"

        Protected Friend Shared Function ListDataStatus(ByVal strQueueID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataStatus(sqlCon, Nothing, strQueueID)
            End Using
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strQueueID As String, ByVal strStatus As String, ByVal strStatusBy As String,
                                                   ByVal strRemarks As String)
            Dim clsData As New VO.QueueStatus With {
                .ID = strQueueID & "-" & Format(DL.Queue.GetMaxIDStatus(sqlCon, sqlTrans, strQueueID), "000"),
                .QueueID = strQueueID,
                .Status = strStatus,
                .StatusBy = strStatusBy,
                .StatusDate = Now,
                .Remarks = strRemarks
            }
            DL.Queue.SaveDataStatus(sqlCon, sqlTrans, clsData)
        End Sub

#End Region

#Region "Detail Status"

        Protected Friend Shared Sub SaveDataDetStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strQueueDetID As String, ByVal intStationID As Integer, ByVal intSubStationID As Integer,
                                                      ByVal strStatus As String, ByVal strStatusBy As String, ByVal strRemarks As String)
            Dim clsData As New VO.QueueDetStatus With {
                .ID = strQueueDetID & "-" & Format(DL.Queue.GetMaxIDDetStatus(sqlCon, sqlTrans, strQueueDetID), "000"),
                .QueueDetID = strQueueDetID,
                .StationID = intStationID,
                .SubStationID = intSubStationID,
                .Status = strStatus,
                .StatusBy = strStatusBy,
                .StatusDate = Now,
                .Remarks = strRemarks
            }
            DL.Queue.SaveDataDetStatus(sqlCon, sqlTrans, clsData)
        End Sub

#End Region

#Region "LPR History"

        Protected Friend Shared Function ListDataLPRHistory(ByVal strQueueID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Queue.ListDataLPRHistory(sqlCon, Nothing, strQueueID)
            End Using
        End Function

        Protected Friend Shared Sub SaveDataLPRHistory(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                       ByVal strQueueID As String, ByVal clsLPRGet As VO.LPRGet)
            Dim clsData As New VO.QueueLPRHistory With {
                .ID = strQueueID & "-" & Format(DL.Queue.GetMaxIDLPRHistory(sqlCon, sqlTrans, strQueueID), "000"),
                .QueueID = strQueueID,
                .ReGetStatus = False, 'Not used again
                .ReGetMessage = "", 'Not used again
                .ReGetPayload = "", 'Not used again
                .GetID = clsLPRGet.Id,
                .WBID = clsLPRGet.WbId,
                .GarduID = clsLPRGet.GarduId,
                .Type = clsLPRGet.Tipe,
                .PlatNumber = clsLPRGet.PlatNo,
                .CaptureDate = clsLPRGet.CaptureDate,
                .GetStatus = clsLPRGet.Status,
                .GetMessage = clsLPRGet.Message
            }
            DL.Queue.SaveDataLPRHistory(sqlCon, sqlTrans, clsData)
        End Sub

#End Region

    End Class

End Namespace