Namespace BL
    Friend Class Driver

#Region "Header"

        Protected Friend Shared Function ListData(ByVal strIdentityCardNumber As String, ByVal strDrivingLicenseNumber As String, ByVal strFullName As String,
                                        ByVal bolShowAllDriver As Boolean, ByVal bolHideInactive As Boolean, ByVal bolHideBlacklist As Boolean,
                                        ByVal bolShowDuplicateOnly As Boolean) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Driver.ListData(sqlCon, Nothing,
                                          strIdentityCardNumber, strDrivingLicenseNumber, strFullName,
                                          bolShowAllDriver, bolHideInactive, bolHideBlacklist,
                                          bolShowDuplicateOnly)
            End Using
        End Function

        Protected Friend Shared Function ListDataForMerge() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Driver.ListDataForMerge(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.Driver, ByVal clsImageAll As List(Of VO.DriverImage)) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    Return SaveDataDefault(sqlCon, sqlTrans, bolNew, clsData, clsImageAll)
                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Function

        Protected Friend Shared Function SaveDataDefault(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal bolNew As Boolean, ByVal clsData As VO.Driver, ByVal clsImageAll As List(Of VO.DriverImage)) As String
            Try
                If bolNew Then
                    clsData.CreatedFromComLocID = DL.CS.GetComLocIDByComLocDiv(sqlCon, sqlTrans, clsData.ComLocDivSubDivID)
                    clsData.ID = DL.CS.GetComLocInitialByComLocDiv(sqlCon, sqlTrans, clsData.ComLocDivSubDivID) & "-" & Format(DL.Driver.GetMaxID(sqlCon, sqlTrans, clsData.CreatedFromComLocID), "00000")
                    If DL.Driver.IsIDExists(sqlCon, sqlTrans, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Save. ID already exist")
                    ElseIf clsData.ID.Trim = "" Then
                        Err.Raise(515, "", "Cannot Save. ID is blank")
                    End If
                Else
                    clsData.LastUpdatedFromComLocID = DL.CS.GetComLocIDByComLocDiv(sqlCon, sqlTrans, clsData.ComLocDivSubDivID)
                End If

                'If DL.Driver.IsDriverExists(clsData.ID, clsData.IdentityCardNumber, clsData.AddressOfIdentityCard, clsData.DateOfBirth) Then
                '    Err.Raise(515, "", "Cannot Save. Driver with Identity Card Number (" & clsData.IdentityCardNumber & "), Address Of Identity Card (" & clsData.AddressOfIdentityCard & ") and Date of Birth (" & Format(clsData.DateOfBirth, "dd MMMM yy") & ") already exist")
                'End If

                If clsData.IdentityCardNumber.Trim <> "" And DL.Driver.IsIdentityCardNumberExists(sqlCon, sqlTrans, clsData.ID, clsData.IdentityCardNumber) Then
                    Err.Raise(515, "", "Cannot Save. Driver with Identity Card Number (" & clsData.IdentityCardNumber & ") already exist")
                ElseIf clsData.DrivingLicenseNumber.Trim <> "" And DL.Driver.IsDrivingLicenseNumberExists(sqlCon, sqlTrans, clsData.ID, clsData.DrivingLicenseNumber) Then
                    Err.Raise(515, "", "Cannot Save. Driver with Driving License Number (" & clsData.DrivingLicenseNumber & ") already exist")
                End If

                If Not bolNew Then
                    DL.Driver.DeleteDataImage(sqlCon, sqlTrans, clsData.ID)
                End If

                DL.Driver.SaveData(sqlCon, sqlTrans, bolNew, clsData)

                '# Save data image
                For Each clsImage In clsImageAll
                    clsImage.DriverID = clsData.ID
                    clsImage.ID = clsData.ID & "-" & Format(DL.Driver.GetMaxIDImage(sqlCon, sqlTrans, clsData.ID), "000")
                    clsImage.ImagePath = SharedLib.DirectoryUtility.CopyFile(clsImage.ImagePath, VO.DefaultServer.DSPath, clsImage.ID)
                    DL.Driver.SaveDataImage(sqlCon, sqlTrans, clsImage)
                Next

                '#Save data Status
                BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, IIf(bolNew, "NEW", "EDIT"), clsData.LogBy, clsData.Remarks)

                sqlTrans.Commit()
            Catch ex As Exception
                sqlTrans.Rollback()
                Throw ex
            End Try
            Return clsData.ID
        End Function

        Protected Friend Shared Function MergeData(ByVal clsData As VO.Driver, ByVal clsDataAll() As VO.Driver) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    '# Checking field
                    If clsData.IdentityCardNumber.Trim = "" Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.IdentityCardNumber.Trim <> "" Then
                                clsData.IdentityCardNumber = clsItem.IdentityCardNumber.Trim
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.GenderID = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.GenderID <> 0 Then
                                clsData.GenderID = clsItem.GenderID
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.BloodTypeID = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.BloodTypeID <> 0 Then
                                clsData.BloodTypeID = clsItem.BloodTypeID
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.AddressOfIdentityCard.Trim = "" Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.AddressOfIdentityCard.Trim <> "" Then
                                clsData.AddressOfIdentityCard = clsItem.AddressOfIdentityCard.Trim
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.ReligionID = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.ReligionID <> 0 Then
                                clsData.ReligionID = clsItem.ReligionID
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.MaritalStatusID = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.MaritalStatusID <> 0 Then
                                clsData.MaritalStatusID = clsItem.MaritalStatusID
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.OccupationsIDOfIdentityCard = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.OccupationsIDOfIdentityCard <> 0 Then
                                clsData.OccupationsIDOfIdentityCard = clsItem.OccupationsIDOfIdentityCard
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.OccupationsOthersOfIdentityCard.Trim = "" Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.OccupationsOthersOfIdentityCard.Trim <> "" Then
                                clsData.OccupationsOthersOfIdentityCard = clsItem.OccupationsOthersOfIdentityCard.Trim
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.NationalityID = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.NationalityID <> 0 Then
                                clsData.NationalityID = clsItem.NationalityID
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.AddressOfDrivingLicense.Trim = "" Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.AddressOfDrivingLicense.Trim <> "" Then
                                clsData.AddressOfDrivingLicense = clsItem.AddressOfDrivingLicense.Trim
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.Height = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.Height <> 0 Then
                                clsData.Height = clsItem.Height
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.OccupationsIDOfDrivingLicense = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.OccupationsIDOfDrivingLicense <> 0 Then
                                clsData.OccupationsIDOfDrivingLicense = clsItem.OccupationsIDOfDrivingLicense
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.OccupationsOthersOfDrivingLicense.Trim = "" Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.OccupationsOthersOfDrivingLicense.Trim <> "" Then
                                clsData.OccupationsOthersOfDrivingLicense = clsItem.OccupationsOthersOfDrivingLicense.Trim
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.DrivingLicenseNumber.Trim = "" Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.DrivingLicenseNumber.Trim <> "" Then
                                clsData.DrivingLicenseNumber = clsItem.DrivingLicenseNumber.Trim
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.ValidThruOfDrivingLicense = "2000/01/01" Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.ValidThruOfDrivingLicense <> "2000/01/01" Then
                                clsData.ValidThruOfDrivingLicense = clsItem.ValidThruOfDrivingLicense
                                Exit For
                            End If
                        Next
                    End If

                    If clsData.DrivingLicenseTypeID = 0 Then
                        For Each clsItem As VO.Driver In clsDataAll
                            If clsItem.DrivingLicenseTypeID <> 0 Then
                                clsData.DrivingLicenseTypeID = clsItem.DrivingLicenseTypeID
                                Exit For
                            End If
                        Next
                    End If

                    DL.Driver.SaveData(sqlCon, sqlTrans, False, clsData)

                    '#Save data Status
                    BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "MERGE", clsData.LogBy, clsData.Remarks)

                    For Each clsItem As VO.Driver In clsDataAll
                        DL.Driver.DeleteData(sqlCon, sqlTrans, clsItem)

                        '#Save data Status
                        BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsItem.ID, "MERGE", clsItem.LogBy, "REFERENCES ID: " & clsData.ID)
                    Next

                    bolReturn = True
                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                End Try
                Return bolReturn
            End Using

        End Function

        Protected Friend Shared Function GetDetail(ByVal strID As String) As VO.Driver
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Driver.GetDetail(sqlCon, Nothing, strID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.Driver)
            Try
                BL.Server.ServerDefault()
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        If DL.Driver.IsInActive(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Delete. Data is not active")
                        ElseIf DL.Driver.IsBlacklist(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Delete. Data is blacklist")
                        End If

                        DL.Driver.DeleteData(sqlCon, sqlTrans, clsData)

                        '#Save data Status
                        BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "DELETE", clsData.LogBy, clsData.Remarks)

                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                        Throw ex
                    End Try
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As New DataTable
                    dtDB = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                            Try
                                DL.Driver.DeleteData(sqlCon, sqlTrans, clsData)

                                '#Save data Status
                                BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "DELETE", clsData.LogBy, clsData.Remarks)

                                sqlTrans.Commit()
                            Catch ex As Exception
                                sqlTrans.Rollback()
                                Throw ex
                            End Try
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub BlacklistData(ByVal clsData As VO.Driver)
            Try
                BL.Server.ServerDefault()
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        If DL.Driver.IsBlacklist(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Blacklist. Data is already blacklist")
                        ElseIf DL.Driver.IsInActive(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Blacklist. Data is not active")
                        End If

                        DL.Driver.BlacklistData(sqlCon, sqlTrans, clsData)

                        '#Save data Status
                        BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "BLACKLIST", clsData.LogBy, clsData.InternalRemarks)

                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                        Throw ex
                    End Try
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                            Try
                                DL.Driver.DeleteData(sqlCon, sqlTrans, clsData)

                                '#Save data Status
                                BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "BLACKLIST", clsData.LogBy, clsData.InternalRemarks)

                                sqlTrans.Commit()
                            Catch ex As Exception
                                sqlTrans.Rollback()
                                Throw ex
                            End Try
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub RevertBlacklistData(ByVal clsData As VO.Driver)
            Try
                BL.Server.ServerDefault()
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        If Not DL.Driver.IsBlacklist(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Revert Blacklist. Data is not blacklist")
                        ElseIf DL.Driver.IsInActive(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Revert Blacklist. Data is not active")
                        End If

                        DL.Driver.RevertBlacklistData(sqlCon, sqlTrans, clsData)

                        '#Save data Status
                        BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "REVERT BLACKLIST", clsData.LogBy, clsData.InternalRemarks)

                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                        Throw ex
                    End Try
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                            Try
                                DL.Driver.DeleteData(sqlCon, sqlTrans, clsData)

                                '#Save data Status
                                BL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "REVERT BLACKLIST", clsData.LogBy, clsData.InternalRemarks)

                                sqlTrans.Commit()
                            Catch ex As Exception
                                sqlTrans.Rollback()
                                Throw ex
                            End Try
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

#End Region

#Region "Image"

        Protected Friend Shared Function ListDataImage(ByVal strDriverID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Driver.ListDataImage(sqlCon, Nothing, strDriverID)
            End Using
        End Function

#End Region

#Region "Status"

        Protected Friend Shared Function ListDataStatus(ByVal strDriverID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Driver.ListDataStatus(sqlCon, Nothing, strDriverID)
            End Using
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strDriverID As String, ByVal strStatus As String,
                                                   ByVal strStatusBy As String,
                                                   ByVal strRemarks As String)
            Dim clsData As New VO.DriverStatus With {
                .ID = strDriverID & "-" & Format(DL.Driver.GetMaxIDStatus(sqlCon, sqlTrans, strDriverID), "000"),
                .DriverID = strDriverID,
                .Status = strStatus,
                .StatusBy = strStatusBy,
                .StatusDate = Now,
                .Remarks = strRemarks
            }
            DL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData)
        End Sub

#End Region

    End Class

End Namespace

