﻿Namespace BL
    Friend Class SyncTable

        Protected Friend Shared Sub SaveDataSyncDefault(ByVal ModuleID As VO.Modules.Values, ByVal strLogBy As String, ByVal dtmSyncDate As DateTime)
            '# Adding Sync Table
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                SaveDataSync(sqlCon, Nothing, ModuleID, strLogBy, dtmSyncDate)
            End Using
        End Sub

        Protected Friend Shared Sub SaveDataSync(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                 ByVal ModuleID As VO.Modules.Values, ByVal strLogBy As String, ByVal dtmSyncDate As DateTime)
            '# Adding Sync Table
            Dim clsSync As New VO.SyncTable With {
                .ID = DL.SyncTable.GetMaxID(sqlCon, sqlTrans),
                .ModuleID = ModuleID,
                .SyncDate = dtmSyncDate,
                .SyncBy = strLogBy
            }
            DL.SyncTable.SaveData(sqlCon, sqlTrans, True, clsSync)
        End Sub

    End Class
End Namespace