Namespace BL
    Friend Class Storage

#Region "Main"

        Protected Friend Shared Function ListData(ByVal strCompanyID As String, ByVal strLocationID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Storage.ListData(sqlCon, Nothing, strCompanyID, strLocationID)
            End Using
        End Function

        Protected Friend Shared Function GetDetail(ByVal intComLocDivSubDivID As Integer, ByVal strProgramID As String, ByVal strStorageGroupID As String, ByVal strStorageID As String) As VO.Storage
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Storage.GetDetail(sqlCon, Nothing, intComLocDivSubDivID, strProgramID, strStorageGroupID, strStorageID)
            End Using
        End Function

#End Region

#Region "Post Data"

        Protected Friend Shared Function ListDataMMRemoting(ByVal strCompanyID As String) As DataTable
            BL.Server.SetServer(strCompanyID)
            Return DL.Storage.ListDataMMRemoting
        End Function

        Protected Friend Shared Function ListDataMMRemoting(ByVal strCompanyID As String, ByVal strLocationID As String) As DataTable
            BL.Server.SetServer(strCompanyID)
            Return DL.Storage.ListDataMMRemoting(strCompanyID, strLocationID)
        End Function

#End Region

    End Class

End Namespace

