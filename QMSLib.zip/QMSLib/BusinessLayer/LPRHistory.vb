Namespace BL
    Public Class LPRHistory
        Public Shared Function ListData() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.LPRHistory.ListData(sqlCon, Nothing)
            End Using
        End Function

        Public Shared Function UpdateReferencesIDAndPlatNumber(ByVal strID As String, ByVal strReferencesID As String, ByVal strPlatNumber As String, ByVal strPlatNumberResponse As String) As Boolean
            BL.Server.ServerDefault()
            Dim bolReturn As Boolean
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    DL.LPRHistory.UpdateReferencesIDAndPlatNumber(sqlCon, Nothing, strID, strReferencesID, strPlatNumber, strPlatNumberResponse)
                End Using
                bolReturn = True
            Catch ex As Exception
                Throw ex
            End Try
            Return bolReturn
        End Function

        Public Shared Function UpdateReferencesID(ByVal strID As String, ByVal strReferencesID As String) As Boolean
            BL.Server.ServerDefault()
            Dim bolReturn As Boolean
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    DL.LPRHistory.UpdateReferencesID(sqlCon, Nothing, strID, strReferencesID)
                End Using

                bolReturn = True
            Catch ex As Exception
                Throw ex
            End Try
            Return bolReturn
        End Function

        Public Shared Function UpdateAcknowledgePlatNumberAndRemarks(ByVal strID As String, ByVal strAcknowledgePlatNumber As String, ByVal strRemarks As String) As Boolean
            BL.Server.ServerDefault()
            Dim bolReturn As Boolean
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    DL.LPRHistory.UpdateAcknowledgePlatNumberAndRemarks(sqlCon, Nothing, strID, strAcknowledgePlatNumber, strRemarks)
                End Using

                bolReturn = True
            Catch ex As Exception
                Throw ex
            End Try
            Return bolReturn
        End Function

        Public Shared Function UpdateRemarks(ByVal strID As String, ByVal strRemarks As String) As Boolean
            BL.Server.ServerDefault()
            Dim bolReturn As Boolean
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    DL.LPRHistory.UpdateRemarks(sqlCon, Nothing, strID, strRemarks)
                End Using

                bolReturn = True
            Catch ex As Exception
                Throw ex
            End Try
            Return bolReturn
        End Function

        Public Shared Function GetDetail(ByVal strID As String) As VO.LPRHistory
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.LPRHistory.GetDetail(sqlCon, Nothing, strID)
            End Using
        End Function

    End Class

End Namespace

