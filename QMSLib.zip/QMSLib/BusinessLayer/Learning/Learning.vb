﻿Namespace BL
    Friend Class Learning

        Protected Friend Shared Sub TrialInOutParamsStoredProcedure(intAssignParams As Integer)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                DL.Learning.TrialInOutParamsStoredProcedure(sqlCon, sqlTrans, intAssignParams)
                sqlTrans.Rollback()
            End Using
        End Sub

        Protected Friend Shared Function CheckTimeoutError() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Learning.CheckTimeoutError(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Function CheckReaderClosed() As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Learning.CheckReaderClosed(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Sub CheckErrorMessage()
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                DL.Learning.CheckErrorMessage(sqlCon, sqlTrans)
                sqlTrans.Rollback()
            End Using
        End Sub

    End Class
End Namespace
