﻿Namespace SharedLib
    Public Class Common
        Public Shared Function GetHostName() As String
            Dim ipAddress As String = ""
            Dim computerName As String = GetCompName()

            Dim host As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName())
            If (host.AddressList.Length > 0) Then
                Dim reg As New System.Text.RegularExpressions.Regex("\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b")
                For i As Integer = 0 To host.AddressList.Length - 1
                    If (reg.IsMatch(host.AddressList(i).ToString())) Then
                        ipAddress = host.AddressList(i).ToString()
                        Exit For
                    End If
                Next
            End If

            Return computerName + " - " + ipAddress

        End Function

        Public Shared Function GetCompName() As String
            Dim computerName As String = GetEnvironmentClientName()

            If (String.IsNullOrWhiteSpace(computerName)) Then
                computerName = GetDNSHostName()

            End If

            Return computerName.ToUpper()
        End Function

        Public Shared Function GetEnvironmentClientName() As String
            Dim computerName As String = ""

            Dim environmenVariables As IDictionary = System.Environment.GetEnvironmentVariables()
            If (environmenVariables.Contains("CLIENTNAME") And environmenVariables.Contains("USERDNSDOMAIN")) Then
                computerName =
                    environmenVariables("CLIENTNAME").ToString() + "." +
                    environmenVariables("USERDNSDOMAIN").ToString()

            End If

            Return computerName.ToUpper()

        End Function

        Public Shared Function GetDNSHostName() As String
            Dim computerName As String = ""

            Dim host As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName())
            computerName = host.HostName

            Return computerName.ToUpper()

        End Function
    End Class
End Namespace